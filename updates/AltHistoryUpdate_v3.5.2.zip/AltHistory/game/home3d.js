// «Судьба» — 3D-город. Один открытый мир без загрузок: площадь с фонтаном, кольцевая дорога с машинами,
// 4 многоэтажки (5 этажей × 4 квартиры, лестницы), 4 улицы по 14 частных домов, магазины, прохожие.
// Игроки с квартирой живут в одном подъезде (общая квартира — одна на всех, кто в ней живёт), с домом — на улицах частного сектора.
// Над дверьми игроков — таблички с именами, двери открываются сами. Любую мебель можно двигать.
// Управление: WASD — ходить, Пробел — прыжок, Ctrl/C — присесть, Shift — бег, ЛКМ зажать на предмете — тащить,
// отпустить с размахом — кинуть, R — повернуть мебель, ПКМ — камера, колесо — зум, Esc — на карту.
'use strict';
const H3 = { on: false, fpsCap: 0 };
(() => {
  let T, R, scene, cam, clock, raf = 0, ov, dyn = null, MAT = null, RC = null;
  const keys = {}, remotes = {}, props = [], PID = {}, doors = [], walkers = [], cars = [], jets = [];
  let me, yaw = Math.PI, pitch = 0.3, dist = 4.5, hint = '', drag = null, sendT = 0, propT = 0, fullT = 0, chk = 0, sig = '', homes = [], dirty = false;
  const mouse = { x: 0, y: 0 };
  const FH = 3.2, WH = 3.0, R0 = 0.33, WORLD = 330;
  const v3 = (x, y, z) => new T.Vector3(x, y, z);
  const uidMe = () => (typeof NET !== 'undefined' && NET.on() ? NET.uid : 'solo');
  const net = () => typeof NET !== 'undefined' && NET.on() && NET.A && NET.A.h3;

  // ---------- загрузка three.js ----------
  H3.load = () => new Promise((res, rej) => {
    if (window.THREE) return res(window.THREE);
    const sc = document.createElement('script'); sc.src = 'lib/three.min.js'; sc.onload = () => res(window.THREE); sc.onerror = () => rej(new Error('three.js не загрузился')); document.head.appendChild(sc);
  });
  H3.can = s => !!(s && s.home && s.home.type && !['parents', 'street', 'army'].includes(s.home.type) && E.age(s) >= 14);
  H3.walk = s => !!(s && E.age(s) >= 7);
  // ключ семьи: у живущих вместе он один и тот же — значит и квартира одна
  H3.hh = s => {
    if (!H3.can(s)) return '';
    const h = s.home, u = uidMe();
    if (h.hh) return h.hh;
    if (h.co && h.co.uid) return 'c:' + [u, h.co.uid].sort().join('+');
    if (h.shared) return 'h:' + h.shared;
    return 'h:' + u;
  };
  H3.info = s => {
    const k = H3.hh(s); if (!k) return null;
    const L0 = s.home.layout || {}, l = {};
    for (const i in L0) l[i] = L0[i].map(x => Math.round(x * 100) / 100);
    return { k, t: /house/.test(s.home.type) ? 'house' : 'flat', f: (s.home.furn || []).map(f => f.id), c: s.home.cls || 'mid', l };
  };

  // ---------- коллизии: сетка коробок ----------
  const GC = 4; let grid = new Map(), stamp = 1;
  const addSolid = b => { b.st = 0; for (let i = Math.floor(b.x0 / GC); i <= Math.floor(b.x1 / GC); i++) for (let j = Math.floor(b.z0 / GC); j <= Math.floor(b.z1 / GC); j++) { const k = i * 4096 + j; let a = grid.get(k); if (!a) grid.set(k, a = []); a.push(b); } return b; };
  const near = (x0, z0, x1, z1) => { stamp++; const out = []; for (let i = Math.floor(x0 / GC); i <= Math.floor(x1 / GC); i++) for (let j = Math.floor(z0 / GC); j <= Math.floor(z1 / GC); j++) { const a = grid.get(i * 4096 + j); if (!a) continue; for (const b of a) if (b.st !== stamp && !b.off) { b.st = stamp; out.push(b); } } return out; };
  const dropGroup = g => { for (const [k, a] of grid) { const n = a.filter(b => b.grp !== g); if (n.length !== a.length) grid.set(k, n); } };
  const heavyBoxes = (x, z, r) => { const out = []; for (const p of props) if (p.heavy) { const b = p.box; if (x + r > b.x0 - 1 && x - r < b.x1 + 1 && z + r > b.z0 - 1 && z - r < b.z1 + 1) out.push(b); } return out; };
  const boxesAt = (x, z, r, skip) => { const a = near(x - r - 0.1, z - r - 0.1, x + r + 0.1, z + r + 0.1); for (const b of heavyBoxes(x, z, r)) if (b !== skip) a.push(b); return a; };
  const groundAt = (x, z, y, r, skip) => { let gy = 0; for (const b of boxesAt(x, z, r, skip)) { if (b.wall || b.nocol) continue; if (x + r > b.x0 && x - r < b.x1 && z + r > b.z0 && z - r < b.z1 && b.y1 <= y + 0.5 && b.y1 > gy) gy = b.y1; } return gy; };
  const ceilAt = (x, z, y, r) => { let cy = 1e9; for (const b of boxesAt(x, z, r)) { if (b.nocol) continue; if (x + r > b.x0 && x - r < b.x1 && z + r > b.z0 && z - r < b.z1 && b.y0 >= y + 0.5 && b.y0 < cy) cy = b.y0; } return cy; };
  const push = (p, r, h, skip) => {
    for (const b of boxesAt(p.x, p.z, r, skip)) {
      if (b.nocol) continue;
      if (!(p.y < b.y1 - 0.02 && p.y + h > b.y0)) continue;
      if (!b.wall && b.y1 <= p.y + 0.5) continue; // можно залезть
      const cx = Math.max(b.x0, Math.min(p.x, b.x1)), cz = Math.max(b.z0, Math.min(p.z, b.z1));
      const dx = p.x - cx, dz = p.z - cz, d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        if (d2 < 1e-8) { const l = p.x - b.x0, rr = b.x1 - p.x, n = p.z - b.z0, f = b.z1 - p.z, m = Math.min(l, rr, n, f); if (m === l) p.x = b.x0 - r; else if (m === rr) p.x = b.x1 + r; else if (m === n) p.z = b.z0 - r; else p.z = b.z1 + r; }
        else { const d = Math.sqrt(d2); p.x = cx + dx / d * r; p.z = cz + dz / d * r; }
      }
    }
  };
  // камера не уходит за стены и перекрытия
  const camBlocked = (x, y, z) => { for (const b of near(x - 0.05, z - 0.05, x + 0.05, z + 0.05)) if (b.cam && x > b.x0 - 0.12 && x < b.x1 + 0.12 && z > b.z0 - 0.12 && z < b.z1 + 0.12 && y > b.y0 - 0.12 && y < b.y1 + 0.12) return true; return false; };

  // ---------- геометрия одним куском (быстро рисуется) ----------
  const CC = {};
  const col = c => CC[c] || (CC[c] = new T.Color(c));
  class Batch {
    constructor(grp) { this.p = []; this.n = []; this.c = []; this.grp = grp; }
    geo(g, color, m) {
      if (m) g.applyMatrix4(m); const ng = g.index ? g.toNonIndexed() : g;
      if (!ng.attributes.normal) ng.computeVertexNormals();
      const P = ng.attributes.position.array, N = ng.attributes.normal.array, many = Array.isArray(color);
      for (let i = 0; i < P.length / 3; i++) { this.p.push(P[i * 3], P[i * 3 + 1], P[i * 3 + 2]); this.n.push(N[i * 3], N[i * 3 + 1], N[i * 3 + 2]); const c = col(many ? color[Math.min(color.length - 1, Math.floor(i / 6))] : color); this.c.push(c.r, c.g, c.b); }
      if (ng !== g) ng.dispose(); g.dispose();
    }
    box(w, h, d, c, x, y, z, ry) { this.geo(new T.BoxGeometry(w, h, d), c, new T.Matrix4().makeRotationY(ry || 0).setPosition(x, y, z)); }
    cyl(rt, rb, h, c, x, y, z, seg, rx) { this.geo(new T.CylinderGeometry(rt, rb, h, seg || 10), c, new T.Matrix4().makeRotationX(rx || 0).setPosition(x, y, z)); }
    ball(r, c, x, y, z, seg) { this.geo(new T.SphereGeometry(r, seg || 8, Math.max(4, (seg || 8) - 2)), c, new T.Matrix4().setPosition(x, y, z)); }
    roof(w, h, d, c, x, y, z, ry) { // двускатная крыша: конёк вдоль X, основание w × d
      const a = w / 2, b = d / 2, V = [[-a, 0, -b], [-a, 0, b], [-a, h, 0], [a, 0, b], [a, 0, -b], [a, h, 0], [-a, 0, -b], [-a, h, 0], [a, h, 0], [-a, 0, -b], [a, h, 0], [a, 0, -b], [-a, 0, b], [a, 0, b], [a, h, 0], [-a, 0, b], [a, h, 0], [-a, h, 0]];
      const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(V.flat(), 3)); g.computeVertexNormals();
      this.geo(g, c, new T.Matrix4().makeRotationY(ry || 0).setPosition(x, y, z));
    }
    mesh() {
      const g = new T.BufferGeometry();
      g.setAttribute('position', new T.Float32BufferAttribute(this.p, 3)); g.setAttribute('normal', new T.Float32BufferAttribute(this.n, 3)); g.setAttribute('color', new T.Float32BufferAttribute(this.c, 3));
      g.computeBoundingSphere(); this.p = this.n = this.c = null;
      return new T.Mesh(g, MAT);
    }
  }
  // ---------- «локально → мир»: повороты на 90° и зеркало ----------
  const TF = (x, z, y, rot, mx) => ({ x, z, y: y || 0, rot: ((rot || 0) % 4 + 4) % 4, mx: !!mx });
  const tp = (t, lx, lz) => { if (t.mx) lx = -lx; let X = lx, Z = lz; for (let k = 0; k < t.rot; k++) { const nx = -Z, nz = X; X = nx; Z = nz; } return [t.x + X, t.z + Z]; };
  const tinv = (t, X, Z) => { let x = X - t.x, z = Z - t.z; for (let k = 0; k < t.rot; k++) { const nx = z, nz = -x; x = nx; z = nz; } if (t.mx) x = -x; return [x, z]; };
  const tdim = (t, w, d) => t.rot % 2 ? [d, w] : [w, d];
  const tyaw = (t, a) => (t.mx ? -a : a) - t.rot * Math.PI / 2;
  const tvec = (t, nx, nz) => { const a = tp(t, nx, nz), o = tp(t, 0, 0); return [a[0] - o[0], a[1] - o[1]]; };
  const tcat = (a, b) => { const [x, z] = tp(a, b.x, b.z); return TF(x, z, a.y + b.y, a.mx ? a.rot - b.rot : a.rot + b.rot, a.mx !== b.mx); };
  // коробка в локальных координатах. kind: wall — стена, slab — пол/перекрытие, solid — можно залезть, rail — перила, cam — только для камеры
  const SB = (B, t, w, h, d, c, lx, ly, lz, kind) => {
    const [x, z] = tp(t, lx, lz), [W, D] = tdim(t, w, d), y = t.y + ly;
    B.box(W, h, D, c, x, y, z);
    if (kind) addSolid({ x0: x - W / 2, x1: x + W / 2, z0: z - D / 2, z1: z + D / 2, y0: y - h / 2, y1: y + h / 2, wall: kind === 'wall' || kind === 'rail', cam: kind === 'wall' || kind === 'slab' || kind === 'cam', nocol: kind === 'cam', grp: B.grp });
  };
  // стена от (x1,z1) до (x2,z2) с дверными проёмами [центр, ширина]; o.skin — облицовка снаружи (o.side: с какой стороны, +1/−1)
  const WALL = (B, t, x1, z1, x2, z2, holes, c, o) => {
    o = o || {}; const th = 0.16, h = o.h || WH, dh = 2.2;
    const along = z1 === z2, a0 = Math.min(along ? x1 : z1, along ? x2 : z2), a1 = Math.max(along ? x1 : z1, along ? x2 : z2), fix = along ? z1 : x1;
    // стены заходят друг в друга на полтолщины, облицовка — ещё дальше: в углах и стыках нет щелей
    const e0 = o.e ? o.e[0] : th / 2 - 0.02, e1 = o.e ? o.e[1] : th / 2 - 0.02, k0 = o.se ? o.se[0] : th / 2 + 0.05, k1 = o.se ? o.se[1] : th / 2 + 0.05;
    const box = (s0, s1, yy0, yy1, kind) => { if (s1 - s0 < 0.01 || yy1 - yy0 < 0.01) return; const m = (s0 + s1) / 2, L = s1 - s0, hh = yy1 - yy0, yc = (yy0 + yy1) / 2; if (along) SB(B, t, L, hh, th, c, m, yc, fix, kind); else SB(B, t, th, hh, L, c, fix, yc, m, kind); };
    const skin = (s0, s1, yy0, yy1) => { if (!o.skin || s1 - s0 < 0.01) return; const m = (s0 + s1) / 2, L = s1 - s0, hh = yy1 - yy0, yc = (yy0 + yy1) / 2, f = fix + o.side * (th / 2 + 0.02); if (along) SB(B, t, L, hh, 0.04, o.skin, m, yc, f); else SB(B, t, 0.04, hh, L, o.skin, f, yc, m); };
    const hs = (holes || []).slice().sort((a, b) => a[0] - b[0]);
    let cur = a0;
    hs.forEach(([cx, w], i) => { const s0 = i === 0 ? cur - e0 : cur, sk0 = i === 0 ? cur - k0 : cur; const s = cx - w / 2; box(s0, s, 0, h, 'wall'); skin(sk0, s, 0, h); box(s, cx + w / 2, dh, h, 'cam'); skin(s, cx + w / 2, dh, h); cur = cx + w / 2; });
    box(hs.length ? cur : cur - e0, a1 + e1, 0, h, 'wall'); skin(hs.length ? cur : cur - k0, a1 + k1, 0, h);
  };
  // окно на стене (просто «наклейка» снаружи и изнутри)
  const WIN = (B, t, lx, ly, lz, nx, nz, w, h) => { const [W] = [w]; if (nx) { SB(B, t, 0.05, h, W, '#5d7f99', lx + nx * 0.13, ly, lz); SB(B, t, 0.03, h, W, '#bfe0f0', lx - nx * 0.1, ly, lz); } else { SB(B, t, W, h, 0.05, '#5d7f99', lx, ly, lz + nz * 0.13); SB(B, t, W, h, 0.03, '#bfe0f0', lx, ly, lz - nz * 0.1); } };
  const label = (t, w, h, bg, fg, font) => {
    const c = document.createElement('canvas'); c.width = Math.ceil(w * 128); c.height = Math.ceil(h * 128);
    const g = c.getContext('2d'); g.fillStyle = bg; g.fillRect(0, 0, c.width, c.height); g.fillStyle = fg; g.textAlign = 'center'; g.textBaseline = 'middle';
    let fs = Math.floor(c.height * 0.6); const f = n => `bold ${n}px ${font || 'Georgia, serif'}`; g.font = f(fs); while (g.measureText(t).width > c.width * 0.92 && fs > 8) g.font = f(--fs);
    g.fillText(t, c.width / 2, c.height / 2 + 1);
    const tx = new T.CanvasTexture(c); tx.anisotropy = 4;
    return new T.Mesh(new T.PlaneGeometry(w, h), new T.MeshBasicMaterial({ map: tx }));
  };
  // табличка на стене: (lx,lz) — точка на стене, (nx,nz) — куда смотрит (локально)
  const plaque = (parent, t, text, lx, ly, lz, nx, nz, w, h, bg, fg) => { const m = label(text, w, h, bg, fg, 'Arial'); const [x, z] = tp(t, lx + nx * 0.13, lz + nz * 0.13), [wx, wz] = tvec(t, nx, nz); m.position.set(x, t.y + ly, z); m.rotation.y = Math.atan2(wx, wz); parent.add(m); return m; };

  // ---------- двери (открываются сами) ----------
  const DOOR = (parent, t, lx, lz, along, w, o) => {
    o = o || {};
    const piv = new T.Group(), half = w / 2;
    const [hx, hz] = along === 'x' ? [lx - half, lz] : [lx, lz - half];
    const [px, pz] = tp(t, hx, hz); piv.position.set(px, t.y, pz);
    const [ux, uz] = tvec(t, along === 'x' ? 1 : 0, along === 'x' ? 0 : 1);
    const inner = new T.Group(); inner.rotation.y = Math.atan2(-uz, ux); piv.add(inner);
    const leaf = new T.Mesh(new T.BoxGeometry(w - 0.04, 2.15, 0.06), new T.MeshLambertMaterial({ color: o.color || '#6b4b33' })); leaf.position.set(w / 2, 1.08, 0); inner.add(leaf);
    const handle = new T.Mesh(new T.BoxGeometry(0.06, 0.06, 0.16), new T.MeshLambertMaterial({ color: '#d4b25a' })); handle.position.set(w - 0.15, 1.05, 0); inner.add(handle);
    parent.add(piv);
    const [cx, cz] = tp(t, lx, lz), [W, D] = tdim(t, along === 'x' ? w : 0.12, along === 'x' ? 0.12 : w);
    const box = addSolid({ x0: cx - W / 2, x1: cx + W / 2, z0: cz - D / 2, z1: cz + D / 2, y0: t.y, y1: t.y + 2.2, wall: true, cam: true, grp: o.grp || 'city' });
    const d = { x: cx, z: cz, y: t.y, piv, open: 0, locked: !!o.locked, kind: o.kind || 'flat', box, owners: '', mine: false };
    doors.push(d); return d;
  };

  // ---------- квартира/дом изнутри (18 × 14 м): перегородки, полы, мебель (вся двигается) ----------
  const ROOMS = { hall: [-9, 1, 1.2, 7], bed: [1, 9, 1.2, 7], kitchen: [-9, -2, -7, -1.2], bath: [-2, 2, -7, -1.2], wc: [2, 4.5, -7, -1.2], entry: [4.5, 9, -7, -1.2], cor: [-9, 9, -1.2, 1.2] };
  const interior = (B, t, sp, key, parent) => {
    const rich = sp.c === 'rich', poor = sp.c === 'poor', has = id => (sp.f || []).includes(id), wc = poor ? '#e8e2d6' : '#f1ede6';
    const fl = { hall: rich ? '#b48a5f' : poor ? '#a89a83' : '#c49a6c', bed: rich ? '#b48a5f' : '#c7a47a', kitchen: '#d8d4cc', bath: '#cfe0e6', wc: '#cfe0e6', entry: '#b9ab97', cor: '#c2a27b' };
    for (const k in ROOMS) { const [x0, x1, z0, z1] = ROOMS[k]; SB(B, t, x1 - x0, 0.02, z1 - z0, fl[k], (x0 + x1) / 2, 0.014, (z0 + z1) / 2); }
    WALL(B, t, -9, 1.2, 9, 1.2, [[-4, 2.2], [5, 1.2]], wc);
    WALL(B, t, -9, -1.2, 4.5, -1.2, [[-5.5, 1.4], [0, 1.1], [3.25, 0.95]], wc);
    WALL(B, t, 1, 1.2, 1, 7, [[4.2, 1.1]], wc);
    WALL(B, t, -2, -7, -2, -1.2, [], '#dfe9ec'); WALL(B, t, 2, -7, 2, -1.2, [], '#dfe9ec'); WALL(B, t, 4.5, -7, 4.5, -1.2, [], wc);
    if (has('curtain') || !poor) { SB(B, t, 1.0, 2.4, 0.06, '#7f9c88', -7.5, 1.6, 6.84); SB(B, t, 1.0, 2.4, 0.06, '#7f9c88', -5.0, 1.6, 6.84); }
    if (has('carpet') || rich) SB(B, t, 3.2, 0.015, 3.4, '#9c3d3d', -4.6, 0.03, 4.4);
    if (has('art')) SB(B, t, 0.04, 0.8, 1.2, '#c48a3a', -8.88, 1.9, 2.4);
    if (has('ac')) SB(B, t, 0.9, 0.3, 0.25, '#f7f7f7', -6, 2.55, 6.85);
    SB(B, t, 5.6, 0.7, 0.35, '#e9e5de', -6.0, 2.1, -6.8); SB(B, t, 0.03, 0.7, 0.5, '#d8eef5', 1.9, 1.5, -4.0); SB(B, t, 0.04, 1.4, 0.7, '#d8eef5', 8.88, 1.4, -4.5);
    for (const [x, z] of [[-4, 4], [5, 4], [-5.5, -4], [0, -4], [3.25, -4], [6.8, -4], [0, 0]]) { const [X, Z] = tp(t, x, z); B.cyl(0.18, 0.18, 0.05, '#fff9e8', X, t.y + WH - 0.03, Z); }
    const F = (n, i, mk, lx, lz, w, h, d, m) => addProp({ key: key + ':' + i, n, mk, t, lx, lz, ly: 0, w, h, d, m, heavy: true, parent });
    const P = (n, i, mk, lx, ly, lz, r, m) => addProp({ key: key + ':' + i, n, mk, t, lx, lz, ly, r, m, heavy: false, parent });
    F('Диван', 1, g => { g.box(0.9, 0.45, 2.8, '#7a5236', -0.12, 0.23, 0); g.box(0.25, 0.6, 2.8, '#6b452c', 0.33, 0.75, 0); g.box(0.9, 0.35, 0.25, '#6b452c', -0.12, 0.6, -1.3); g.box(0.9, 0.35, 0.25, '#6b452c', -0.12, 0.6, 1.3); }, -2.5, 4.4, 1.15, 1.05, 2.8, 40);
    F('Журнальный столик', 2, g => { g.box(0.7, 0.04, 1.3, '#5e4a38', 0, 0.45, 0); for (const [dx, dz] of [[-0.3, -0.6], [0.3, -0.6], [-0.3, 0.6], [0.3, 0.6]]) g.box(0.05, 0.43, 0.05, '#4a3a2c', dx, 0.22, dz); }, -4.4, 4.4, 0.7, 0.47, 1.3, 10);
    if (has('tv') || has('theater') || !poor) F('Телевизор', 3, g => { g.box(0.45, 0.5, 2.2, '#3d3631', 0, 0.25, 0); g.box(0.08, 0.9, 1.7, '#151515', -0.05, 0.95, 0); g.box(0.02, 0.8, 1.6, '#2d4656', 0.0, 0.95, 0); if (has('console')) g.box(0.3, 0.06, 0.35, '#202020', 0.05, 0.53, -0.8); }, -8.55, 4.4, 0.45, 1.4, 2.2, 25);
    else F('Тумба', 3, g => g.box(0.45, 0.5, 2.2, '#3d3631', 0, 0.25, 0), -8.55, 4.4, 0.45, 0.5, 2.2, 20);
    F('Кресло', 4, g => { g.box(0.9, 0.45, 0.9, '#5f6b7a', 0, 0.23, 0); g.box(0.9, 0.5, 0.2, '#56606e', 0, 0.7, 0.35); }, -4.6, 6.3, 0.9, 0.95, 0.9, 20);
    if (has('shelf')) F('Стеллаж', 5, g => { g.box(1.8, 2.0, 0.4, '#8a6a48', 0, 1.0, 0); for (let i = 0; i < 4; i++) g.box(1.7, 0.03, 0.42, '#6e5238', 0, 0.4 + i * 0.45, 0); }, -7.2, 6.65, 1.8, 2.0, 0.4, 30);
    if (has('piano')) F('Пианино', 6, g => { g.box(1.5, 1.2, 0.6, '#151515', 0, 0.6, 0); g.box(1.3, 0.05, 0.25, '#f2f2f2', 0, 0.75, -0.35); }, 0, 6.55, 1.5, 1.2, 0.6, 80);
    if (has('aqua')) F('Аквариум', 7, g => { g.box(1.2, 0.7, 0.45, '#2c2c2c', 0, 0.35, 0); g.box(1.15, 0.55, 0.4, '#5fb5d6', 0, 0.98, 0); }, -0.5, 1.65, 1.2, 1.25, 0.45, 40);
    if (has('lamp') || rich) F('Торшер', 8, g => { g.cyl(0.04, 0.04, 1.6, '#333', 0, 0.8, 0); g.cyl(0.18, 0.25, 0.3, '#f5e3b3', 0, 1.7, 0); g.cyl(0.2, 0.2, 0.04, '#333', 0, 0.02, 0); }, -8.4, 6.5, 0.5, 1.85, 0.5, 5);
    if (has('plant') || rich) F('Фикус', 9, g => { g.cyl(0.22, 0.18, 0.4, '#a0522d', 0, 0.2, 0); g.ball(0.4, '#3e8e41', 0, 0.8, 0, 7); }, 0.4, 2.0, 0.7, 1.2, 0.7, 8);
    if (has('theater')) { F('Колонка', 10, g => g.box(0.3, 1.0, 0.3, '#2a2a2a', 0, 0.5, 0), -8.6, 2.6, 0.3, 1.0, 0.3, 8); F('Колонка', 11, g => g.box(0.3, 1.0, 0.3, '#2a2a2a', 0, 0.5, 0), -8.6, 6.2, 0.3, 1.0, 0.3, 8); }
    F('Кровать', 12, g => { g.box(2.0, 0.5, 2.3, '#e8e3da', 0, 0.25, 0); g.box(2.0, 0.9, 0.15, '#6e4f37', 0, 0.45, 1.12); g.box(1.9, 0.12, 1.4, '#6a8caf', 0, 0.56, -0.45); g.box(0.6, 0.12, 0.35, '#ffffff', -0.45, 0.58, 0.8); g.box(0.6, 0.12, 0.35, '#ffffff', 0.45, 0.58, 0.8); }, 7.6, 5.7, 2.0, 0.9, 2.3, 50);
    F('Тумбочка', 13, g => g.box(0.45, 0.5, 0.4, '#6e4f37', 0, 0.25, 0), 6.2, 6.6, 0.45, 0.5, 0.4, 6);
    if (has('wardrobe') || !poor) F('Шкаф', 14, g => { g.box(2.0, 2.3, 0.65, rich ? '#3b3b3b' : '#c9b79c', 0, 1.15, 0); g.box(0.02, 2.1, 0.02, '#999', 0, 1.15, -0.33); }, 2.3, 6.55, 2.0, 2.3, 0.65, 60);
    if (has('desk') || has('pc')) F('Письменный стол', 15, g => { g.box(1.4, 0.05, 0.7, '#8b6b4a', 0, 0.75, 0); g.box(0.05, 0.75, 0.6, '#6d533a', -0.65, 0.37, 0); g.box(0.05, 0.75, 0.6, '#6d533a', 0.65, 0.37, 0); if (has('pc')) { g.box(0.7, 0.45, 0.05, '#111', 0, 1.05, -0.2); g.box(0.2, 0.45, 0.45, '#222', 0.5, 1.0, 0.05); } }, 4.8, 1.7, 1.4, 1.3, 0.7, 15);
    if (has('speaker')) P('Умная колонка', 16, g => g.cyl(0.08, 0.08, 0.15, '#333', 0, 0, 0), 6.2, 0.58, 6.6, 0.1, 0.5);
    F('Кухонный гарнитур', 17, g => { g.box(5.6, 0.9, 0.65, '#e9e5de', 0, 0.45, 0); g.box(5.6, 0.04, 0.68, '#4f4a45', 0, 0.92, 0); g.box(0.6, 0.02, 0.5, '#2a2a2a', 1.6, 0.95, 0); g.box(0.5, 0.1, 0.4, '#c8cdd2', -0.8, 0.9, 0); if (has('dish')) g.box(0.6, 0.85, 0.02, '#ddd', 2.6, 0.45, 0.33); }, -6.0, -6.55, 5.6, 0.94, 0.65, 120);
    F('Холодильник', 18, g => { g.box(0.75, 1.9, 0.7, '#f4f4f4', 0, 0.95, 0); g.box(0.03, 0.6, 0.02, '#aaa', 0.3, 1.3, 0.36); }, -8.5, -2.0, 0.75, 1.9, 0.7, 70);
    F('Кухонный стол', 19, g => { g.box(1.6, 0.05, 1.0, '#a37b52', 0, 0.76, 0); for (const [dx, dz] of [[-0.7, -0.42], [0.7, -0.42], [-0.7, 0.42], [0.7, 0.42]]) g.box(0.06, 0.74, 0.06, '#7d5c3d', dx, 0.37, dz); }, -5.5, -3.8, 1.6, 0.78, 1.0, 15);
    F('Ванна', 20, g => { g.box(1.7, 0.6, 0.8, '#ffffff', 0, 0.3, 0); g.box(1.5, 0.05, 0.6, '#9fd3e6', 0, 0.58, 0); }, -0.6, -6.5, 1.7, 0.6, 0.8, 60);
    F('Раковина', 21, g => { g.box(0.6, 0.85, 0.45, '#f4f4f4', 0, 0.43, 0); g.box(0.4, 0.06, 0.3, '#dfe9ec', 0, 0.86, 0); }, 1.5, -4.0, 0.6, 0.9, 0.45, 20);
    if (has('wash')) F('Стиральная машина', 22, g => { g.box(0.6, 0.85, 0.6, '#f0f0f0', 0, 0.43, 0); g.cyl(0.2, 0.2, 0.02, '#888', 0, 0.5, 0.31, 14, Math.PI / 2); }, -1.5, -2.0, 0.6, 0.85, 0.6, 40);
    F('Унитаз', 23, g => { g.box(0.42, 0.42, 0.6, '#ffffff', 0, 0.21, 0.05); g.box(0.42, 0.45, 0.2, '#ffffff', 0, 0.65, -0.3); g.cyl(0.2, 0.2, 0.04, '#f4f4f4', 0, 0.44, 0.1); }, 3.25, -6.45, 0.42, 0.9, 0.8, 25);
    F('Обувница', 24, g => g.box(1.0, 0.5, 0.35, '#7d6249', 0, 0.25, 0), 5.3, -6.75, 1.0, 0.5, 0.35, 8);
    F('Вешалка', 25, g => { g.cyl(0.03, 0.03, 1.8, '#4d3b2b', 0, 0.9, 0); g.cyl(0.18, 0.18, 0.03, '#4d3b2b', 0, 0.02, 0); }, 8.5, -2.0, 0.4, 1.8, 0.4, 4);
    const chair = g => { g.box(0.45, 0.05, 0.45, '#a37b52', 0, 0, 0); for (const [dx, dz] of [[-0.19, -0.19], [0.19, -0.19], [-0.19, 0.19], [0.19, 0.19]]) g.box(0.04, 0.45, 0.04, '#7d5c3d', dx, -0.23, dz); g.box(0.45, 0.45, 0.04, '#a37b52', 0, 0.25, -0.2); };
    P('Стул', 30, chair, -6.4, 0.47, -3.8, 0.38, 3); P('Стул', 31, chair, -4.6, 0.47, -3.8, 0.38, 3); P('Стул', 32, chair, -5.5, 0.47, -4.6, 0.38, 3); P('Стул', 33, chair, -5.5, 0.47, -3.0, 0.38, 3);
    if (has('desk') || has('pc')) P('Стул', 34, chair, 4.8, 0.47, 2.4, 0.38, 3);
    const pillow = c => g => g.box(0.5, 0.15, 0.4, c, 0, 0, 0);
    P('Подушка', 35, pillow('#d6a65c'), -2.6, 0.6, 3.6, 0.27, 0.4); P('Подушка', 36, pillow('#9e5b8c'), -2.6, 0.6, 5.2, 0.27, 0.4); P('Подушка', 37, pillow('#f2f2f2'), 7.2, 0.72, 6.1, 0.27, 0.4);
    P('Мяч', 38, g => g.ball(0.15, '#e2533b', 0, 0, 0, 12), -5.5, 0.15, 2.4, 0.15, 0.4);
    P('Кружка', 39, g => g.cyl(0.05, 0.05, 0.1, '#3b6ea8', 0, 0, 0), -5.7, 0.84, -3.8, 0.08, 0.3); P('Кружка', 40, g => g.cyl(0.05, 0.05, 0.1, '#e0a800', 0, 0, 0), -5.2, 0.84, -3.6, 0.08, 0.3);
    P('Книга', 41, g => g.box(0.22, 0.05, 0.3, '#8e2f2f', 0, 0, 0), -4.3, 0.5, 4.2, 0.18, 0.4); P('Книга', 42, g => g.box(0.22, 0.05, 0.3, '#2e7d32', 0, 0, 0), 6.2, 0.53, 6.6, 0.18, 0.4);
    const crate = g => { g.box(0.5, 0.5, 0.5, '#c9a66b', 0, 0, 0); g.box(0.52, 0.04, 0.1, '#a8894f', 0, 0.12, 0); };
    P('Коробка', 43, crate, 6.4, 0.25, -5.6, 0.3, 2); P('Коробка', 44, crate, 7.1, 0.25, -5.3, 0.3, 2);
    P('Туалетная бумага', 45, g => g.cyl(0.06, 0.06, 0.11, '#ffffff', 0, 0, 0), 3.7, 0.06, -6.6, 0.08, 0.2);
    P('Сковорода', 46, g => { g.cyl(0.14, 0.14, 0.03, '#333', 0, 0, 0); g.box(0.25, 0.02, 0.04, '#333', 0.24, 0, 0); }, -4.4, 0.98, -6.55, 0.16, 0.6);
    P('Тапок', 47, g => g.box(0.12, 0.06, 0.28, '#5a7d9a', 0, 0, 0), 5.0, 0.53, -6.75, 0.12, 0.2);
    P('Банан', 48, g => g.box(0.22, 0.05, 0.06, '#f2d33b', 0, 0, 0), -6.1, 0.84, -3.9, 0.09, 0.15);
    if (has('micro')) P('Микроволновка', 49, g => g.box(0.5, 0.3, 0.35, '#333', 0, 0, 0), -7.6, 1.1, -6.55, 0.25, 4);
    if (has('kettle')) P('Чайник', 50, g => g.cyl(0.09, 0.1, 0.22, '#ccc', 0, 0, 0), -5.4, 1.06, -6.55, 0.11, 1);
    if (has('vac')) P('Робот-пылесос', 51, g => { g.cyl(0.17, 0.17, 0.08, '#2b2b2b', 0, 0, 0); g.cyl(0.05, 0.05, 0.02, '#5fd35f', 0, 0.05, 0.08); }, 6, 0.04, 3, 0.18, 1.5);
  };

  // ---------- предметы ----------
  const addProp = o => {
    const B = new Batch(); o.mk(B); const mesh = B.mesh();
    const g = new T.Group(); g.add(mesh); (o.parent || scene).add(g);
    const [x, z] = tp(o.t, o.lx, o.lz);
    const p = { key: o.key, n: o.n, g, t: o.t, m: o.m, heavy: o.heavy, w: o.w, d: o.d, h: o.h, r: o.r || 0.3, ry: tyaw(o.t, 0), v: v3(0, 0, 0), w3: v3(0, 0, 0), held: '', still: 9, floor: o.t.y };
    g.position.set(x, o.t.y + (o.heavy ? 0 : o.ly), z); g.rotation.y = p.ry;
    if (p.heavy) { p.box = { x0: 0, x1: 0, z0: 0, z1: 0, y0: 0, y1: 0, wall: false }; hbox(p); }
    props.push(p); PID[p.key] = p; return p;
  };
  const hbox = p => { const q = Math.abs(Math.round(p.ry / (Math.PI / 2))) % 2 === 1; const w = q ? p.d : p.w, d = q ? p.w : p.d, b = p.box, x = p.g.position.x, z = p.g.position.z; b.x0 = x - w / 2; b.x1 = x + w / 2; b.z0 = z - d / 2; b.z1 = z + d / 2; b.y0 = p.g.position.y; b.y1 = p.g.position.y + p.h; };
  const placeProp = (p, L0) => { const [x, z] = tp(p.t, L0[0], L0[1]); p.g.position.x = x; p.g.position.z = z; if (L0.length > 3 && !p.heavy) p.g.position.y = p.t.y + L0[3]; p.ry = tyaw(p.t, L0[2] || 0); p.g.rotation.y = p.ry; if (p.heavy) hbox(p); };

  // ---------- человечек ----------
  const MATS = {}; const pm = c => MATS[c] || (MATS[c] = new T.MeshLambertMaterial({ color: c }));
  const nameSprite = name => { const c = document.createElement('canvas'); c.width = 256; c.height = 48; const x = c.getContext('2d'); x.font = 'bold 26px Arial'; x.textAlign = 'center'; x.fillStyle = 'rgba(0,0,0,.45)'; x.fillRect(16, 6, 224, 36); x.fillStyle = '#fff'; x.fillText(name.slice(0, 18), 128, 33); const sp = new T.Sprite(new T.SpriteMaterial({ map: new T.CanvasTexture(c), depthTest: false })); sp.scale.set(1.3, 0.25, 1); return sp; };
  H3.person = (shirt, pants, skin, name, hair) => {
    const g = new T.Group();
    const add = (w, h, d, c, x, y, z, p) => { const m = new T.Mesh(new T.BoxGeometry(w, h, d), pm(c)); m.position.set(x, y, z); (p || g).add(m); return m; };
    const up = new T.Group(); g.add(up);
    const torso = add(0.55, 0.65, 0.3, shirt, 0, 1.12, 0, up), head = add(0.36, 0.36, 0.36, skin, 0, 1.65, 0, up);
    if (hair) add(0.38, 0.1, 0.38, hair, 0, 1.86, 0, up);
    add(0.06, 0.06, 0.02, '#222', -0.08, 1.68, 0.18, up); add(0.06, 0.06, 0.02, '#222', 0.08, 1.68, 0.18, up); add(0.14, 0.03, 0.02, '#9a4c3c', 0, 1.56, 0.18, up);
    const limb = (x, y, c, h, w, par) => { const p = new T.Group(); p.position.set(x, y, 0); par.add(p); add(w, h, w, c, 0, -h / 2, 0, p); return p; };
    const la = limb(-0.38, 1.42, shirt, 0.62, 0.18, up), ra = limb(0.38, 1.42, shirt, 0.62, 0.18, up);
    const hl = new T.Mesh(new T.BoxGeometry(0.17, 0.15, 0.17), pm(skin)); hl.position.y = -0.66; la.add(hl); ra.add(hl.clone());
    const ll = limb(-0.14, 0.8, pants, 0.8, 0.22, g), rl = limb(0.14, 0.8, pants, 0.8, 0.22, g);
    if (name) { const sp = nameSprite(name); sp.position.y = 2.2; up.add(sp); }
    return { g, up, la, ra, ll, rl, head, torso, pos: v3(0, 0, 0), vy: 0, ry: 0, ground: true, walk: 0, kb: v3(0, 0, 0), cr: 0 };
  };
  const looks = name => { let h = 0; for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) >>> 0; const shirts = ['#3b6ea8', '#c0392b', '#2e8b57', '#8e44ad', '#e67e22', '#16a085', '#d35400', '#2c3e50', '#b03a6e', '#5d6d7e']; const pants = ['#2c3e50', '#34495e', '#4e3b2a', '#1f2a36', '#3d3d3d']; const skins = ['#f1c9a5', '#e0ac83', '#c68b5f', '#f5d6b8']; const hair = ['#2b1d12', '#5a3a1e', '#c9a35a', '#1a1a1a', '#7a3b1f', '#9c9c9c']; return [shirts[h % shirts.length], pants[(h >>> 3) % pants.length], skins[(h >>> 5) % skins.length], hair[(h >>> 7) % hair.length]]; };
  const CR = 0.36;
  const animate = (p, dt, moving, run, crouch, dragging) => {
    p.cr += ((crouch ? 1 : 0) - p.cr) * Math.min(1, dt * 14);
    p.walk += dt * (moving ? (run ? 13 : crouch ? 6 : 8) : 0);
    const sw = moving && p.ground ? Math.sin(p.walk) * (run ? 0.9 : crouch ? 0.4 : 0.6) : 0;
    p.ll.scale.y = p.rl.scale.y = 1 - p.cr * 0.45;
    p.ll.rotation.x = sw; p.rl.rotation.x = -sw;
    p.up.position.y = -CR * p.cr; p.up.rotation.x = 0.25 * p.cr;
    p.la.rotation.set(-sw * 0.8, 0, 0); p.ra.rotation.set(sw * 0.8, 0, 0);
    if (!p.ground) { p.la.rotation.z = -0.5; p.ra.rotation.z = 0.5; p.ll.rotation.x = 0.4; p.rl.rotation.x = -0.2; }
    if (dragging) p.ra.rotation.set(-1.4, 0, 0);
    p.g.position.set(p.pos.x, p.pos.y, p.pos.z); p.g.rotation.y = p.ry;
  };

  // ============================== ГОРОД ==============================
  // площадь ±26, кольцевая дорога 28…36, тротуар 36…40, улицы от 40 до 220 (север, восток, юг, запад)
  const BLD = [TF(75, -70, 0, 0, false), TF(-75, -70, 0, 0, true), TF(75, 70, 0, 2, true), TF(-75, 70, 0, 2, false)];
  const STREETS = ['Садовая', 'Липовая', 'Школьная', 'Речная'];
  const SHOPS = [['Продукты', 19, -19, '#3f8f5a'], ['Аптека', -19, -19, '#3c7fb0'], ['Кафе «Уют»', 19, 19, '#b5663a'], ['Хозтовары', -19, 19, '#8a6db0']];
  const FLATS = [TF(-9, -9, 0, 2, false), TF(9, -9, 0, 2, true), TF(-9, 9, 0, 0, false), TF(9, 9, 0, 0, true)];
  const flatTF = (b, f, u) => { const t = tcat(BLD[b], FLATS[u]); t.y = f * FH; return t; };
  const houseTF = (k, i) => { const side = i < 7 ? 1 : -1, n = i % 7; return tcat(TF(0, 0, 0, k, false), TF(side * 18, -52 - n * 24, 0, side > 0 ? 3 : 1, false)); };
  const tree = (B, x, z, seed) => { seed = Math.abs(seed | 0); const h = 2.2 + (seed % 5) * 0.3; B.cyl(0.18, 0.25, h, '#6b4b33', x, h / 2, z, 6); B.ball(1.4 + (seed % 3) * 0.25, ['#3e8e41', '#4f9a47', '#2f7d3a', '#5aa55a'][seed % 4], x, h + 0.8, z, 7); addSolid({ x0: x - 0.25, x1: x + 0.25, z0: z - 0.25, z1: z + 0.25, y0: 0, y1: h, wall: true, grp: 'city' }); };
  const lamp = (B, x, z) => { B.cyl(0.07, 0.1, 4, '#3a3a3a', x, 2, z, 6); B.box(0.5, 0.15, 0.5, '#3a3a3a', x, 4.05, z); B.box(0.36, 0.06, 0.36, '#fff2c0', x, 3.95, z); addSolid({ x0: x - 0.1, x1: x + 0.1, z0: z - 0.1, z1: z + 0.1, y0: 0, y1: 4, wall: true, grp: 'city' }); };
  const bench = (B, x, z, ry) => { const cs = Math.cos(ry), sn = Math.sin(ry), add = (w, h, d, c, lx, ly, lz) => B.box(w, h, d, c, x + lx * cs + lz * sn, ly, z - lx * sn + lz * cs, ry); add(1.8, 0.08, 0.5, '#8b5a2b', 0, 0.45, 0); add(1.8, 0.4, 0.06, '#8b5a2b', 0, 0.7, -0.24); add(0.08, 0.45, 0.45, '#3a3a3a', -0.8, 0.22, 0); add(0.08, 0.45, 0.45, '#3a3a3a', 0.8, 0.22, 0); addSolid({ x0: x - 0.7, x1: x + 0.7, z0: z - 0.7, z1: z + 0.7, y0: 0, y1: 0.49, grp: 'city' }); };
  const buildCity = () => {
    const B = new Batch('city');
    const g = new T.Mesh(new T.PlaneGeometry(WORLD * 2 + 120, WORLD * 2 + 120), new T.MeshLambertMaterial({ color: '#7fae5a' })); g.rotation.x = -Math.PI / 2; g.position.y = -0.01; scene.add(g);
    B.box(56, 0.06, 56, '#d9d2c3', 0, 0.03, 0);
    for (let i = -24; i <= 24; i += 4) { B.box(0.06, 0.065, 52, '#cbc3b2', i, 0.03, 0); B.box(52, 0.065, 0.06, '#cbc3b2', 0, 0.03, i); }
    const road = (x0, z0, x1, z1) => B.box(x1 - x0, 0.05, z1 - z0, '#4a4d52', (x0 + x1) / 2, 0.025, (z0 + z1) / 2);
    const walk = (x0, z0, x1, z1) => B.box(x1 - x0, 0.1, z1 - z0, '#bdb7ab', (x0 + x1) / 2, 0.05, (z0 + z1) / 2);
    road(-36, -36, 36, -28); road(-36, 28, 36, 36); road(-36, -28, -28, 28); road(28, -28, 36, 28);
    walk(-40, -40, 40, -36); walk(-40, 36, 40, 40); walk(-40, -36, -36, 36); walk(36, -36, 40, 36);
    for (let a = -32; a < 32; a += 4) { B.box(2, 0.06, 0.15, '#f2f2f2', a + 1, 0.03, -32); B.box(2, 0.06, 0.15, '#f2f2f2', a + 1, 0.03, 32); B.box(0.15, 0.06, 2, '#f2f2f2', -32, 0.03, a + 1); B.box(0.15, 0.06, 2, '#f2f2f2', 32, 0.03, a + 1); }
    for (let k = 0; k < 4; k++) {
      const st = TF(0, 0, 0, k, false), R2 = (x0, z0, x1, z1, c, h) => { const [a, b] = tp(st, x0, z0), [c2, d] = tp(st, x1, z1); B.box(Math.abs(c2 - a), h || 0.05, Math.abs(d - b), c, (a + c2) / 2, (h || 0.05) / 2, (b + d) / 2); };
      R2(-4, -224, 4, -36, '#4a4d52'); R2(-7, -224, -4, -40, '#bdb7ab', 0.1); R2(4, -224, 7, -40, '#bdb7ab', 0.1);
      for (let z = -220; z < -44; z += 5) R2(-0.08, z, 0.08, z + 2.4, '#f2f2f2', 0.06);
      for (let x = -3.5; x < 4; x += 1) R2(x, -35.5, x + 0.5, -29, '#f2f2f2', 0.06); // зебра через кольцо
      const [sx, sz] = tp(st, 8.6, -44); B.cyl(0.05, 0.05, 2.6, '#555', sx, 1.3, sz, 6);
      const sg = label('ул. ' + STREETS[k], 2.4, 0.5, '#1f4f8a', '#ffffff', 'Arial'); sg.position.set(sx, 2.5, sz); const [vx, vz] = tvec(st, 0, 1); sg.rotation.y = Math.atan2(vx, vz); scene.add(sg); const sg2 = sg.clone(); sg2.rotation.y += Math.PI; scene.add(sg2);
      for (let z = -48; z > -220; z -= 12) for (const s2 of [-8.6, 8.6]) { const [x, zz] = tp(st, s2, z); tree(B, x, zz, z * 7 + s2 * 3); }
    }
    // фонтан
    B.cyl(5.2, 5.4, 0.6, '#b9b2a4', 0, 0.3, 0, 24); B.cyl(4.7, 4.7, 0.62, '#9a9384', 0, 0.31, 0, 24);
    B.cyl(0.7, 0.9, 1.6, '#b9b2a4', 0, 0.8, 0, 12); B.cyl(1.8, 1.2, 0.35, '#b9b2a4', 0, 1.7, 0, 16); B.cyl(0.25, 0.35, 0.9, '#b9b2a4', 0, 2.2, 0, 10);
    addSolid({ x0: -4.3, x1: 4.3, z0: -4.3, z1: 4.3, y0: 0, y1: 0.62, grp: 'city' });
    addSolid({ x0: -0.9, x1: 0.9, z0: -0.9, z1: 0.9, y0: 0, y1: 2.6, wall: true, grp: 'city' });
    const wm = (r, h, c, o) => new T.Mesh(new T.CylinderGeometry(r, r, h, 28), new T.MeshLambertMaterial({ color: c, transparent: true, opacity: o }));
    const water = wm(4.6, 0.05, '#5fb5d6', 0.8); water.position.y = 0.5; scene.add(water);
    const top = wm(1.6, 0.04, '#7cc7e3', 0.85); top.position.y = 1.86; scene.add(top);
    for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2, j = new T.Mesh(new T.CylinderGeometry(0.06, 0.1, 1, 6), new T.MeshLambertMaterial({ color: '#cdeefa', transparent: true, opacity: 0.7 })); j.position.set(Math.cos(a) * 3, 1, Math.sin(a) * 3); scene.add(j); jets.push(j); }
    const cj = new T.Mesh(new T.CylinderGeometry(0.08, 0.14, 1.4, 8), new T.MeshLambertMaterial({ color: '#cdeefa', transparent: true, opacity: 0.75 })); cj.position.y = 3.2; scene.add(cj); jets.push(cj);
    for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2 + Math.PI / 8; bench(B, Math.cos(a) * 9, Math.sin(a) * 9, Math.atan2(-Math.cos(a), -Math.sin(a))); }
    for (const [x, z] of [[-12, -24], [12, -24], [-12, 24], [12, 24], [-24, -12], [-24, 12], [24, -12], [24, 12]]) lamp(B, x, z);
    for (const [x, z] of [[-24, -24], [24, -24], [-24, 24], [24, 24], [-6, -22], [6, -22], [-6, 22], [6, 22], [-22, -6], [-22, 6], [22, -6], [22, 6]]) tree(B, x, z, x * 13 + z);
    for (const [x, z] of [[-11, 0], [11, 0], [0, -11], [0, 11]]) { B.cyl(1.4, 1.4, 0.4, '#8a6a48', x, 0.2, z, 14); B.ball(1.0, '#c0405a', x, 0.55, z, 8); addSolid({ x0: x - 1.3, x1: x + 1.3, z0: z - 1.3, z1: z + 1.3, y0: 0, y1: 0.4, grp: 'city' }); }
    for (const [n, x, z, c] of SHOPS) shop(B, n, x, z, c);
    BLD.forEach((t, i) => building(B, t, i));
    for (const q of [[1, -1], [-1, -1], [1, 1], [-1, 1]]) { for (let i = 0; i < 8; i++) tree(B, q[0] * (44 + (i * 7) % 52), q[1] * (44 + (i % 2) * 2), i * 7 + q[0] * 3); for (let i = 0; i < 10; i++) B.ball(0.8, '#4a8f3f', q[0] * (106 + (i % 2) * 4), 0.5, q[1] * (52 + i * 4), 6); }
    // дорожки от подъездов к кольцу
    BLD.forEach(t => { const [ex, ez] = tp(t, -19.6, 4), [tx, tz] = tp(t, -19.6, 32); const x0 = Math.min(ex, tx) - 1.3, x1 = Math.max(ex, tx) + 1.3, z0 = Math.min(ez, tz) - 1.3, z1 = Math.max(ez, tz) + 1.3; B.box(x1 - x0, 0.08, z1 - z0, '#bdb7ab', (x0 + x1) / 2, 0.04, (z0 + z1) / 2); });
    scene.add(B.mesh());
  };
  const shop = (B, n, x, z, c) => {
    const t = TF(x, z, 0, x > 0 ? 1 : 3, false); // дверь — на стене z = −3.5 (смотрит к фонтану)
    const o = s => ({ h: 3.2, skin: c, side: s });
    WALL(B, t, -4.5, -3.5, 4.5, -3.5, [[0, 1.4]], '#f4efe6', o(-1)); WALL(B, t, -4.5, 3.5, 4.5, 3.5, [], '#f4efe6', o(1));
    WALL(B, t, -4.5, -3.5, -4.5, 3.5, [], '#f4efe6', o(-1)); WALL(B, t, 4.5, -3.5, 4.5, 3.5, [], '#f4efe6', o(1));
    SB(B, t, 9.4, 0.2, 7.4, c, 0, 3.3, 0, 'slab'); SB(B, t, 8.9, 0.03, 6.9, '#d8d0c0', 0, 0.075, 0);
    WIN(B, t, -2.8, 1.5, -3.5, 0, -1, 2.0, 1.4); WIN(B, t, 2.8, 1.5, -3.5, 0, -1, 2.0, 1.4);
    SB(B, t, 3, 1.0, 0.6, '#8b6b4a', 1.5, 0.5, 1.6, 'solid');
    for (const sx of [-3.8, 3.8]) { SB(B, t, 0.5, 2.2, 5.5, '#c9b79c', sx, 1.1, 0.4, 'wall'); for (let i = 0; i < 4; i++) for (let j = 0; j < 5; j++) SB(B, t, 0.3, 0.25, 0.3, ['#d35400', '#2e8b57', '#c0392b', '#f1c40f', '#3b6ea8'][(i + j) % 5], sx - Math.sign(sx) * 0.3, 0.45 + i * 0.5, -1.8 + j * 1.1); }
    plaque(scene, t, n, 0, 3.7, -3.6, 0, -1, 4.2, 0.8, c, '#ffffff');
    DOOR(scene, t, 0, -3.5, 'x', 1.4, { kind: 'shop', color: '#2c4a52' });
  };
  // многоэтажка: 5 этажей × 4 квартиры, коридор, лестница в торце (x −26…−18), подъезд
  const building = (B, t, bi) => {
    const fac = ['#d8cfc2', '#c9b8a0', '#d3c6b2', '#bfae96'][bi], wc = '#efe9df', NF = 5;
    for (let f = 0; f < NF; f++) {
      const tt = Object.assign({}, t, { y: f * FH }), S = (s, e) => Object.assign({ skin: fac, side: s, h: FH }, e || {}), I = { h: FH };
      WALL(B, tt, -18, -16, 18, -16, [], wc, S(-1)); WALL(B, tt, -18, 16, 18, 16, [], wc, S(1)); WALL(B, tt, 18, -16, 18, 16, [], wc, S(1));
      WALL(B, tt, -18, -16, -18, -2, [], wc, S(-1)); WALL(B, tt, -18, 2, -18, 16, [], wc, S(-1));
      for (const x of [-14.5, -10.5, -5.2, -2.4, 3, 6.25, 11.75, 15.25]) { WIN(B, tt, x, 1.6, -16, 0, -1, 1.5, 1.3); WIN(B, tt, x, 1.6, 16, 0, 1, 1.5, 1.3); }
      for (const z of [-12, -6, 6, 12]) { WIN(B, tt, 18, 1.6, z, 1, 0, 1.5, 1.3); WIN(B, tt, -18, 1.6, z, -1, 0, 1.5, 1.3); }
      if (f > 0) SB(B, tt, 36.3, 0.2, 32.3, '#f7f5f0', 0, -0.1, 0, 'slab'); else SB(B, tt, 36, 0.02, 32, '#cfc4b0', 0, 0.006, 0);
      SB(B, tt, 36, 0.02, 4, '#b9a98f', 0, 0.016, 0); // коридор
      const dx = FLATS.map(ft => tp(ft, 7, -7));
      WALL(B, tt, -18, -2, 18, -2, dx.filter(d => d[1] < 0).map(d => [d[0], 1.1]), wc, I);
      WALL(B, tt, -18, 2, 18, 2, dx.filter(d => d[1] > 0).map(d => [d[0], 1.1]), wc, I);
      WALL(B, tt, 0, -16, 0, -2, [], wc, I); WALL(B, tt, 0, 2, 0, 16, [], wc, I);
      for (const x of [-9, 9]) { const [X, Z] = tp(tt, x, 0); B.cyl(0.18, 0.18, 0.05, '#fff9e8', X, tt.y + WH - 0.03, Z); }
      FLATS.forEach((ft, u) => { const [x, z] = dx[u]; const d = DOOR(scene, tt, x, z, 'x', 1.0, { kind: 'flat', locked: true, color: '#5a4636' }); d.slot = [bi, f, u]; d.nl = [x, z < 0 ? 1 : -1]; d.tt = tt; d.no = f * 4 + u + 1; plaque(scene, tt, 'кв. ' + (f * 4 + u + 1), x + 0.85, 1.6, z, 0, z < 0 ? 1 : -1, 0.5, 0.22, '#e9e2d0', '#3d3d3d'); });
      plaque(scene, tt, 'Этаж ' + (f + 1), -18, 1.8, 0.9, 1, 0, 1.0, 0.32, '#3d5a63', '#ffffff');
      // лестничная клетка
      WALL(B, tt, -26, -4, -26, 4, [], wc, S(-1)); WALL(B, tt, -26, -4, -18, -4, [], wc, S(-1, { se: [0.13, 0] }));
      WALL(B, tt, -26, 4, -18, 4, f === 0 ? [[-19.6, 1.6]] : [], wc, S(1, { se: [0.13, 0] }));
      WIN(B, tt, -26, 1.9, 0, -1, 0, 1.2, 1.0);
      if (f > 0) { SB(B, tt, 3.1, 0.2, 8.1, '#d2c7b4', -19.5, -0.1, 0, 'slab'); SB(B, tt, 5, 0.2, 1, '#d2c7b4', -23.5, -0.1, -3.5, 'slab'); SB(B, tt, 0.06, 1.0, 6.8, '#6b6b6b', -21.03, 0.5, 0.55, 'rail'); }
      else SB(B, tt, 8, 0.02, 8, '#cfc4b0', -22, 0.012, 0);
      if (f < NF - 1) {
        for (let i = 0; i < 8; i++) SB(B, tt, 2.5, 0.2, 0.6, '#c9bda8', -24.75, 0.2 * (i + 1) - 0.1, -3.0 + 0.6 * i + 0.3, 'solid');
        SB(B, tt, 5, 0.2, 2.2, '#d2c7b4', -23.5, 1.5, 2.9, 'solid');
        for (let i = 0; i < 8; i++) SB(B, tt, 2.5, 0.2, 0.6, '#c9bda8', -22.25, 1.6 + 0.2 * (i + 1) - 0.1, 1.8 - 0.6 * i - 0.3, 'solid');
      }
    }
    const ty = Object.assign({}, t, { y: NF * FH });
    SB(B, ty, 36.6, 0.3, 32.6, '#7d746a', 0, 0.15, 0, 'slab'); SB(B, ty, 8.6, 0.3, 8.6, '#7d746a', -22.1, 0.15, 0, 'slab');
    SB(B, t, 3, 0.15, 1.6, '#7d746a', -19.6, 2.6, 4.8);
    plaque(scene, t, 'Дом ' + (bi + 1) + ' · подъезд 1', -19.6, 2.95, 4, 0, 1, 2.2, 0.42, '#2f5f6a', '#ffffff');
    DOOR(scene, t, -19.6, 4, 'x', 1.6, { kind: 'entrance', color: '#3a3a3a' });
  };
  // частный дом (снаружи; у игроков — с комнатами и мебелью)
  const HC = ['#c78a5a', '#e2d3b0', '#a9c3cf', '#d9b8b8', '#c9d6a3', '#e8c27a', '#b9a3c9'];
  const house = (B, t, k, i, sp, key, parent) => {
    const c = HC[(k * 14 + i) % HC.length], wc = '#f1ede6', mine = !!sp, S = s => ({ skin: c, side: s });
    WALL(B, t, -9, -7, 9, -7, [[7, 1.1]], wc, S(-1)); WALL(B, t, -9, 7, 9, 7, [], wc, S(1));
    WALL(B, t, -9, -7, -9, 7, [], wc, S(-1)); WALL(B, t, 9, -7, 9, 7, [], wc, S(1));
    for (const x of [-5.5, -1.5, 2.8]) WIN(B, t, x, 1.6, -7, 0, -1, 1.5, 1.2);
    for (const x of [-6.25, 4.8]) WIN(B, t, x, 1.6, 7, 0, 1, 1.5, 1.2);
    for (const z of [-4, 4]) { WIN(B, t, -9, 1.6, z, -1, 0, 1.4, 1.2); WIN(B, t, 9, 1.6, z, 1, 0, 1.4, 1.2); }
    SB(B, t, 18.4, 0.2, 14.4, '#f7f5f0', 0, WH + 0.1, 0, 'slab');
    const [rx, rz] = tp(t, 0, 0), [W, D] = tdim(t, 19.4, 15.4);
    B.roof(Math.max(W, D), 3.2, Math.min(W, D), '#8c3b2e', rx, WH + 0.2, rz, W > D ? 0 : Math.PI / 2);
    SB(B, t, 2.2, 0.2, 1.4, '#a89c88', 7, 0.1, -7.8, 'solid'); SB(B, t, 1.4, 0.06, 3.4, '#bdb7ab', 7, 0.03, -10.2);
    for (const [x0, x1] of [[-11, 6.1], [7.9, 11]]) SB(B, t, x1 - x0, 0.9, 0.08, '#e9e2d0', (x0 + x1) / 2, 0.45, -11.6, 'rail');
    SB(B, t, 0.08, 0.9, 20, '#e9e2d0', -11, 0.45, -1.6, 'rail'); SB(B, t, 0.08, 0.9, 20, '#e9e2d0', 11, 0.45, -1.6, 'rail'); SB(B, t, 22, 0.9, 0.08, '#e9e2d0', 0, 0.45, 8.4, 'rail');
    plaque(parent, t, STREETS[k] + ', ' + (i + 1), 4.6, 2.35, -7, 0, -1, 1.5, 0.36, '#ffffff', '#2d2a26');
    if (mine) interior(B, t, sp, key, parent); else SB(B, t, 17.6, 0.02, 13.6, '#c9b9a0', 0, 0.012, 0);
    const d = DOOR(parent, t, 7, -7, 'x', 1.1, { kind: 'house', locked: !mine, grp: 'dyn', color: mine ? '#7a3b1f' : '#5a4636' });
    d.slot = ['h', k, i]; d.dyn = true; return d;
  };

  // ---------- кто где живёт ----------
  const hash = s => { let h = 2166136261; for (const ch of s) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619) >>> 0; } return h; };
  H3.households = () => {
    const out = new Map(), add = (uid, name, i) => { if (!i || !i.k) return; let h = out.get(i.k); if (!h) out.set(i.k, h = { key: i.k, t: i.t, names: [], uids: [], sp: { f: i.f, c: i.c, l: i.l } }); if (!h.names.includes(name)) h.names.push(name); h.uids.push(uid); if (uid === uidMe()) h.sp = { f: i.f, c: i.c, l: i.l }; };
    const s = UI.s; add(uidMe(), s.ch.name + ' ' + s.ch.surname, H3.info(s));
    if (typeof NET !== 'undefined' && NET.on()) for (const p of NET.list()) if (!p.self && p.h3) add(p.uid, p.name, p.h3);
    const list = [...out.values()].sort((a, b) => a.key < b.key ? -1 : 1); list.forEach(h => h.names.sort());
    const ft = new Set(), ht = new Set();
    for (const h of list) {
      if (h.t === 'house') { const i = hash(h.key) % 14; for (let n = 0; n < 56; n++) { const k = Math.floor(n / 14), j = (i + n) % 14, id = k * 14 + j; if (!ht.has(id)) { ht.add(id); h.addr = ['h', k, j]; break; } } }
      else { const i = hash(h.key) % 20; for (let n = 0; n < 80; n++) { const b = Math.floor(n / 20), j = (i + n) % 20, id = b * 20 + j; if (!ft.has(id)) { ft.add(id); h.addr = [b, Math.floor(j / 4), j % 4]; break; } } }
    }
    return list;
  };
  const homesSig = hs => hs.map(h => h.key + '@' + h.addr.join(':') + '#' + h.names.join(',') + '#' + (h.sp.f || []).join(',')).join('|');
  const buildHomes = () => {
    if (drag) drag = null;
    if (dyn) { scene.remove(dyn); dyn.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material && o.material.map) o.material.map.dispose(); }); dropGroup('dyn'); }
    for (const p of props) delete PID[p.key]; props.length = 0;
    for (let i = doors.length - 1; i >= 0; i--) if (doors[i].dyn) doors.splice(i, 1);
    dyn = new T.Group(); scene.add(dyn);
    homes = H3.households();
    const B = new Batch('dyn'), mineKey = H3.hh(UI.s), flatOf = {}, houseOf = {};
    for (const h of homes) { if (h.addr[0] === 'h') houseOf[h.addr[1] * 14 + h.addr[2]] = h; else flatOf[h.addr.join(':')] = h; }
    const lay = h => { for (const p of props) if (p.key.startsWith(h.key + ':')) { const L0 = (h.sp.l || {})[p.key.split(':').pop()]; if (L0) placeProp(p, L0); } };
    for (const d of doors) if (d.kind === 'flat') {
      const h = flatOf[d.slot.join(':')]; d.locked = !h; d.owners = h ? h.names.join(' и ') : ''; d.mine = !!(h && h.key === mineKey);
      if (!h) continue;
      interior(B, flatTF(...d.slot), Object.assign({}, h.sp), h.key, dyn); lay(h);
      plaque(dyn, d.tt, d.owners, d.nl[0], 2.62, d.nl[1] > 0 ? -2 : 2, 0, d.nl[1], 1.9, 0.34, d.mine ? '#b8892f' : '#2f6f7e', '#ffffff');
      const [W, D] = tdim(d.tt, 1.3, 0.24), fr = new T.Mesh(new T.BoxGeometry(W, 0.1, D), new T.MeshBasicMaterial({ color: d.mine ? '#f2c14e' : '#7fd1e0' })); fr.position.set(d.x, d.y + 2.27, d.z); dyn.add(fr);
    }
    for (let k = 0; k < 4; k++) for (let i = 0; i < 14; i++) {
      const h = houseOf[k * 14 + i], t = houseTF(k, i);
      const d = house(B, t, k, i, h ? Object.assign({}, h.sp) : null, h ? h.key : '', dyn);
      if (h) { d.owners = h.names.join(' и '); d.mine = h.key === mineKey; lay(h); plaque(dyn, t, d.owners, 7, 2.65, -7, 0, -1, 2.2, 0.4, d.mine ? '#b8892f' : '#2f6f7e', '#ffffff'); }
    }
    dyn.add(B.mesh());
    sig = homesSig(homes);
  };
  const myAddr = () => { const k = H3.hh(UI.s); const h = homes.find(x => x.key === k); return h ? h.addr : null; };
  const addrTF = a => a[0] === 'h' ? houseTF(a[1], a[2]) : flatTF(a[0], a[1], a[2]);

  // ---------- машины и прохожие (их движение — от времени, у всех игроков одинаковое) ----------
  const poly = pts => { const seg = []; let L = 0; for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length], l = Math.hypot(b[0] - a[0], b[1] - a[1]); seg.push({ a, b, l, s: L }); L += l; } return { seg, L }; };
  const at = (P, d) => { d = ((d % P.L) + P.L) % P.L; for (const g of P.seg) if (d <= g.s + g.l) { const k = (d - g.s) / g.l; return [g.a[0] + (g.b[0] - g.a[0]) * k, g.a[1] + (g.b[1] - g.a[1]) * k, Math.atan2(g.b[0] - g.a[0], g.b[1] - g.a[1])]; } const g = P.seg[0]; return [g.a[0], g.a[1], 0]; };
  const carMesh = c => { const B = new Batch(); B.box(1.9, 0.7, 4.2, c, 0, 0.65, 0); B.box(1.7, 0.6, 2.2, c, 0, 1.25, -0.2); B.box(1.72, 0.45, 2.0, '#9fc3d6', 0, 1.25, -0.2); for (const [x, z] of [[-0.9, 1.3], [0.9, 1.3], [-0.9, -1.3], [0.9, -1.3]]) B.cyl(0.36, 0.36, 0.25, '#1d1d1d', x, 0.36, z, 10, 0); B.box(1.5, 0.15, 0.05, '#fff6c2', 0, 0.75, 2.11); B.box(1.5, 0.15, 0.05, '#c0392b', 0, 0.75, -2.11); const g = new T.Group(); g.add(B.mesh()); g.children[0].children.forEach(() => { }); return g; };
  const buildTraffic = () => {
    const ring = poly([[30, 30], [30, -30], [-30, -30], [-30, 30]]), ring2 = poly([[-34, -34], [34, -34], [34, 34], [-34, 34]]);
    const routes = [];
    for (let i = 0; i < 4; i++) routes.push([ring, i * ring.L / 4, 9]); for (let i = 0; i < 3; i++) routes.push([ring2, i * ring2.L / 3, 10]);
    for (let k = 0; k < 4; k++) { const st = TF(0, 0, 0, k, false); routes.push([poly([[2, -36], [2, -218], [-2, -218], [-2, -36]].map(p => tp(st, p[0], p[1]))), k * 40, 8]); }
    const cs = ['#c0392b', '#2e86c1', '#f1c40f', '#ecf0f1', '#27ae60', '#7f8c8d', '#2c3e50', '#e67e22', '#8e44ad', '#16a085', '#d35400'];
    routes.forEach(([P, off, sp], i) => { const g = carMesh(cs[i % cs.length]); scene.add(g); cars.push({ P, off, sp, g, x: 999, z: 999, a: 0 }); });
    const shopStops = SHOPS.map(([n, x, z]) => tp(TF(x, z, 0, x > 0 ? 1 : 3, false), 0, -4.6));
    const plazaShops = poly([[0, -23], shopStops[1], [-23, 0], shopStops[3], [0, 23], shopStops[2], [23, 0], shopStops[0]]);
    const fount = poly(Array.from({ length: 16 }, (_, i) => [Math.cos(i / 16 * Math.PI * 2) * 7, Math.sin(i / 16 * Math.PI * 2) * 7]));
    const side = poly([[-38, -38], [38, -38], [38, 38], [-38, 38]]);
    const R3 = (P, n, sp) => { for (let i = 0; i < n; i++) walkers.push({ P, off: i * P.L / n + i * 3.7, sp: sp * (0.85 + (i * 37 % 30) / 100), seed: walkers.length * 977 + 13 }); };
    R3(plazaShops, 8, 1.25); R3(fount, 4, 1.0); R3(side, 8, 1.35);
    for (let k = 0; k < 4; k++) { const st = TF(0, 0, 0, k, false); R3(poly([[5.5, -40], [5.5, -216], [-5.5, -216], [-5.5, -40]].map(p => tp(st, p[0], p[1]))), 3, 1.3); }
    walkers.forEach(w => { const [a, b, c, hc] = looks('npc' + w.seed); const p = H3.person(a, b, c, '', hc); scene.add(p.g); w.p = p; w.shops = shopStops; w.x = 999; w.z = 999; });
  };
  const stepTraffic = (dt, t) => {
    for (const c of cars) { const [x, z, a] = at(c.P, c.off + t * c.sp); c.g.position.set(x, 0, z); c.g.rotation.y = a; c.x = x; c.z = z; c.a = a; }
    const cp = cam.position;
    for (const w of walkers) {
      const d = w.off + t * w.sp, [x, z, a] = at(w.P, d), p = w.p;
      let hide = false; for (const s of w.shops) if (Math.hypot(x - s[0], z - s[1]) < 0.9 && (Math.floor(d / w.P.L) + w.seed) % 3 === 0) hide = true; // зашёл в магазин
      p.g.visible = !hide && Math.hypot(x - cp.x, z - cp.z) < 90; w.x = hide ? 999 : x; w.z = hide ? 999 : z;
      if (!p.g.visible) continue;
      p.pos.set(x, 0.1, z); p.ry = a; animate(p, dt, true, false, false, false);
    }
    for (let i = 0; i < jets.length; i++) { const j = jets[i], k = 0.8 + Math.sin(t * 3 + i) * 0.25; j.scale.y = k; j.position.y = i === jets.length - 1 ? 2.6 + 0.7 * k : 0.5 + 0.5 * k; }
  };

  // ============================== ОТКРЫТЬ / ЗАКРЫТЬ ==============================
  const typing = () => { const a = document.activeElement; return a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName); };
  const modalOpen = () => { const m = document.getElementById('modal'); return m && !m.classList.contains('hidden'); };
  const spawnHome = () => { const a = myAddr(); if (!a) return false; const t = addrTF(a); const [x, z] = tp(t, 6.6, -4.3); me.pos.set(x, t.y + 0.05, z); me.vy = 0; const [vx, vz] = tvec(t, 0, -1); yaw = Math.atan2(vx, vz); return true; };
  H3.open = async opt => {
    opt = opt || {};
    if (H3.on) H3.close(true);
    const host = document.querySelector('.mapwrap'); if (!host) return;
    try { T = await H3.load(); } catch (e) { UI.toast('Не удалось загрузить 3D: ' + e.message, 'bad'); return; }
    H3.on = true; drag = null; props.length = 0; doors.length = 0; walkers.length = 0; cars.length = 0; jets.length = 0; grid = new Map(); dyn = null;
    for (const k in remotes) delete remotes[k]; for (const k in PID) delete PID[k];
    ov = document.createElement('div'); ov.id = 'h3ov';
    ov.innerHTML = `<canvas id="h3c" tabindex="0"></canvas><div class="h3top"><b>${UI.ic('home')} <span id="h3where">Город</span></b><span id="h3who"></span><div>${net() ? '<select id="h3inv"><option value="">Позвать друга…</option>' + NET.list().filter(p => !p.self).map(p => `<option value="${p.uid}">${UI.esc(p.name)}</option>`).join('') + '</select>' : ''}${H3.can(UI.s) ? '<button id="h3home">Домой</button>' : ''}<button id="h3x">На карту (Esc)</button></div></div>
      <div class="h3help"><b>WASD</b> ходить · <b>Пробел</b> прыжок · <b>Ctrl</b> присесть · <b>Shift</b> бег · <b>ЛКМ</b> зажать на предмете или мебели — тащить, отпустить с размахом — кинуть · <b>R</b> повернуть мебель · <b>ПКМ</b> камера · колесо — зум</div><div class="h3hint" id="h3hint"></div>`;
    host.appendChild(ov); host.classList.add('h3'); document.documentElement.classList.add('h3on');
    const cv = ov.querySelector('#h3c');
    R = new T.WebGLRenderer({ canvas: cv, antialias: true }); R.setClearColor('#bcd9ea');
    MAT = new T.MeshLambertMaterial({ vertexColors: true, side: T.DoubleSide });
    scene = new T.Scene(); scene.fog = new T.Fog('#cfe3ee', 90, 260);
    cam = new T.PerspectiveCamera(65, 1, 0.05, 420); clock = new T.Clock();
    scene.add(new T.HemisphereLight(0xffffff, 0xcfc6b0, 0.85));
    const sun = new T.DirectionalLight(0xffffff, 0.5); sun.position.set(60, 120, 40); scene.add(sun);
    buildCity(); buildHomes(); buildTraffic();
    const s = UI.s, [sh, pa, sk, hc] = looks(s.ch.name + s.ch.surname);
    me = H3.person(sh, pa, sk, '', hc); scene.add(me.g);
    if (opt.at) me.pos.set(opt.at[0] + 0.8, opt.at[1] + 0.1, opt.at[2] + 0.8);
    else if (opt.plaza || !spawnHome()) { me.pos.set(0, 0.1, 15); yaw = 0; }
    pitch = 0.3;
    const resize = () => { if (!ov) return; const w = Math.max(50, ov.clientWidth), h = Math.max(50, ov.clientHeight), z = parseFloat(document.body.style.zoom) || 1; ov.classList.toggle('narrow', w < 760); R.setPixelRatio(Math.min(1.5, (window.devicePixelRatio || 1) * z)); R.setSize(w, h, false); cv.style.width = '100%'; cv.style.height = '100%'; cam.aspect = w / h; cam.updateProjectionMatrix(); };
    resize(); H3._ro = new ResizeObserver(resize); H3._ro.observe(ov);
    const OUR = ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'ControlLeft', 'ControlRight', 'KeyC', 'ShiftLeft', 'ShiftRight', 'KeyR'];
    H3._kd = e => {
      if (!H3.on) return;
      if (e.code === 'Escape') { if (typing()) { document.activeElement.blur(); return; } if (modalOpen()) return; e.preventDefault(); e.stopPropagation(); H3.close(); return; }
      if (typing() || modalOpen()) return;
      if (OUR.includes(e.code) || (e.ctrlKey && /^Key/.test(e.code))) { if (e.code === 'KeyR' && !e.repeat) H3.rotate(); keys[e.code] = true; e.preventDefault(); e.stopPropagation(); }
    };
    H3._ku = e => { keys[e.code] = false; if (!e.ctrlKey) keys.ControlLeft = keys.ControlRight = false; };
    H3._blur = () => { for (const k in keys) keys[k] = false; };
    window.addEventListener('keydown', H3._kd, true); window.addEventListener('keyup', H3._ku, true); window.addEventListener('blur', H3._blur);
    let rmb = false;
    const ndc = e => { const r = cv.getBoundingClientRect(); if (!r.width) return; mouse.x = (e.clientX - r.left) / r.width * 2 - 1; mouse.y = -((e.clientY - r.top) / r.height) * 2 + 1; };
    cv.addEventListener('contextmenu', e => e.preventDefault());
    cv.addEventListener('mousedown', e => { if (typing()) document.activeElement.blur(); cv.focus({ preventScroll: true }); if (e.button === 2) { rmb = true; try { cv.requestPointerLock(); } catch (x) { } } if (e.button === 0) { ndc(e); H3.grab(); } e.preventDefault(); });
    H3._mu = e => { if (e.button === 2 && rmb) { rmb = false; try { document.exitPointerLock(); } catch (x) { } } if (e.button === 0 && drag) H3.release(); };
    window.addEventListener('mouseup', H3._mu);
    H3._mm = e => { if (rmb) { yaw -= e.movementX * 0.005; pitch = E.clamp(pitch + e.movementY * 0.004, -0.35, 1.25); } };
    window.addEventListener('mousemove', H3._mm);
    cv.addEventListener('mousemove', e => { if (!rmb) ndc(e); });
    cv.addEventListener('wheel', e => { if (drag && !props[drag.i].heavy) drag.d = E.clamp(drag.d - Math.sign(e.deltaY) * 0.3, 1, 5); else dist = E.clamp(dist + Math.sign(e.deltaY) * 0.5, 1.2, 12); e.preventDefault(); }, { passive: false });
    ov.querySelector('#h3x').onclick = () => H3.close();
    const hb = ov.querySelector('#h3home'); if (hb) hb.onclick = () => { spawnHome(); cv.focus(); };
    const inv = ov.querySelector('#h3inv'); if (inv) inv.onchange = () => { if (inv.value) { H3.invite(inv.value); inv.value = ''; } };
    if (typeof SFX !== 'undefined') SFX.play('open');
    try { UI.mapBtns(); UI.quick(); } catch (e) { }
    cv.focus({ preventScroll: true });
    let last = 0; const loop = t => { if (!H3.on) return; raf = requestAnimationFrame(loop); if (H3.fpsCap && t - last < 1000 / H3.fpsCap) return; last = t; H3.step(Math.min(0.05, clock.getDelta())); R.render(scene, cam); };
    loop(0);
  };
  H3.close = quiet => {
    if (!H3.on) return;
    if (drag) H3.release();
    saveLayout(true);
    H3.net({ k: 'bye' });
    H3.on = false; cancelAnimationFrame(raf);
    window.removeEventListener('keydown', H3._kd, true); window.removeEventListener('keyup', H3._ku, true); window.removeEventListener('mouseup', H3._mu); window.removeEventListener('mousemove', H3._mm); window.removeEventListener('blur', H3._blur);
    try { H3._ro.disconnect(); } catch (e) { }
    try { document.exitPointerLock(); } catch (e) { }
    try { scene.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) { if (o.material.map) o.material.map.dispose(); if (o.material.dispose) o.material.dispose(); } }); R.dispose(); } catch (e) { }
    for (const k in MATS) delete MATS[k];
    if (ov) ov.remove(); ov = null; for (const k in keys) keys[k] = false;
    grid = new Map(); props.length = 0; doors.length = 0; walkers.length = 0; cars.length = 0; jets.length = 0;
    const host = document.querySelector('.mapwrap'); if (host) host.classList.remove('h3'); document.documentElement.classList.remove('h3on');
    if (!quiet) { try { UI.mapBtns(); UI.quick(); } catch (e) { } if (typeof SFX !== 'undefined') SFX.play('close'); }
  };

  // ---------- ЛКМ: тащить мебель и предметы ----------
  const rayFromMouse = () => { if (!RC) RC = new T.Raycaster(); RC.setFromCamera(mouse, cam); return RC; };
  H3.grab = () => {
    const rc = rayFromMouse();
    const nearProps = props.filter(p => p.g.position.distanceTo(me.pos) < 9);
    const objs = nearProps.map(p => p.g), hits = rc.intersectObjects(objs, true);
    for (const u in remotes) { const r = remotes[u], hit = rc.intersectObject(r.p.g, true); if (hit.length && (!hits.length || hit[0].distance < hits[0].distance) && r.p.pos.distanceTo(me.pos) < 2.4) { const f = r.p.pos.clone().sub(me.pos).setY(0).normalize(); H3.net({ k: 'hit', to: u, v: [f.x * 6, 3, f.z * 6] }); me.push = 0.25; return; } }
    if (!hits.length) return;
    let o = hits[0].object; while (o.parent && !objs.includes(o)) o = o.parent;
    const p = nearProps[objs.indexOf(o)]; if (!p) return;
    if (p.held && p.held !== 'me') { H3.say('Это сейчас двигает другой игрок'); return; }
    if (p.g.position.distanceTo(v3(me.pos.x, me.pos.y + 1, me.pos.z)) > (p.heavy ? 4.6 : 4.2)) { H3.say('Слишком далеко — подойдите ближе'); return; }
    p.held = 'me'; p.v.set(0, 0, 0); p.w3.set(0, 0, 0); p.flying = false;
    drag = { i: props.indexOf(p), d: E.clamp(hits[0].distance, 1.2, 4.5), vel: v3(0, 0, 0), prev: p.g.position.clone(), off: hits[0].point.clone().sub(p.g.position).setY(0) };
    H3.net({ k: 'act', a: 'grab', id: p.key });
    if (typeof SFX !== 'undefined') SFX.play('tab');
  };
  H3.rotate = () => { if (!drag) return; const p = props[drag.i]; p.ry += Math.PI / 2; p.g.rotation.y = p.ry; if (p.heavy) { hbox(p); moveHeavy(p, 0, 0); } };
  H3.release = () => {
    if (!drag) return;
    const p = props[drag.i]; drag = null; if (!p) return;
    const v = H3._lastVel ? H3._lastVel.clone() : v3(0, 0, 0); if (v.length() > 15) v.setLength(15);
    const throwable = !p.heavy || p.m <= 12;
    if (!throwable) v.set(0, 0, 0); else if (v.length() > 3) v.y += 1;
    p.held = ''; p.still = 0; p.thrower = 'me'; p.moved = true;
    p.v.copy(v); if (v.length() > 3 && !p.heavy) p.w3.set(Math.random() * 10 - 5, Math.random() * 10 - 5, Math.random() * 10 - 5); p.flying = p.heavy && v.lengthSq() > 0.01;
    p.tgt = p.g.position.clone(); p.tr = [p.g.rotation.x, p.g.rotation.y, p.g.rotation.z];
    const q = p.g.position;
    H3.net({ k: 'act', a: 'drop', id: p.key, p: [q.x, q.y, q.z], r: p.ry, v: [p.v.x, p.v.y, p.v.z] });
    if (v.length() > 6 && typeof SFX !== 'undefined') SFX.play('send');
    noteMoved(p);
  };
  // перестановку запоминают хозяева квартиры (в своём сохранении)
  const noteMoved = p => { const k = H3.hh(UI.s); if (k && p.key.startsWith(k + ':')) dirty = true; };
  const saveLayout = force => {
    const s = UI.s, k = H3.hh(s); if (!s || !k || (!dirty && !force)) return;
    const L0 = s.home.layout = s.home.layout || {}; let n = 0;
    for (const p of props) if (p.key.startsWith(k + ':') && (p.moved || L0[p.key.split(':').pop()])) { const [lx, lz] = tinv(p.t, p.g.position.x, p.g.position.z); const a = p.t.mx ? -(p.ry + p.t.rot * Math.PI / 2) : p.ry + p.t.rot * Math.PI / 2; L0[p.key.split(':').pop()] = [+lx.toFixed(2), +lz.toFixed(2), +a.toFixed(3), +(p.g.position.y - p.t.y).toFixed(2)]; n++; }
    if (!n) delete s.home.layout;
    if (dirty) { dirty = false; try { UI.save(); } catch (e) { } }
  };
  H3.resetLayout = () => { const s = UI.s; if (s && s.home) { delete s.home.layout; UI.save(); } if (H3.on) buildHomes(); };
  const moveHeavy = (p, dx, dz) => {
    const pos = p.g.position; pos.x += dx; pos.z += dz; hbox(p);
    for (let it = 0; it < 4; it++) {
      const b = p.box, cand = near(b.x0 - 0.2, b.z0 - 0.2, b.x1 + 0.2, b.z1 + 0.2).concat(heavyBoxes((b.x0 + b.x1) / 2, (b.z0 + b.z1) / 2, Math.max(b.x1 - b.x0, b.z1 - b.z0)));
      let moved = false;
      for (const c of cand) {
        if (c === b || c.nocol) continue;
        if (!(b.y0 < c.y1 - 0.05 && b.y1 > c.y0 + 0.05)) continue;
        if (!c.wall && c.y1 <= b.y0 + 0.08) continue;
        const ox = Math.min(b.x1, c.x1) - Math.max(b.x0, c.x0), oz = Math.min(b.z1, c.z1) - Math.max(b.z0, c.z0);
        if (ox <= 0 || oz <= 0) continue;
        if (ox < oz) pos.x += ((b.x0 + b.x1) / 2 < (c.x0 + c.x1) / 2 ? -1 : 1) * ox; else pos.z += ((b.z0 + b.z1) / 2 < (c.z0 + c.z1) / 2 ? -1 : 1) * oz;
        hbox(p); moved = true;
      }
      if (!moved) break;
    }
    if (!p.flying) { pos.y = p.floor; hbox(p); }
    const q = { x: me.pos.x, y: me.pos.y, z: me.pos.z }; push(q, R0, 1.8); me.pos.x = q.x; me.pos.z = q.z;
    p.moved = true;
  };

  // ============================== КАДР ==============================
  const master = () => { let m = uidMe(); for (const u in remotes) if (u < m) m = u; return m === uidMe(); };
  H3.step = dt => {
    const tnow = Date.now() / 1000;
    const crouch = !!(keys.ControlLeft || keys.ControlRight || keys.KeyC), run = (keys.ShiftLeft || keys.ShiftRight) && !crouch, sp = crouch ? 1.8 : run ? 6.5 : 3.8;
    let mx = 0, mz = 0;
    if (keys.KeyW || keys.ArrowUp) mz -= 1; if (keys.KeyS || keys.ArrowDown) mz += 1; if (keys.KeyA || keys.ArrowLeft) mx -= 1; if (keys.KeyD || keys.ArrowRight) mx += 1;
    const moving = !!(mx || mz);
    if (moving) { const l = Math.hypot(mx, mz); mx /= l; mz /= l; const s = Math.sin(yaw), c = Math.cos(yaw); const wx = mx * c + mz * s, wz = -mx * s + mz * c; me.pos.x += wx * sp * dt; me.pos.z += wz * sp * dt; const ty = Math.atan2(wx, wz); let d = ty - me.ry; d = Math.atan2(Math.sin(d), Math.cos(d)); me.ry += d * Math.min(1, dt * 12); }
    me.pos.x += me.kb.x * dt; me.pos.z += me.kb.z * dt; me.kb.multiplyScalar(Math.max(0, 1 - dt * 4));
    if (keys.Space && me.ground) { me.vy = crouch ? 3.6 : 5.2; me.ground = false; }
    me.vy -= 14 * dt; me.pos.y += me.vy * dt;
    const gy = groundAt(me.pos.x, me.pos.z, me.pos.y, R0 * 0.7), tall = crouch ? 1.45 : 1.9;
    if (me.pos.y <= gy) { me.pos.y = gy; me.vy = 0; me.ground = true; } else me.ground = me.pos.y - gy < 0.02;
    const cy = ceilAt(me.pos.x, me.pos.z, me.pos.y, R0 * 0.6); if (me.pos.y + tall > cy) { me.pos.y = Math.max(gy, cy - tall); me.vy = Math.min(0, me.vy); }
    push(me.pos, R0, tall - 0.1);
    me.pos.x = E.clamp(me.pos.x, -WORLD, WORLD); me.pos.z = E.clamp(me.pos.z, -WORLD, WORLD);
    if (me.pos.y < -5) { me.pos.set(0, 0.2, 15); me.vy = 0; }
    animate(me, dt, moving, run, crouch, !!drag);
    if (me.push > 0) { me.push -= dt; me.ra.rotation.x = -1.6; }
    for (const c of cars) { const dx = me.pos.x - c.x, dz = me.pos.z - c.z, ca = Math.cos(c.a), sa = Math.sin(c.a), lx = dx * ca - dz * sa, lz = dx * sa + dz * ca; if (Math.abs(lx) < 1.25 && Math.abs(lz) < 2.4 && me.pos.y < 1.5) { me.kb.set(Math.sin(c.a) * 9 + Math.sign(lx || 1) * ca * 4, 0, Math.cos(c.a) * 9 - Math.sign(lx || 1) * sa * 4); me.vy = 4; me.ground = false; H3.say('Осторожно, машина!'); } }
    for (const w of walkers) { if (w.x > 900) continue; const dx = me.pos.x - w.x, dz = me.pos.z - w.z, d = Math.hypot(dx, dz); if (d < 0.6 && d > 1e-3 && me.pos.y < 1) { me.pos.x = w.x + dx / d * 0.6; me.pos.z = w.z + dz / d * 0.6; } }
    // камера: не уходит за стены
    const tgt = v3(me.pos.x, me.pos.y + 1.55 - CR * me.cr, me.pos.z);
    const off = v3(Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
    let d = dist; for (let k = 0.3; k <= dist; k += 0.2) if (camBlocked(tgt.x + off.x * k, tgt.y + off.y * k, tgt.z + off.z * k)) { d = Math.max(0.3, k - 0.3); break; }
    const cp = tgt.clone().addScaledVector(off, d); if (cp.y < 0.25) cp.y = 0.25;
    cam.position.lerp(cp, Math.min(1, dt * 18)); cam.lookAt(tgt); cam.updateMatrixWorld();
    me.g.visible = d > 0.75;
    stepTraffic(dt, tnow);
    // тащим
    if (drag) {
      const p = props[drag.i], r = rayFromMouse(), pos = p.g.position;
      if (p.heavy) {
        const dir = r.ray.direction;
        if (Math.abs(dir.y) > 0.02) { const k = (p.floor + 0.3 - r.ray.origin.y) / dir.y; if (k > 0) {
          const want = r.ray.origin.clone().addScaledVector(dir, Math.min(k, 9)).sub(drag.off), rel = v3(want.x - me.pos.x, 0, want.z - me.pos.z); if (rel.length() > 3.2) { rel.setLength(3.2); want.x = me.pos.x + rel.x; want.z = me.pos.z + rel.z; }
          const spd = Math.max(1.2, 9 / Math.sqrt(p.m)) * dt, mv = v3(want.x - pos.x, 0, want.z - pos.z); if (mv.length() > spd) mv.setLength(spd);
          moveHeavy(p, mv.x, mv.z);
        } }
      } else {
        const want = r.ray.origin.clone().addScaledVector(r.ray.direction, drag.d), body = v3(me.pos.x, me.pos.y + 1.1, me.pos.z), rel = want.clone().sub(body); if (rel.length() > 3) want.copy(body).addScaledVector(rel.normalize(), 3);
        pos.lerp(want, Math.min(1, dt * 16));
        const q = { x: pos.x, y: pos.y - p.r, z: pos.z }; push(q, p.r, p.r * 2); pos.x = q.x; pos.z = q.z;
        const fy = groundAt(pos.x, pos.z, pos.y - p.r, p.r * 0.6) + p.r * 0.5, cy2 = ceilAt(pos.x, pos.z, pos.y, p.r * 0.5); pos.y = Math.min(Math.max(pos.y, fy), cy2 - p.r);
        p.g.rotation.x *= 0.9; p.g.rotation.z *= 0.9;
      }
      const inst = pos.clone().sub(drag.prev).divideScalar(Math.max(dt, 1e-3)); drag.vel.lerp(inst, Math.min(1, dt * 14)); drag.prev.copy(pos); H3._lastVel = drag.vel;
      const fy2 = Math.atan2(pos.x - me.pos.x, pos.z - me.pos.z); let dd = fy2 - me.ry; dd = Math.atan2(Math.sin(dd), Math.cos(dd)); me.ry += dd * Math.min(1, dt * 8);
    } else H3._lastVel = null;
    const M = master();
    // физика (считает «главный» игрок; если вы одни — вы)
    for (const p of props) {
      if (p.held === 'me') continue;
      if (p.held && remotes[p.held]) { const r = remotes[p.held]; if (r.hp && r.hid === p.key) { p.g.position.lerp(v3(r.hp[0], r.hp[1], r.hp[2]), Math.min(1, dt * 15)); if (r.hr !== undefined) { p.ry = r.hr; p.g.rotation.y = p.ry; } if (p.heavy) hbox(p); } continue; }
      if (!M) { if (p.tgt) { const k = Math.min(1, dt * 12); p.g.position.lerp(p.tgt, k); p.g.rotation.x += (p.tr[0] - p.g.rotation.x) * k; p.g.rotation.y += (p.tr[1] - p.g.rotation.y) * k; p.g.rotation.z += (p.tr[2] - p.g.rotation.z) * k; if (p.heavy) { p.ry = p.g.rotation.y; hbox(p); } } continue; }
      if (p.heavy && !p.flying) continue;
      if (p.still > 1.5 && p.v.lengthSq() < 0.01) continue;
      p.v.y -= 14 * dt;
      const pos = p.g.position; pos.addScaledVector(p.v, dt); p.moved = true;
      if (!p.heavy) { p.g.rotation.x += p.w3.x * dt; p.g.rotation.y += p.w3.y * dt; p.g.rotation.z += p.w3.z * dt; }
      const rr = p.heavy ? 0.3 : p.r, fy = p.heavy ? groundAt(pos.x, pos.z, pos.y, 0.2, p.box) : groundAt(pos.x, pos.z, pos.y - p.r, p.r * 0.6) + p.r * 0.5;
      if (pos.y < fy) { pos.y = fy; if (p.v.y < -1.5 && !p.heavy) p.v.y *= -0.35; else p.v.y = 0; p.v.x *= 0.8; p.v.z *= 0.8; p.w3.multiplyScalar(0.7); if (!p.heavy) { p.g.rotation.x *= 0.85; p.g.rotation.z *= 0.85; } else if (p.v.lengthSq() < 0.05) { p.flying = false; p.v.set(0, 0, 0); p.floor = fy; } }
      const cy3 = ceilAt(pos.x, pos.z, pos.y, rr * 0.5), top = p.heavy ? p.h : p.r; if (pos.y + top > cy3) { pos.y = cy3 - top; p.v.y = -Math.abs(p.v.y) * 0.4; }
      if (p.heavy) moveHeavy(p, 0, 0);
      else { const bx = pos.x, bz = pos.z, q = { x: pos.x, y: pos.y - p.r, z: pos.z }; push(q, p.r, p.r * 2); pos.x = q.x; pos.z = q.z; if (Math.abs(q.x - bx) > 1e-4) p.v.x *= -0.4; if (Math.abs(q.z - bz) > 1e-4) p.v.z *= -0.4; }
      const sp2 = p.v.length();
      if (sp2 > 4) {
        const hitP = (P, who) => { if (Math.hypot(pos.x - P.pos.x, pos.z - P.pos.z) < R0 + rr && pos.y > P.pos.y - 0.2 && pos.y < P.pos.y + 1.9) { const k = v3(p.v.x, 0, p.v.z).normalize().multiplyScalar(Math.min(7, sp2 * 0.5 * Math.min(p.m, 6))); if (who) H3.net({ k: 'hit', to: who, v: [k.x, 2, k.z], n: p.n }); else { me.kb.add(k); me.vy = Math.max(me.vy, 1.5); H3.say('Ай! ' + p.n); } p.v.multiplyScalar(-0.3); } };
        if (p.thrower !== 'me') hitP(me, null);
        for (const u in remotes) if (p.thrower !== u) hitP(remotes[u].p, u);
      }
      if (p.v.lengthSq() < 0.02 && pos.y <= fy + 0.01) { p.still += dt; if (p.still > 1.2 && p.still - dt <= 1.2) noteMoved(p); } else p.still = 0;
    }
    if (M) { const vac = props.find(p => p.n === 'Робот-пылесос' && !p.held); if (vac && vac.g.position.y - vac.floor < 0.1) { vac.dir = (vac.dir || 0) + (Math.random() - 0.5) * dt * 2; const q = { x: vac.g.position.x + Math.sin(vac.dir) * dt * 0.6, y: vac.g.position.y, z: vac.g.position.z + Math.cos(vac.dir) * dt * 0.6 }, x0 = q.x, z0 = q.z; push(q, 0.2, 0.1); if (Math.abs(q.x - x0) + Math.abs(q.z - z0) > 1e-4) vac.dir += Math.PI * 0.7; vac.g.position.x = q.x; vac.g.position.z = q.z; vac.still = 0; vac.moved = true; } }
    // двери
    let doorHint = '';
    for (const d of doors) {
      const dm = Math.hypot(me.pos.x - d.x, me.pos.z - d.z); if (dm > 40) continue;
      const same = y => Math.abs(y - d.y) < 1.6;
      let want = false;
      if (!d.locked) {
        if (dm < 2.0 && same(me.pos.y)) want = true;
        for (const u in remotes) { const p = remotes[u].p; if (Math.hypot(p.pos.x - d.x, p.pos.z - d.z) < 2.0 && same(p.pos.y)) want = true; }
        if (d.kind === 'shop' || d.kind === 'entrance') for (const w of walkers) if (Math.hypot(w.x - d.x, w.z - d.z) < 2.4) want = true;
        if (dm < 2.4 && d.owners && same(me.pos.y)) doorHint = d.mine ? 'Ваш дом' : 'Здесь живёт: ' + d.owners;
      } else if (dm < 1.6 && same(me.pos.y)) doorHint = d.kind === 'house' ? 'Закрыто: здесь живут соседи' : d.kind === 'flat' ? 'Квартира соседей — закрыто' : 'Закрыто';
      if (!want && d.open > 0.05 && dm < 0.9) want = true;
      const o2 = d.open + ((want ? 1 : 0) - d.open) * Math.min(1, dt * 6);
      if (Math.abs(o2 - d.open) > 1e-4) { d.open = o2; d.piv.rotation.y = -o2 * 1.45; }
      d.box.off = d.open > 0.35;
    }
    for (const u in remotes) { const r = remotes[u], p = r.p; p.pos.lerp(r.tgt, Math.min(1, dt * 12)); let dd = r.ry - p.ry; dd = Math.atan2(Math.sin(dd), Math.cos(dd)); p.ry += dd * Math.min(1, dt * 12); p.ground = r.gr !== 0; animate(p, dt, r.mv, r.run, r.cr, r.hold); if (Date.now() - r.t > 8000) { scene.remove(p.g); delete remotes[u]; H3.who(); } }
    let h = '';
    if (typing()) h = 'Кликните по экрану, чтобы снова ходить';
    else if (drag) { const p = props[drag.i]; h = p.heavy ? (p.m <= 12 ? p.n + ': тащите мышкой, R — повернуть, отпустите с размахом — полетит' : p.n + ': тащите мышкой, R — повернуть') : 'Отпустите ЛКМ с размахом мыши — «' + p.n + '» полетит'; }
    else if (H3._sayT > performance.now()) h = H3._say;
    else if (doorHint) h = doorHint;
    if (h !== hint) { hint = h; const el = document.getElementById('h3hint'); if (el) { el.textContent = h; el.style.opacity = h ? 1 : 0; } }
    if (++chk % 30 === 0) { const w = document.getElementById('h3where'); if (w) w.textContent = where(); if (chk % 150 === 0) { if (homesSig(H3.households()) !== sig) buildHomes(); saveLayout(); } }
    const now = performance.now();
    if (net()) {
      if (now - sendT > 100) { sendT = now; const dp = drag ? props[drag.i] : null; H3.net({ k: 'p', n: UI.s.ch.name, l: looks(UI.s.ch.name + UI.s.ch.surname), x: +me.pos.x.toFixed(2), y: +me.pos.y.toFixed(2), z: +me.pos.z.toFixed(2), r: +me.ry.toFixed(2), m: moving ? 1 : 0, u2: run ? 1 : 0, c: crouch ? 1 : 0, hid: dp ? dp.key : '', hp: dp ? [+dp.g.position.x.toFixed(2), +dp.g.position.y.toFixed(2), +dp.g.position.z.toFixed(2)] : null, hr: dp ? +dp.ry.toFixed(3) : undefined, g: me.ground ? 1 : 0 }); }
      if (M && Object.keys(remotes).length && now - propT > 120) { propT = now; const full = now - fullT > 3000; if (full) fullT = now; const a = []; for (const p of props) { if ((full && p.moved) || p.still < 1.5 || p.held || p.flying) { const q = p.g.position, r = p.g.rotation; a.push([p.key, +q.x.toFixed(2), +q.y.toFixed(2), +q.z.toFixed(2), +r.x.toFixed(2), +r.y.toFixed(3), +r.z.toFixed(2), p.held === 'me' ? NET.uid : p.held || '']); } } for (let i = 0; i < a.length; i += 40) H3.net({ k: 'pr', a: a.slice(i, i + 40) }); }
    }
  };
  const where = () => {
    const x = me.pos.x, z = me.pos.z;
    for (let b = 0; b < 4; b++) { const [lx, lz] = tinv(BLD[b], x, z); if (lx > -26 && lx < 18 && lz > -16 && lz < 16) { const f = Math.max(0, Math.floor((me.pos.y + 0.6) / FH)); let u = -1; FLATS.forEach((ft, i) => { const [a, c] = tinv(ft, lx, lz); if (Math.abs(a) < 9 && Math.abs(c) < 7) u = i; }); if (u >= 0) { const d = doors.find(d => d.kind === 'flat' && d.slot[0] === b && d.slot[1] === f && d.slot[2] === u); if (d && d.owners) return (d.mine ? 'Ваша квартира' : 'В гостях: ' + d.owners) + ' · дом ' + (b + 1) + ', кв. ' + (f * 4 + u + 1); } return 'Дом ' + (b + 1) + (lx < -18 ? ', подъезд' : '') + ', ' + (f + 1) + ' этаж'; } }
    for (let k = 0; k < 4; k++) for (let i = 0; i < 14; i++) { const [lx, lz] = tinv(houseTF(k, i), x, z); if (Math.abs(lx) < 9 && Math.abs(lz) < 7) { const d = doors.find(d => d.kind === 'house' && d.slot[1] === k && d.slot[2] === i); return (d && d.owners ? (d.mine ? 'Ваш дом' : 'В гостях: ' + d.owners) + ' · ' : '') + 'ул. ' + STREETS[k] + ', ' + (i + 1); } }
    for (const [n, sx, sz] of SHOPS) if (Math.abs(x - sx) < 4.6 && Math.abs(z - sz) < 4.6) return 'Магазин «' + n.replace(/«|»/g, '') + '»';
    if (Math.abs(x) < 26 && Math.abs(z) < 26) return 'Площадь с фонтаном';
    if (Math.abs(x) < 40 && Math.abs(z) < 40) return 'Кольцевая';
    for (let k = 0; k < 4; k++) { const [lx, lz] = tinv(TF(0, 0, 0, k, false), x, z); if (Math.abs(lx) < 30 && lz < -40 && lz > -230) return 'ул. ' + STREETS[k]; }
    return 'Город';
  };
  H3._st = () => ({ me, props, remotes, drag, doors, walkers, cars, homes, set: (x, z, y, yw) => { me.pos.set(x, y || 0, z); me.vy = 0; if (yw !== undefined) yaw = yw; }, setPitch: p => { pitch = p; }, setDist: d => { dist = d; }, where, tp, tinv, BLD, FLATS, flatTF, houseTF, myAddr, addrTF, buildHomes, sig: () => sig });
  H3._scr = n => { const p = typeof n === 'string' ? props.filter(q => q.n === n).sort((a, b) => a.g.position.distanceTo(me.pos) - b.g.position.distanceTo(me.pos))[0] : n; if (!p) return null; const v = p.g.position.clone(); v.y += p.heavy ? p.h / 2 : 0; v.project(cam); const r = R.domElement.getBoundingClientRect(); return { key: p.key, i: props.indexOf(p), x: r.left + (v.x + 1) / 2 * r.width, y: r.top + (1 - v.y) / 2 * r.height }; };
  H3.say = t => { H3._say = t; H3._sayT = performance.now() + 2500; };
  H3.who = () => { const el = document.getElementById('h3who'); if (el) el.textContent = Object.keys(remotes).length ? 'рядом: ' + Object.values(remotes).map(r => r.n).join(', ') : ''; };

  // ============================== СЕТЬ ==============================
  H3.net = d => { if (!net()) return; d.u = NET.uid; d.sid = 'city'; NET.A.h3(d); };
  H3.invite = uid => { const s = UI.s; H3.net({ k: 'inv', to: uid, from: s.ch.name + ' ' + s.ch.surname, at: [+me.pos.x.toFixed(2), +me.pos.y.toFixed(2), +me.pos.z.toFixed(2)], where: where() }); UI.toast('Приглашение отправлено'); };
  H3.onNet = d => {
    if (!d || d.u === NET.uid) return;
    if (d.k === 'inv') { if (d.to !== NET.uid) return; UI.appendMsg({ k: 'out', ok: true, title: d.from + ' зовёт в гости', lines: [(d.where || 'Город') + '. Нажмите «Войти в гости» — окажетесь рядом с ним в 3D.'], h3inv: { at: d.at, from: d.u } }); if (typeof SFX !== 'undefined') SFX.play('event'); return; }
    if (!H3.on) return;
    if (d.k === 'p') {
      let r = remotes[d.u];
      if (!r) { const l = d.l || looks(d.n || '?'); const p = H3.person(l[0], l[1], l[2], d.n, l[3]); scene.add(p.g); r = remotes[d.u] = { p, tgt: v3(d.x, d.y, d.z), ry: d.r, n: d.n }; p.pos.set(d.x, d.y, d.z); H3.who(); H3.say(d.n + ' в городе'); fullT = 0; }
      r.tgt.set(d.x, d.y, d.z); r.ry = d.r; r.mv = !!d.m; r.run = !!d.u2; r.cr = !!d.c; r.hold = !!d.hid; r.hid = d.hid; r.hp = d.hp; r.hr = d.hr; r.gr = d.g; r.t = Date.now();
      for (const p of props) if (p.held === d.u && p.key !== d.hid) p.held = '';
      if (d.hid && PID[d.hid] && !PID[d.hid].held) PID[d.hid].held = d.u;
      return;
    }
    if (d.k === 'bye') { const r = remotes[d.u]; if (r) { scene.remove(r.p.g); delete remotes[d.u]; H3.who(); H3.say(r.n + ' ушёл из города'); } for (const p of props) if (p.held === d.u) p.held = ''; return; }
    if (d.k === 'pr') { if (master()) return; for (const [key, x, y, z, rx, ry, rz, h] of d.a) { const p = PID[key]; if (!p || p.held === 'me') continue; p.tgt = v3(x, y, z); p.tr = [rx, ry, rz]; p.held = h === NET.uid ? '' : h || ''; p.moved = true; noteMoved(p); } return; }
    if (d.k === 'act') { const p = PID[d.id]; if (!p) return; if (d.a === 'grab') { if (!p.held) p.held = d.u; } if (d.a === 'drop') { if (p.held === d.u) p.held = ''; p.g.position.set(d.p[0], d.p[1], d.p[2]); p.tgt = p.g.position.clone(); p.ry = d.r; p.g.rotation.y = d.r; p.tr = [0, d.r, 0]; p.v.set(d.v[0], d.v[1], d.v[2]); p.still = 0; p.thrower = d.u; p.moved = true; if (p.heavy) { hbox(p); p.flying = p.v.lengthSq() > 0.01; } else if (p.v.length() > 3) p.w3.set(Math.random() * 8 - 4, Math.random() * 8 - 4, Math.random() * 8 - 4); noteMoved(p); } return; }
    if (d.k === 'hit' && d.to === NET.uid) { me.kb.add(v3(d.v[0], 0, d.v[2])); me.vy = Math.max(me.vy, d.v[1]); me.ground = false; H3.say(d.n ? 'Ай! В вас прилетело: ' + d.n.toLowerCase() : 'Вас толкнули!'); return; }
  };
  document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('[data-h3inv]'); if (!b) return; try { const sp = JSON.parse(decodeURIComponent(b.dataset.h3inv)); if (!net() || !NET.byUid(sp.from)) { UI.toast('Друга уже нет в сети', 'bad'); return; } if (!H3.walk(UI.s)) { UI.toast('Сейчас не получится', 'bad'); return; } UI.closeModal(); if (H3.on && me) { me.pos.set(sp.at[0] + 0.8, sp.at[1] + 0.1, sp.at[2] + 0.8); return; } H3.open({ at: sp.at }); } catch (x) { console.warn(x); } });

  // ============================== ВХОД ==============================
  H3.enter = () => { const s = UI.s; if (!H3.can(s)) { UI.toast('Зайти домой можно в своё или съёмное жильё — не к родителям', 'bad'); return; } UI.closeModal(); H3.open({}); };
  H3.city = () => { const s = UI.s; if (!H3.walk(s)) { UI.toast('Сейчас не получится выйти в город', 'bad'); return; } UI.closeModal(); H3.open({ plaza: true }); };
  H3.toggle = () => H3.on ? H3.close() : (H3.can(UI.s) ? H3.enter() : H3.city());
  document.addEventListener('DOMContentLoaded', () => {
    // данные о доме — в «визитку» игрока, чтобы друзья видели вашу квартиру и табличку
    if (typeof NET !== 'undefined' && NET.me) { const _me = NET.me; NET.me = () => { const o = _me(); try { if (UI.s) o.h3 = H3.info(UI.s); } catch (e) { } return o; }; }
    // «Сдать другу квартиру» — отдельная квартира, а не та, где живёт хозяин
    if (typeof IA !== 'undefined' && IA.DEFS) { const d = IA.DEFS.find(x => x.id === 'rentflat'); if (d && d.onAccept) { const _a = d.onAccept; d.onAccept = (s, f, dd, from) => { const r = _a(s, f, dd, from); if (s.home) s.home.hh = 'r:' + from.uid + ':' + (f.pi != null ? f.pi : dd.n); return r; }; } }
    if (typeof U !== 'undefined' && U.home) { const _h = U.home; U.home = tab => { _h(tab); if (H3.can(UI.s) && !H3.on) { const hd = document.querySelector('#modal .mhead'); if (hd && !hd.querySelector('.h3btn')) { const b = document.createElement('button'); b.className = 'btn small primary h3btn'; b.innerHTML = UI.ic('home') + 'Зайти домой (3D)'; b.onclick = () => H3.enter(); hd.insertBefore(b, hd.querySelector('.close')); if (UI.s.home.layout) { const r = document.createElement('button'); r.className = 'btn small h3btn2'; r.textContent = 'Вернуть мебель на места'; r.onclick = () => { H3.resetLayout(); r.remove(); UI.toast('Мебель вернулась на свои места'); }; hd.insertBefore(r, hd.querySelector('.close')); } } } }; }
    if (typeof UI !== 'undefined' && UI.quick) { const _q = UI.quick; UI.quick = () => { _q(); const q = document.getElementById('quick'); if (q && UI.s && (H3.can(UI.s) || H3.on) && !q.querySelector('.h3q')) { const b = document.createElement('button'); b.className = 'h3q'; b.textContent = H3.on ? '🗺 На карту' : '🏠 Зайти домой'; b.onclick = () => H3.toggle(); q.insertBefore(b, q.firstChild); } }; }
    if (typeof UI !== 'undefined' && UI.mapBtns) { const _b = UI.mapBtns; UI.mapBtns = () => { _b(); const el = document.getElementById('mapbtns'); if (!el || !UI.s) return; el.querySelectorAll('.mb-h3').forEach(x => x.remove()); if (!H3.on && !H3.walk(UI.s)) return; const b = document.createElement('button'); b.className = 'mb-h3'; const home = H3.can(UI.s); b.innerHTML = H3.on ? `${UI.ic('globe')}<span><b>На карту</b><small>выйти из города · Esc</small></span>` : home ? `${UI.ic('home')}<span><b>Зайти домой</b><small>3D-город: дом, улицы, друзья</small></span>` : `${UI.ic('home')}<span><b>Выйти в город</b><small>3D: площадь, магазины, друзья</small></span>`; b.onclick = () => H3.toggle(); el.insertBefore(b, el.firstChild); }; }
    if (typeof UI !== 'undefined' && UI.msgHtml) { const _m = UI.msgHtml; UI.msgHtml = m => { let h = _m(m); if (m && m.h3inv) h = h.replace(/<\/div>\s*$/, `<button class="btn small primary" data-h3inv="${encodeURIComponent(JSON.stringify(m.h3inv))}">🏠 Войти в гости</button></div>`); return h; }; }
    if (typeof UI !== 'undefined' && UI.game) { const _g = UI.game; UI.game = (...a) => { H3.close(true); return _g(...a); }; }
  });
})();
