// «Судьба» — окно «Правительство» и кнопка «Власть» на карте.
'use strict';
const GOVUI = { tab: 'over', ci: -1, prop: '' };
(() => {
  const pct = v => GOV.fmtPct(v);
  const bar = (v, col) => `<i class="gbar"><em style="width:${E.clamp(v, 0, 100)}%;${col ? 'background:' + col : ''}"></em></i>`;
  const fxTxt = fx => Object.entries(fx || {}).map(([k, v]) => ({ gr: 'рост', infl: 'инфляция', stab: 'стабильность', appr: 'популярность', mp: 'резерв ×', trade: 'торговля ×', pc: 'капитал/мес', crime: 'давление на преступников', west: 'отношения с Западом' }[k] + ' ' + (k === 'mp' || k === 'trade' ? v : (v > 0 ? '+' : '') + v))).join(', ') || 'без эффектов';
  const s_ = () => UI.s;
  GOVUI.TABS = [['over', 'Обзор', 'flag'], ['laws', 'Законы', 'book'], ['budget', 'Бюджет', 'coin'], ['min', 'Министры', 'user'], ['eco', 'Ресурсы и торговля', 'factory'], ['dip', 'Дипломатия', 'globe'], ['army', 'Армия', 'shield']];
  GOVUI.open = (tab, ci) => {
    const s = s_(); if (!E.isLeader(s)) { UI.toast('Правительство — у главы государства', 'bad'); return; }
    const G = GOV.ensure(s); ARMY.op('seed', { c: s.world.home });
    if (tab) GOVUI.tab = tab; if (ci !== undefined) GOVUI.ci = ci;
    const C = s.world.cs[s.world.home];
    const body = GOVUI['t_' + GOVUI.tab](s, G, C);
    U.big(`${U.head('globe', 'Правительство · ' + UI.esc(C.n), GOV.FORMS[G.form].n + ' · популярность ' + Math.round(G.appr) + '% · капитал ' + Math.round(G.pc), [['Гос. решения', 'DEC.ui()', 'flag']])}
      <nav class="gtabs">${GOVUI.TABS.map(([k, n, ic]) => `<button class="${GOVUI.tab === k ? 'on' : ''}" data-gt="${k}">${UI.ic(ic)}${n}${k === 'over' && G.crisis.length ? ' <em class="gbadge">' + G.crisis.length + '</em>' : ''}</button>`).join('')}</nav>
      <div class="gbody">${body}</div>`);
    $$('#modal [data-gt]').forEach(b => b.onclick = () => GOVUI.open(b.dataset.gt));
    (GOVUI['b_' + GOVUI.tab] || (() => { }))(s, G, C);
  };
  // ---------- обзор ----------
  GOVUI.t_over = (s, G, C) => {
    const st = C.st, F = GOV.FORMS[G.form], bu = GOV.budget(s, s.world.home);
    const kpi = (n, v, sub, cls) => `<div class="gkp ${cls || ''}"><small>${n}</small><b>${v}</b>${sub ? `<span>${sub}</span>` : ''}</div>`;
    const crises = G.crisis.map(k => { const d = GOV.CRISES.find(x => x.id === k.id); return d ? `<div class="gcris"><b>⚠ ${d.n}</b><p>${d.d}</p><small>Решите до ${E.dateStr(k.until)}, иначе станет хуже</small><div>${d.o.map((o, i) => `<button class="btn small" data-cr="${k.id}|${i}">${o.n}</button>`).join('')}</div></div>` : ''; }).join('');
    return `<div class="gkpi">${kpi('Популярность', Math.round(G.appr) + '%', bar(G.appr, G.appr > 50 ? '#5a9a62' : G.appr > 30 ? '#d9a53a' : '#c4544a'))}${kpi('Полит. капитал', Math.round(G.pc), '+' + Math.round(8 * F.pc + GOV.lawFx(G).pc * 10 + (G.appr - 50) * 0.05) + ' в месяц · законы, формы правления')}${kpi('Стабильность', Math.round(st.stab) + '%', bar(st.stab))}${kpi('Рост ВВП', pct(st.gr) + '/год', UI.gdp(s, st.gdp))}${kpi('Инфляция', pct(st.infl) + '/год', 'двигает цены и зарплаты в игре', st.infl > 15 ? 'bad' : '')}${kpi('Госдолг', Math.round(st.debt) + '% ВВП', 'бюджет: ' + (bu.bal >= 0 ? 'профицит ' : 'дефицит ') + pct(Math.abs(bu.bal)), bu.bal < -3 ? 'bad' : '')}${kpi('Безработица', pct(st.unemp), '')}${kpi('Резерв / военные очки', Math.round(G.mp || 0) + ' тыс. / ' + Math.floor(G.mil || 0), 'для новых дивизий')}</div>
      ${crises ? `<h4>Кризисы</h4>${crises}` : ''}
      <div class="gcols"><div><h4>Партии</h4>${G.parties.map(p => `<div class="gparty"><span><i style="background:${p.col}"></i>${UI.esc(p.n)}</span>${bar(p.pop, p.col)}<b>${pct(p.pop)}</b></div>`).join('')}
        <p class="small">${F.dem ? 'Следующие выборы: <b>' + E.dateStr(G.elect) + '</b>. Проиграете — потеряете власть. Шансы растут с популярностью и «своими» СМИ.' : 'Выборов нет. Но если популярность упадёт ниже ~15%, армия может вас свергнуть.'}</p></div>
        <div><h4>Форма правления</h4><p class="gform"><b>${F.n}</b><br><small>${F.d}</small></p>
        <details class="gforms"><summary>Сменить форму правления (120 капитала, стабильность −10)</summary>${Object.entries(GOV.FORMS).filter(([k]) => k !== G.form).map(([k, f]) => `<button class="btn small" data-form="${k}" ${G.pc < 120 ? 'disabled' : ''} title="${f.d}">${f.n}</button>`).join('')}</details>
        <h4>Последние решения</h4><ul class="glog">${G.log.slice(0, 6).map(l => `<li><small>${E.dateStr(l.d)}</small> ${UI.esc(l.t)}</li>`).join('') || '<li class="small">Пока ничего</li>'}</ul></div></div>
      <div class="ghist">${(G.hist || []).map(v => `<i style="height:${Math.max(4, v)}%" title="${v}%"></i>`).join('')}</div><p class="small center">Популярность по месяцам</p>`;
  };
  GOVUI.b_over = (s, G, C) => {
    $$('#modal [data-cr]').forEach(b => b.onclick = () => { const [id, k] = b.dataset.cr.split('|'); const r = GOV.op('crisis', { c: s.world.home, id, k: +k }); UI.appendMsg({ k: 'me', t: 'Кризис: ' + b.textContent }); U.res(r, () => GOVUI.open()); });
    $$('#modal [data-form]').forEach(b => b.onclick = () => { if (!confirm2(b)) return; GOV.op('form', { c: s.world.home, v: b.dataset.form }); UI.appendMsg({ k: 'out', ok: true, title: 'Новая форма правления: ' + GOV.FORMS[b.dataset.form].n, lines: [GOV.FORMS[b.dataset.form].d] }); GOVUI.open(); });
  };
  const confirm2 = b => { if (b.dataset.sure) return true; b.dataset.sure = 1; b.textContent = 'Точно? Нажмите ещё раз'; b.classList.add('danger'); return false; };
  // ---------- законы ----------
  GOVUI.t_laws = (s, G) => `<p class="small">Смена закона стоит <b>${GOV.LAWCOST}</b> политического капитала (у вас ${Math.round(G.pc)}). Капитал копится каждый месяц. Законы можно менять и из чата: «ввожу всеобщую воинскую обязанность».</p>
    <div class="glaws">${Object.entries(GOV.LAWS).map(([cat, L]) => `<div class="glaw"><h5>${L.n}</h5>${Object.entries(L.o).map(([k, o]) => `<button class="${G.laws[cat] === k ? 'on' : ''}" data-law="${cat}|${k}" ${G.laws[cat] !== k && G.pc < GOV.LAWCOST ? 'disabled' : ''}><b>${o.n}</b><small>${o.d}</small><em>${fxTxt(o.fx)}</em></button>`).join('')}</div>`).join('')}</div>`;
  GOVUI.b_laws = s => $$('#modal [data-law]').forEach(b => b.onclick = () => { const [cat, v] = b.dataset.law.split('|'); const G = GOV.my(s); if (G.laws[cat] === v) return; GOV.op('law', { c: s.world.home, cat, v }); if (typeof SFX !== 'undefined') SFX.play('good'); UI.appendMsg({ k: 'out', ok: true, title: 'Закон принят: ' + GOV.LAWS[cat].o[v].n, lines: [GOV.LAWS[cat].n + ': ' + GOV.LAWS[cat].o[v].d] }); GOVUI.open(); });
  // ---------- бюджет ----------
  GOVUI.BUD = [['tax', 'Налоги (доход)', 5, 45, 'Выше — больше денег, но рост и популярность падают'], ['army', 'Армия', 0.5, 15, 'Военные очки для дивизий, военная мощь'], ['social', 'Пенсии и пособия', 2, 16, 'Популярность'], ['health', 'Здравоохранение', 1, 10, 'Популярность'], ['edu', 'Образование', 1, 9, 'Рост в долгую'], ['infra', 'Инфраструктура', 0.5, 9, 'Рост экономики'], ['science', 'Наука', 0, 5, 'Рост экономики'], ['police', 'Полиция', 0.5, 6, 'Стабильность, собираемость налогов']];
  GOVUI.t_budget = (s, G) => `<p class="small">Всё — в процентах ВВП. Дефицит растит госдолг, а если печатать деньги — инфляцию. Инфляция в вашей стране двигает цены и зарплаты всех игроков.</p>
    <div class="gbud">${GOVUI.BUD.map(([k, n, a, b, d]) => `<label class="gsl ${k === 'tax' ? 'rev' : ''}"><span>${n}<small>${d}</small></span><input type="range" min="${a}" max="${b}" step="0.5" value="${G.bud[k]}" data-b="${k}"><b data-v="${k}">${pct(G.bud[k])}</b></label>`).join('')}
    <label class="gchk"><input type="checkbox" id="gPrint" ${G.bud.print ? 'checked' : ''}> Покрывать дефицит печатью денег (долг не растёт, зато инфляция)</label></div>
    <div class="gsum" id="gSum"></div><button class="btn primary" id="gBudOk">Утвердить бюджет</button>`;
  GOVUI.b_budget = (s, G, C) => {
    const cur = Object.assign({}, G.bud);
    const upd = () => { const old = G.bud; G.bud = cur; const b = GOV.budget(s, s.world.home); G.bud = old; $('#gSum').innerHTML = `<div class="kv"><span>Доходы (налоги × собираемость ${Math.round(b.eff * 100)}% + экспорт ${pct(b.exportInc)})</span><b>${pct(b.rev)}</b></div><div class="kv"><span>Расходы (с долгом ${pct(b.debtCost)}, импортом ${pct(b.importCost)}, коррупцией ${pct(b.corr)})</span><b>${pct(b.spend)}</b></div><div class="kv big"><span>${b.bal >= 0 ? 'Профицит' : 'Дефицит'}</span><b class="${b.bal >= 0 ? 'pos' : 'neg'}">${pct(b.bal)} ВВП</b></div>`; };
    $$('#modal input[data-b]').forEach(i => i.oninput = () => { cur[i.dataset.b] = +i.value; $('#modal [data-v="' + i.dataset.b + '"]').textContent = pct(+i.value); upd(); });
    $('#gPrint').onchange = e => { cur.print = e.target.checked ? 1 : 0; };
    upd();
    $('#gBudOk').onclick = () => { GOV.op('bud', { c: s.world.home, b: cur }); UI.appendMsg({ k: 'out', ok: true, title: 'Бюджет утверждён', lines: ['Налоги ' + pct(cur.tax) + ', армия ' + pct(cur.army) + ', соцрасходы ' + pct(cur.social)] }); GOVUI.open(); };
  };
  // ---------- министры ----------
  GOVUI.t_min = (s, G) => {
    const players = typeof NET !== 'undefined' && NET.on() ? NET.list().filter(p => !p.self) : [];
    const stars = n => '★'.repeat(n) + '☆'.repeat(5 - n);
    return `<p class="small">Назначение — 10 капитала. Министр с подходящей чертой работает лучше. Коррупционер ворует из бюджета, нелояльный — опасен.${players.length ? ' Можно назначить живого игрока: он станет министром и получит свои гос. решения.' : ''}</p>
    <div class="gmins">${Object.entries(GOV.MIN).map(([k, m]) => { const x = G.min[k] || {}; return `<div class="gmin"><h5>Министр ${m.n.toLowerCase()} <small>${m.d}</small></h5><b>${x.uid ? '👤 ' : ''}${UI.esc(x.n || 'вакансия')}</b>${x.n ? `<small>${UI.esc(x.trait || '')} · ${stars(x.comp || 1)}${x.uid ? '' : ` · лояльность ${x.loy} · коррупция ${x.cor}`}</small>` : ''}
      <details><summary>Заменить</summary>${[1, 2, 3].map(i => { const c = GOV.cand(s, k, i); return `<button class="btn small" data-min="${k}|${i}" ${G.pc < 10 ? 'disabled' : ''}>${UI.esc(c.n)} · ${c.trait} · ${stars(c.comp)} · кор. ${c.cor}</button>`; }).join('')}${players.map(p => `<button class="btn small inv" data-pmin="${k}|${p.uid}">👤 Предложить: ${UI.esc(p.name)}</button>`).join('')}</details></div>`; }).join('')}</div>`;
  };
  GOVUI.b_min = s => {
    $$('#modal [data-min]').forEach(b => b.onclick = () => { const [k, i] = b.dataset.min.split('|'); const c = GOV.cand(s, k, +i); GOV.op('min', { c: s.world.home, slot: k, m: c }); UI.appendMsg({ k: 'out', ok: true, title: 'Назначен министр ' + GOV.MIN[k].n.toLowerCase(), lines: [c.n + ' (' + c.trait + ')'] }); GOVUI.open(); });
    $$('#modal [data-pmin]').forEach(b => b.onclick = () => { const [k, uid] = b.dataset.pmin.split('|'); IA.offer(uid, 'govmin', { slot: k }); });
  };
  // ---------- ресурсы и торговля ----------
  GOVUI.t_eco = (s, G) => {
    const res = GOV.res(s, s.world.home);
    return `<p class="small">Ресурсы берутся с ваших провинций. Не хватает энергии — экономика тормозит, а танки и моторизованные дивизии слабеют. Нет еды — популярность и стабильность падают. Излишки можно продавать — это доход бюджета.</p>
    <table class="gtab"><tr><th>Ресурс</th><th>Добыча</th><th>Нужно</th><th>Импорт</th><th>Экспорт</th><th>Итог</th><th></th></tr>${Object.entries(res).filter(([k]) => k !== 'lux' || res[k].prod).map(([k, r]) => `<tr><td>${UI.ic(GOV.RES[k].ic)} ${GOV.RES[k].n}</td><td>${r.prod}</td><td>${r.need}</td><td>${r.imp}</td><td>${r.exp}</td><td class="${r.bal < 0 ? 'neg' : 'pos'}"><b>${r.bal > 0 ? '+' : ''}${r.bal}</b></td><td>${r.bal < 0 ? `<button class="btn small" data-find="buy|${k}">Найти поставщика</button>` : r.bal > 5 ? `<button class="btn small" data-find="sell|${k}">Продать</button>` : ''}</td></tr>`).join('')}</table>
    <h4>Сделки</h4>${(G.deals || []).length ? `<ul class="glog">${G.deals.map((d, i) => `<li>${d.dir === 'in' ? 'Импорт' : 'Экспорт'}: ${GOV.RES[d.res].n.toLowerCase()} ${d.amt} ед. — ${UI.esc(d.cn)} до ${E.dateStr(d.until)} <button class="gx" data-undeal="${i}">✕</button></li>`).join('')}</ul>` : '<p class="small">Нет. Договоритесь в «Дипломатии» или кнопками выше.</p>'}
    <h4>Торговые соглашения и пакты</h4><p class="small">${Object.entries(G.pacts).map(([ci, p]) => UI.esc(s.world.cs[ci].n) + ' — ' + ({ trade: 'торговля', nap: 'ненападение', alliance: 'союз' }[p.t] || p.t)).join(', ') || 'Пока нет'}</p>`;
  };
  GOVUI.b_eco = s => {
    $$('#modal [data-find]').forEach(b => b.onclick = () => {
      const [kind, k] = b.dataset.find.split('|'), W = s.world;
      const cands = E.alive(s).filter(i => i !== W.home && !WD.atWar(s, W.home, i) && W.cs[i].st.gdp > 5).map(i => { const r = GOV.res(s, i)[k]; return [i, kind === 'buy' ? r.bal : -r.bal]; }).filter(x => x[1] > 0).sort((a, b) => (b[1] + W.cs[b[0]].rel * 0.3) - (a[1] + W.cs[a[0]].rel * 0.3));
      if (!cands.length) return UI.toast('Подходящих стран нет', 'bad');
      GOVUI.prop = kind; GOVUI.res = k; GOVUI.open('dip', cands[0][0]);
    });
    $$('#modal [data-undeal]').forEach(b => b.onclick = () => { GOV.op('undeal', { c: s.world.home, i: +b.dataset.undeal }); GOVUI.open(); });
  };
  // ---------- дипломатия ----------
  GOVUI.BLOCLEAD = { 'НАТО': '840', 'ЕС': '276', 'ОДКБ': '643' };
  GOVUI.t_dip = (s, G) => {
    const W = s.world, home = W.home, cs = W.cs;
    const nb = new Set(); for (const e of M().edges) { const a = W.own[e.a], b = W.own[e.b]; if (a === home && b !== home) nb.add(b); if (b === home && a !== home) nb.add(a); }
    const big = E.alive(s).filter(i => i !== home).sort((a, b) => cs[b].st.gdp - cs[a].st.gdp).slice(0, 14);
    const list = [...new Set([...WD.enemies(s, home), ...Object.keys(G.pacts).map(Number), ...nb, ...big])].filter(i => !cs[i].dead && i !== home);
    if (GOVUI.ci < 0 || cs[GOVUI.ci].dead || GOVUI.ci === home) GOVUI.ci = list[0];
    const ci = GOVUI.ci, C = cs[ci], log = (G.dip[ci] || []);
    const blocs = {}; for (const i of E.alive(s)) for (const b of (cs[i].st.bloc || [])) (blocs[b] = blocs[b] || []).push(i);
    const props = Object.keys(GOV.PROPS).filter(k => k === 'peace' ? WD.atWar(s, home, ci) : !(k === 'joinbloc' && !(C.st.bloc || []).length));
    return `<div class="gdip"><aside><h5>Страны</h5>${list.map(i => `<button class="${i === ci ? 'on' : ''}" data-ci="${i}"><i style="background:${cs[i].col}"></i><span>${UI.esc(cs[i].n)}<small>${WD.atWar(s, home, i) ? '⚔ война' : (G.pacts[i] ? '🤝 ' : '') + UI.rel(cs[i].rel)}</small></span></button>`).join('')}
      <h5>Блоки</h5>${Object.entries(blocs).map(([b, m]) => `<div class="gbloc"><b>${UI.esc(b)}</b> <small>${m.length} стран</small>${(cs[home].st.bloc || []).includes(b) ? `<button class="btn small" data-leave="${UI.esc(b)}">Выйти</button>` : ''}</div>`).join('')}
      <details><summary>Создать свой блок</summary><input id="gBlocN" placeholder="Название блока" maxlength="24"><button class="btn small" id="gBlocGo" ${G.pc < 50 ? 'disabled' : ''}>Создать (50 капитала)</button></details></aside>
      <section><div class="gdh"><i style="background:${C.col}"></i><div><b>${UI.esc(C.n)}</b><small>${UI.esc(C.st.gov || '')}${(C.st.bloc || []).length ? ' · ' + C.st.bloc.join(', ') : ''} · отношения: ${UI.rel(C.rel)} (${Math.round(C.rel)}) · сила ${Math.round(E.power(s, ci))} против ваших ${Math.round(E.power(s, home))}</small></div><button class="btn small" data-country="${ci}" onclick="UI.closeModal();U.country&&U.country(${ci})">Досье</button></div>
        <div class="gchat" id="gChat">${log.length ? log.map(m => `<div class="${m.me ? 'me' : 'th'}"><span>${UI.esc(m.t)}</span></div>`).join('') : `<p class="small center">Напишите лидеру страны — он ответит сам (через нейросеть). Можно просто поговорить, а можно сделать предложение кнопками ниже.</p>`}</div>
        <div class="gprops">${props.map(k => `<button class="${GOVUI.prop === k ? 'on' : ''}" data-prop="${k}" title="${GOV.PROPS[k].d}">${GOV.PROPS[k].n}<small>${GOV.PROPS[k].base >= 999 ? 'без согласия' : '~' + GOV.chance(s, ci, k) + '%'}</small></button>`).join('')}${(G.pacts[ci]) ? `<button data-unpact="${ci}">Разорвать: ${({ trade: 'торговля', nap: 'ненападение', alliance: 'союз' }[G.pacts[ci].t])}</button>` : ''}${!WD.atWar(s, home, ci) ? `<button class="war" data-war="${ci}">Объявить войну</button>` : ''}${G.myBloc ? `<button data-invite="${ci}">Позвать в «${UI.esc(G.myBloc)}»</button>` : ''}</div>
        <div class="gsend"><textarea id="gMsg" rows="2" placeholder="${GOVUI.prop ? 'Сопроводительные слова к предложению «' + GOV.PROPS[GOVUI.prop].n + '» (можно пусто)' : 'Ваше послание лидеру…'}"></textarea><button class="btn primary" id="gSend">${UI.ic('send')}</button></div></section></div>`;
  };
  GOVUI.b_dip = (s, G) => {
    const ci = GOVUI.ci, home = s.world.home;
    const ch = $('#gChat'); if (ch) ch.scrollTop = ch.scrollHeight;
    $$('#modal [data-ci]').forEach(b => b.onclick = () => { GOVUI.prop = ''; GOVUI.open('dip', +b.dataset.ci); });
    $$('#modal [data-prop]').forEach(b => b.onclick = () => { GOVUI.prop = GOVUI.prop === b.dataset.prop ? '' : b.dataset.prop; GOVUI.open('dip'); });
    $$('#modal [data-unpact]').forEach(b => b.onclick = () => { GOV.op('pact', { c: home, ci, v: null, rel: -15, news: `${s.world.cs[home].n} разорвала договор с ${s.world.cs[ci].n}.` }); GOVUI.open('dip'); });
    $$('#modal [data-war]').forEach(b => b.onclick = () => { if (!confirm2(b)) return; const r = E.act(s, { type: 'war', target: s.world.cs[ci].n, raw: 'объявляю войну ' + s.world.cs[ci].n }); U.res(r, () => { if (window.MAP && MAP.svg) MAP.paint(s); GOVUI.open('army'); }); });
    $$('#modal [data-leave]').forEach(b => b.onclick = () => { GOV.op('bloc', { c: home, b: b.dataset.leave, join: false, news: `${s.world.cs[home].n} вышла из ${b.dataset.leave}.` }); GOVUI.open('dip'); });
    const bg = $('#gBlocGo'); if (bg) bg.onclick = () => { const n = ($('#gBlocN').value || '').trim(); if (n.length < 2) return UI.toast('Назовите блок', 'bad'); GOV.op('bloc', { c: home, b: n, join: true, news: `${s.world.cs[home].n} основала новый блок — «${n}».` }); GOV.op('stat', { c: home, d: {}, g: { pc: -50 } }); G.myBloc = n; GOVUI.open('dip'); };
    $$('#modal [data-invite]').forEach(b => b.onclick = async () => { const r = await GOV.talk(s, ci, 'Предлагаем вам вступить в наш блок «' + G.myBloc + '».', 'alliance'); if (r.ok) GOV.op('bloc', { c: ci, b: G.myBloc, join: true, news: `${s.world.cs[ci].n} вступила в блок «${G.myBloc}».` }); GOVUI.open('dip'); if (r.res) U.res(r.res); });
    const send = async () => {
      const t = ($('#gMsg').value || '').trim(), kind = GOVUI.prop;
      if (!t && !kind) return;
      const btn = $('#gSend'); btn.disabled = true; btn.innerHTML = '…';
      const chat = $('#gChat'); chat.insertAdjacentHTML('beforeend', `<div class="me"><span>${UI.esc(t || '(' + GOV.PROPS[kind].n + ')')}</span></div><div class="th typing"><span>печатает…</span></div>`); chat.scrollTop = chat.scrollHeight;
      const r = await GOV.talk(s, ci, t || ('Предлагаю: ' + GOV.PROPS[kind].n.toLowerCase() + '.'), kind || null);
      GOVUI.prop = ''; UI.save();
      if (r.res) { UI.appendMsg({ k: 'out', ok: r.res.ok, title: r.res.title, lines: [s.world.cs[ci].n + ': «' + r.reply + '»'].concat(r.res.lines || []) }); if (typeof SFX !== 'undefined') SFX.play(r.res.ok ? 'good' : 'bad'); }
      if (window.MAP && MAP.svg) { MAP.paint(s); UI.legend(); }
      if ($('#gChat')) GOVUI.open('dip');
    };
    $('#gSend').onclick = send;
    $('#gMsg').onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };
  };
  // ---------- армия ----------
  GOVUI.t_army = (s, G) => {
    const T = ARMY.tpl(s), home = s.world.home, divs = ARMY.of(s, home), P = M().provinces, W = s.world;
    const own = P.map((p, i) => i).filter(i => W.own[i] === home);
    const front = own.filter(i => P[i].nb.some(j => WD.atWar(s, home, W.own[j])));
    const border = own.filter(i => P[i].nb.some(j => W.own[j] !== home));
    const C = W.cs[home], cap = C.cap >= 0 && W.own[C.cap] === home ? C.cap : own[0];
    const places = [[cap, 'Столица: ' + P[cap].n]].concat(front.slice(0, 12).map(i => [i, '⚔ Фронт: ' + P[i].n])).concat(border.filter(i => !front.includes(i)).slice(0, 10).map(i => [i, 'Граница: ' + P[i].n]));
    const groups = {}; for (const d of divs) (groups[d.p] = groups[d.p] || []).push(d);
    return `<div class="gkpi">${[['Дивизий', divs.length], ['Военные очки', Math.floor(G.mil || 0) + ' <small>+' + Math.round(G.bud.army * Math.sqrt(C.st.gdp) * 0.1 * (GOV.FORMS[G.form].mil || 1)) + '/мес</small>'], ['Резерв', Math.round(G.mp || 0) + ' тыс.'], ['Призыв', GOV.LAWS.conscr.o[G.laws.conscr].n], ['Энергия для техники', GOV.res(s, home).energy.bal >= 0 ? 'хватает' : '<span class="neg">дефицит −35% танкам</span>']].map(([n, v]) => `<div class="gkp"><small>${n}</small><b>${v}</b></div>`).join('')}</div>
      <h4>Сформировать дивизию</h4><div class="gnew"><select id="gPlace">${places.map(([i, n]) => `<option value="${i}">${UI.esc(n)}</option>`).join('')}</select>
      ${Object.entries(T).map(([k, t]) => `<button class="gdt" data-new="${k}" ${(G.mil || 0) < t.mil || (G.mp || 0) < t.mp ? 'disabled' : ''}><b>${t.n}</b><small>атака ${t.atk} · оборона ${t.def} · скорость ${t.spd}</small><em>${t.mil} очков · ${t.mp} тыс. чел. · ${t.wk} нед.${t.oil ? ' · топливо' : ''}</em></button>`).join('')}</div>
      <p class="small">Военные очки дают расходы на армию (вкладка «Бюджет»), людей — закон о призыве. Как воевать: закройте окно, нажмите на значок дивизии на карте, затем на провинцию — дивизия пойдёт туда. Вражеская провинция — штурм. Несколько дивизий вместе с артиллерией и танками берут оборону гарнизона. Пустой фронт враг продавливает быстрее.</p>
      <h4>Дивизии</h4><div class="gdivs">${Object.entries(groups).map(([p, ds]) => `<div class="gdg"><div class="gdgh"><b>${P[p].n}</b>${front.includes(+p) ? ' <span class="tag poor">фронт</span>' : ''}<button class="btn small" data-show="${p}">На карте</button></div>${ds.map(d => `<div class="gdr"><span>${UI.esc(d.n)}</span>${bar(d.str, '#5a9a62')}${bar(d.org, '#6a9fd0')}<small>${d.train > 0 ? 'обучение ' + d.train + ' нед.' : d.path.length ? '→ ' + P[d.path[d.path.length - 1]].n : 'на позиции'}</small><button class="gx" data-dis="${d.id}" title="Расформировать (люди вернутся в резерв)">✕</button></div>`).join('')}</div>`).join('') || '<p class="small">Дивизий нет.</p>'}</div>`;
  };
  GOVUI.b_army = s => {
    $$('#modal [data-new]').forEach(b => b.onclick = () => { const p = +$('#gPlace').value; const err = ARMY.op('create', { c: s.world.home, t: b.dataset.new, p, id: ARMY.uid() }); if (err) return UI.toast(err, 'bad'); if (typeof SFX !== 'undefined') SFX.play('coin'); UI.toast('Формируется: ' + ARMY.tpl(s)[b.dataset.new].n); GOVUI.open('army'); });
    $$('#modal [data-show]').forEach(b => b.onclick = () => { const p = +b.dataset.show, P = M().provinces[p]; UI.closeModal(); if (MAP.focusOn) MAP.focusOn(P.x, P.y, 500); ARMY.click(p); });
    $$('#modal [data-dis]').forEach(b => b.onclick = () => { if (!confirm2(b)) return; ARMY.op('disband', { c: s.world.home, ids: [b.dataset.dis] }); GOVUI.open('army'); });
  };

  // ---------- взаимодействие: позвать игрока в министры ----------
  if (typeof IA !== 'undefined') {
    const def = { id: 'govmin', cat: 'Власть', n: 'Сделать министром', d: 'Только для главы государства: друг станет министром и получит свои гос. решения.',
      fields: [{ k: 'slot', label: 'Министерство', type: 'select', opts: () => Object.entries(GOV.MIN).map(([k, m]) => [k, 'Министр ' + m.n.toLowerCase()]) }],
      need: s => !E.isLeader(s) ? 'Нужно быть главой государства' : null,
      text: (s, f) => `предлагает пост: министр ${GOV.MIN[f.slot].n.toLowerCase()} (${s.world.cs[s.world.home].n})`,
      accept: s => s.pol && s.pol.id === 'president' ? 'Вы сами глава государства' : null,
      reply: s => ({ comp: E.clamp(Math.round((E.sk(s, 'int') + E.sk(s, 'cha') + E.sk(s, 'biz')) / 60), 1, 5), name: s.ch.name + ' ' + s.ch.surname }),
      onAccept: (s, f, d, from) => { s.pol = { id: 'minister', n: 'Министр ' + GOV.MIN[f.slot].n.toLowerCase(), months: 0 }; s.job = null; E.fact(s, `${E.monthStr(s.date)}: ${from.name} назначил меня министром ${GOV.MIN[f.slot].n.toLowerCase()}.`); return { fx: { rep: 8, happy: 10 }, rel: 10, note: 'министр в правительстве', lines: ['Вы — министр ' + GOV.MIN[f.slot].n.toLowerCase() + '. Открыты гос. решения министра.'] }; },
      done: (s, p, f, r, d, rp) => { GOV.op('min', { c: s.world.home, slot: f.slot, m: { n: p.name, uid: p.uid, comp: (rp && rp.comp) || 3, loy: 90, cor: 0, trait: 'Свой человек', tk: f.slot } }); const G = GOV.my(s); if (G) G.pc += 10; return { rel: 10, note: 'назначил министром', lines: [p.name + ' — министр ' + GOV.MIN[f.slot].n.toLowerCase()], pub: `${p.name} назначен(а) министром` }; }, fin: () => null };
    const hi = IA.DEFS.findIndex(d => d.hostile); IA.DEFS.splice(hi >= 0 ? hi : IA.DEFS.length, 0, def); IA.DEF.govmin = def;
    if (!IA.CATS.includes('Власть')) IA.CATS.push('Власть');
  }

  // ---------- кнопка «Власть» в углу карты ----------
  const _mb = UI.mapBtns;
  UI.mapBtns = () => {
    _mb();
    const el = $('#mapbtns'), s = UI.s; if (!el || !s || !s.pol) return;
    const G = GOV.my(s), n = DEC.open(s).filter(d => !((s.dec || {})[d.id] > s.turn)).length;
    el.insertAdjacentHTML('beforeend', `<button class="mb-gov" id="mbGov" title="Гос. решения${G ? ' и правительство' : ''}"><span class="mb-ic">${UI.ic('flag')}</span><span class="mb-t"><b>${G ? 'Правительство' : 'Власть'}</b><small>${UI.esc(s.pol.n)}${G ? ' · ' + Math.round(G.appr) + '%' : ''}</small></span>${G && G.crisis.length ? '<em class="gbadge">!</em>' : n ? `<em class="gbadge ok">${n}</em>` : ''}</button>`);
    $('#mbGov').onclick = () => G ? GOVUI.open() : DEC.ui();
  };
  // старая вкладка «Власть»: кнопки ведут в новые окна
  const _ts = UI.tState;
  UI.tState = () => {
    let h = _ts(); const s = UI.s;
    if (s.pol) h = h.replace('<div class="statet">', `<div class="statet"><button class="btn wide primary" onclick="${E.isLeader(s) ? 'GOVUI.open()' : 'DEC.ui()'}">${UI.ic('flag')} ${E.isLeader(s) ? 'Правительство и гос. решения' : 'Гос. решения (' + DEC.open(s).length + ')'}</button>`);
    return h.replace(/<button class="btn wide" data-act='\{"type":"army"\}'[\s\S]*?Укрепить армию<\/button>/, `<button class="btn wide" onclick="GOVUI.open('army')">${UI.ic('shield')} Армия: дивизии на карте</button>`);
  };
})();
