// «Судьба» — интерфейс: титульный экран, создание персонажа, верхняя панель, карта, досье, Нейрочат, события.
'use strict';
const UI = { s: null, busy: false, queue: [], tab: 'dossier', KEY: 'sudba_save_v1' };
const $ = (q, r) => (r || document).querySelector(q);
const $$ = (q, r) => Array.from((r || document).querySelectorAll(q));
UI.esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// ---------- иконки ----------
const IC = {
  hand: '<path d="M7 11.5V6a1.5 1.5 0 0 1 3 0v4.5M10 10V4.5a1.5 1.5 0 0 1 3 0V10M13 10V5.5a1.5 1.5 0 0 1 3 0V11M16 9.5a1.5 1.5 0 0 1 3 0V14a7 7 0 0 1-7 7h-1a6 6 0 0 1-5-2.7l-2.6-4a1.6 1.6 0 0 1 2.6-1.8L7 14"/>',
  radio: '<rect x="3" y="9" width="18" height="11" rx="2"/><circle cx="8.5" cy="14.5" r="2.5"/><path d="M14 13h4M14 16h4M6 9l11-5"/>',
  coin: '<circle cx="12" cy="12" r="8.5"/><path d="M9.5 8.5h3.8a2.2 2.2 0 0 1 0 4.4H9.5V7v10M8 15h6"/>',
  smile: '<circle cx="12" cy="12" r="8.5"/><path d="M8.5 14q3.5 3.5 7 0"/><circle cx="9.3" cy="10" r=".6" fill="currentColor"/><circle cx="14.7" cy="10" r=".6" fill="currentColor"/>',
  heart: '<path d="M12 19.5S4 14.6 4 9.3A4.1 4.1 0 0 1 12 7.6a4.1 4.1 0 0 1 8 1.7c0 5.3-8 10.2-8 10.2z"/>',
  star: '<path d="M12 3.8l2.4 5.1 5.6.6-4.2 3.8 1.2 5.5L12 16l-5 2.8 1.2-5.5-4.2-3.8 5.6-.6z"/>',
  brief: '<rect x="3.5" y="7.5" width="17" height="11.5" rx="1.6"/><path d="M9 7.5V5.8a1.3 1.3 0 0 1 1.3-1.3h3.4A1.3 1.3 0 0 1 15 5.8v1.7M3.5 12.5h17"/>',
  home: '<path d="M4 11 12 4.5l8 6.5M6 9.6V19.5h12V9.6M10 19.5v-5h4v5"/>',
  box: '<path d="M4 8l8-4 8 4v8.5l-8 4-8-4zM4 8l8 4 8-4M12 12v8.5"/>',
  factory: '<path d="M3.5 19.5V10l5 3V10l5 3V5h4v14.5zM3.5 19.5h17"/>',
  cal: '<rect x="4" y="5.5" width="16" height="14" rx="1.5"/><path d="M4 9.5h16M8.5 3.5v4M15.5 3.5v4"/>',
  play: '<path d="M8 5.5v13l10-6.5z" fill="currentColor"/>',
  dice: '<rect x="4.5" y="4.5" width="15" height="15" rx="3"/><circle cx="9" cy="9" r="1.1" fill="currentColor"/><circle cx="15" cy="15" r="1.1" fill="currentColor"/><circle cx="12" cy="12" r="1.1" fill="currentColor"/>',
  book: '<path d="M4.5 5.5c3-1 5.5-.6 7.5 1 2-1.6 4.5-2 7.5-1v13c-3-1-5.5-.6-7.5 1-2-1.6-4.5-2-7.5-1zM12 6.5v13"/>',
  ring: '<circle cx="12" cy="14" r="5.5"/><path d="M9.5 8.8 8 5.5h8l-1.5 3.3"/>',
  flag: '<path d="M5.5 20.5V4M5.5 4.5h11l-2 3.5 2 3.5h-11"/>',
  up: '<path d="M4.5 17.5l5-5 3.5 3.5 6.5-7M14.5 9h5v5"/>',
  send: '<path d="M4.5 12 19.5 5l-4.5 14-3.5-5.5zM11.5 13.5l8-8.5"/>',
  menu: '<path d="M5 7h14M5 12h14M5 17h14"/>',
  sword: '<path d="M14.5 4.5h5v5l-9 9-5-5zM4 16.5l3.5 3.5M3.5 20.5l2-2"/>',
  shield: '<path d="M12 3.5 19 6v5.5c0 4.5-3.2 7.6-7 9-3.8-1.4-7-4.5-7-9V6z"/>',
  user: '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20c.8-4 3.8-6 7.5-6s6.7 2 7.5 6"/>',
  target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', minus: '<path d="M5 12h14"/>', x: '<path d="M6 6l12 12M18 6 6 18"/>',
  bolt: '<path d="M13 3.5 5.5 13.5h6l-1 7 8-10h-6z"/>',
  chip: '<rect x="6.5" y="6.5" width="11" height="11" rx="1.5"/><path d="M9.5 3.5v3M14.5 3.5v3M9.5 17.5v3M14.5 17.5v3M3.5 9.5h3M3.5 14.5h3M17.5 9.5h3M17.5 14.5h3"/>',
  save: '<path d="M5 4.5h11l3 3v12H5zM8 4.5v5h7v-5M8 19.5v-6h8v6"/>',
  globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.6 2.6 3.6 5.4 3.6 8.5s-1 5.9-3.6 8.5c-2.6-2.6-3.6-5.4-3.6-8.5s1-5.9 3.6-8.5z"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
};
UI.ic = (n, cls) => `<svg class="ic ${cls || ''}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${IC[n] || ''}</svg>`;

// ---------- портрет ----------
UI.avatar = (ch, size) => {
  const L = ch.look || 0;
  const bgs = ['#e7d6c3', '#cfe0d9', '#dcd3e8', '#e8d5d0', '#d3dfe9', '#e6e0c6'];
  const skins = ['#f1d3bc', '#e9c3a5', '#d9a983', '#c08b66'];
  const hairs = ['#2d2420', '#4a3426', '#7a5532', '#b8894f', '#1e1c1c', '#8c3b26'];
  const bg = bgs[L % 6], sk = skins[(L >> 3) % 4], hr = hairs[(L >> 5) % 6];
  const f = ch.sex === 'f';
  const hair = f ? `<path d="M15 33c-3-14 4-23 17-23s20 9 17 23c2 7 1 14-3 18h-4c3-6 3-14 1-20-6 1-15-2-19-7-3 5-5 11-2 27h-4c-4-4-5-11-3-18z" fill="${hr}"/>`
    : (L % 3 === 0 ? `<path d="M18 30c-2-11 5-18 14-18s16 6 14 18c-3-5-7-7-14-7s-11 2-14 7z" fill="${hr}"/>` : `<path d="M17 29c0-12 6-17 15-17s15 5 15 17l-3-1c-2-4-6-6-12-6s-10 2-12 6z" fill="${hr}"/>`);
  return `<svg class="avatar" width="${size}" height="${size}" viewBox="0 0 64 64"><circle cx="32" cy="32" r="31" fill="${bg}"/><path d="M12 60c2-10 10-15 20-15s18 5 20 15" fill="${['#466d7a', '#7a5a46', '#5b6b45', '#6c4f73', '#8a6d3b'][L % 5]}"/><rect x="28" y="38" width="8" height="8" fill="${sk}"/><ellipse cx="32" cy="30" rx="11" ry="12.5" fill="${sk}"/>${hair}<circle cx="27.5" cy="31" r="1.2" fill="#2b2522"/><circle cx="36.5" cy="31" r="1.2" fill="#2b2522"/><path d="M29 37q3 1.8 6 0" stroke="#9a5a4a" stroke-width="1.2" fill="none" stroke-linecap="round"/></svg>`;
};

UI.toast = (t, kind) => { const e = $('#toast'); e.innerHTML = t; e.className = 'toast show ' + (kind || ''); clearTimeout(UI._tt); UI._tt = setTimeout(() => e.className = 'toast', 2600); };

// ---------- сохранения ----------
UI.save = () => { try { localStorage.setItem(UI.KEY, JSON.stringify(UI.s)); } catch (e) { } };
UI.load = () => { try { const t = localStorage.getItem(UI.KEY); return t ? JSON.parse(t) : null; } catch (e) { return null; } };
UI.exportSave = () => {
  const s = UI.s; const blob = new Blob([JSON.stringify(s)], { type: 'application/json' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
  a.download = `althistory_${s.ch.name}_${s.ch.surname}_${E.dateStr(s.date).replace(/ /g, '-')}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  UI.toast('Сохранение скачано');
};
UI.importSave = () => {
  const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.json,application/json';
  inp.onchange = () => { const f = inp.files[0]; if (!f) return; f.text().then(t => { try { const s = JSON.parse(t); if (!s.ch || !s.st || !s.world) throw 0; UI.s = s; UI.save(); UI.closeModal(); UI.game(); UI.toast('Сохранение загружено'); } catch (e) { UI.toast('Это не сохранение «Судьбы»', 'bad'); } }); };
  inp.click();
};

// ---------- титульный экран ----------
UI.bgMap = () => { // фон титула: ночная карта мира. Рисуется ОДИН раз в картинку (иначе меню тормозит до 1 FPS)
  if (!UI._bgUrl && !UI._bgBusy) setTimeout(UI.makeBg, 0);
  return `<div class="bgwrap"><img class="bgmap ${UI._bgUrl ? 'on' : ''}" alt="" ${UI._bgUrl ? `src="${UI._bgUrl}"` : ''}></div>`;
};
UI.makeBg = () => {
  if (UI._bgUrl || UI._bgBusy) return; UI._bgBusy = true;
  try {
    const m = M(), Wc = 2560, Hc = Math.round(Wc * m.H / m.W), k = Wc / m.W;
    const c = document.createElement('canvas'); c.width = Wc; c.height = Hc; const x = c.getContext('2d');
    const g = x.createRadialGradient(Wc * 0.45, Hc * 0.4, 0, Wc * 0.45, Hc * 0.4, Wc * 0.62);
    g.addColorStop(0, '#2c6475'); g.addColorStop(0.55, '#173f4d'); g.addColorStop(1, '#0b222c'); x.fillStyle = g; x.fillRect(0, 0, Wc, Hc);
    x.save(); x.scale(k, k);
    // сетка меридианов
    x.strokeStyle = 'rgba(159,208,220,.09)'; x.lineWidth = 1.2 / k; x.beginPath();
    for (let X = 0; X <= m.W; X += m.W / 24) { x.moveTo(X, 0); x.lineTo(X, m.H); } for (let Y = 0; Y <= m.H; Y += m.H / 12) { x.moveTo(0, Y); x.lineTo(m.W, Y); } x.stroke();
    const coast = new Path2D(m.coast);
    x.lineJoin = 'round'; x.strokeStyle = 'rgba(127,194,211,.18)'; x.lineWidth = 16; x.stroke(coast);
    const land = new Path2D(); for (const p of m.provinces) land.addPath(new Path2D(p.d));
    const lg = x.createLinearGradient(0, 0, m.W, m.H); lg.addColorStop(0, 'rgba(232,217,181,.2)'); lg.addColorStop(1, 'rgba(200,180,138,.2)'); x.fillStyle = lg; x.fill(land);
    x.strokeStyle = 'rgba(231,201,131,.55)'; x.lineWidth = 1.6; x.stroke(coast);
    // огни городов
    const cs = m.cities.filter(c => c.p > 250000 || c.cap), r = c => c.cap ? 4.2 : Math.min(3.4, 1.4 + Math.log10(c.p) - 5);
    x.fillStyle = 'rgba(255,207,115,.75)'; x.shadowColor = 'rgba(255,190,90,.9)'; x.shadowBlur = 14;
    for (const c of cs) { x.beginPath(); x.arc(c.x, c.y, r(c), 0, 7); x.fill(); }
    x.shadowBlur = 0; x.fillStyle = 'rgba(255,244,207,.95)';
    for (const c of cs) { x.beginPath(); x.arc(c.x, c.y, r(c) * 0.38, 0, 7); x.fill(); }
    x.restore();
    // лёгкое зерно
    const id = x.getImageData(0, 0, Wc, Hc), d = id.data;
    for (let i = 0; i < d.length; i += 4) { const n = (Math.random() - 0.5) * 10; d[i] += n; d[i + 1] += n; d[i + 2] += n; }
    x.putImageData(id, 0, 0);
    c.toBlob(b => { UI._bgUrl = URL.createObjectURL(b); UI._bgBusy = false; document.querySelectorAll('img.bgmap').forEach(im => { im.src = UI._bgUrl; im.onload = () => im.classList.add('on'); }); }, 'image/jpeg', 0.9);
  } catch (e) { console.warn('bg', e); UI._bgBusy = false; }
};

UI.VER = '3.5.2'; // показывается на главном экране — видно, что обновление встало
UI.title = () => {
  const save = UI.load();
  $('#app').innerHTML = `<div class="title">${UI.bgMap()}<div class="veil"></div>
    <div class="tcard">
      <div class="logo"><img src="lib/icon.png" alt=""></div>
      <h1>AltHistory</h1>
      <p class="sub">Альтернативная история твоей жизни — с нейросетью-рассказчиком.<br>Три эпохи — 2018, 2026 и 1936. Пишите, что делает ваш герой, — а кубик и живой мир решат, что из этого выйдет.</p>
      <div class="tbtns">
        ${save && !save.over ? `<button class="btn big primary" id="tContinue">${UI.ic('play')} Продолжить — ${UI.esc(save.ch.name)} ${UI.esc(save.ch.surname)}, ${E.years(E.age(save))}</button>` : ''}
        <button class="btn big ${save && !save.over ? '' : 'primary'}" id="tNew">${UI.ic('plus')} Новая жизнь</button>
        <button class="btn" id="tLoad">${UI.ic('save')} Загрузить из файла</button>
        <button class="btn" id="tMp">${UI.ic('globe')} Мультиплеер — войти по коду</button>
      </div>
      <div class="aistat" id="tAi"></div>
      <div class="tver">версия ${UI.VER}</div>
    </div></div>`;
  if ($('#tContinue')) $('#tContinue').onclick = () => { UI.s = save; UI.game(); };
  $('#tNew').onclick = () => UI.create();
  $('#tLoad').onclick = () => UI.importSave();
  $('#tMp').onclick = () => {
    UI.modal(`<div class="menu room"><h3>Войти в комнату друга</h3><p class="small">Введите код, который прислал друг. Вы начнёте новую жизнь в его мире. Создать свою комнату — внутри игры: кнопка «Мультиплеер» над картой.</p><div class="rjoin"><input id="tmCode" placeholder="ABC-123" autocomplete="off" spellcheck="false"><button class="btn" id="tmPaste" title="Вставить из буфера">Вставить</button><button class="btn primary" id="tmGo">Войти</button></div><button class="btn wide" id="tmX">Отмена</button></div>`);
    U.codeInput('#tmCode', '#tmPaste'); $('#tmCode').focus();
    $('#tmX').onclick = UI.closeModal;
    const go = () => { const c = NET.pick($('#tmCode').value); if (c.length < 6) { UI.toast('Код — 6 символов, например ABC-123', 'bad'); return; } U.joinFlow(c); };
    $('#tmGo').onclick = go; $('#tmCode').onkeydown = e => { if (e.key === 'Enter') go(); };
  };
  UI.aiBadge();
};

// ---------- создание персонажа ----------
const NAMES = {
  m: ['Александр', 'Дмитрий', 'Максим', 'Сергей', 'Андрей', 'Алексей', 'Артём', 'Илья', 'Кирилл', 'Михаил', 'Никита', 'Иван', 'Егор', 'Роман', 'Павел', 'Денис', 'Тимур', 'Владимир', 'Олег', 'Глеб'],
  f: ['Анна', 'Мария', 'Елена', 'Дарья', 'Алина', 'Ирина', 'Екатерина', 'Ольга', 'Полина', 'Виктория', 'Софья', 'Ксения', 'Наталья', 'Юлия', 'Вера', 'Алиса', 'Татьяна', 'Варвара', 'Ева', 'Марина'],
  s: ['Иванов', 'Смирнов', 'Кузнецов', 'Попов', 'Васильев', 'Петров', 'Соколов', 'Михайлов', 'Новиков', 'Фёдоров', 'Морозов', 'Волков', 'Алексеев', 'Лебедев', 'Семёнов', 'Егоров', 'Павлов', 'Козлов', 'Степанов', 'Николаев', 'Орлов', 'Андреев', 'Макаров', 'Никитин', 'Захаров', 'Зайцев', 'Соловьёв', 'Борисов', 'Яковлев', 'Григорьев'],
};
UI.fem = sn => /(ов|ев|ёв|ин|ын)$/.test(sn) ? sn + 'а' : (/ий$/.test(sn) ? sn.replace(/ий$/, 'ая') : sn);
const CONFLICT = [['hard', 'lazy'], ['charm', 'shy'], ['strong', 'sickly']];

UI.create = () => {
  const c = { sex: 'm', name: E.pick(NAMES.m), surname: E.pick(NAMES.s), age: 20, city: 0, cityName: '', bg: 'mid', edu: 2, traits: [], bio: '', look: E.ri(0, 9999), era: (UI.cr && UI.cr.era) || 'y2018', diff: (UI.cr && UI.cr.diff) || 'normal' };
  UI.cr = c;
  const cityOpts = () => M().start.map((x, i) => (c.era === 'ww2' && x.no36) ? '' : `<option value="${i}">${c.era === 'ww2' && x.n2 || x.n}</option>`).join('');
  const cities = cityOpts();
  $('#app').innerHTML = `<div class="create">${UI.bgMap()}<div class="veil"></div>
   <div class="cwrap">
    <div class="cform">
      <h2>Новая жизнь</h2>
      <label>Эпоха</label>
      <div class="cards2" id="cEra">${Object.keys(D.ERA).map(k => `<button data-v="${k}"><b>${D.ERA[k].n} <em>${D.ERA[k].y}</em></b><span>${D.ERA[k].d}</span></button>`).join('')}</div>
      <label>Сложность</label>
      <div class="cards3" id="cDiff">${Object.keys(D.DIFF).map(k => `<button data-v="${k}" class="d-${k}"><b>${D.DIFF[k].n}</b><span>${D.DIFF[k].d}</span></button>`).join('')}</div>
      <div class="row2">
        <label>Имя<input id="cName" maxlength="20"></label>
        <label>Фамилия<input id="cSur" maxlength="24"></label>
      </div>
      <div class="row2">
        <label>Пол<div class="seg" id="cSex"><button data-v="m">Мужской</button><button data-v="f">Женский</button></div></label>
        <label>Возраст: <b id="cAgeV"></b><input type="range" id="cAge" min="14" max="60"></label>
      </div>
      <div class="row2">
        <label>Город<select id="cCity">${cities}</select></label>
        <label>Свой город <small>(необязательно)</small><input id="cCityName" maxlength="24" placeholder="рядом с выбранным"></label>
      </div>
      <label>Семья</label>
      <div class="cards3" id="cBg"></div>
      <label>Образование<select id="cEdu"></select></label>
      <label>Черты характера <small>(до трёх)</small></label>
      <div class="traits" id="cTraits">${D.TRAITS.map(t => `<button data-v="${t.id}" title="${UI.esc(t.d)}">${t.n}</button>`).join('')}</div>
      <label>О себе <small>(нейросеть учтёт это в истории)</small><textarea id="cBio" rows="2" maxlength="300" placeholder="Например: мечтаю открыть автосервис, люблю рыбалку, есть младшая сестра"></textarea></label>
      <div class="cbtns"><button class="btn" id="cBack">Назад</button><button class="btn" id="cRand">Случайно</button><button class="btn big primary" id="cGo">${UI.ic('play')} Начать жизнь</button></div>
    </div>
    <div class="cpreview" id="cPrev"></div>
   </div></div>`;
  const sync = () => {
    $('#cName').value = c.name; $('#cSur').value = c.surname; $('#cAge').value = c.age; $('#cAgeV').textContent = E.years(c.age);
    $$('#cSex button').forEach(b => b.classList.toggle('on', b.dataset.v === c.sex));
    D.useEra(c.era);
    $('#cBg').innerHTML = Object.keys(D.BACKGROUND).map(k => `<button data-v="${k}" class="${k === c.bg ? 'on' : ''}"><b>${D.BACKGROUND[k].n}</b><span>${E.money(Math.round(D.BACKGROUND[k].money * D.ERA[c.era].k * D.DIFF[c.diff].sal))} на старте</span></button>`).join('');
    $$('#cBg button').forEach(b => b.onclick = () => { c.bg = b.dataset.v; sync(); });
    $$('#cEra button').forEach(b => b.classList.toggle('on', b.dataset.v === c.era));
    $$('#cDiff button').forEach(b => b.classList.toggle('on', b.dataset.v === c.diff));
    if (c.era === 'ww2' && M().start[c.city].no36) c.city = 0;
    $('#cCity').innerHTML = cityOpts();
    $$('#cTraits button').forEach(b => b.classList.toggle('on', c.traits.includes(b.dataset.v)));
    $('#cCity').value = c.city; $('#cCityName').value = c.cityName; $('#cBio').value = c.bio;
    const maxEdu = c.age < 16 ? 0 : c.age < 18 ? 1 : c.age < 20 ? 3 : c.age < 26 ? 4 : 5;
    c.edu = Math.min(c.edu, maxEdu);
    $('#cEdu').innerHTML = D.EDU.slice(0, maxEdu + 1).map((e, i) => `<option value="${i}">${e[0].toUpperCase() + e.slice(1)}</option>`).join(''); $('#cEdu').value = c.edu;
    preview();
  };
  const preview = () => {
    const city = M().start[c.city], bg = D.BACKGROUND[c.bg];
    const cn = c.era === 'ww2' && city.n2 || city.n;
    $('#cPrev').innerHTML = `<div class="pcard">${UI.avatar(c, 110)}<h3>${UI.esc(c.name)} ${UI.esc(c.surname)}</h3>
      <p>${E.years(c.age)} · ${UI.esc(c.cityName || cn)}</p>
      <div class="ptraits era"><span>${D.ERA[c.era].n}, ${D.ERA[c.era].y}</span><span class="d-${c.diff}">${D.DIFF[c.diff].n}</span></div>
      <ul><li>${UI.ic('home')} ${c.age < 18 ? 'С родителями' : (bg.home === 'parents' ? (c.age >= 25 ? 'Комната в аренду' : 'С родителями') : 'Своя съёмная квартира')}</li><li>${UI.ic('coin')} ${E.money(Math.round(bg.money * D.ERA[c.era].k * D.DIFF[c.diff].sal))}</li><li>${UI.ic('book')} ${D.EDU[c.edu]}</li>
      <li>${UI.ic('chip')} Жизнь в городе: ${city.cost >= 1.3 ? 'дорогая' : city.cost <= 0.95 ? 'недорогая' : 'средняя'}, зарплаты ×${city.sal.toFixed(2).replace('.', ',')}</li></ul>
      <div class="ptraits">${c.traits.map(id => `<span>${D.TRAITS.find(t => t.id === id).n}</span>`).join('') || '<i>черты не выбраны</i>'}</div></div>`;
  };
  $('#cName').oninput = e => { c.name = e.target.value.trim(); preview(); };
  $('#cSur').oninput = e => { c.surname = e.target.value.trim(); preview(); };
  $('#cAge').oninput = e => { c.age = +e.target.value; sync(); };
  $('#cCity').onchange = e => { c.city = +e.target.value; preview(); };
  $('#cCityName').oninput = e => { c.cityName = e.target.value.trim(); preview(); };
  $('#cEdu').onchange = e => { c.edu = +e.target.value; preview(); };
  $('#cBio').oninput = e => { c.bio = e.target.value; };
  $$('#cSex button').forEach(b => b.onclick = () => { if (c.sex === b.dataset.v) return; c.sex = b.dataset.v; c.name = E.pick(NAMES[c.sex]); c.surname = c.sex === 'f' ? UI.fem(c.surname) : c.surname.replace(/(ов|ев|ёв|ин|ын)а$/, '$1').replace(/ая$/, 'ий'); sync(); });
  $$('#cEra button').forEach(b => b.onclick = () => { if (typeof NET !== 'undefined' && NET.welcome) { UI.toast('Эпоху выбрал хост комнаты', 'bad'); return; } c.era = b.dataset.v; sync(); });
  $$('#cDiff button').forEach(b => b.onclick = () => { c.diff = b.dataset.v; sync(); });
  $$('#cTraits button').forEach(b => b.onclick = () => {
    const id = b.dataset.v;
    if (c.traits.includes(id)) c.traits = c.traits.filter(x => x !== id);
    else {
      const pair = CONFLICT.find(p => p.includes(id)); if (pair) c.traits = c.traits.filter(x => !pair.includes(x));
      if (c.traits.length >= 3) c.traits.shift(); c.traits.push(id);
    }
    sync();
  });
  $('#cBack').onclick = () => UI.title();
  $('#cRand').onclick = () => {
    c.sex = Math.random() < 0.5 ? 'm' : 'f'; c.name = E.pick(NAMES[c.sex]); c.surname = E.pick(NAMES.s); if (c.sex === 'f') c.surname = UI.fem(c.surname);
    c.age = E.pick([16, 18, 19, 21, 23, 25, 28, 32, 37, 45]); c.city = E.ri(0, M().start.length - 1); if (c.era === 'ww2' && M().start[c.city].no36) c.city = 0; c.bg = E.pick(['poor', 'mid', 'mid', 'rich']); c.edu = 5; c.look = E.ri(0, 9999);
    c.traits = []; const pool = D.TRAITS.map(t => t.id).sort(() => Math.random() - .5);
    for (const id of pool) { if (c.traits.length >= 2) break; const pair = CONFLICT.find(p => p.includes(id)); if (pair && c.traits.some(x => pair.includes(x))) continue; c.traits.push(id); }
    sync(); c.edu = E.ri(Math.max(0, +$('#cEdu').options.length - 3), $('#cEdu').options.length - 1); sync();
  };
  $('#cGo').onclick = async () => {
    if (!c.name) { UI.toast('Введите имя', 'bad'); return; }
    if (!c.surname) c.surname = E.pick(NAMES.s);
    UI.s = E.newGame(c);
    if (typeof NET !== 'undefined' && NET.welcome) { if (NET.welcome.era !== c.era) c.era = NET.welcome.era; await NET.adopt(UI.s); }
    UI.s.ch.look = c.look;
    UI.s.chat.push({ k: 'sys', t: `Начало истории · ${E.dateStr(UI.s.date)} · ${D.ERA[c.era].n} · ${D.DIFF[c.diff].n}` });
    UI.s.chat.push({ k: 'ai', t: `${E.dateStr(UI.s.date)}. ${UI.s.ch.name} ${UI.s.ch.surname}, ${E.years(c.age)}, ${E.cityName(UI.s)}. ${c.age < 18 ? 'Ты живёшь с родителями и думаешь, кем стать.' : E.homeName(UI.s) + ', на счету ' + E.money(UI.s.st.money) + '.'} Твой лучший друг со двора — ${UI.s.npcs[0].name}. Вся жизнь впереди — напиши, что будешь делать.` });
    UI.s.chat.push({ k: 'guide' });
    UI.save(); UI.game();
  };
  sync();
  if (typeof NET !== 'undefined' && NET.welcome) { c.era = NET.welcome.era; sync(); $$('#cEra button').forEach(b => b.classList.toggle('locked', b.dataset.v !== c.era)); const h = $('.cform h2'); if (h) h.textContent = 'Новая жизнь — в мире друга'; }
};

// ---------- игровой экран ----------
UI.game = () => {
  setTimeout(() => { if (UI.s && !UI.busy) AI.warm(UI.s); }, 1200);
  const s = UI.s;
  D.useEra(s.era || 'modern'); E.cur = s; WD.migrate(s); D.useEra(s.era); L.init(s); B.migrate(s); U.applyUI(); if (typeof NET !== 'undefined') setTimeout(() => { if (s.mp && !NET.on()) NET.resume(s); else if (NET.on()) { NET.announce(); NET.refresh(); } }, 600); setTimeout(() => { try { RADIO.init(); } catch (e) { } }, 300);
  $('#app').innerHTML = `<div class="game">
    <header class="top" id="top"></header>
    <aside class="left" id="left">
      <nav class="tabs">
        <button data-t="dossier">${UI.ic('user')}<span>Досье</span></button>
        <button data-t="focus">${UI.ic('target')}<span>Цели</span></button>
        <button data-t="assets">${UI.ic('coin')}<span>Имущество</span></button>
        <button data-t="state">${UI.ic('flag')}<span>Власть</span></button>
        <button data-t="world">${UI.ic('globe')}<span>Мир</span></button>
      </nav>
      <div class="tabbody" id="tabbody"></div>
    </aside>
    <main class="mapwrap">
      <div id="map" class="maphost"></div>
      <div class="mapctl"><button id="zIn" title="Приблизить">${UI.ic('plus')}</button><button id="zOut" title="Отдалить">${UI.ic('minus')}</button><button id="zHome" title="Домой">${UI.ic('home')}</button><button id="zWorld" title="Весь мир">${UI.ic('globe')}</button></div>
      <div class="pstack hidden" id="pstack"></div>
      <div class="legend" id="legend"></div>
      <div class="mapbtns" id="mapbtns"></div>
    </main>
    <aside class="chat">
      <div class="chead"><div class="chrow"><b>Нейрочат</b><button class="qhelp" id="qHelp" title="С чего начать? Подсказки">?</button><nav class="ctabs" id="ctabs"></nav></div><div class="aistat" id="gAi"></div></div>
      <div class="msgs" id="msgs"></div>
      <button class="tobottom hidden" id="tobottom" title="К последним сообщениям">↓</button>
      <div class="msgs mpmsgs hidden" id="msgs2"></div>
      <div class="quick" id="quick"></div>
      <div class="cinput">
        <textarea id="inp" rows="2" maxlength="400" placeholder="Что вы делаете? Например: «устроился дворником в ЖЭК»"></textarea>
        <button class="send" id="send" title="Отправить (Enter)">${UI.ic('send')}</button>
      </div>
    </aside>
  </div>`;
  $$('.tabs button').forEach(b => b.onclick = () => { UI.tab = b.dataset.t; UI.left(); });
  $('#send').onclick = () => UI.send();
  $('#tobottom').onclick = () => { const b = UI.ctab === 'mp' ? $('#msgs2') : $('#msgs'); b._stick = true; b.scrollTo({ top: b.scrollHeight, behavior: 'smooth' }); };
  $('#inp').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); UI.send(); } });
  $('#zIn').onclick = () => MAP.zoomBtn(1.5); $('#zOut').onclick = () => MAP.zoomBtn(1 / 1.5);
  $('#zHome').onclick = () => MAP.focusOn(E.city(UI.s).x, E.city(UI.s).y, 760);
  $('#zWorld').onclick = () => MAP.focusOn(M().W / 2, M().H / 2, M().W);
  document.onkeydown = e => { if (e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT') return; if (e.code === 'Space' && $('#modal').classList.contains('hidden') && UI.s && !UI.s.over) { e.preventDefault(); UI.nextWeek(); } };
  MAP.init($('#map'), s);
  UI.renderAll();
  UI.renderChat();
  UI.aiBadge();
  if (s.over) UI.gameOver();
};

UI.renderAll = () => { UI.top(); UI.left(); UI.quick(); UI.legend(); UI.chatTabs(); UI.mapBtns(); };

UI.stat = (icon, label, val, extra, cls, tip, go) => `<button class="stat ${cls || ''}" ${go ? `data-go="${go}"` : ''} title="${UI.esc(tip || label)}"><span class="sic">${UI.ic(icon)}</span><div><small>${label}</small><b>${val}</b>${extra || ''}</div></button>`;
UI.bar = (v, cls) => `<i class="mbar ${cls || ''}"><i style="width:${E.clamp(v, 0, 100)}%"></i></i>`;
UI.top = () => {
  const s = UI.s, age = E.age(s);
  const net = E.monthlyIncome(s) - E.monthlyCost(s);
  const props = s.items.length + s.props.length + (s.home.owned ? 1 : 0) + (s.car ? 1 : 0) + (s.home.furn || []).length;
  const bizP = s.biz.reduce((a, b) => a + b.lastProfit, 0);
  const lvl = v => v >= 70 ? 'good' : v < 35 ? 'bad' : '';
  $('#top').innerHTML = `
    <div class="who" id="whoBtn">${UI.avatar(s.ch, 40)}<div><b>${UI.esc(s.ch.name)} ${UI.esc(s.ch.surname)}</b><small>${E.years(age)} · ${UI.esc(E.cityName(s))}</small></div></div>
    <div class="stats">
      ${UI.stat('coin', 'Деньги', E.short(s.st.money) + ' ₽', `<em class="${net >= 0 ? 'pos' : 'neg'}">${net >= 0 ? '+' : ''}${E.short(net)}/мес</em>`, s.st.money < 0 ? 'bad' : '', 'Деньги на руках. Ниже — сколько прибавляется или убывает за месяц. Нажмите — доходы, расходы, имущество (' + props + '), вклады, кредиты', 'assets')}
      ${UI.stat('smile', 'Счастье', Math.round(s.st.happy), UI.bar(s.st.happy, lvl(s.st.happy)), lvl(s.st.happy), 'Счастье. Нажмите — близкие люди: друзья, семья, соседи', 'people')}
      ${UI.stat('heart', 'Здоровье', Math.round(s.st.health), UI.bar(s.st.health, lvl(s.st.health)), lvl(s.st.health), 'Здоровье. Нажмите — досье: навыки, близкие, летопись', 'dossier')}
      ${UI.stat('star', 'Репутация', Math.round(s.st.rep), UI.bar(s.st.rep), '', 'Известность и уважение: нужна для выборов, кредитов и карьеры. Нажмите — власть и выборы', 'state')}
      ${UI.stat('brief', 'Работа', UI.esc(E.position(s)), s.job ? `<em>${E.short(s.job.salary)}/мес</em>` : (s.pol ? `<em>${s.pol.months} мес. у власти</em>` : ''), 'wide' + (s.crime && s.crime.on ? ' crim' : ''), 'Нажмите — работа: вакансии, резюме' + (s.crime && s.crime.on ? '; у вас есть и тёмная сторона' : ''), s.crime && s.crime.on && !s.job ? 'crime' : 'hh')}
      ${UI.stat('home', 'Жильё', UI.esc(E.homeName(s)), s.home.owned ? '<em>своё' + (s.home.area ? ', ' + s.home.area + ' м²' : '') + '</em>' : (E.homeRent(s) ? `<em>${E.short(E.homeRent(s))}/мес</em>` : ''), 'wide2', 'Нажмите — мой дом: мебель, техника, машина, семья. Оттуда же — поиск другого жилья', 'home')}
      ${UI.stat('factory', 'Бизнес', s.biz.length, s.biz.length ? `<em class="${bizP >= 0 ? 'pos' : 'neg'}">${bizP >= 0 ? '+' : ''}${E.short(bizP)}</em>` : '<em>открыть дело</em>', '', 'Нажмите — ваши бизнесы: сотрудники, производство, контракты', 'biz')}
    </div>
    <div class="turn">
      <button class="date" id="dateBtn" title="Нажмите — газета">${UI.ic('cal')}<div><b>${E.dateStr(s.date)}</b><small>неделя ${s.turn + 1} · <span class="d-${s.diff}">${E.dif(s).n}</span></small></div></button>
      <div class="ap" title="Действия на этой неделе">${[0, 1, 2].map(i => `<i class="${i < s.ap ? 'on' : ''}"></i>`).join('')}</div>
      ${typeof NET !== 'undefined' && NET.on() ? NET.topHtml() : `<div class="nextg"><button class="btn primary next" id="nextBtn" ${UI.busy ? 'disabled' : ''}>Неделя ${UI.ic('play')}</button><button class="btn next2" id="nextM" ${UI.busy ? 'disabled' : ''} title="4 недели подряд">Месяц</button><button class="btn next2" id="nextQ" ${UI.busy ? 'disabled' : ''} title="13 недель подряд">Квартал</button></div>`}
      <div class="topbtns">
        ${typeof NET !== 'undefined' && NET.on() ? `<button class="tbtn iab" id="iaBtn" title="Взаимодействие с другими игроками: блат, общий бизнес, жильё, свадьба, подлянки…">${UI.ic('hand')}<span>Взаимодействие</span>${typeof IA !== 'undefined' && IA.incoming.length ? `<em class="badge">${IA.incoming.length}</em>` : ''}</button>` : ''}
        <button class="tbtn mpb ${typeof NET !== 'undefined' && NET.on() ? 'on' : ''}" id="mpBtn" title="Мультиплеер: комната с друзьями">${UI.ic('globe')}<span>Мультиплеер</span>${typeof NET !== 'undefined' && NET.on() ? `<em class="badge">${NET.list().length}</em>` : ''}</button>
        <button class="tbtn radiob ${typeof RADIO !== 'undefined' && RADIO.st.on ? 'on' : ''}" id="radioBtn" title="Радио и звук">${UI.ic('radio')}<span>Радио</span></button>
        <button class="tbtn" id="menuBtn" title="Меню: настройки, сохранения, помощь">${UI.ic('menu')}<span>Меню</span></button>
      </div>
    </div>`;
  $('#radioBtn').onclick = () => RADIO.toggle();
  $('#mpBtn').onclick = () => U.room();
  if ($('#iaBtn')) $('#iaBtn').onclick = () => IA.open();

  $('#dateBtn').onclick = () => U.paper();
  $$('#top [data-go]').forEach(b => b.onclick = () => UI.go(b.dataset.go));
  $('#nextBtn').onclick = () => UI.nextWeek();
  if ($('#nextM')) { $('#nextM').onclick = () => U.advance(4); $('#nextQ').onclick = () => U.advance(13); }
  if (typeof NET !== 'undefined' && NET.on()) NET.bindTop();
  $('#menuBtn').onclick = () => UI.menu();
  $('#whoBtn').onclick = () => { UI.tab = 'dossier'; UI.left(); };
};

// куда ведут кнопки верхней панели
UI.go = k => {
  const s = UI.s;
  if (['assets', 'dossier', 'state'].includes(k)) { UI.tab = k; UI.left(); const l = $('#left'); if (l) { l.classList.remove('flash'); void l.offsetWidth; l.classList.add('flash'); } return; }
  ({ people: () => U.people(), hh: () => U.hh(), crime: () => U.crime(), home: () => U.home(), biz: () => s.biz.length ? U.biz() : U.bizNew() })[k]();
};
// Кнопки в углу карты: газета и тёмная сторона
UI.mapBtns = () => {
  const el = $('#mapbtns'), s = UI.s; if (!el || !s) return;
  const ps = s.papers || [], last = ps[ps.length - 1], C = s.crime || {}, w = C.on ? L.wanted(s) : 0, ww = E.ww2(s);
  const title = last && last.title ? last.title : (ww ? 'Рабочий вестник' : 'Городские вести');
  el.innerHTML = `
    <button class="mb-paper" id="mbPaper" title="Газета: городская каждую неделю, мировая раз в месяц">
      <span class="mb-mast">${UI.esc(String(title).split('·')[0].trim())}</span>
      <span class="mb-sub">${last ? UI.esc(E.dateStr(last.date || s.date)) : 'свежий номер — в понедельник'}</span>
      ${s.unread ? `<em class="mb-new">${s.unread} ${s.unread === 1 ? 'новый выпуск' : s.unread < 5 ? 'новых выпуска' : 'новых выпусков'}</em>` : `<em class="mb-read">${UI.ic('book')} читать</em>`}
    </button>
    <button class="mb-crime ${C.on ? 'on' : ''}" id="mbCrime" title="Криминальный путь: банда, розыск, полиция, конкуренты">
      <span class="mb-ic">${UI.ic('bolt')}</span>
      <span class="mb-t"><b>Тёмная сторона</b><small>${C.on ? (C.gang ? 'банда «' + UI.esc(C.gang) + '»' : 'одиночка') : 'вы пока чисты'}</small></span>
      <span class="mb-stars">${[1, 2, 3, 4, 5].map(i => `<i class="${i <= w ? 'on' : ''}">★</i>`).join('')}</span>
    </button>`;
  $('#mbPaper').onclick = () => U.paper();
  $('#mbCrime').onclick = () => U.crime();
};
UI.legend = () => {
  const s = UI.s, cs = s.world.cs;
  const home = s.world.home, wars = E.homeAtWar(s), all = s.world.wars.length;
  $('#legend').innerHTML = `<span class="click" data-c="${home}"><i style="background:${cs[home].col}"></i>${cs[home].n}: ${E.countryProvs(s, home).length} пров.</span>` + (wars.length ? `<span class="war">${UI.ic('sword')} Война: ${wars.map(w => E.countryName(w.a === home ? w.b : w.a)).join(', ')}</span>` : '') + (all - wars.length > 0 ? `<span class="muted">${UI.ic('globe')} Войн в мире: ${all - wars.length}</span>` : '');
  $$('#legend [data-c]').forEach(b => b.onclick = () => UI.country(+b.dataset.c));
};

// ---------- левая панель ----------
UI.left = () => {
  $$('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.t === UI.tab));
  const f = { dossier: UI.tDossier, focus: UI.tFocus, assets: UI.tAssets, state: UI.tState, world: UI.tWorld }[UI.tab];
  $('#tabbody').innerHTML = f();
  $$('#tabbody [data-fill]').forEach(b => b.onclick = () => UI.fill(b.dataset.fill));
  $$('#tabbody [data-act]').forEach(b => b.onclick = () => UI.doIntent(JSON.parse(b.dataset.act), b.dataset.label));
  $$('#tabbody [data-country]').forEach(b => b.onclick = () => UI.country(+b.dataset.country));
  $$('#tabbody [data-focus]').forEach(b => b.onclick = () => { UI.s.focus = { id: b.dataset.focus, d: UI.s.date }; E.checkFocus(UI.s, null); UI.save(); UI.left(); UI.toast('Новая цель: ' + D.FOCUS.find(x => x.id === b.dataset.focus).n); });
};
UI.fill = t => { const i = $('#inp'); i.value = t; i.focus(); i.setSelectionRange(t.length, t.length); };

UI.tDossier = () => {
  const s = UI.s, b = new Date(s.ch.birth);
  const rel = s.rel.map(r => `<li><span>${UI.esc(r.name)} <small>${r.role}</small></span>${UI.bar(r.att, r.att >= 65 ? 'good' : r.att < 30 ? 'bad' : '')}</li>`).join('');
  const relX = typeof SOC !== 'undefined' && s.soc ? SOC.known(s).filter(p => !s.rel.some(r => r.soc === p.id || r.name === p.name) && p.att >= 62).sort((a, b) => b.att - a.att).slice(0, 5).map(p => `<li><span>${UI.esc(p.name)} <small>${UI.esc(p.role)}</small></span>${UI.bar(p.att, 'good')}</li>`).join('') : '';
  return `<div class="dossier">
    <div class="dhead">${UI.avatar(s.ch, 72)}<div><h3>${UI.esc(s.ch.name)} ${UI.esc(s.ch.surname)}</h3><p>${E.years(E.age(s))}, род. ${b.getDate()}.${String(b.getMonth() + 1).padStart(2, '0')}.${b.getFullYear()}</p><p>${UI.esc(E.cityName(s))} · ${D.EDU[s.ch.edu]}</p></div></div>
    ${s.ch.traits.length ? `<div class="ptraits">${s.ch.traits.map(id => { const t = D.TRAITS.find(x => x.id === id); return `<span title="${UI.esc(t.d)}">${t.n}</span>`; }).join('')}</div>` : ''}
    <h4>Навыки</h4>
    <ul class="skills">${Object.keys(D.SKILLS).map(k => `<li><span>${D.SKILLS[k]}</span><b>${Math.round(s.st.sk[k])}</b>${UI.bar(s.st.sk[k])}</li>`).join('')}
      <li><span>Стресс</span><b>${Math.round(s.st.stress)}</b>${UI.bar(s.st.stress, s.st.stress > 65 ? 'bad' : '')}</li>
      <li title="Растёт от работы без отдыха. Выше 85 — портится здоровье. Снимается отдыхом, путешествиями, временем с близкими"><span>Усталость</span><b>${Math.round(s.st.fatigue || 0)}</b>${UI.bar(s.st.fatigue || 0, (s.st.fatigue || 0) > 70 ? 'bad' : '')}</li>
      <li title="Связи и вес в обществе: помогает со взятками, выборами, бизнес-войнами и ОПГ. Растёт от репутации, власти, бизнеса, СМИ и роскоши"><span>Влияние</span><b>${Math.round(s.st.infl || 0)}</b>${UI.bar(s.st.infl || 0, 'good')}</li></ul>
    ${(s.grind || 0) >= 16 ? `<p class="note warnbal">${UI.ic('heart')} Уже ${s.grind} нед. одна работа. Если не отдохнуть и не провести время с близкими — начнутся проблемы со здоровьем.</p>` : ''}
    ${s.opg && !s.opg.gone ? `<h4>ОПГ «${UI.esc(s.opg.name)}»</h4><div class="opgc"><div class="kv"><span>Людей</span><b>${s.opg.members}</b></div><div class="kv"><span>Районов</span><b>${s.opg.terr}</b></div><div class="kv"><span>Влияние ОПГ</span><b>${Math.round(s.opg.infl)}/100</b></div><small>Команды: «набираю людей», «захватываю район», «прикармливаю полицию», «объявляю независимость региона».</small></div>` : ''}
    ${typeof PROJ !== 'undefined' && (s.proj || []).some(p => !p.closed) ? `<h4>Мои затеи</h4><ul class="facts">${s.proj.filter(p => !p.closed).map(p => `<li>${UI.esc(PROJ.title(s, p))}${p.subs ? ' · ' + E.short(p.subs) : ''}${p.inc ? ' · ' + E.short(p.inc) + ' ₽/мес' : ''}</li>`).join('')}</ul><p class="small">Управляются через чат: «сниму ролик», «вложу 100к в канал», «как дела на канале?»</p>` : ''}
    ${(s.lux || []).length ? `<h4>Роскошь</h4><ul class="facts">${s.lux.map(l => `<li>${UI.esc(l.n)}</li>`).join('')}</ul>` : ''}
    ${s.study ? `<h4>Учёба</h4><p class="note">${UI.esc(s.study.n)}: осталось ${s.study.weeks} нед. ${UI.bar(100 - s.study.weeks / s.study.total * 100, 'good')}</p>` : ''}
    ${s.election ? `<h4>Выборы</h4><p class="note">${s.election.n}: через ${s.election.weeks} нед., шанс ~${E.clamp(s.election.chance + (s.flags.campaign || 0), 3, 95)}%</p>` : ''}
    <h4>Близкие и друзья</h4><ul class="rels">${rel}${relX}<li class="relmore"><span>Все знакомые →</span></li></ul>
    <h4>Летопись</h4>
    ${s.summary ? `<p class="summary">${UI.esc(s.summary)}</p>` : ''}
    ${(s.open || []).length ? `<h5 class="memh">Незавершённое</h5><ul class="facts open">${s.open.map(x => `<li>${UI.esc(x)}</li>`).join('')}</ul>` : ''}
    ${(s.chron || []).length ? `<h5 class="memh">По годам</h5>${s.chron.slice().reverse().map(c => `<details class="chron"><summary>${c.y}</summary><p>${UI.esc(c.t)}</p></details>`).join('')}` : ''}
    <ul class="facts">${s.facts.slice().reverse().slice(0, 14).map(f => `<li>${UI.esc(f.t)}</li>`).join('')}</ul>
  </div>`;
};

UI.tFocus = () => {
  const s = UI.s;
  const cur = s.focus ? D.FOCUS.find(f => f.id === s.focus.id) : null;
  const fi = { coin: 'coin', up: 'up', book: 'book', home: 'home', biz: 'factory', heart: 'heart', ring: 'ring', star: 'star', flag: 'flag' };
  return `<div class="focus"><p class="hint">Цель — как фокус в хойке: выберите одну, и когда она будет выполнена, получите награду.</p>
    ${cur ? `<div class="fcur"><div class="fic">${UI.ic(fi[cur.icon] || 'target')}</div><div><b>${cur.n}</b><small>${cur.d}</small>${UI.bar(E.clamp(cur.prog(s) * 100, 0, 100), 'good')}<small class="rw">Награда: ${cur.rewardT}</small></div></div>` : '<p class="note">Цель не выбрана.</p>'}
    <div class="ftree">${D.FOCUS.map(f => {
      const done = s.focusDone.includes(f.id), on = cur && cur.id === f.id;
      return `<button class="fnode ${done ? 'done' : ''} ${on ? 'on' : ''}" ${done || on ? 'disabled' : `data-focus="${f.id}"`} title="${UI.esc(f.d + ' — ' + f.rewardT)}"><div class="fic">${UI.ic(done ? 'check' : (fi[f.icon] || 'target'))}</div><span>${f.n}</span></button>`;
    }).join('')}</div></div>`;
};

UI.tAssets = () => {
  const s = UI.s;
  const inc = [], exp = [];
  if (s.job) inc.push([s.job.title, s.job.salary]);
  if (s.pol && D.POL_SAL[s.pol.id]) inc.push([s.pol.n, E.salary(s, D.POL_SAL[s.pol.id])]);
  for (const b of s.biz) inc.push(['«' + b.n + '» (прошлый месяц)', b.lastProfit]);
  for (const p of s.props) if (p.rentOut) inc.push(['Аренда: ' + p.n, p.rentIncome]);
  if (s.inv.deposit) inc.push(['Проценты по вкладу', Math.round(s.inv.deposit * 0.01)]);
  exp.push(['Еда, связь, проезд', E.living(s)]);
  if (E.homeRent(s)) exp.push(['Жильё', E.homeRent(s)]);
  if (E.utilities(s)) exp.push(['Коммунальные', E.utilities(s)]);
  if (E.transit(s)) exp.push(['Проездной', E.transit(s)]);
  if (E.carUp(s)) exp.push(['Машина', E.carUp(s)]);
  if (L.kidCost(s)) exp.push(['Дети', L.kidCost(s)]);
  if (L.spouseIncome(s)) inc.push(['Зарплата супруга(и)', L.spouseIncome(s)]);
  for (const l of s.loans) exp.push([l.n, l.monthly]);
  if (E.upkeep(s)) exp.push(['Содержание, спорт', E.upkeep(s)]);
  if (s.study && s.study.monthly) exp.push(['Учёба', s.study.monthly]);
  const row = (a, cls) => `<li><span>${UI.esc(a[0])}</span><b class="${cls}">${E.money(a[1])}</b></li>`;
  const ti = inc.reduce((a, x) => a + x[1], 0), te = exp.reduce((a, x) => a + x[1], 0);
  return `<div class="assets">
    <div class="nw"><small>Состояние (всё имущество минус долги)</small><b>${E.money(E.netWorth(s))}</b></div>
    <h4>Месяц</h4><ul class="ledger">${inc.map(x => row(x, 'pos')).join('') || '<li><i>доходов нет</i></li>'}</ul>
    <ul class="ledger">${exp.map(x => row(x, 'neg')).join('')}</ul>
    <div class="nwl"><span>Итого за месяц</span><b class="${ti - te >= 0 ? 'pos' : 'neg'}">${ti - te >= 0 ? '+' : ''}${E.money(ti - te)}</b></div>
    <h4>Жильё</h4><p class="note">${UI.esc(E.homeName(s))}${s.home.area ? ', ' + s.home.area + ' м²' : ''}${s.home.owned ? ' · стоимость ' + E.money(s.home.value) : ''} · уют ${Math.round(E.comfort(s))}</p>
    <h4>Транспорт</h4><p class="note">${s.car ? UI.esc(s.car.n) + ' · ' + E.money(E.carUp(s)) + '/мес' : 'Общественный транспорт · ' + E.money(E.transit(s)) + '/мес'}</p>
    ${s.props.length ? `<h4>Недвижимость</h4><ul class="ledger">${s.props.map(p => row([p.n + (p.rentOut ? ' (сдаётся)' : ''), p.value])).join('')}</ul>` : ''}
    ${s.biz.length ? `<h4>Бизнес</h4>${s.biz.map(b => `<div class="bizc"><b>${UI.esc(b.n)}</b><small>${UI.esc(b.type)} · ${b.months} мес.</small><div class="kv"><span>Стоимость</span><b>${E.money(b.value)}</b></div><div class="kv"><span>Прибыль</span><b class="${b.lastProfit >= 0 ? 'pos' : 'neg'}">${E.money(b.lastProfit)}</b></div><div class="kv"><span>Состояние</span>${UI.bar(b.health, b.health > 60 ? 'good' : b.health < 30 ? 'bad' : '')}</div></div>`).join('')}` : ''}
    ${(s.inv.deposit + s.inv.stocks + s.inv.crypto) ? `<h4>Вложения</h4><ul class="ledger">${s.inv.deposit ? row(['Вклад', s.inv.deposit]) : ''}${s.inv.stocks ? row(['Акции', s.inv.stocks]) : ''}${s.inv.crypto ? row(['Криптовалюта', s.inv.crypto]) : ''}</ul>` : ''}
    ${s.loans.length ? `<h4>Долги</h4><ul class="ledger">${s.loans.map(l => row([l.n + ' (' + E.money(l.monthly) + '/мес)', l.left], 'neg')).join('')}</ul>` : ''}
    ${s.items.length ? `<h4>Вещи</h4><ul class="items">${s.items.map(i => `<li>${UI.esc(i.n)}</li>`).join('')}</ul>` : ''}
  </div>`;
};

UI.tState = () => {
  const s = UI.s, cs = s.world.cs, home = s.world.home;
  const lead = E.isLeader(s);
  const ci = D.POLITICS.findIndex(p => s.pol && p.id === s.pol.id);
  const ladder = D.POLITICS.map((p, i) => `<li class="${i <= ci ? 'done' : ''} ${i === ci + 1 ? 'next' : ''}"><i>${i <= ci ? UI.ic('check') : i + 1}</i><div><b>${p.n}</b><small>${p.appoint ? 'по назначению' : 'выборы, ' + (p.cost ? E.short(E.price(s, p.cost)) + ' ₽' : 'без затрат')} · репутация ${p.rep}+ · с ${E.years(p.age)}${p.months ? ' · ' + p.months + ' мес. на прошлой должности' : ''}</small></div></li>`).join('');
  const next = D.POLITICS[ci + 1];
  let html = `<div class="statet"><h4>Путь к власти</h4><ol class="ladder">${ladder}</ol>`;
  if (next && !s.election) html += `<button class="btn wide" data-fill="${next.appoint ? 'Добиваюсь назначения: ' : 'Выдвигаюсь на выборы: '}${next.n.toLowerCase()}">${UI.ic('flag')} ${next.appoint ? 'Добиваться назначения' : 'Выдвинуться'}: ${next.n.toLowerCase()}</button>`;
  const H = cs[home];
  html += `<h4>${UI.esc(H.n)}</h4>
    <button class="btn wide" data-country="${home}">${UI.ic('globe')} Вся статистика страны</button>
    <div class="kv"><span>Провинций</span><b>${E.countryProvs(s, home).length} <small>(было ${s.world.startCount})</small></b></div>
    <div class="kv"><span>ВВП</span><b>${UI.gdp(s, H.st.gdp)}</b></div>
    <div class="kv"><span>Стабильность</span><b>${Math.round(H.st.stab)}%</b></div>
    <div class="kv"><span>Военная мощь</span><b>${Math.round(E.power(s, home))}</b></div>`;
  if (lead || (s.pol && s.pol.id === 'minister')) {
    html += `<h4>Указы</h4><div class="chips">${['Программа развития экономики', 'Снизить налоги', 'Повысить пенсии и зарплаты бюджетникам', 'Борьба с коррупцией', 'Жёсткий бюджет'].map(t => `<button data-fill="Указ: ${t.toLowerCase()}">${t}</button>`).join('')}</div>`;
  }
  if (lead) {
    html += `<div class="kv"><span>Армия</span><b>×${s.world.army.toFixed(2)}</b></div><button class="btn wide" data-act='{"type":"army"}' data-label="Укрепить армию">${UI.ic('shield')} Укрепить армию</button>`;
    const wars = E.homeAtWar(s);
    if (wars.length) html += `<h4>Войны</h4>` + wars.map(w => { const en = w.a === home ? w.b : w.a, sc = w.a === home ? w.took - w.lost : w.lost - w.took; return `<div class="warc"><b>${UI.ic('sword')} ${UI.esc(cs[en].n)}</b><small>${w.weeks} нед. · счёт ${sc >= 0 ? '+' : ''}${sc} пров. · сила врага ${Math.round(E.power(s, en))}</small><button class="btn small" data-act='${JSON.stringify({ type: 'peace', target: cs[en].n })}' data-label="Предложить мир: ${UI.esc(cs[en].n)}">Предложить мир</button></div>`; }).join('');
    const nb = new Set(); for (const e of M().edges) { const a = s.world.own[e.a], b = s.world.own[e.b]; if (a === home && b !== home) nb.add(b); if (b === home && a !== home) nb.add(a); }
    html += `<h4>Соседи</h4><ul class="nbs">${[...nb].sort((a, b) => E.power(s, b) - E.power(s, a)).map(c => `<li><i style="background:${cs[c].col}"></i><span class="click" data-country="${c}">${UI.esc(cs[c].n)}<small>сила ${Math.round(E.power(s, c))} · отношения ${UI.rel(cs[c].rel)}</small></span>${WD.atWar(s, home, c) ? '<em>война</em>' : `<button class="btn small danger" data-act='${JSON.stringify({ type: 'war', target: cs[c].n })}' data-label="Объявить войну: ${UI.esc(cs[c].n)}">Война</button>`}</li>`).join('')}</ul>`;
  } else html += `<p class="note">Указы, армия и войны — у главы государства${E.ww2(s) ? ' (генсека)' : ' (президента)'}.</p>`;
  if (s.world.annexed.length) html += `<h4>Присоединено</h4><p class="note">${s.world.annexed.map(c => UI.esc(cs[c].n)).join(', ')}</p>`;
  return html + '</div>';
};
UI.rel = r => r >= 50 ? 'союзные' : r >= 15 ? 'тёплые' : r > -15 ? 'ровные' : r > -60 ? 'холодные' : 'враждебные';
UI.gdp = (s, v) => (v >= 1000 ? (v / 1000).toFixed(v >= 10000 ? 0 : 1).replace('.', ',') + ' трлн $' : (v >= 10 ? Math.round(v) : v.toFixed(1).replace('.', ',')) + ' млрд $');
UI.num = (v, d) => (+v).toFixed(d === undefined ? 1 : d).replace('.', ',');
UI.pop = v => v >= 1 ? UI.num(v, v >= 100 ? 0 : 1) + ' млн' : Math.round(v * 1000) + ' тыс.';

// ---------- мир ----------
UI.tWorld = () => {
  const s = UI.s, cs = s.world.cs, al = E.alive(s);
  const tot = k => al.reduce((a, i) => a + cs[i].st[k], 0);
  const topG = al.slice().sort((a, b) => cs[b].st.gdp - cs[a].st.gdp).slice(0, 10);
  const topP = al.slice().sort((a, b) => E.power(s, b) - E.power(s, a)).slice(0, 8);
  const row = (i, v) => `<li class="click" data-country="${i}"><i style="background:${cs[i].col}"></i><span>${UI.esc(cs[i].n)}</span><b>${v}</b></li>`;
  const wars = s.world.wars;
  const news = s.world.news.slice().reverse().slice(0, 40);
  return `<div class="worldt">
    <div class="wstats"><div><small>Население мира</small><b>${UI.num(tot('pop') / 1000, 2)} млрд</b></div><div><small>Мировой ВВП</small><b>${UI.gdp(s, tot('gdp'))}</b></div><div><small>Стран</small><b>${al.length}</b></div><div><small>Войн</small><b>${wars.length}</b></div></div>
    ${wars.length ? `<h4>Войны</h4><ul class="wlist">${wars.map(w => `<li><span class="click" data-country="${w.a}">${UI.esc(cs[w.a].n)}</span> ${UI.ic('sword')} <span class="click" data-country="${w.b}">${UI.esc(cs[w.b].n)}</span><small>${w.weeks} нед.${w.civil ? ' · гражданская' : ''}</small></li>`).join('')}</ul>` : ''}
    <h4>Крупнейшие экономики</h4><ul class="rank">${topG.map(i => row(i, UI.gdp(s, cs[i].st.gdp))).join('')}</ul>
    <h4>Сильнейшие армии</h4><ul class="rank">${topP.map(i => row(i, Math.round(E.power(s, i)))).join('')}</ul>
    <h4>Новости мира</h4><ul class="news">${news.map(n => `<li class="imp${n.imp}"><small>${E.dateStr(n.d)}</small>${UI.esc(n.t)}</li>`).join('') || '<li><small>Пока тихо.</small></li>'}</ul>
  </div>`;
};

// мини-график
UI.spark = (arr, col, h) => {
  h = h || 46;
  if (!arr || arr.length < 2) return '<div class="spark empty">мало данных</div>';
  const w = 260, mn = Math.min(...arr), mx = Math.max(...arr), r = mx - mn || 1;
  const pts = arr.map((v, i) => `${(i / (arr.length - 1) * w).toFixed(1)},${(h - 3 - (v - mn) / r * (h - 8)).toFixed(1)}`).join(' ');
  const up = arr[arr.length - 1] >= arr[0];
  return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><polyline points="0,${h} ${pts} ${w},${h}" fill="${col || (up ? '#4f8a4b' : '#b5483b')}" opacity=".12"/><polyline points="${pts}" fill="none" stroke="${col || (up ? '#4f8a4b' : '#b5483b')}" stroke-width="1.8" vector-effect="non-scaling-stroke"/></svg>`;
};
UI.chg = (arr, n) => { if (!arr || arr.length < 2) return ''; const a = arr[Math.max(0, arr.length - 1 - n)], b = arr[arr.length - 1]; const p = (b / a - 1) * 100; return `<em class="${p >= 0 ? 'pos' : 'neg'}">${p >= 0 ? '+' : ''}${UI.num(p)}%</em>`; };

UI.country = ci => {
  const s = UI.s, c = s.world.cs[ci]; if (!c) return;
  const st = c.st, home = s.world.home;
  const provs = E.countryProvs(s, ci).length;
  const pc = st.gdp * 1e9 / Math.max(1, st.pop * 1e6);
  const capN = c.cap >= 0 ? M().provinces[c.cap].n : '—';
  const wars = WD.enemies(s, ci);
  const yrs = Math.min(12, c.h.gdp.length - 1);
  const life = pc > 30000 ? 'очень высокий' : pc > 12000 ? 'высокий' : pc > 4000 ? 'средний' : pc > 1500 ? 'низкий' : 'очень низкий';
  const pcOld = E.ww2(s);
  const kv = (k, v, tip) => `<div class="kv" ${tip ? `title="${UI.esc(tip)}"` : ''}><span>${k}</span><b>${v}</b></div>`;
  const bar = (v, good) => UI.bar(v, good ? (v >= 60 ? 'good' : v < 30 ? 'bad' : '') : '');
  UI.modal(`<div class="cmodal">
    <div class="chead2" style="--c:${c.col}"><div class="flag" style="background:${c.col}"></div><div><h3>${UI.esc(c.n)}</h3><small>${UI.esc(st.gov || '')}${st.lead ? ' · ' + UI.esc(st.lead) : ''}${st.bloc && st.bloc.length ? ' · ' + st.bloc.join(', ') : ''}</small></div><button class="close" id="cmX">${UI.ic('x')}</button></div>
    ${c.dead ? '<p class="note" style="padding:0 18px">Этой страны больше нет на карте.</p>' : ''}
    <div class="cgrid">
      <div class="cbox"><h5>Экономика</h5>
        ${kv('ВВП', UI.gdp(s, st.gdp) + ' ' + UI.chg(c.h.gdp, 12), pcOld ? 'В долларах 1990 года (оценки Мэддисона)' : 'В текущих долларах')}
        ${UI.spark(c.h.gdp)}
        ${kv('ВВП на душу', Math.round(pc).toLocaleString('ru-RU') + ' $')}
        ${kv('Уровень жизни', life)}
        ${kv('Рост за год', UI.chg(c.h.gdp, 12) || '—')}
        ${kv('Инфляция', UI.num(st.infl) + '%')}
        ${kv('Безработица', UI.num(st.unemp) + '%')}
        ${kv('Госдолг', Math.round(st.debt) + '% ВВП')}
      </div>
      <div class="cbox"><h5>Население и власть</h5>
        ${kv('Население', UI.pop(st.pop) + ' ' + UI.chg(c.h.pop, 12))}
        ${UI.spark(c.h.pop, '#2f6f7e')}
        ${kv('Площадь', Math.round(st.km / 1000).toLocaleString('ru-RU') + ' тыс. км²')}
        ${kv('Столица', UI.esc(capN))}
        ${kv('Провинций', provs + (c.base && provs !== c.base ? ` <small>(было ${c.base})</small>` : ''))}
        <div class="kv"><span>Стабильность</span><b>${Math.round(st.stab)}%</b></div>${bar(st.stab, true)}
        ${UI.spark(c.h.stab, '#b8892f', 30)}
      </div>
      <div class="cbox"><h5>Армия и политика</h5>
        ${kv('Армия', Math.round(st.army).toLocaleString('ru-RU') + ' тыс.')}
        ${kv('Военные расходы', UI.num(st.milp) + '% ВВП')}
        ${kv('Военная мощь', Math.round(E.power(s, ci)))}
        ${ci !== home ? kv('Отношения с нами', UI.rel(c.rel) + ` <small>(${c.rel > 0 ? '+' : ''}${Math.round(c.rel)})</small>`) : kv('Это', 'ваша страна')}
        ${kv('Войны', wars.length ? wars.map(x => UI.esc(s.world.cs[x].n)).join(', ') : 'нет')}
        ${c.puppetOf !== undefined && s.world.cs[c.puppetOf] ? kv('Зависит от', UI.esc(s.world.cs[c.puppetOf].n)) : ''}
      </div>
    </div>
    <div class="cev"><h5>События</h5><ul>${c.ev.slice().reverse().map(e => `<li><small>${E.dateStr(e.d)}</small>${UI.esc(e.t)}</li>`).join('') || '<li><small>Ничего заметного.</small></li>'}</ul></div>
    <div class="cbtns2">${ci !== home && E.isLeader(s) && !c.dead ? (WD.atWar(s, home, ci) ? `<button class="btn" data-act='${JSON.stringify({ type: 'peace', target: c.n })}'>Предложить мир</button>` : `<button class="btn" data-fill="Указ: заключить договор о сотрудничестве с ${UI.esc(c.n)}">Договор</button><button class="btn" data-fill="Указ: ввести санкции против ${UI.esc(c.n)}">Санкции</button><button class="btn danger" data-act='${JSON.stringify({ type: 'war', target: c.n })}'>${UI.ic('sword')} Объявить войну</button>`) : ''}
      ${!c.dead && c.cap >= 0 ? `<button class="btn" id="cmGo">${UI.ic('globe')} Показать на карте</button>` : ''}</div>
  </div>`);
  $('#cmX').onclick = UI.closeModal;
  if ($('#cmGo')) $('#cmGo').onclick = () => { UI.closeModal(); const p = M().provinces[c.cap]; MAP.focusOn(p.x, p.y, Math.max(300, Math.sqrt(st.km) * 0.5)); };
  $$('#modal [data-act]').forEach(b => b.onclick = () => { UI.closeModal(); UI.doIntent(JSON.parse(b.dataset.act), b.textContent.trim() + ': ' + c.n); });
  $$('#modal [data-fill]').forEach(b => b.onclick = () => { UI.closeModal(); UI.fill(b.dataset.fill); });
};

UI.provPanel = i => {
  const el = $('#provpanel');
  if (i < 0) { el.classList.add('hidden'); return; }
  const s = UI.s, m = M(), cs = s.world.cs, p = m.provinces[i], o = s.world.own[i];
  const core = (s.world.core || s.world.own)[i];
  const cities = m.cities.filter(c => !(E.ww2(s) && c.h2) && (c.x - p.x) ** 2 + (c.y - p.y) ** 2 < p.a * 0.5).slice(0, 3);
  const C = cs[o];
  const pop = C.st.pop * (p.w || 0) * (C.base ? 1 : 1);
  el.innerHTML = `<button class="close" id="ppX">${UI.ic('x')}</button><div class="flagbar" style="background:${C.col}"></div>
    <h3>${C.cap === i ? '★ ' : ''}${UI.esc(p.n)}</h3><p class="click" id="ppC">${UI.esc(C.n)} ›</p>
    ${core !== o && cs[core] ? `<p class="small neg">Оккупирована. Принадлежала: ${UI.esc(cs[core].n)}</p>` : ''}
    ${cities.length ? `<p class="small">Города: ${cities.map(c => UI.esc(E.ww2(s) && c.n2 || c.n)).join(', ')}</p>` : ''}
    <div class="kv"><span>Площадь</span><b>${Math.round(p.km || 0).toLocaleString('ru-RU')} км²</b></div>
    <div class="kv"><span>Сила страны</span><b>${Math.round(E.power(s, o))}</b></div>
    <button class="btn small" id="ppMore">${UI.ic('globe')} О стране</button>`;
  el.classList.remove('hidden');
  $('#ppX').onclick = () => MAP.select(-1);
  $('#ppC').onclick = $('#ppMore').onclick = () => UI.country(o);
};

// ---------- быстрые действия ----------
UI.quick = () => {
  const s = UI.s, q = [];
  if (!s.job && !s.pol && E.age(s) >= 14) q.push(['Найти работу…', 'fill', 'Устраиваюсь работать ']);
  if (s.job) q.push(['Работать усердно', 'send', 'Работаю усердно всю неделю']);
  if (s.job && s.job.months >= 3) q.push(['Попросить повышение', 'send', 'Прошу у начальства повышение']);
  q.push(['Отдохнуть', 'send', 'Отдыхаю, гуляю по городу']);
  q.push(['Учиться…', 'fill', 'Записываюсь на ']);
  q.push(['Позвонить маме', 'send', 'Звоню маме, долго разговариваем']);
  if (s.st.health < 60) q.push(['К врачу', 'send', 'Иду к врачу']);
  if (!s.biz.length && s.st.money > E.m(s, 500000)) q.push(['Открыть бизнес…', 'fill', 'Открываю свой бизнес: ']);
  const fr = (s.npcs || []).find(n => n.id === 'friend' && n.alive); if (fr) q.push(['Позвонить ' + L.gen(fr.name).replace(/[иы]$/, 'е').replace(/а$/, 'у'), 'send', 'Звоню ' + fr.name + ', болтаем обо всём']);
  if (E.isLeader(s)) q.unshift(['Указ…', 'fill', 'Указ: ']);
  if ((s.props || []).some(p => !p.rentOut)) q.push(['Сдать квартиру', 'send', 'Сдаю свою свободную квартиру жильцам']);
  const pj = (s.proj || []).find(p => !p.closed);
  if (pj && (pj.kind === 'media' || pj.kind === 'music')) q.push([pj.kind === 'music' ? 'Записать трек' : 'Снять ролик', 'send', pj.kind === 'music' ? 'Записываю новый трек' : 'Снимаю новый выпуск для канала «' + pj.n + '»']);
  else if (!pj && E.age(s) >= 14 && !E.ww2(s) && s.turn % 3 === 0) q.push(['Завести канал…', 'fill', 'Завожу ютуб-канал про ']);
  q.push(['Как у меня дела?', 'send', 'Как у меня сейчас дела? Что я имею?']);
  $('#quick').innerHTML = q.map((x, i) => `<button data-i="${i}">${x[0]}</button>`).join('');
  $$('#quick button').forEach(b => b.onclick = () => { const x = q[+b.dataset.i]; if (x[1] === 'fill') UI.fill(x[2]); else { $('#inp').value = x[2]; UI.send(); } });
};

// ---------- чат ----------
UI.pushChat = m => { UI.s.chat.push(m); if (UI.s.chat.length > 260) UI.s.chat.splice(0, UI.s.chat.length - 260); };
UI.msgHtml = m => {
  if (m.k === 'me') return `<div class="m me"><div>${UI.esc(m.t)}</div></div>`;
  if (m.k === 'ai') return `<div class="m ai"><div>${UI.esc(m.t).replace(/\n/g, '<br>')}</div></div>`;
  if (m.k === 'sys') return `<div class="m sys"><span>${UI.esc(m.t)}</span></div>`;
  if (m.k === 'guide') return UI.guideHtml();
  if (m.k === 'out') {
    const r = m.roll;
    const cls = m.impossible ? 'imp' : (m.ok ? (m.crit ? 'crit' : 'ok') : 'bad');
    return `<div class="m out ${cls}"><div class="oh"><b>${UI.esc(m.title)}</b>${r ? `<span class="roll" title="Нужно выбросить ${r.chance} или меньше">${UI.ic('dice')} ${r.roll} / ${r.chance}%</span>` : ''}</div>${m.lines && m.lines.length ? `<ul>${m.lines.map(l => `<li class="${/[+]/.test(l) && !/−|-\d/.test(l) ? 'pos' : (/(−|-)\d/.test(l) ? 'neg' : '')}">${UI.esc(l)}</li>`).join('')}</ul>` : ''}</div>`;
  }
  if (m.k === 'month') {
    const r = m.r;
    return `<div class="m month"><div class="oh"><b>${UI.ic('coin')} Итоги месяца · ${UI.esc(m.mon)}</b><span class="${r.net >= 0 ? 'pos' : 'neg'}">${r.net >= 0 ? '+' : ''}${E.money(r.net)}</span></div><ul>${r.inc.map(x => `<li><span>${UI.esc(x[0])}</span><b class="${x[1] >= 0 ? 'pos' : 'neg'}">${x[1] >= 0 ? '+' : ''}${E.money(x[1])}</b></li>`).join('')}${r.exp.map(x => `<li><span>${UI.esc(x[0])}</span><b class="neg">−${E.money(x[1])}</b></li>`).join('')}${r.stocks ? `<li><span>Акции подешевели/подорожали</span><b class="${r.stocks >= 0 ? 'pos' : 'neg'}">${E.money(r.stocks)}</b></li>` : ''}${r.crypto ? `<li><span>Криптовалюта</span><b class="${r.crypto >= 0 ? 'pos' : 'neg'}">${E.money(r.crypto)}</b></li>` : ''}</ul>${(r.bizInc || []).map(t => '<p class="neg sm">' + UI.esc(t) + '</p>').join('')}${(r.notes || []).map(t => '<p class="sm">' + UI.esc(t) + '</p>').join('')}${r.collectors ? '<p class="neg">Коллекторы звонят каждый день. Пора гасить долги.</p>' : ''}${r.evicted ? `<p class="neg">Платить за жильё нечем. Пришлось съехать: ${UI.esc(r.evicted.toLowerCase())}.</p>` : ''}${r.bankrupt ? `<p class="neg">Обанкротился: ${UI.esc(r.bankrupt.join(', '))}</p>` : ''}</div>`;
  }
  if (m.k === 'news') return `<div class="m news"><div class="oh"><b>${UI.ic(m.title ? 'brief' : 'globe')} ${m.title || 'В мире'}</b></div><ul>${m.items.map(x => `<li class="${x.imp >= 2 ? 'big' : ''}">${UI.esc(x.t)}</li>`).join('')}</ul></div>`;
  if (m.k === 'mp') return m.sys ? `<div class="m sys mpsys"><span>${UI.ic('globe')} ${UI.esc(m.t)}</span></div>` : m.chat ? `<div class="m mpchat ${m.mine ? 'mine' : ''}"><div><b>${UI.esc(m.who)}</b> ${UI.esc(m.t)}</div></div>` : `<div class="m mpfeed"><div><b>${UI.ic('user')} ${UI.esc(m.who)}${m.city ? ' · ' + UI.esc(m.city) : ''}</b><span>${UI.esc(m.t)}</span>${m.x ? `<p>${UI.esc(m.x)}</p>` : ''}</div></div>`;
  if (m.k === 'war') return `<div class="m war"><div class="oh"><b>${UI.ic('sword')} Фронт</b></div><ul>${m.items.map(x => `<li class="${x.good ? 'pos' : x.bad ? 'neg' : ''}${x.big ? ' big' : ''}">${UI.esc(x.t)}</li>`).join('')}</ul></div>`;
  return '';
};
// ---------- второй чат: что делают другие игроки (только чтение) ----------
UI.ctab = 'me';
UI.appendMp = m => {
  const s = UI.s; if (!s) return;
  s.mpChat = s.mpChat || []; s.mpChat.push(m); if (s.mpChat.length > 200) s.mpChat.splice(0, s.mpChat.length - 200);
  if (UI.ctab === 'mp') { const box = $('#msgs2'); if (box) { UI.bindScroll(box); box.insertAdjacentHTML('beforeend', UI.mpHtml(m)); UI.stick(box); } }
  else if (!m.sys || /вышел|Хост/.test(m.t)) { s.mpUnread = (s.mpUnread || 0) + 1; }
  UI.chatTabs();
};
UI.mpHtml = m => {
  if (m.sys) return `<div class="m sys mpsys"><span>${UI.ic('globe')} ${UI.esc(m.t)}</span></div>`;
  if (m.chat) return `<div class="m mpchat ${m.mine ? 'mine' : ''}"><div><b>${UI.esc(m.who)}</b> ${UI.esc(m.t)}</div></div>`;
  const cls = m.ok === false ? 'bad' : 'ok';
  return `<div class="mpf"><div class="mpfh">${UI.avatar({ sex: m.sex || 'm', look: m.look || 1 }, 30)}<div><b>${UI.esc(m.who)}</b><small>${m.city ? UI.esc(m.city) : ''}${m.date ? ' · ' + UI.esc(m.date) : ''}</small></div></div>
    ${m.said ? `<div class="mpsaid">«${UI.esc(m.said)}»</div>` : ''}
    <div class="mpres ${cls}">${m.ok === false ? '✕' : '✓'} ${UI.esc(m.title || '')}</div>
    ${m.x ? `<div class="mpnar">${UI.esc(m.x).replace(/\n/g, '<br>')}</div>` : ''}</div>`;
};
UI.chatTabs = () => {
  const el = $('#ctabs'); if (!el || !UI.s) return;
  const show = (typeof NET !== 'undefined' && NET.on()) || (UI.s.mpChat || []).length;
  if (!show) { el.innerHTML = ''; if (UI.ctab !== 'me') UI.setCtab('me'); return; }
  const n = UI.s.mpUnread || 0;
  el.innerHTML = `<button data-ct="me" class="${UI.ctab === 'me' ? 'on' : ''}">Мой чат</button><button data-ct="mp" class="${UI.ctab === 'mp' ? 'on' : ''}">Игроки${n && UI.ctab !== 'mp' ? `<em>${n > 99 ? '99+' : n}</em>` : ''}</button>`;
  el.querySelectorAll('[data-ct]').forEach(b => b.onclick = () => UI.setCtab(b.dataset.ct));
};
UI.setCtab = t => {
  UI.ctab = t;
  const me = t === 'me';
  $('#msgs').classList.toggle('hidden', !me); $('#msgs2').classList.toggle('hidden', me);
  $('#quick').classList.toggle('hidden', !me); $('.cinput').classList.toggle('hidden', !me);
  let ro = $('#mpro'); if (!me && !ro) { $('.cinput').insertAdjacentHTML('afterend', `<div class="mpro" id="mpro">${UI.ic('globe')} Здесь — что делают другие игроки и что им отвечает их нейросеть. Писать сюда нельзя; поболтать — в окне «Мультиплеер».</div>`); ro = $('#mpro'); }
  if (ro) ro.classList.toggle('hidden', me);
  if (!me) { UI.s.mpUnread = 0; const box = $('#msgs2'); box.innerHTML = (UI.s.mpChat || []).map(UI.mpHtml).join('') || '<div class="m sys"><span>Пока тихо. Как только другие игроки что-то сделают — это появится здесь.</span></div>'; box.scrollTop = box.scrollHeight; }
  UI.chatTabs();
};
UI.renderChat = () => {
  const box = $('#msgs'); if (!box) return;
  box.innerHTML = UI.s.chat.map(UI.msgHtml).join('');
  box.scrollTop = box.scrollHeight;
};
// Прокрутка чата: вниз — только если игрок и так внизу. Листаешь вверх — чат не дёргается, пока нейросеть пишет.
UI.near = box => box.scrollHeight - box.scrollTop - box.clientHeight < 90;
UI.stick = (box, force) => { if (!box) return; if (force || box._stick !== false) box.scrollTop = box.scrollHeight; };
UI.bindScroll = box => { if (!box || box._sb) return; box._sb = true; box.addEventListener('scroll', () => { box._stick = UI.near(box); const j = $('#tobottom'); if (j) j.classList.toggle('hidden', box._stick); }, { passive: true }); };
UI.appendMsg = m => { UI.pushChat(m); const box = $('#msgs'); UI.bindScroll(box); box.insertAdjacentHTML('beforeend', UI.msgHtml(m)); UI.stick(box, m.k === 'me'); if (m.k === 'me') box._stick = true; return box.lastElementChild; };

UI.setBusy = b => { UI.busy = b; UI.busySince = b ? Date.now() : 0; $('#send').disabled = b; $('#inp').disabled = b; for (const id of ['#nextBtn', '#nextM', '#nextQ', '#skipM']) { const nb = $(id); if (nb) nb.disabled = b; } $('.chat').classList.toggle('busy', b); };

UI.send = async () => {
  if (UI.busy) return;
  const s = UI.s, text = $('#inp').value.trim();
  AI.stopBg(); UI._sum = false;
  if (!text) return;
  if (s.over) { UI.gameOver(); return; }
  $('#inp').value = '';
  if (typeof SFX !== 'undefined') SFX.play('send');
  UI.appendMsg({ k: 'me', t: text });
  UI.setBusy(true);
  let it = null;
  const typing = UI.typing('Нейросеть читает…');
  if (AI.state === 'ok') { try { it = await AI.interpret(s, text); } catch (e) { console.warn('interpret', e); } }
  if (!it) it = E.parseLocal(text);
  typing.remove();
  await UI.resolve(it, text);
  UI.setBusy(false);
  $('#inp').focus();
};

UI.doIntent = async (it, label) => {
  if (UI.busy || UI.s.over) return;
  AI.stopBg(); UI._sum = false;
  UI.appendMsg({ k: 'me', t: label || it.type });
  UI.setBusy(true);
  it.raw = label || ''; it.summary = label || '';
  await UI.resolve(it, label || '');
  UI.setBusy(false);
};

UI.typing = t => { const box = $('#msgs'); box.insertAdjacentHTML('beforeend', `<div class="m typing"><span></span><span></span><span></span><em>${t}</em></div>`); UI.stick(box); return box.lastElementChild; };

UI.resolve = async (it, text) => {
  const s = UI.s;
  if (s.ap <= 0 && it.type !== 'chat') {
    UI.appendMsg({ k: 'sys', t: 'На этой неделе сил больше нет — нажмите «Следующая неделя».' });
    $('#nextBtn').classList.add('pulse'); return;
  }
  const before = s.world.own.slice();
  const out = E.act(s, it);
  if (!out.chat) {
    UI.appendMsg({ k: 'out', title: out.title, ok: out.ok, crit: out.crit, impossible: out.impossible, roll: out.roll ? { roll: out.roll.roll, chance: out.roll.chance } : null, lines: out.lines });
    if (typeof SFX !== 'undefined') SFX.play(out.impossible ? 'close' : out.ok ? (out.crit ? 'great' : 'good') : 'bad');
    E.logAdd(s, 'act', it.summary || text, { ok: out.ok, title: out.title, said: text !== it.summary ? text : undefined, lines: (out.lines || []).slice(0, 4) });
  }
  UI.renderAll();
  if (out.war !== undefined || out.map) { MAP.paint(s, before.map((o, i) => o !== s.world.own[i] ? i : -1).filter(i => i >= 0)); UI.legend(); }
  // рассказ
  if (AI.state === 'ok') {
    const el = UI.appendMsg({ k: 'ai', t: '' });
    const div = el.firstElementChild; div.classList.add('stream');
    const msg = s.chat[s.chat.length - 1];
    try {
      const t = await AI.narrate(s, text, out, tt => { div.textContent = tt; UI.stick($('#msgs')); });
      msg.t = (t || '').trim() || AI.template(s, text, out);
    } catch (e) { console.warn('narrate', e); msg.t = AI.template(s, text, out); }
    const lg = s.log[s.log.length - 1]; if (lg && lg.kind === 'act' && !out.chat) lg.nar = msg.t.slice(0, 300);
    if (typeof NET !== 'undefined' && NET.on() && !out.chat && !out.impossible) NET.feed(out.title, out.ok, msg.t, text || it.summary);
    div.textContent = msg.t; div.classList.remove('stream');
  } else UI.appendMsg({ k: 'ai', t: AI.template(s, text, out) });
  if (out.dead || s.over) { UI.save(); UI.gameOver(); return; }
  if (s.ap <= 0) $('#nextBtn').classList.add('pulse');
  UI.save();
  UI.maybeSummarize();
};

UI.maybeSummarize = () => {
  const s = UI.s;
  if (AI.state !== 'ok' || UI._sum) return;
  if (s.log.length - s.sumAt < 12) return;
  UI._sum = true;
  AI.summarize(s).catch(() => { }).finally(() => { UI._sum = false; UI.save(); if (UI.tab === 'dossier') UI.left(); });
};

// ---------- неделя ----------
UI.nextWeek = async (silent, mp) => {
  if (UI.busy) return;
  AI.stopBg(); UI._sum = false;
  const s = UI.s; if (s.over) { UI.gameOver(); return; }
  if (typeof NET !== 'undefined' && NET.on() && !mp) { NET.toggleReady(); return; } // мультиплеер: «Готов»
  UI.setBusy(true);
  $('#nextBtn') && $('#nextBtn').classList.remove('pulse');
  const before = s.world.own.slice();
  const wasMonth = new Date(s.date).getMonth();
  const wasYear = new Date(s.date).getFullYear();
  if (typeof SFX !== 'undefined' && !silent) SFX.play('week');
  let rep;
  if (mp && mp.tick) { // игрок: мир пришёл от хоста
    s.date = mp.tick.prev; s.turn = mp.tick.turn - 1; NET.applyWorld(s, mp.world);
    rep = E.nextWeek(s, { war: mp.tick.war, news: mp.tick.news });
    s.date = mp.tick.date; s.turn = mp.tick.turn;
  } else {
    const prev = s.date;
    rep = E.nextWeek(s);
    if (mp && mp.host) NET.broadcast(prev, rep);
  }
  if (mp) NET.announce();
  UI.appendMsg({ k: 'sys', t: `Неделя ${s.turn + 1} · ${E.dateStr(s.date)}` });
  for (const t of rep.life || []) if (!/^Газета|газет/i.test(t)) E.logAdd(s, 'life', t);
  if (rep.life && rep.life.length) UI.appendMsg({ k: 'news', title: 'Ваши дела', items: rep.life.map(t => ({ t, imp: /приглаш|получена|взяли/i.test(t) ? 2 : 0 })) });
  const notable = [];
  if (rep.war.length) { UI.appendMsg({ k: 'war', items: rep.war.slice(0, 12) }); rep.war.slice(0, 6).forEach(w => notable.push(w.t)); rep.war.filter(w => w.big).slice(0, 2).forEach(w => E.logAdd(s, 'world', w.t)); }
  const changed = before.map((o, i) => o !== s.world.own[i] ? i : -1).filter(i => i >= 0);
  if (changed.length || rep.news.length) MAP.paint(s, changed);
  const nws = rep.news.filter(n => n.imp >= 1);
  if (nws.length) UI.appendMsg({ k: 'news', items: nws.map(n => ({ t: n.t, imp: n.imp })) });
  const bigs = rep.news.filter(n => n.imp >= 2);
  if (bigs.length) { await UI.worldNews(bigs); bigs.forEach(n => { if (n.c.includes(s.world.home)) { notable.push(n.t); E.logAdd(s, 'world', n.t); } }); }
  if (rep.monthly) { UI.appendMsg({ k: 'month', mon: E.monthStr(new Date(wasYear, wasMonth, 1)), r: rep.monthly }); if (typeof IA !== 'undefined' && NET.on()) try { IA.monthly(); } catch (e) { console.warn('IA.monthly', e); } }
  UI.renderAll();
  for (const ev of rep.events) {
    if (ev.sys) { notable.push(ev.t + ': ' + ev.x); UI.appendMsg({ k: 'out', title: ev.t, ok: !/Поражение|уволили/.test(ev.t), lines: [ev.x].concat(ev.lines || []), roll: ev.roll ? { roll: ev.roll.roll, chance: ev.roll.chance } : null }); if (ev.big) await UI.bigNews(ev); }
    else if (ev.soc && typeof SOC !== 'undefined') await SOC.modal(ev.soc);
    else if (ev.npc) await U.npcEvent(ev.npc);
    else await UI.event(ev.ev);
  }
  UI.renderAll();
  if (notable.length && AI.state === 'ok' && !silent && !(typeof NET !== 'undefined' && NET.on() && NET.speed)) { // в мультиплеере на скорости — без пересказа недели, чтобы не задерживать время
    const el = UI.appendMsg({ k: 'ai', t: '' }); const div = el.firstElementChild; div.classList.add('stream'); const msg = s.chat[s.chat.length - 1];
    try { msg.t = (await AI.narrateWeek(s, notable, tt => { div.textContent = tt; UI.stick($('#msgs')); })).trim(); } catch (e) { msg.t = ''; }
    if (!msg.t) { el.remove(); s.chat.pop(); } else { div.textContent = msg.t; div.classList.remove('stream'); }
  }
  UI.save();
  UI.setBusy(false);
  if (s.over) UI.gameOver();
  if (new Date(s.date).getFullYear() !== wasYear && AI.state === 'ok') AI.chronicle(s, wasYear).then(() => UI.save()).catch(e => console.warn('chronicle', e));
  UI.maybeSummarize();
};

// ---------- окна ----------
UI.modal = html => { if (typeof SFX !== 'undefined') SFX.play(/^\s*<div class="ev/.test(html) ? 'event' : 'open'); const m = $('#modal'); m.innerHTML = `<div class="mbox">${html}</div>`; m.classList.remove('hidden'); return m; };
UI.closeModal = () => { if (typeof SFX !== 'undefined' && !$('#modal').classList.contains('hidden')) SFX.play('close'); $('#modal').classList.add('hidden'); $('#modal').innerHTML = ''; };

UI.fxText = fx => {
  if (!fx) return '';
  const p = [];
  if (fx.money) p.push((fx.money > 0 ? '+' : '−') + E.money(Math.abs(E.m(UI.s, fx.money))));
  if (fx.rub) p.push((fx.rub > 0 ? '+' : '−') + E.money(Math.abs(fx.rub * E.cpi(UI.s))));
  if (fx.moneyJob) p.push('+' + Math.round(fx.moneyJob * 100) + '% зарплаты');
  if (fx.moneyPct) p.push('−' + Math.round(-fx.moneyPct * 100) + '% денег');
  const L = { happy: 'счастья', health: 'здоровья', rep: 'репутации', stress: 'стресса', perf: 'к работе', str: 'силы', int: 'интеллекта', cha: 'харизмы', craft: 'ремесла', biz: 'хватки', bizHealth: 'бизнесу' };
  for (const k in L) if (fx[k]) p.push((fx[k] > 0 ? '+' : '−') + Math.abs(fx[k]) + ' ' + L[k]);
  return p.join(', ');
};

UI.event = evId => new Promise(res => {
  const s = UI.s, ev0 = E.findEv(evId);
  const ev = Object.assign({}, ev0, { t: E.evText(s, ev0.t), x: E.evText(s, ev0.x), opts: ev0.opts.map(o => Object.assign({}, o, { n: E.evText(s, o.n) })) });
  const opts = ev.opts.map((o, i) => {
    let ch = '';
    if (o.roll) ch = `<span class="roll">${UI.ic('dice')} шанс ${o.roll.luck !== undefined ? o.roll.luck : E.chance(s, 100 - o.roll.diff, o.roll.sk)}%</span>`;
    const fx = UI.fxText(o.fx);
    return `<button class="eopt" data-i="${i}"><b>${o.n}</b>${ch}<small>${fx}${o.roll ? (fx ? '; ' : '') + 'удача: ' + (UI.fxText(o.ok) || 'обойдётся') + ' · неудача: ' + (UI.fxText(o.bad) || 'ничего') : ''}</small></button>`;
  }).join('');
  UI.modal(`<div class="ev"><div class="evpic ev-${ev.id}">${UI.ic(EVIC[ev.id] || ({ flood: 'home', phonebroke: 'bolt', crash: 'bolt', kitten: 'heart', rentup: 'home', landsell: 'home', wifemicro: 'home', kidgadget: 'user', babyborn: 'heart', broke: 'bolt', arrest: 'shield', anniv: 'ring' })[ev.id] || 'bolt')}</div><h3>${ev.t}</h3><p>${ev.x}</p><div class="eopts">${opts}</div></div>`);
  if (typeof NET !== 'undefined') NET.autoPick();
  $$('#modal .eopt').forEach(b => b.onclick = () => {
    const o = ev.opts[+b.dataset.i];
    const r = E.eventResolve(s, ev.id, +b.dataset.i);
    UI.closeModal(); if (r.roll && typeof SFX !== 'undefined') SFX.play(r.ok ? 'good' : 'bad', true);
    UI.appendMsg({ k: 'out', title: ev.t + ': ' + o.n.toLowerCase(), x: ev.x, ok: r.ok, lines: r.lines, roll: r.roll ? { roll: r.roll.roll, chance: r.roll.chance } : null });
    UI.renderAll(); res();
  });
});
const EVIC = { mobil: 'shield', occupied: 'sword', layoff: 'brief', revolt: 'flag', zaem: 'coin', stakh: 'up', subbot: 'user', parade: 'flag', purge: 'bolt', pipe: 'home', side: 'box', flu: 'heart', wallet: 'coin', boss: 'brief', bonus: 'coin', friend: 'user', scam: 'bolt', crisis: 'up', love: 'heart', lottery: 'star', inspect: 'factory', gym: 'heart', scandal: 'star', neighbor: 'home' };

UI.worldNews = list => new Promise(res => {
  const s = UI.s, top = list.reduce((a, n) => n.imp > a.imp ? n : a, list[0]);
  const war = /войн|напал|вторг/i.test(top.t);
  UI.modal(`<div class="ev big news"><div class="evpic ev-world ${top.imp >= 3 ? 'huge' : ''}"><span>${E.dateStr(top.d)}</span>${UI.ic(war ? 'sword' : 'globe')}</div><h3>${war ? 'Война' : 'Мировые новости'}</h3>${list.slice(0, 4).map(n => `<p>${UI.esc(n.t)}</p>`).join('')}<div class="eopts">${top.c && top.c.length ? `<button class="eopt" id="wnC"><b>Подробнее о стране: ${UI.esc(s.world.cs[top.c[0]].n)}</b></button>` : ''}<button class="eopt" id="wnOk"><b>${top.imp >= 3 ? 'Это касается каждого' : 'Понятно'}</b></button></div></div>`);
  $('#wnOk').onclick = () => { UI.closeModal(); res(); };
  if ($('#wnC')) $('#wnC').onclick = () => { UI.closeModal(); UI.country(top.c[0]); const t = setInterval(() => { if ($('#modal').classList.contains('hidden')) { clearInterval(t); res(); } }, 300); };
});

UI.bigNews = ev => new Promise(res => {
  UI.modal(`<div class="ev big"><div class="evpic ev-news">${UI.ic(/война|Столица|капитул/i.test(ev.t + ev.x) ? 'sword' : 'flag')}</div><h3>${UI.esc(ev.t)}</h3><p>${UI.esc(ev.x)}</p><div class="eopts"><button class="eopt" id="bnOk"><b>Отлично</b></button></div></div>`);
  $('#bnOk').onclick = () => { UI.closeModal(); res(); };
});

UI.menu = () => {
  UI.modal(`<div class="menu"><h3>Меню</h3>
    <button class="btn wide" id="mHelp">${UI.ic('book')} Как играть</button>
    <button class="btn wide" id="mSet">${UI.ic('box')} Настройки интерфейса (размер)</button>
    <button class="btn wide" id="mExp">${UI.ic('save')} Сохранить в файл</button>
    <button class="btn wide" id="mImp">${UI.ic('box')} Загрузить из файла</button>
    <button class="btn wide" id="mSnd">${UI.ic('radio')} Радио и звук</button>
    <button class="btn wide" id="mTitle">${UI.ic('home')} Главное меню</button>
    ${window.sudba ? `<button class="btn wide" id="mAi">${UI.ic('bolt')} Сменить нейросеть (перезапуск)</button><button class="btn wide" id="mQuit">${UI.ic('x')} Выйти из игры</button>` : ''}
    <button class="btn wide danger" id="mNew">${UI.ic('plus')} Начать новую жизнь</button>
    <button class="btn wide" id="mClose">Закрыть</button>
    <p class="small">Игра сохраняется сама после каждого хода.</p></div>`);
  $('#mHelp').onclick = UI.help;
  $('#mSnd').onclick = () => { UI.closeModal(); RADIO.toggle(true); };
  if (window.sudba) { $('#mAi').onclick = () => { UI.save(); window.sudba.back(); }; $('#mQuit').onclick = () => { UI.save(); window.sudba.quit(); }; }
  $('#mSet').onclick = U.settings; $('#mExp').onclick = UI.exportSave; $('#mImp').onclick = UI.importSave;
  $('#mTitle').onclick = () => { UI.save(); UI.closeModal(); UI.title(); };
  $('#mNew').onclick = () => { if (confirm('Начать новую жизнь? Текущая будет потеряна (если не сохранить её в файл).')) { UI.closeModal(); UI.create(); } };
  $('#mClose').onclick = UI.closeModal;
};

UI.help = () => {
  UI.modal(`<div class="help"><h3>Как играть</h3>
    <p><b>Пишите в Нейрочат, что делает ваш герой</b>, — своими словами: «устроился дворником», «попросил прибавку», «открываю шаурмичную на остановке», «пригласил Алину в кино».</p>
    <p>Нейросеть понимает, что вы задумали, а игра честно бросает кубик: шанс зависит от навыков, черт характера, репутации и здоровья. Если выпало число не больше шанса — удача. Потом нейросеть рассказывает, что произошло.</p>
    <p><b>Неделя = 3 действия.</b> Потом жмите «Неделя» (или пробел). «Месяц» и «Квартал» проматывают 4 и 13 недель. Раз в месяц — зарплата и расходы, иногда случаются события.</p>
    <p><b>Окна над картой:</b> «Работа» — вакансии и резюме, как на HH; «Жильё» — объявления, как на ЦИАН (аренда или покупка, любой город); «Мой дом» — нарисованная квартира, мебель, техника, машина, семья; «Бизнес» — сотрудники, зарплаты, расширение, заводы и контракты со странами; «Близкие» — друг детства, соседи; «Газета» — городская каждую неделю и мировая раз в месяц; «Криминал» — банда, розыск, конкуренты (всё вымышлено).</p>
    <p><b>Мультиплеер.</b> Кнопка «Мультиплеер» над картой → «Создать комнату» — вы хост, ваш мир становится общим; друзьям отправьте код. Друг на главном экране жмёт «Мультиплеер — войти по коду», создаёт героя и попадает в ваш мир. Сервер не нужен. Время: хост выбирает скорость (пауза / ▶ 120 с / ▶▶ 60 с / ▶▶▶ 30 с на неделю) и может промотать месяц; «Готов» у всех — неделя наступает сразу. В комнате есть чат, переводы денег, лента дел других игроков и их значки на карте. Нейросеть у каждого своя, на его ПК.</p>
    <p><b>Можно почти всё.</b> Взятки («даю взятку, чтобы взяли без опыта», «заношу в военкомат», «плачу за поступление»), роскошь (яхта, самолёт, особняк, остров, футбольный клуб, своё СМИ, охрана), благотворительность, своя ОПГ («создаю свою ОПГ», «набираю людей», «захватываю район», «прикармливаю полицию») — вплоть до отделения региона в отдельную страну. Для крупных дел нужно <b>влияние</b>: оно растёт от репутации, власти, бизнеса, СМИ и роскоши.</p>
    <p><b>Усталость и баланс.</b> Если в жизни одна работа, копится усталость и начинаются проблемы со здоровьем (давление, бессонница, спина…). Копится медленно: предупреждение — после 16 недель без отдыха и общения, болезни — не раньше чем через полгода. Отдых, путешествия и время с близкими спасают (один отдых снимает 8 недель).</p>
    <p><b>Бизнес:</b> вкладка «Конкуренты» — демпинг, чёрный пиар, переманивание людей, проверки, «спортики», охрана, поглощение ослабших конкурентов; вкладка «HR-отдел» — HR-менеджер сам ищет людей по фильтрам и может нанимать без вас.</p>
    <p><b>Взаимодействие (мультиплеер):</b> взять друга к себе в бизнес (должность и зарплата — ваши), вложиться в его бизнес за долю, сдать ему квартиру, продать машину, баня, рыбалка, бар, вечеринка, гонки на деньги, дебаты, алиби, крыша, совместный ролик; а ещё устроить по блату, общий бизнес, продать долю, дать в долг (возврат сам раз в месяц), жить вместе, купить жильё вместе, встречаться и пожениться, позвать в банду, совместное дело, поддержать на выборах, пари, карты, шахматы — и подлянки: слухи, чёрный пиар, проверка, спортики, переманить людей, сдать полиции, суд.</p>
    <p><b>Цели</b> — как фокусы в хойке: выбрали, выполнили, получили награду.</p>
    <p><b>Три эпохи.</b> «2018 · до СВО» — Россия, январь 2018: чемпионат мира, пенсионная реформа, пандемия, 24 февраля 2022-го, мобилизация — всё по реальным датам, а ваша жизнь — как сложится. «Современность» — 2026 год. «Вторая мировая» — СССР, январь 1936.</p>
    <p><b>Свои затеи — прямо в чате.</b> «Завожу ютуб-канал про машины», «вкладываю 150к в технику», «снимаю ролик», «реклама на 50к», «нанимаю монтажёра», «как дела на канале?». Так же — TikTok, Telegram, стримы, музыка, книга, стартап, своя партия, фонд, бои, изобретения и даже захват власти (нужны деньги на подкуп, люди, влияние, репутация и пропаганда; провал — тюрьма). Нейросеть спрашивает, сколько вложить, а доходы и подписчики приходят в итогах месяца.</p>
    <p><b>Власть.</b> Политика — 6 ступеней: муниципальный депутат → депутат гордумы → мэр → губернатор → министр → президент. С первой же должности в углу карты появляется кнопка «Власть» — гос. решения: на каждой ступени открываются новые (депутатский запрос, бюджетная поправка, лоббирование, городской подряд, благоустройство, налоговые каникулы, силовая операция, госзаказ, назначение замминистра, реформы; у президента — помилование, награды, национализация, ЧП, референдум, мобилизация). Многие можно направить на живых игроков или на неигровых персонажей.</p>
    <p><b>Правительство (у президента).</b> Законы за политический капитал (экономика, призыв, СМИ, торговля, соцполитика, правопорядок, миграция), форма правления, бюджет и налоги (дефицит — долг или инфляция, а инфляция двигает цены в игре), министры (можно назначить друга-игрока), партии и выборы (проиграли — власть потеряна), ресурсы и торговые сделки, кризисы. Дипломатия: напишите лидеру любой страны — он ответит через нейросеть и решит, принять ли ваше предложение (торговля, пакт, союз, кредит, ресурсы, территория, мир, блоки, санкции).</p>
    <p><b>Нейросеть долго думает?</b> Если ответа нет дольше 20 секунд, в чате появится кнопка «Нейросеть долго думает — прервать». Ход доиграется без пересказа, и можно сразу писать дальше.</p>
    <p><b>3D-город («Зайти домой» / «Выйти в город»).</b> Вместо карты открывается город — без загрузок, всё на одной карте: площадь с фонтаном и лавочками, кольцевая дорога с машинами, магазины, прохожие, 4 многоэтажки (5 этажей × 4 квартиры, лестницы) и 4 улицы по 14 частных домов. Если у вас квартира — вы живёте в подъезде (все игроки — в одном подъезде, общая квартира — одна на всех её жильцов), если дом — на улицах частного сектора. Над дверьми игроков — таблички с именами, ваша дверь подсвечена золотым; двери открываются сами, когда подходите. Из квартиры можно спуститься по лестнице и выйти гулять. Вся мебель двигается: <b>ЛКМ</b> зажать на диване/шкафу/столе — тащить, <b>R</b> — повернуть; мелочь (стулья, подушки, мяч) можно кинуть. Расстановка запоминается («Мой дом» → «Вернуть мебель на места»). Управление: <b>WASD</b>, <b>Пробел</b> — прыжок, <b>Ctrl</b> — присесть, <b>Shift</b> — бег, <b>ПКМ</b> — камера, колесо — зум, <b>Esc</b> — на карту. Чат и вся игра работают и из 3D. В мультиплеере — «Позвать друга…».</p>
    <p><b>Знакомые</b> (плитка «Счастье» или «Все знакомые →» в досье). Все, кого вы знаете: одноклассники, коллеги, соседи, друзья друзей. Они дружат, ссорятся, влюбляются и расстаются между собой, распускают слухи, попадают в хорошие и плохие истории — смотрите вкладку «Что происходит». Раз в несколько недель — событие с выбором: травля в школе, слух про вас, друзья поссорились, знакомый в беде, праздник, предложение от влиятельного человека. Вкладка «Выйти на людей» — цепочки знакомств: через друга — к директору, через директора — к депутату и выше. Влиятельные знакомые помогают с работой, деньгами и репутацией (но потом «вы им должны»). Можно собрать свою компанию, помириться, поссориться, пустить слух.</p>
    <p><b>Стартовый режим</b> (только одиночная игра): на экране «Новая жизнь» можно начать сразу министром или президентом — с постом, репутацией, служебным жильём и окном «Власть».</p>
    <p><b>Дивизии.</b> Армия теперь — это дивизии на карте. Формируйте их в «Правительство → Армия» (военные очки от бюджета армии + люди из резерва), кликните по значку дивизии на карте, затем по провинции — пойдут туда. Вражеская провинция — штурм: танки и артиллерия вместе с пехотой берут оборону. Пустой фронт враг продавливает быстрее.</p>
    <p><b>Сдача квартир.</b> «Жильё» → «Моя недвижимость»: купите квартиру «под сдачу» без переезда, обставьте под ключ и выберите жильцов. Чем дороже и уютнее квартира, тем лучше жильцы: больше платят, реже задерживают, меньше ломают. Можно посуточно. В чате: «сдаю квартиру».</p>
    <p><b>Сложность</b> влияет на шансы во всём, что вы делаете, на удачу в событиях, цены, зарплаты и опасность фронта.</p>
    <p><b>Живой мир.</b> У каждой страны есть ВВП, население, инфляция, безработица, долг, стабильность, армия. Они меняются каждый месяц: кризисы, бумы, выборы, перевороты, гражданские и пограничные войны. Кликните по стране на карте → «О стране», вкладка «Мир» — рейтинги и новости. Глава государства может издавать указы: «Указ: снизить налоги», «Указ: санкции против …», «Указ: договор с …».</p>
    <p><b>Власть:</b> муниципальный депутат → дума → мэр → губернатор → министр → президент. Президент может объявлять войну соседям — и карта перекрашивается под того, кто захватил провинции. Возьмёте столицу врага — страна сдастся целиком.</p>
    <p>Нельзя «просто написать себе миллиард»: все деньги и цифры считает игра, нейросеть только рассказывает.</p>
    <p class="small">Карта: колесо мыши — зум, перетаскивание — сдвиг, клик по провинции — три окна: провинция, политика региона, страна. Размер интерфейса — в меню ☰ → «Масштаб».</p>
    <button class="btn wide" id="hOk">Понятно</button></div>`);
  $('#hOk').onclick = UI.closeModal;
};

UI.gameOver = () => {
  const s = UI.s;
  UI.modal(`<div class="ev big over"><div class="evpic ev-over">${UI.ic('star')}</div><h3>Жизнь окончена</h3>
    <p>${UI.esc(s.ch.name)} ${UI.esc(s.ch.surname)} прожил${s.ch.sex === 'f' ? 'а' : ''} ${E.years(E.age(s))}. ${s.overReason === 'старость' ? 'Ушёл тихо, в своей постели.' : 'Здоровье не выдержало.'}</p>
    <div class="kv"><span>Положение</span><b>${UI.esc(E.position(s))}</b></div>
    <div class="kv"><span>Состояние</span><b>${E.money(E.netWorth(s))}</b></div>
    <div class="kv"><span>Целей выполнено</span><b>${s.focusDone.length}</b></div>
    ${s.summary ? `<p class="summary">${UI.esc(s.summary)}</p>` : ''}
    <div class="eopts"><button class="eopt" id="goNew"><b>Новая жизнь</b></button><button class="eopt" id="goExp"><b>Сохранить историю в файл</b></button></div></div>`);
  $('#goNew').onclick = () => { localStorage.removeItem(UI.KEY); UI.closeModal(); UI.create(); };
  $('#goExp').onclick = UI.exportSave;
};

// ---------- статус нейросети ----------
UI.aiBadge = () => {
  const t = { wait: ['wait', 'Проверяю нейросеть…'], loading: ['load', 'Нейросеть загружается в видеокарту…'], ok: ['ok', 'Нейросеть работает на вашем ПК' + (AI.dev && AI.dev.mode === 'gpu' ? ' · видеокарта' + (AI.dev.dev ? ': ' + AI.dev.dev : '') : AI.dev && AI.dev.mode === 'cpu' ? ' · на процессоре (медленно)' : '') + (AI.dev && AI.dev.model ? ' · ' + AI.dev.model : AI.model ? ' · ' + AI.model.replace(/-Instruct.*$/, '') : '') + (AI.dev && AI.dev.tier === 'smart' ? ' · Умная' : AI.dev && AI.dev.tier === 'std' ? ' · Стандарт' : '')], off: ['off', window.sudba ? 'Нейросеть выключена — упрощённый режим. Включить: меню ☰ → «Сменить нейросеть»' : 'Нейросеть не запущена — упрощённый режим. Запускайте игру через AltHistory.exe'] }[AI.state];
  for (const id of ['#gAi', '#tAi']) { const e = $(id); if (e) e.innerHTML = `<i class="dot ${t[0]}"></i>${UI.esc(t[1])}`; }
};
AI.onState = () => UI.aiBadge();

window.addEventListener('DOMContentLoaded', () => { UI.title(); AI.watch(); });

// ---------- «С чего начать» — карточка-подсказка в чате ----------
UI.TRY = s => E.ww2(s) ? ['Устраиваюсь на завод токарем', 'Иду на танцы в клуб', 'Записываюсь в стахановцы', 'Открываю сапожную артель'] : ['Устраиваюсь курьером', 'Завожу ютуб-канал про машины', 'Иду в спортзал', 'Знакомлюсь с девушкой в кафе', 'Хочу открыть кофейню', 'Сдаю квартиру'];
UI.guideHtml = () => {
  const s = UI.s; if (!s) return '';
  return `<div class="m guide"><div class="gd">
    <div class="gdh"><b>С чего начать</b><button class="gx" data-guide="hide" title="Скрыть">✕</button></div>
    <ol>
      <li><b>Пишите в чат, что делает герой</b> — своими словами, что угодно. Нейросеть поймёт и расскажет, что вышло. Попробуйте:
        <div class="gtry">${UI.TRY(s).map(t => `<button data-guide="try" data-t="${UI.esc(t)}">${UI.esc(t)}</button>`).join('')}</div></li>
      <li><b>3 действия в неделю.</b> Потом жмите <span class="gk">Неделя ▶</span> справа сверху — время идёт, зарплата приходит раз в месяц.</li>
      <li><b>Плитки сверху кликаются:</b> деньги, работа, жильё, бизнес — нажмите на любую, там подробности и кнопки.</li>
      <li><b>Карта — живой мир:</b> страны воюют и богатеют, ${E.ww2(s) ? 'впереди большая война' : Y18.on(s) ? 'история идёт по реальным датам' : 'бывают кризисы'}. Газета и «Тёмная сторона» — в углу карты.</li>
    </ol>
    <div class="gbtns"><button class="btn small primary" data-guide="hh">${UI.ic('brief')} Найти работу</button><button class="btn small" data-guide="home">${UI.ic('home')} Найти жильё</button><button class="btn small" data-guide="biz">${UI.ic('factory')} Свой бизнес</button><button class="btn small" data-guide="hide">Понятно</button></div>
  </div></div>`;
};
document.addEventListener('click', e => {
  const b = e.target.closest('[data-guide]'); if (b) {
    const k = b.dataset.guide, s = UI.s; if (!s) return;
    if (k === 'hide') { s.chat = s.chat.filter(m => m.k !== 'guide'); const el = b.closest('.m.guide'); if (el) el.remove(); UI.save(); return; }
    if (k === 'try') { UI.fill(b.dataset.t); return; }
    if (k === 'hh') return U.hh(); if (k === 'home') return U.cian(); if (k === 'biz') return s.biz.length ? U.biz() : U.bizNew();
  }
  if (e.target.closest('#qHelp')) { const s = UI.s; if (!s) return; if (!s.chat.some(m => m.k === 'guide')) UI.appendMsg({ k: 'guide' }); else { const el = $('#msgs .m.guide'); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' }); } }
});
