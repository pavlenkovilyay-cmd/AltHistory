// «Судьба» — государственные решения на каждой ступени политической карьеры.
// Муниципальный депутат — 2 решения, каждая следующая должность открывает ещё 2, министр — ещё 3, президент — всё
// и свои особые указы плюс окно «Правительство». Больше половины решений можно направить на живых игроков
// (их бизнес, работа, розыск) или на неигровых персонажей — без мультиплеера тоже работает.
'use strict';
const DEC = {};
(() => {
  const M_ = (s, v) => { const x = E.m(s, v); return E.ww2(s) ? Math.round(x) : Math.round(x / 1000) * 1000; };
  const mon = (s, v) => E.money(v);
  const lv = s => s.pol ? D.POLITICS.findIndex(p => p.id === s.pol.id) : -1;
  const NPC = s => E.ww2(s) ? ['артель «Красный пахарь»', 'трест «Стройматериал»', 'сельпо №3', 'кооператив «Заря»', 'фабрика «Большевичка»'] : ['ООО «СтройИнвест»', 'ЗАО «ТрансЛогистик»', 'сеть «Продмаркет»', 'холдинг «Северные ресурсы»', 'управляющая компания «Комфорт»', 'автосалон «Мега-Авто»'];
  const heat = (s, v) => { L.crimeInit(s); s.crime.heat = E.clamp((s.crime.heat || 0) + v, 0, 100); };
  const scandal = (s, p) => Math.random() < p ? ['Журналисты раскопали детали — репутация −8.'] : [];
  // target: 'any' — игрок или неигровой персонаж; 'player' — только игрок; 'none' — без цели
  DEC.LIST = [
    // ===== Муниципальный депутат =====
    { id: 'query', lv: 0, n: 'Депутатский запрос', d: 'Официальная проверка организации: бизнес игрока или компании-нарушителя.', cd: 4, target: 'any',
      npc: (s, t) => ({ ok: true, lines: ['Прокуратура проверила ' + t + ': нарушения найдены, штраф выписан.', 'Жители благодарны'], fx: { rep: 3 } }),
      me: () => ({ fx: { rep: 2 } }),
      fx: (s, a, from) => { const b = s.biz.slice().sort((x, y) => y.value - x.value)[0]; if (b) { b.health = Math.max(0, b.health - 8); return { ok: false, title: 'Проверка по депутатскому запросу', lines: [from.name + ' направил запрос: «' + b.n + '» проверили. Состояние бизнеса −8.'] }; } if (s.job) { s.job.perf = Math.max(0, (s.job.perf || 50) - 5); return { ok: false, title: 'Проверка на вашей работе', lines: ['По запросу депутата ' + from.name + ' — проверка. Оценка работы −5.'] }; } return { ok: true, title: 'Запрос депутата', lines: [from.name + ' интересовался вами, но придраться не к чему.'] }; } },
    { id: 'reception', lv: 0, n: 'Приём граждан', d: 'Люди идут с бедами: трубы, дороги, соседи. Поможете — растут репутация и связи.', cd: 3, target: 'none',
      npc: s => { const t = E.pick(['починили крышу в доме ветеранов', 'добились светофора у школы', 'нашли деньги на ремонт детской площадки', 'выбили новый автобусный маршрут']); return { ok: true, lines: ['На приёме: ' + t + '.'], fx: { rep: 3, happy: 3 }, infl: 1 }; } },
    // ===== Депутат городской думы =====
    { id: 'amend', lv: 1, n: 'Бюджетная поправка', d: 'Направить деньги из городского бюджета: грант игроку или ремонт в вашем округе.', cd: 8, target: 'any',
      npc: (s, t) => ({ ok: true, lines: ['Поправка принята: деньги пошли на ' + E.pick(['ремонт школы', 'новую поликлинику', 'дороги в округе']) + '.'], fx: { rep: 5 } }),
      me: () => ({ infl: 2, fx: { rep: 1 } }),
      fx: (s, a, from) => { const v = M_(s, 250000); s.st.money += v; return { ok: true, title: 'Грант из городского бюджета', lines: ['По поправке депутата ' + from.name + ': +' + mon(s, v)] }; } },
    { id: 'lobby', lv: 1, n: 'Лоббирование', d: 'Продвинуть интересы бизнеса: бизнес игрока получает клиентов, а неигровые компании платят «благодарность».', cd: 6, target: 'any',
      npc: (s, t) => { const v = M_(s, 300000); s.st.money += v; heat(s, 8); const sc = scandal(s, 0.15); return { ok: true, lines: [t + ' «отблагодарил» за поправку: +' + mon(s, v), 'Это коррупция: розыск +8'].concat(sc), fx: { rep: sc.length ? -8 : 0 } }; },
      me: () => ({ infl: 2 }),
      fx: (s, a, from) => { const b = s.biz[0]; if (!b) return { ok: true, title: 'Лоббирование', lines: [from.name + ' хотел помочь вашему бизнесу, но бизнеса у вас нет.'] }; b.base = Math.min(1, (b.base || 0.5) + 0.15); b.health = Math.min(100, b.health + 6); return { ok: true, title: 'За вас лоббируют в думе', lines: ['«' + b.n + '»: клиентская база +15%, состояние +6 — спасибо ' + from.name + '.'] }; } },
    // ===== Мэр =====
    { id: 'contract', lv: 2, n: 'Городской подряд', d: 'Отдать подряд: бизнес игрока получает крупный заказ, неигровая фирма — откат вам.', cd: 6, target: 'any',
      npc: (s, t) => { const v = M_(s, 600000); s.st.money += v; heat(s, 12); const sc = scandal(s, 0.2); return { ok: true, lines: ['Подряд у ' + t + ', «откат» +' + mon(s, v), 'Розыск +12'].concat(sc), fx: { rep: sc.length ? -8 : 0 } }; },
      me: () => ({ infl: 3 }),
      fx: (s, a, from) => { const v = M_(s, 1500000); s.st.money += v; const b = s.biz[0]; if (b) b.health = Math.min(100, b.health + 5); return { ok: true, title: 'Городской подряд', lines: [from.name + ' отдал вам городской подряд: +' + mon(s, v)] }; } },
    { id: 'improve', lv: 2, n: 'Благоустройство города', d: 'Парки, дороги, освещение на полгода. Весь бизнес в городе получает +5% клиентов — у всех игроков тоже.', cd: 10, target: 'none',
      npc: s => { GOV.op('cityBoost', { city: s.ch.city, until: new Date(Date.parse(s.date) + 182 * 864e5).toISOString() }); DEC.broadcast(s, 'improve', { city: s.ch.city, cityN: E.cityName(s) }); if (s.home.owned && s.home.value) s.home.value = Math.round(s.home.value * 1.03); return { ok: true, lines: ['Город похорошел. Бизнес в городе: +5% клиентов на полгода.', 'Ваше жильё подорожало на 3%'], fx: { rep: 6, happy: 3 } }; },
      fx: (s, a, from) => a.city === s.ch.city ? { ok: true, title: 'Город благоустраивают', lines: [from.name + ' взялся за благоустройство: ' + a.cityN + ': бизнесу +5% клиентов на полгода.'] } : null },
    // ===== Губернатор =====
    { id: 'taxbreak', lv: 3, n: 'Налоговые каникулы', d: 'Полгода налог на бизнес в стране вдвое меньше — у всех игроков тоже. Бюджет теряет, бизнес любит.', cd: 26, target: 'none',
      npc: s => { GOV.op('taxBreak', { c: s.world.home, until: new Date(Date.parse(s.date) + 182 * 864e5).toISOString() }); GOV.op('stat', { c: s.world.home, d: { debt: 1 } }); DEC.broadcast(s, 'taxbreak', { c: s.world.home }); return { ok: true, lines: ['Налог на бизнес −50% на полгода.'], fx: { rep: 5 }, infl: 3 }; },
      fx: (s, a, from) => a.c === s.world.home ? { ok: true, title: 'Налоговые каникулы', lines: [from.name + ' снизил налог на бизнес вдвое на полгода.'] } : null },
    { id: 'raid', lv: 3, n: 'Силовая операция', d: 'Полиция и ОМОН против банды. Можно ударить по преступнику-игроку: его розыск взлетит.', cd: 8, target: 'any',
      npc: s => { GOV.op('stat', { c: s.world.home, d: { stab: 1 } }); return { ok: true, lines: ['Задержаны лидеры местной ОПГ. Стабильность +1'], fx: { rep: 4 } }; },
      me: () => ({ fx: { rep: 3 } }),
      fx: (s, a, from) => { heat(s, 35); const lines = ['Силовая операция по приказу ' + from.name + ': ваш розыск +35.']; if (s.opg && !s.opg.gone) { s.opg.members = Math.max(1, Math.round(s.opg.members * 0.8)); lines.push('ОПГ потеряла 20% людей.'); } return { ok: false, title: 'На вас вышли силовики', lines }; } },
    // ===== Министр =====
    { id: 'order', lv: 4, n: 'Госзаказ', d: 'Крупный государственный заказ бизнесу игрока — или «распил» с неигровой компанией.', cd: 8, target: 'any',
      npc: (s, t) => { const v = M_(s, 1500000); s.st.money += v; heat(s, 15); const sc = scandal(s, 0.25); return { ok: true, lines: ['Госзаказ ушёл ' + t + ', вам — +' + mon(s, v), 'Розыск +15'].concat(sc), fx: { rep: sc.length ? -8 : 0 } }; },
      me: () => ({ infl: 4 }),
      fx: (s, a, from) => { const v = M_(s, 4000000); s.st.money += v; const b = s.biz[0]; if (b) b.health = Math.min(100, b.health + 8); return { ok: true, title: 'Госзаказ!', lines: [from.name + ' дал госзаказ, аванс: +' + mon(s, v)] }; } },
    { id: 'deputy', lv: 4, n: 'Назначить замминистра', d: 'Взять игрока к себе заместителем: высокая зарплата и влияние. Без игроков — своего человека.', cd: 12, target: 'any',
      npc: (s, t) => ({ ok: true, lines: ['Замом стал ваш человек — лоялен и полезен.'], infl: 5 }),
      fx: (s, a, from) => { const v = M_(s, 250000); s.job = { id: 'deputymin', title: 'Заместитель министра', org: 'Министерство', salary: v, level: 3, perf: 60, months: 0, weeks: 0, sk: 'cha', ladder: ['Заместитель министра'], boss: a.uid }; s.st.infl = Math.min(100, (s.st.infl || 0) + 5); return { ok: true, title: 'Вы — заместитель министра', lines: ['Назначил ' + from.name + '. Зарплата ' + mon(s, v) + '/мес, влияние +5.'] }; } },
    { id: 'reform', lv: 4, n: 'Отраслевая реформа', d: 'Программа для экономики, соцсферы, армии или борьбы с коррупцией.', cd: 10, target: 'opt', opts: ['Программа развития экономики', 'Повысить пенсии и зарплаты бюджетникам', 'Борьба с коррупцией', 'Жёсткий бюджет, сократить расходы'],
      npc: (s, t) => { const r = E.roll(s, E.chance(s, 66, 'int', 0)); GOV.op('policy', { c: s.world.home, text: t, ok: r.ok, crit: r.crit }); return { ok: r.ok, roll: r, lines: [r.ok ? 'Реформа запущена: ' + t.toLowerCase() : 'Реформу саботировали чиновники'] }; } },
    // ===== Президент =====
    { id: 'pardon', lv: 5, n: 'Помилование', d: 'Снять с игрока розыск и судимость. Без игроков — амнистия.', cd: 8, target: 'any',
      npc: s => { GOV.op('stat', { c: s.world.home, d: { stab: 2 } }); return { ok: true, lines: ['Амнистия к празднику: стабильность +2'], fx: { rep: 2 } }; },
      fx: (s, a, from) => { L.crimeInit(s); s.crime.heat = 0; return { ok: true, title: 'Помилован(а) президентом', lines: [from.name + ' подписал помилование: розыск обнулён.'], fx: { rep: 3 } }; } },
    { id: 'award', lv: 5, n: 'Государственная награда', d: 'Орден игроку — репутация и гордость. Или герою из народа.', cd: 6, target: 'any',
      npc: s => { GOV.op('stat', { c: s.world.home, d: { stab: 1 } }); return { ok: true, lines: ['Орден врачу из глубинки. Страна растрогана'], fx: { rep: 1 } }; },
      fx: (s, a, from) => ({ ok: true, title: 'Государственная награда!', lines: [from.name + ' вручил вам государственную награду.'], fx: { rep: 10, happy: 8 } }) },
    { id: 'national', lv: 5, n: 'Национализация', d: 'Забрать в казну самый дорогой бизнес игрока — или олигарха. Бюджет пополнится, но друзей не прибавится.', cd: 12, target: 'any',
      npc: (s, t) => { GOV.op('stat', { c: s.world.home, d: { debt: -2 }, g: { appr: 2 } }); return { ok: true, lines: ['Активы «' + t + '» перешли государству: госдолг −2% ВВП, народ доволен.'] }; },
      me: () => ({ g: { appr: -3 } }),
      fx: (s, a, from) => { const b = s.biz.slice().sort((x, y) => y.value - x.value)[0]; if (!b) return { ok: true, title: 'Национализация', lines: [from.name + ' хотел забрать ваш бизнес, но его нет.'] }; s.biz = s.biz.filter(x => x !== b); E.fact(s, `${E.monthStr(s.date)}: бизнес «${b.n}» национализировал ${from.name}.`); return { ok: false, title: 'Ваш бизнес национализирован', lines: ['«' + b.n + '» по указу ' + from.name + ' теперь принадлежит государству.'], fx: { happy: -15, stress: 15 } }; } },
    { id: 'emerg', lv: 5, n: 'Чрезвычайное положение', d: 'Стабильность +10, но популярность падает, а преступники (и игроки тоже) под прицелом.', cd: 26, target: 'none',
      npc: s => { GOV.op('stat', { c: s.world.home, d: { stab: 10 }, g: { appr: -8, pc: 15 } }); DEC.broadcast(s, 'emerg', { c: s.world.home }); return { ok: true, lines: ['Комендантский час, патрули на улицах.', 'Стабильность +10, популярность −8'] }; },
      fx: (s, a, from) => { if (a.c !== s.world.home) return null; if (s.crime && s.crime.on) { heat(s, 20); return { ok: false, title: 'Чрезвычайное положение', lines: ['Патрули повсюду: ваш розыск +20.'] }; } return { ok: true, title: 'Чрезвычайное положение', lines: [from.name + ' ввёл ЧП: проверки документов на каждом шагу.'] }; } },
    { id: 'referendum', lv: 5, n: 'Референдум о доверии', d: 'Если народ вас поддержит — много политического капитала. Если нет — удар по рейтингу.', cd: 52, target: 'none',
      npc: s => { const G = GOV.ensure(s), r = E.roll(s, E.clamp(Math.round(G.appr * 1.1), 5, 95)); GOV.op('stat', { c: s.world.home, d: {}, g: r.ok ? { pc: 80, appr: 5 } : { pc: -30, appr: -10 } }); return { ok: r.ok, roll: r, lines: [r.ok ? 'Народ сказал «да»: политический капитал +80' : 'Народ сказал «нет». Популярность −10'] }; } },
    { id: 'mobil', lv: 5, n: 'Мобилизация', d: 'Резерв армии растёт, популярность падает. Мужчинам 18–50 в стране, включая игроков, приходят повестки.', cd: 26, target: 'none',
      npc: s => { const C = s.world.cs[s.world.home]; GOV.op('stat', { c: s.world.home, d: { milp: 2 }, g: { mp: Math.round(C.st.pop * 1000 * 0.003), appr: -10 } }); DEC.broadcast(s, 'mobil', { c: s.world.home }); return { ok: true, lines: ['Резерв армии +' + Math.round(C.st.pop * 3) + ' тыс. человек', 'Популярность −10'] }; },
      fx: (s, a, from) => { if (a.c !== s.world.home || s.ch.sex !== 'm' || E.age(s) < 18 || E.age(s) > 50 || (s.job && s.job.army) || s.pol) return null; setTimeout(() => UI.event('mobilgov').then(() => UI.save()), 300); return { ok: false, title: 'Мобилизация', lines: ['Указ ' + from.name + ': вам пришла повестка.'] }; } },
  ];
  DEC.byId = id => DEC.LIST.find(d => d.id === id);
  DEC.open = s => { const l = lv(s); return l < 0 ? [] : DEC.LIST.filter(d => d.lv <= l); };
  DEC.newAt = l => DEC.LIST.filter(d => d.lv === l);
  // повестка (без привязки к 2022 году)
  if (E.SPECIAL.mobil22) E.SPECIAL.mobilgov = Object.assign({}, E.SPECIAL.mobil22, { id: 'mobilgov', x: 'Объявлена мобилизация. В почтовом ящике повестка, на работе тоже спрашивали.' });
  // ---------- выполнение ----------
  DEC.run = (s, id, tgt) => {
    const d = DEC.byId(id); if (!d) return null;
    s.dec = s.dec || {};
    if (lv(s) < d.lv) return { ok: false, title: 'Решение недоступно', lines: ['Откроется на должности: ' + D.POLITICS[d.lv].n] };
    if ((s.dec[id] || 0) > s.turn) return { ok: false, title: 'Рано', lines: ['Снова можно через ' + (s.dec[id] - s.turn) + ' нед.'] };
    if (s.ap <= 0) return { ok: false, title: 'Нет сил на этой неделе', lines: ['Закончите неделю.'] };
    let out;
    if (tgt && tgt.uid) {
      if (typeof NET === 'undefined' || !NET.on() || !NET.A.gov) return { ok: false, title: 'Игрок недоступен', lines: [] };
      NET.A.gov({ k: 'fx', to: tgt.uid, dec: id, a: { uid: NET.uid, c: s.world.home, city: s.ch.city, cityN: E.cityName(s) }, from: { uid: NET.uid, name: s.ch.name + ' ' + s.ch.surname } });
      out = Object.assign({ ok: true, lines: ['Решение касается игрока: ' + tgt.name + '.'] }, d.me ? d.me(s) : {});
      if (typeof NET !== 'undefined' && NET.feed) try { NET.feed(d.n + ': ' + tgt.name, true, d.n, s.ch.name + ' ' + s.ch.surname + ' — ' + d.n.toLowerCase() + ' (' + tgt.name + ')'); } catch (e) { }
    } else out = d.npc(s, tgt && tgt.npc ? tgt.npc : (tgt && tgt.opt) || '');
    if (!out) return null;
    s.dec[id] = s.turn + d.cd; s.ap--;
    if (out.fx) E.apply(s, out.fx);
    if (out.infl) s.st.infl = Math.min(100, (s.st.infl || 0) + out.infl);
    if (out.g && E.isLeader(s)) GOV.op('stat', { c: s.world.home, d: {}, g: out.g });
    const fxl = out.fx ? Object.entries(out.fx).filter(([k, v]) => v).map(([k, v]) => ({ rep: 'Репутация', happy: 'Счастье', stress: 'Стресс' }[k] ? ({ rep: 'Репутация', happy: 'Счастье', stress: 'Стресс' }[k] + ' ' + (v > 0 ? '+' : '') + v) : '')).filter(Boolean) : [];
    E.logAdd(s, 'act', 'Гос. решение: ' + d.n + (tgt && (tgt.name || tgt.npc || tgt.opt) ? ' (' + (tgt.name || tgt.npc || tgt.opt) + ')' : ''), { ok: out.ok !== false });
    return { ok: out.ok !== false, roll: out.roll, title: d.n + (tgt && (tgt.name || tgt.npc) ? ': ' + (tgt.name || tgt.npc) : ''), lines: (out.lines || []).concat(fxl).concat(out.infl ? ['Влияние +' + out.infl] : []) };
  };
  DEC.broadcast = (s, id, a) => { if (typeof NET === 'undefined' || !NET.on() || !NET.A.gov) return; NET.A.gov({ k: 'fx', to: '*', dec: id, a, from: { uid: NET.uid, name: s.ch.name + ' ' + s.ch.surname } }); };
  DEC.recv = m => {
    const s = UI.s, d = DEC.byId(m.dec); if (!s || !d || !d.fx) return;
    const r = d.fx(s, m.a || {}, m.from || { name: 'Кто-то' }); if (!r) return;
    if (r.fx) E.apply(s, r.fx);
    UI.appendMsg({ k: 'out', ok: r.ok, title: r.title, lines: r.lines });
    if (typeof SFX !== 'undefined') SFX.play(r.ok ? 'good' : 'bad');
    UI.renderAll(); UI.save();
  };
  // ---------- окно ----------
  DEC.ui = () => {
    const s = UI.s, l = lv(s);
    if (l < 0) { U.big(`${U.head('flag', 'Гос. решения', 'Сначала нужна должность')}<div class="decwrap"><p class="note">Выдвигайтесь на выборы муниципального депутата (вкладка «Власть» слева или напишите в чат «иду на выборы депутата»). На каждой ступени открываются новые решения.</p></div>`); return; }
    const players = typeof NET !== 'undefined' && NET.on() ? NET.list().filter(p => !p.self) : [];
    const tsel = (d) => {
      if (d.target === 'none') return '';
      if (d.target === 'opt') return `<select data-t="${d.id}">${d.opts.map(o => `<option value="opt:${UI.esc(o)}">${UI.esc(o)}</option>`).join('')}</select>`;
      const pl = players.map(p => `<option value="uid:${p.uid}">👤 ${UI.esc(p.name)}</option>`).join('');
      const npc = d.target === 'any' ? NPC(s).map(n => `<option value="npc:${UI.esc(n)}">${UI.esc(n)}</option>`).join('') : '';
      return `<select data-t="${d.id}">${pl ? `<optgroup label="Игроки">${pl}</optgroup>` : ''}${npc ? `<optgroup label="Не игроки">${npc}</optgroup>` : ''}</select>`;
    };
    const card = d => {
      const open = d.lv <= l, wait = (s.dec || {})[d.id] > s.turn ? s.dec[d.id] - s.turn : 0;
      return `<div class="decc ${open ? '' : 'lock'}"><div class="dch"><b>${d.n}</b>${d.target === 'any' || d.target === 'player' ? '<span class="tag mid" title="Можно применить к живому игроку">👥 игроки</span>' : ''}${d.id === 'improve' || d.id === 'taxbreak' || d.id === 'emerg' || d.id === 'mobil' ? '<span class="tag mid" title="Касается всех игроков в стране">👥 все</span>' : ''}</div><p>${d.d}</p>
        ${open ? `<div class="dcf">${tsel(d)}<button class="btn small primary" data-dec="${d.id}" ${wait || s.ap <= 0 ? 'disabled' : ''}>${wait ? 'через ' + wait + ' нед.' : 'Принять'}</button></div>` : `<small class="lk">Откроется: ${D.POLITICS[d.lv].n}</small>`}</div>`;
    };
    const lvls = D.POLITICS.map((p, i) => { const ds = DEC.LIST.filter(d => d.lv === i); return ds.length ? `<h4 class="${i <= l ? '' : 'lockh'}">${i <= l ? '✓ ' : ''}${p.n}</h4><div class="decg">${ds.map(card).join('')}</div>` : ''; }).join('');
    U.big(`${U.head('flag', 'Гос. решения', s.pol.n + ' · действий на неделе: ' + s.ap, E.isLeader(s) ? [['Правительство', 'GOVUI.open()', 'globe']] : [])}
      <div class="decwrap">${E.isLeader(s) ? `<button class="btn wide primary govbig" onclick="GOVUI.open()">${UI.ic('globe')} Правительство: законы, бюджет, министры, дипломатия, армия</button>` : ''}${lvls}</div>`);
    $$('#modal [data-dec]').forEach(b => b.onclick = () => {
      const id = b.dataset.dec, sel = $('#modal select[data-t="' + id + '"]');
      let tgt = null;
      if (sel) { const v = sel.value; if (v.startsWith('uid:')) { const p = players.find(x => x.uid === v.slice(4)); tgt = { uid: p.uid, name: p.name }; } else if (v.startsWith('npc:')) tgt = { npc: v.slice(4) }; else if (v.startsWith('opt:')) tgt = { opt: v.slice(4) }; }
      UI.appendMsg({ k: 'me', t: 'Гос. решение: ' + DEC.byId(id).n + (tgt ? ' — ' + (tgt.name || tgt.npc || tgt.opt) : '') });
      const r = DEC.run(s, id, tgt);
      U.res(r, () => DEC.ui());
    });
  };
  // ---------- новая должность → какие решения открылись ----------
  const _take = E.takeOffice;
  E.takeOffice = (s, p) => {
    _take(s, p);
    const l = D.POLITICS.findIndex(x => x.id === p.id), nd = DEC.newAt(l);
    s.flags.decNew = { t: s.turn + 2, n: nd.map(d => d.n) };
    if (typeof UI !== 'undefined' && UI.appendMsg) setTimeout(() => { try { UI.appendMsg({ k: 'out', ok: true, title: 'Открыты гос. решения: ' + p.n, lines: nd.map(d => d.n + ' — ' + d.d).concat(p.id === 'president' ? ['А ещё — окно «Правительство»: законы, бюджет, министры, дипломатия и дивизии.'] : []).concat(['Кнопка «Власть» в углу карты.']) }); UI.renderAll(); } catch (e) { } }, 500);
  };
  document.addEventListener('DOMContentLoaded', () => {
    if (typeof AI === 'undefined') return;
    const _br = AI.brief;
    AI.brief = s => { const b = _br(s), n = s.flags && s.flags.decNew; return n && n.t >= s.turn && n.n.length ? b + '; на новой должности открылись гос. решения: ' + n.n.join(', ') + ' (расскажи о них)' : b; };
  });
})();
