// «Судьба» — сдача жилья в аренду. Чем лучше квартира (класс, площадь, мебель), тем лучше жильцы:
// платят больше, реже задерживают и почти ничего не ломают. Можно купить квартиру «под сдачу», не переезжая.
'use strict';
const RENT = {};
RENT.CLS = { poor: 0.8, mid: 1, rich: 1.4 };
RENT.comfort = (s, h) => (h.furn || []).reduce((a, f) => { const it = L.FURN(s).find(x => x.id === f.id); return a + (it ? it.c * D.TIER[f.tier || 'std'].c * (f.broken ? 0.3 : 1) : 0); }, 0);
// 0..100: насколько квартира привлекательна для хороших жильцов
RENT.score = (s, p) => {
  const h = p.home || {}, c = RENT.comfort(s, h);
  const cls = { poor: 10, mid: 35, rich: 60 }[h.cls] || 25;
  const kind = h.type === 'room' ? -15 : h.type === 'house' ? 5 : 0;
  return Math.round(E.clamp(cls + kind + Math.min(35, c * 1.1) + Math.min(8, (h.area || 30) / 10) - (p.wear || 0) * 0.4, 0, 100));
};
RENT.base = (s, p) => {
  const h = p.home || {}, mk = L.market(s, h.city != null ? h.city : s.ch.city);
  const c = RENT.comfort(s, h);
  return Math.round(mk.rm2 * (h.area || 30) * (RENT.CLS[h.cls] || 1) * (0.72 + Math.min(0.5, c / 60)) * (1 - (p.wear || 0) / 250) / 100) * 100;
};
RENT.TYPES = {
  modern: [
    { min: 0, n: 'Шумная компания студентов', who: ['Артём, Кирилл и Влад', 'Трое студентов-первокурсников', 'Парень с другом из общаги'], k: 0.82, late: 0.25, dmg: 0.12, leave: 0.1, d: 'Платят как получится, бывают вечеринки' },
    { min: 0, n: 'Вахтовики', who: ['Бригада отделочников', 'Двое вахтовиков с севера', 'Рабочие со стройки'], k: 0.88, late: 0.15, dmg: 0.08, leave: 0.12, d: 'Неприхотливые, но квартиру не берегут' },
    { min: 25, n: 'Молодая пара', who: ['Даша и Никита', 'Молодожёны Савельевы', 'Пара бариста и курьера'], k: 1, late: 0.07, dmg: 0.04, leave: 0.06, d: 'Нормальные жильцы, иногда просят подождать с оплатой' },
    { min: 30, n: 'Семья с ребёнком', who: ['Семья Ковалёвых', 'Мама с дочкой-школьницей', 'Семья военного'], k: 1, late: 0.05, dmg: 0.06, leave: 0.03, d: 'Живут долго, но ребёнок — это обои' },
    { min: 45, n: 'Офисный сотрудник', who: ['Менеджер банка', 'Бухгалтер из логистической компании', 'Аналитик из «большой четвёрки»'], k: 1.08, late: 0.03, dmg: 0.02, leave: 0.05, d: 'Аккуратный, платит день в день' },
    { min: 62, n: 'IT-специалист', who: ['Тимлид из IT-компании', 'Разработчик на удалёнке', 'Дизайнер из геймдева'], k: 1.18, late: 0.015, dmg: 0.01, leave: 0.05, d: 'Платит вперёд, ценит хороший интернет и ремонт' },
    { min: 75, n: 'Топ-менеджер / экспат', who: ['Директор по продажам', 'Иностранный инженер с контрактом', 'Владелец сети кофеен'], k: 1.35, late: 0.01, dmg: 0.01, leave: 0.06, d: 'Готов платить много — но только за премиум' },
  ],
  ww2: [
    { min: 0, n: 'Сезонные рабочие', who: ['Двое рабочих с лесозаготовок', 'Артель плотников'], k: 0.85, late: 0.2, dmg: 0.1, leave: 0.12, d: 'Платят нерегулярно' },
    { min: 0, n: 'Студенты рабфака', who: ['Трое рабфаковцев', 'Студенты техникума'], k: 0.85, late: 0.2, dmg: 0.08, leave: 0.1, d: 'Шумно, но весело' },
    { min: 30, n: 'Семья рабочего', who: ['Семья токаря', 'Семья слесаря с завода'], k: 1, late: 0.06, dmg: 0.05, leave: 0.03, d: 'Тихие, работящие' },
    { min: 50, n: 'Инженер с семьёй', who: ['Инженер-конструктор', 'Учительница с мужем-счетоводом'], k: 1.12, late: 0.03, dmg: 0.02, leave: 0.04, d: 'Аккуратные, платят исправно' },
    { min: 70, n: 'Ответственный работник', who: ['Начальник цеха', 'Командированный из наркомата'], k: 1.3, late: 0.01, dmg: 0.01, leave: 0.06, d: 'Хорошо платит, требует уюта' },
  ],
};
RENT.types = s => RENT.TYPES[E.ww2(s) ? 'ww2' : 'modern'];
// кандидаты в жильцы (3 штуки, меняются каждые 2 недели)
RENT.cands = (s, i) => {
  const p = s.props[i]; if (!p) return [];
  const sc = RENT.score(s, p), base = RENT.base(s, p), r = L.rng(L.hash('ten', i, Math.floor(s.turn / 2), p.n));
  const pool = RENT.types(s).filter(t => t.min <= sc + 5);
  const out = [];
  for (let k = 0; k < 3; k++) {
    // хорошая квартира — больше шансов на лучших жильцов
    const t = pool[Math.min(pool.length - 1, Math.floor(Math.pow(r(), 0.6 - Math.min(0.35, sc / 250)) * pool.length))];
    const rent = Math.round(base * t.k * (0.92 + r() * 0.16) / 100) * 100;
    out.push({ t: t.n, who: t.who[Math.floor(r() * t.who.length)], d: t.d, rent, late: t.late, dmg: t.dmg, leave: t.leave, months: [6, 11, 12, 24][Math.floor(r() * 4)] });
  }
  return out;
};
RENT.lease = (s, i, k) => {
  const p = s.props[i], c = RENT.cands(s, i)[k]; if (!p || !c) return null;
  p.tenant = Object.assign({ since: s.date, left: c.months }, c); p.rentOut = true; p.rentIncome = c.rent; p.daily = false;
  E.fact(s, `${E.monthStr(s.date)}: сдал ${p.n.toLowerCase()} — ${c.who}, ${E.money(c.rent)}/мес.`);
  return { ok: true, title: 'Квартира сдана', lines: [c.who + ' (' + c.t.toLowerCase() + ')', 'Аренда: ' + E.money(c.rent) + '/мес, договор на ' + c.months + ' мес.', c.d] };
};
RENT.daily = (s, i) => { // посуточно: дороже, но износ и хлопоты
  const p = s.props[i]; if (!p) return null;
  if (E.ww2(s)) return { ok: false, title: 'Посуточной аренды нет', lines: ['В 1930-е такого не бывает.'] };
  if (RENT.score(s, p) < 30) return { ok: false, title: 'Сначала обставьте квартиру', lines: ['Посуточно снимают только квартиры с мебелью и техникой (оценка 30+).'] };
  p.tenant = null; p.daily = true; p.rentOut = true; p.rentIncome = Math.round(RENT.base(s, p) * 1.45 / 100) * 100;
  return { ok: true, title: 'Сдаёте посуточно', lines: ['Ожидаемо ~' + E.money(p.rentIncome) + '/мес, но доход скачет, а мебель изнашивается быстрее.', 'Уборка и бельё — 15% выручки.'] };
};
RENT.stop = (s, i) => { const p = s.props[i]; if (!p) return null; p.tenant = null; p.daily = false; p.rentOut = false; p.rentIncome = 0; return { ok: true, title: 'Квартира свободна', lines: ['Жильцов больше нет. Коммуналку теперь платите вы.'] }; };
RENT.raise = (s, i) => {
  const p = s.props[i]; if (!p || !p.tenant) return null;
  const t = p.tenant, nr = Math.round(t.rent * 1.1 / 100) * 100;
  if (Math.random() < 0.35 + (t.rent / RENT.base(s, p) - 1)) { RENT.stop(s, i); return { ok: false, title: 'Жильцы съехали', lines: [t.who + ' не согласились на +10% и съехали.'] }; }
  t.rent = nr; p.rentIncome = nr; return { ok: true, title: 'Аренда повышена', lines: ['Теперь ' + E.money(nr) + '/мес.'] };
};
// меблировка «под ключ» для сдачи
RENT.KITS = { eco: ['bed', 'fridge', 'stove', 'wash', 'table', 'wardrobe', 'kettle'], std: ['bed', 'sofa', 'tv', 'fridge', 'stove', 'micro', 'wash', 'table', 'wardrobe', 'kettle', 'curtain', 'lamp', 'ac'], pre: ['bed', 'sofa', 'tv', 'fridge', 'stove', 'micro', 'wash', 'dish', 'table', 'wardrobe', 'kettle', 'curtain', 'lamp', 'ac', 'vac', 'art', 'plant', 'speaker', 'carpet'] };
RENT.kitCost = (s, tier) => RENT.KITS[tier].reduce((a, id) => { const it = L.FURN(s).find(x => x.id === id); return a + (it ? L.furnPrice(s, it, tier) : 0); }, 0);
RENT.furnish = (s, i, tier) => {
  const p = s.props[i]; if (!p) return null;
  const cost = RENT.kitCost(s, tier);
  if (s.st.money < cost) return { ok: false, title: 'Не хватает денег', lines: ['Меблировка «' + D.TIER[tier].n + '»: ' + E.money(cost)] };
  s.st.money -= cost; p.home.furn = RENT.KITS[tier].filter(id => L.FURN(s).some(x => x.id === id)).map(id => ({ id, tier }));
  p.wear = 0;
  return { ok: true, title: 'Квартира обставлена', lines: ['Мебель и техника «' + D.TIER[tier].n + '»: −' + E.money(cost), 'Оценка жилья: ' + RENT.score(s, p) + '/100 — придут жильцы получше.'] };
};
RENT.repair = (s, i) => {
  const p = s.props[i]; if (!p || !p.wear) return null;
  const cost = Math.round(RENT.base(s, p) * p.wear / 25 / 100) * 100;
  if (s.st.money < cost) return { ok: false, title: 'Не хватает денег', lines: ['Ремонт: ' + E.money(cost)] };
  s.st.money -= cost; p.wear = 0; (p.home.furn || []).forEach(f => { f.broken = false; });
  return { ok: true, title: 'Косметический ремонт', lines: ['−' + E.money(cost) + '. Квартира как новая.'] };
};
// купить жильё под сдачу, не переезжая
RENT.invest = (s, id, mortgage) => {
  const ci = +id.split('-')[0], l = L.listings(s, ci).find(x => x.id === id);
  if (!l) return { ok: false, title: 'Объявление устарело', lines: [] };
  const lines = [];
  if (mortgage) {
    if (E.ww2(s)) return { ok: false, title: 'Ипотеки нет', lines: [] };
    const down = Math.round(l.price * 0.2), mrate = 0.21 / 12, monthly = Math.round((l.price - down) * mrate / (1 - Math.pow(1 + mrate, -240)));
    if (s.st.money < down) return { ok: false, title: 'Нужен первый взнос', lines: ['20% — ' + E.money(down)] };
    if (E.monthlyIncome(s) + Math.round(L.market(s, ci).rm2 * l.area * 0.8) < monthly * 1.6) return { ok: false, title: 'Банк отказал', lines: ['Платёж ' + E.money(monthly) + '/мес — ваших доходов не хватает.'] };
    s.st.money -= down; s.loans.push({ n: 'Ипотека (инвест.)', left: monthly * 240, monthly, rate: 0.21 });
    lines.push('Ипотека: взнос ' + E.money(down) + ', платёж ' + E.money(monthly) + '/мес');
  } else {
    if (s.st.money < l.price) return { ok: false, title: 'Не хватает денег', lines: [l.n + ' стоит ' + E.money(l.price)] };
    s.st.money -= l.price; lines.push('Куплено за ' + E.money(l.price));
  }
  const h = L.fromListing(s, l, true); h.furn = [];
  s.props.push({ n: l.n + ', ' + l.addr + (ci !== s.ch.city ? ' (' + E.startName(s, L.cityStart(ci)) + ')' : ''), value: l.price, rentOut: false, rentIncome: 0, home: h, wear: 0 });
  E.fact(s, `${E.monthStr(s.date)}: купил ${l.n.toLowerCase()} под сдачу (${E.money(l.price)}).`);
  lines.push('Квартира пустая: обставьте её и найдите жильцов в разделе «Моя недвижимость».');
  return { ok: true, title: 'Куплено под сдачу', lines };
};
// переехать в свою сдаваемую квартиру
RENT.moveIn = (s, i) => {
  const p = s.props[i]; if (!p) return null;
  const lines = []; s.props.splice(i, 1);
  L.leave(s, lines);
  const furn = s.home.furn || [];
  s.home = Object.assign({}, p.home, { owned: true, value: p.value, furn: furn.length ? furn : (p.home.furn || []), since: s.date });
  if (p.home.city != null && p.home.city !== s.ch.city) { s.ch.city = p.home.city; s.ch.cityName = ''; if (s.job && !s.job.army) { s.job = null; lines.push('Работу в старом городе пришлось оставить.'); } }
  lines.unshift('Вы переехали: ' + E.homeName(s));
  return { ok: true, title: 'Переезд в свою квартиру', lines, map: true };
};
// ---------- месяц ----------
RENT.month = (s, r) => {
  const notes = r.notes || (r.notes = []);
  for (const p of s.props) {
    if (p.wear == null) p.wear = 0;
    const util = Math.round(L.market(s, p.home && p.home.city != null ? p.home.city : s.ch.city).rm2 * (p.home ? p.home.area || 30 : 30) * 0.12 / 100) * 100;
    if (!p.rentOut) { if (util) r.exp.push(['Коммуналка пустой квартиры: ' + p.n, util]); continue; }
    if (p.daily) {
      const occ = E.rnd(0.35, 1.05), inc = Math.round(p.rentIncome * occ * 0.85 / 100) * 100;
      r.inc.push(['Посуточно: ' + p.n + ' (загрузка ' + Math.round(occ * 70) + '%)', inc]);
      p.wear = Math.min(100, p.wear + 3);
      if (Math.random() < 0.12) { const c = Math.round(p.rentIncome * E.rnd(0.1, 0.3) / 100) * 100; r.exp.push(['Гости испортили вещи: ' + p.n, c]); }
      continue;
    }
    const t = p.tenant;
    if (t && t.mp) continue; // друг-игрок платит сам переводом (см. «Взаимодействие»)
    if (!t) { // старые сохранения: сдаётся без жильца
      r.inc.push(['Аренда: ' + p.n, p.rentIncome]); continue;
    }
    if (Math.random() < t.late) notes.push(`${t.who} задержали оплату за «${p.n}» — денег в этом месяце нет.`);
    else r.inc.push(['Аренда: ' + p.n + ' — ' + t.who, t.rent]);
    p.wear = Math.min(100, p.wear + t.dmg * 12);
    if (Math.random() < t.dmg) {
      const fs = (p.home.furn || []).filter(f => !f.broken);
      if (fs.length) { const f = fs[Math.floor(Math.random() * fs.length)]; f.broken = true; const it = L.FURN(s).find(x => x.id === f.id); notes.push(`Жильцы сломали: ${it ? it.n.toLowerCase() : 'вещь'} в «${p.n}».`); }
      else { const c = Math.round(t.rent * E.rnd(0.2, 0.6) / 100) * 100; r.exp.push(['Ремонт после жильцов: ' + p.n, c]); }
    }
    t.left--;
    if (t.left <= 0 || Math.random() < t.leave / 3) {
      if (t.left <= 0 && Math.random() < 0.55 && RENT.score(s, p) >= 30) { t.left = 12; notes.push(`${t.who} продлили договор аренды «${p.n}» ещё на год.`); }
      else { notes.push(`${t.who} съехали из «${p.n}». Найдите новых жильцов в «Моей недвижимости».`); p.tenant = null; p.rentOut = false; p.rentIncome = 0; }
    }
  }
};
// налог с аренды (самозанятый 4% / 13% НДФЛ — берём 6%)
RENT.tax = (s, r) => { const inc = r.inc.filter(x => /^Аренда|^Посуточно/.test(x[0])).reduce((a, x) => a + x[1], 0); if (inc > 0 && !E.ww2(s)) r.exp.push(['Налог с аренды', Math.round(inc * 0.06)]); };

// ---------- окно «Моя недвижимость» ----------
RENT.ui = () => {
  const s = UI.s;
  const tierBtns = i => ['eco', 'std', 'pre'].map(t => `<button class="btn small" data-furn="${i}|${t}">${D.TIER[t].n} · ${E.short(RENT.kitCost(s, t))} ₽</button>`).join('');
  const card = (p, i) => {
    const sc = RENT.score(s, p), base = RENT.base(s, p), t = p.tenant;
    const status = p.daily ? `<span class="tag mid">посуточно · ~${E.money(p.rentIncome)}/мес</span>` : t ? `<span class="tag rich">сдана · ${E.money(t.rent)}/мес</span>` : p.rentOut ? `<span class="tag rich">сдана · ${E.money(p.rentIncome)}/мес</span>` : '<span class="tag poor">пустует</span>';
    const cands = !p.rentOut ? RENT.cands(s, i).map((c, k) => `<div class="tenant"><div><b>${UI.esc(c.who)}</b><small>${c.t} · ${UI.esc(c.d)}</small><small class="risk">Задержки: ${Math.round(c.late * 100)}% · Порча: ${Math.round(c.dmg * 100)}% · договор ${c.months} мес</small></div><div class="tp"><b>${E.money(c.rent)}</b><small>в месяц</small><button class="btn small primary" data-lease="${i}|${k}">Сдать</button></div></div>`).join('') : '';
    return `<div class="prop">
      <div class="ph">${U.thumb(p.home.type || 'flat', p.home.cls || 'mid', p.home.photo != null ? p.home.photo : i % 4)}<div><b>${UI.esc(p.n)}</b>${status}
        <small>${p.home.area || '?'} м² · мебель: ${(p.home.furn || []).length} шт. · износ ${Math.round(p.wear || 0)}% · стоит ~${E.short(p.value)} ₽</small>
        <div class="meter" title="Чем выше оценка, тем лучше жильцы: больше платят, реже задерживают и меньше ломают"><i style="width:${sc}%"></i><span>Привлекательность ${sc}/100 · рынок ~${E.money(base)}/мес</span></div></div></div>
      ${t ? `<p class="small">${UI.esc(t.who)} (${t.t.toLowerCase()}): договор ещё ${t.left} мес. ${UI.esc(t.d)}</p>` : ''}
      ${cands ? `<h5>Желающие снять</h5>${cands}` : ''}
      <div class="pbtns">${!p.rentOut && !E.ww2(s) ? `<button class="btn small" data-daily="${i}">Сдавать посуточно</button>` : ''}${t ? `<button class="btn small" data-raise="${i}">Поднять аренду +10%</button>` : ''}${p.rentOut ? `<button class="btn small" data-stop="${i}">Снять с аренды</button>` : ''}
        ${p.wear > 10 ? `<button class="btn small" data-repair="${i}">Ремонт (~${E.short(Math.round(base * p.wear / 25))} ₽)</button>` : ''}
        <button class="btn small" data-movein="${i}">Переехать сюда</button><button class="btn small danger" data-sell="${i}">Продать ~${E.short(p.value)} ₽</button></div>
      ${!p.rentOut ? `<div class="pbtns"><span class="small">Обставить под ключ:</span>${tierBtns(i)}</div>` : ''}
    </div>`;
  };
  U.big(`${U.head('home', 'Моя недвижимость', 'Сдавайте квартиры: чем дороже и уютнее жильё, тем лучше жильцы', [['Купить ещё', 'U.cian()', 'plus']])}
    <div class="props">${s.props.length ? s.props.map(card).join('') : `<div class="empty"><p>Своей недвижимости кроме жилья пока нет.</p><p class="small">Купите квартиру в «Поиске жилья» кнопкой <b>«Купить под сдачу»</b> — переезжать не нужно. Или купите своё жильё: при переезде старое останется вам.</p><button class="btn primary" onclick="U.cian()">Открыть объявления</button></div>`}</div>
    <p class="small rnote">Как это работает: оценка жилья складывается из класса дома, площади, мебели и износа. Студенты и вахтовики берут что угодно, но задерживают оплату и ломают вещи. Семьи и офисные — стабильные. IT-шники и топ-менеджеры платят больше всех, но идут только в хорошо обставленные квартиры. Налог с аренды — 6%.</p>`);
  const act = (sel, fn) => $$('#modal [' + sel + ']').forEach(b => b.onclick = () => { const v = b.getAttribute(sel).split('|'); const r = fn(...v); UI.appendMsg({ k: 'me', t: b.textContent.trim().slice(0, 60) }); U.res(r, () => { if (r && r.map) { UI.closeModal(); MAP.home(s); } else RENT.ui(); }); });
  act('data-lease', (i, k) => RENT.lease(s, +i, +k));
  act('data-daily', i => RENT.daily(s, +i));
  act('data-stop', i => RENT.stop(s, +i));
  act('data-raise', i => RENT.raise(s, +i));
  act('data-repair', i => RENT.repair(s, +i));
  act('data-furn', (i, t) => RENT.furnish(s, +i, t));
  act('data-movein', i => RENT.moveIn(s, +i));
  act('data-sell', i => L.sellProp(s, +i));
};

// при переезде старое своё жильё остаётся пустым (мебель вы забираете) — дальше решаете сами
L.leave = (s, lines) => {
  const h = s.home;
  if (h.deposit) { s.st.money += h.deposit; lines.push('Залог за старое жильё вернули: ' + E.money(h.deposit)); }
  if (h.owned && h.value) {
    const home = JSON.parse(JSON.stringify(h)); home.furn = [];
    const p = { n: E.homeName(s) + (h.addr ? ', ' + h.addr : ''), value: h.value, rentOut: false, rentIncome: 0, home, wear: 0 };
    s.props.push(p);
    // сразу подбираем жильцов попроще — чтобы квартира не пустовала
    const c = RENT.cands(s, s.props.length - 1)[0];
    if (c) { p.tenant = Object.assign({ since: s.date, left: c.months }, c); p.rentOut = true; p.rentIncome = c.rent; lines.push('Старую квартиру сдали: ' + c.who + ', ' + E.money(c.rent) + '/мес. Мебель вы забрали — обставьте её, и придут жильцы получше («Моя недвижимость»).'); }
  }
};
E.bizIncome = s => s.biz.reduce((a, b) => a + b.lastProfit, 0) + s.props.reduce((a, p) => a + (p.rentOut ? (p.tenant ? p.tenant.rent : p.rentIncome) : 0), 0);

// ---------- из чата: «сдаю квартиру», «сдам посуточно» ----------
E.ACTIONS.push('rentout');
E.A.rentout = (s, it) => {
  const t = E.norm(it.raw || it.target || '');
  if (!s.props.length) return { ok: false, impossible: true, title: 'Сдавать нечего', lines: ['Своей второй квартиры нет. Купите жильё «под сдачу» в поиске жилья или переедьте — старое своё жильё останется вам.'], apCost: 0 };
  const i = s.props.findIndex(p => !p.rentOut);
  if (/посуточ/.test(t)) { const r = RENT.daily(s, i >= 0 ? i : 0); return Object.assign(r, { apCost: 1 }); }
  if (/обстав|мебел/.test(t)) { const tier = /преми|дорог|люкс/.test(t) ? 'pre' : /эконом|деш/.test(t) ? 'eco' : 'std'; return Object.assign(RENT.furnish(s, i >= 0 ? i : 0, tier), { apCost: 1 }); }
  if (/подн|повыс/.test(t)) { const j = s.props.findIndex(p => p.tenant); return j >= 0 ? Object.assign(RENT.raise(s, j), { apCost: 1 }) : { ok: false, impossible: true, title: 'Жильцов нет', lines: [], apCost: 0 }; }
  if (i < 0) return { ok: true, title: 'Всё уже сдано', lines: s.props.map(p => p.n + ': ' + (p.tenant ? p.tenant.who + ', ' + E.money(p.tenant.rent) + '/мес' : 'посуточно')), apCost: 0 };
  const cs = RENT.cands(s, i), best = cs.map((c, k) => [c.rent * (1 - c.late) - c.rent * c.dmg * 3, k]).sort((a, b) => b[0] - a[0])[0][1];
  const r = RENT.lease(s, i, best);
  r.lines.push('Привлекательность квартиры: ' + RENT.score(s, s.props[i]) + '/100. Больше мебели и выше класс — лучше жильцы.');
  return Object.assign(r, { apCost: 1 });
};
document.addEventListener('DOMContentLoaded', () => {
  if (typeof AI === 'undefined') return;
  AI.SYS_INTERPRET = AI.SYS_INTERPRET.replace('other — всё остальное.', 'rentout — сдать свою квартиру/дом жильцам или посуточно, обставить сдаваемую квартиру мебелью, поднять аренду жильцам\nother — всё остальное.');
  AI.SCHEMA.properties.type.enum = E.ACTIONS.concat(['chat']);
});
const _plR = E.parseLocal;
E.parseLocal = text => { const it = _plR(text), t = E.norm(text); if (/сда(ть|м|ю|вать)(?![а-яё]).*(квартир|жиль|дом|комнат|посуточ)|в аренду (квартир|жиль)|посуточно|жильц/.test(t) && !/сним(у|аю)|снять/.test(t)) return Object.assign(it, { type: 'rentout', target: text }); return it; };
