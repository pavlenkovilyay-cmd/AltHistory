// «Судьба» — стартовый режим (только одиночная игра): начать жизнь сразу министром или главой государства.
'use strict';
const START = {
  MODES: [
    { id: 'life', n: 'Обычная жизнь', d: 'С нуля, как все', age: 0 },
    { id: 'minister', n: 'Министр', d: 'Сразу в правительстве · от 30 лет', age: 30 },
    { id: 'president', n: 'Президент', d: 'Сразу глава страны · от 35 лет', age: 35 },
  ],
};
(() => {
  const mp = () => typeof NET !== 'undefined' && (NET.welcome || NET.on());
  START.apply = (s, mode) => {
    const m = START.MODES.find(x => x.id === mode); if (!m || mode === 'life') return;
    const p = (D.POLITICS || []).find(x => x.id === mode); if (!p) return;
    E.takeOffice(s, p);
    s.st.rep = Math.max(s.st.rep, p.rep + 2);
    s.st.infl = Math.max(s.st.infl || 0, mode === 'president' ? 70 : 45);
    s.st.money += Math.round(E.m(s, mode === 'president' ? 600000 : 250000));
    s.flags.startMode = mode;
    // служебное жильё: президенту — особняк, министру — хорошая квартира (своё)
    try { const kind = mode === 'president' ? 'house' : 'flat', ls = L.listings(s); const l = ls.find(x => x.kind === kind && x.cls === 'rich') || ls.find(x => x.kind === kind) || ls[0]; if (l) { s.home = L.fromListing(s, l, true); s.home.value = l.price || s.home.value; s.home.cls = 'rich'; const have = new Set((s.home.furn || []).map(f => f.id)); s.home.furn = (s.home.furn || []).concat(['tv', 'sofa', 'bed', 'fridge', 'stove', 'wardrobe', 'table', 'desk', 'pc', 'lamp', 'plant', 'art', 'carpet', 'curtain', 'shelf', 'wash', 'micro', 'kettle'].filter(id => (L.FURN(s) || []).some(f => f.id === id)).map(id => ({ id, tier: 1, d: s.date })).filter(f => !have.has(f.id))); } } catch (e) { console.warn('start home', e); }
    if (mode === 'president' && typeof GOV !== 'undefined') try { GOV.ensure(s); } catch (e) { }
    const ww2 = E.ww2(s);
    UI.appendMsg({ k: 'ai', t: mode === 'president'
      ? `${E.dateStr(s.date)}. Вы — ${p.n.toLowerCase()} страны. Кабинет, охрана, папки с докладами на столе. Справа — окно «Власть»: законы, бюджет, министры, армия и дипломатия. Страна ждёт решений.`
      : `${E.dateStr(s.date)}. Вас назначили министром. ${ww2 ? 'Наркомат' : 'Министерство'}, подчинённые, первые совещания. В окне «Власть» — ваши гос. решения. Отсюда можно дорасти до главы государства.` });
    E.fact(s, `${E.monthStr(s.date)}: начал(а) путь сразу с поста — ${p.n}.`);
  };
  document.addEventListener('DOMContentLoaded', () => {
    // выбор режима на экране «Новая жизнь»
    const _c = UI.create;
    UI.create = (...a) => {
      _c(...a);
      if (mp()) return; // в мультиплеере — только обычная жизнь
      const c = UI.cr; c.start = c.start || 'life';
      const btns = document.querySelector('.cform .cbtns'); if (!btns) return;
      const wrap = document.createElement('div');
      wrap.innerHTML = `<label>Стартовый режим <small>(только одиночная игра)</small></label><div class="cards3" id="cStart">${START.MODES.map(m => `<button data-v="${m.id}" class="${m.id === c.start ? 'on' : ''}"><b>${m.n}</b><span>${m.d}</span></button>`).join('')}</div>`;
      btns.parentNode.insertBefore(wrap, btns);
      const age = document.getElementById('cAge');
      const sync = () => document.querySelectorAll('#cStart button').forEach(b => b.classList.toggle('on', b.dataset.v === c.start));
      document.querySelectorAll('#cStart button').forEach(b => b.onclick = () => {
        c.start = b.dataset.v; sync();
        const need = START.MODES.find(m => m.id === c.start).age;
        if (need && c.age < need && age) { age.value = need; age.oninput({ target: age }); UI.toast('Возраст поднят до ' + E.years(need) + ' — моложе на этот пост не берут'); }
      });
      const go = document.getElementById('cGo'), _go = go.onclick;
      go.onclick = async () => {
        const mode = c.start, need = (START.MODES.find(m => m.id === mode) || {}).age || 0;
        if (need && c.age < need) c.age = need;
        await _go();
        if (mode !== 'life' && UI.s && !mp()) { START.apply(UI.s, mode); UI.save(); try { UI.renderAll(); } catch (e) { } }
      };
    };
    // стартовый режим — только для одиночной игры
    if (typeof NET !== 'undefined' && NET.host) { const _h = NET.host; NET.host = (...a) => { if (UI.s && UI.s.flags && UI.s.flags.startMode) { UI.toast('Эта жизнь начата в стартовом режиме (министр/президент) — он только для одиночной игры. Для мультиплеера начните новую жизнь.', 'bad'); return; } return _h(...a); }; }
  });
})();
