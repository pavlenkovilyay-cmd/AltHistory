// «Судьба» — мультиплеер. Без своих серверов: сообщения идут через открытые публичные ретрансляторы
// (MQTT и Nostr, сразу по нескольким путям — см. bus.js). Ничего настраивать не нужно — только код комнаты.
// Хост считает общий мир (страны, войны, экономика, время). Каждый игрок считает свою жизнь и свою нейросеть у себя.
'use strict';
const NET = {
  APP: 'sudba-mp-v1', room: null, role: null, code: '', uid: '', status: 'off', // off | search | on | hostlost
  players: {}, // peerId → { uid, name, ... , ready }
  readySelf: false, hostPeer: null, welcome: null, chat: [], queue: [], t0: 0, A: {},
};
NET.on = () => !!NET.room;
NET.mkCode = () => { const A = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; let c = ''; for (let i = 0; i < 6; i++) c += A[Math.floor(Math.random() * A.length)]; return c.slice(0, 3) + '-' + c.slice(3); };
NET.norm = c => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '').replace(/0/g, 'O').replace(/1/g, 'I').slice(0, 6);
NET.pick = t => { const m = String(t || '').toUpperCase().match(/(^|[^A-Z0-9])([A-Z2-9]{3})-?([A-Z2-9]{3})([^A-Z0-9]|$)/); return m ? m[2] + m[3] : NET.norm(t); };
NET.fmt = c => { c = NET.pick(c); return c.slice(0, 3) + (c.length > 3 ? '-' + c.slice(3) : ''); };
NET.rid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

// ---------- упаковка мира (gzip + base64) ----------
NET.pack = async obj => {
  const bytes = new TextEncoder().encode(JSON.stringify(obj));
  if (!window.CompressionStream) return 'J' + JSON.stringify(obj);
  const cs = new Blob([bytes]).stream().pipeThrough(new CompressionStream('gzip'));
  const buf = new Uint8Array(await new Response(cs).arrayBuffer());
  let s = ''; for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return 'G' + btoa(s);
};
NET.unpack = async str => {
  if (str[0] === 'J') return JSON.parse(str.slice(1));
  const bin = atob(str.slice(1)), buf = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
  const ds = new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'));
  return JSON.parse(await new Response(ds).text());
};
NET.KEEP = ['home', 'army', 'gained', 'lost', 'annexed']; // это у каждого своё
NET.applyWorld = (s, w) => { const keep = {}; for (const k of NET.KEEP) if (s.world && s.world[k] !== undefined) keep[k] = s.world[k]; s.world = Object.assign(w, keep); };

// ---------- кто я ----------
NET.me = () => {
  const s = UI.s; if (!s) return { uid: NET.uid, name: '…' };
  return { uid: NET.uid, name: s.ch.name + ' ' + s.ch.surname, sex: s.ch.sex, look: s.ch.look, city: s.ch.city, cityN: E.cityName(s), pos: E.position(s), age: E.age(s), home: s.world.home, era: s.era, ready: NET.readySelf, host: NET.role === 'host', turn: s.turn };
};
NET.list = () => [Object.assign({}, NET.me(), { self: true })].concat(Object.entries(NET.players).map(([pid, p]) => Object.assign({ pid }, p)));
NET.byUid = uid => Object.entries(NET.players).find(([pid, p]) => p.uid === uid);

// ---------- подключение ----------
NET.connect = (code, role) => {
  if (!window.BUSLIB || typeof BUS === 'undefined') { UI.toast('Модуль сети не загрузился', 'bad'); return false; }
  NET.leave(true);
  NET.code = NET.fmt(code); NET.role = role; NET.status = 'search'; NET.t0 = Date.now();
  NET.players = {}; NET.readySelf = false; NET.hostPeer = null;
  let room;
  try { room = NET.room = BUS.room(NET.norm(code), NET.uid); } catch (e) { console.warn(e); NET.status = 'off'; NET.room = null; UI.toast('Сеть недоступна: ' + e.message, 'bad'); return false; }
  const act = n => { const [send, get] = room.makeAction(n); NET.A[n] = send; return get; };
  act('hello')((d, pid) => NET.onHello(d, pid));
  act('welcome')((d, pid) => NET.onWelcome(d, pid));
  act('tick')((d, pid) => NET.onTick(d, pid));
  act('ready')((d, pid) => { if (NET.players[pid]) { NET.players[pid].ready = !!d.on; NET.players[pid].turn = d.turn; } NET.refresh(); if (NET.role === 'host') NET.checkAll(); });
  act('me')((d, pid) => { NET.players[pid] = Object.assign(NET.players[pid] || {}, d); NET.refresh(); });
  act('feed')((d, pid) => NET.onFeed(d, pid));
  act('chat')((d, pid) => NET.onChat(d, pid));
  act('money')((d, pid) => NET.onMoney(d, pid));
  room.onPeerJoin(pid => { NET.A.hello(NET.me(), pid); });
  room.onPeerLeave(pid => {
    const p = NET.players[pid]; delete NET.players[pid];
    if (p) NET.sys(`${p.name} вышел из комнаты`);
    if (pid === NET.hostPeer) { NET.hostPeer = null; NET.status = 'hostlost'; NET.sys('Хост вышел — ждём, пока он вернётся. Свои действия можно делать, но неделя не наступит.'); }
    NET.refresh(); if (NET.role === 'host') NET.checkAll();
  });
  if (role === 'host') NET.status = 'on';
  NET.refresh(); if (UI.s && document.getElementById('top')) UI.renderAll();
  return true;
};
NET.leave = silent => {
  if (NET.room) { try { NET.room.leave(); } catch (e) { } }
  NET.room = null; NET.status = 'off'; NET.players = {}; NET.hostPeer = null; NET.readySelf = false; NET.role = null;
  if (!silent) { NET.refresh(); if (UI.s && document.getElementById('top')) UI.renderAll(); }
};
// Хост: создать комнату с текущей жизнью
NET.host = () => {
  const s = UI.s; if (!s) return;
  s.mp = s.mp && s.mp.role === 'host' ? s.mp : { code: NET.mkCode(), role: 'host', uid: (s.mp && s.mp.uid) || NET.rid() };
  NET.uid = s.mp.uid; s.mpWorldDate = s.date; s.mpTurn = s.turn; UI.save();
  NET.connect(s.mp.code, 'host');
  NET.sys(`Комната создана. Код: ${s.mp.code} — отправьте его друзьям.`);
};
// Игрок: войти по коду (жизнь создаётся заново, в мире хоста)
NET.join = code => {
  NET.uid = NET.rid(); NET.welcome = null;
  return NET.connect(code, 'client');
};
// После перезагрузки — вернуться в свою комнату
NET.resume = s => {
  if (!s.mp || !s.mp.code || NET.on()) return;
  NET.uid = s.mp.uid || (s.mp.uid = NET.rid());
  if (s.mp.role === 'host' && s.mpWorldDate && s.mpWorldDate > s.date) { s.date = s.mpWorldDate; s.turn = s.mpTurn; }
  NET.connect(s.mp.code, s.mp.role);
  if (s.mp.role === 'host') NET.sys(`Комната ${s.mp.code} снова открыта.`);
};

// ---------- сообщения ----------
NET.onHello = async (d, pid) => {
  NET.players[pid] = Object.assign(NET.players[pid] || {}, d);
  if (d.host) { NET.hostPeer = pid; if (NET.status !== 'on' && UI.s && UI.s.mp) NET.status = 'on'; }
  if (NET.role === 'host' && UI.s) {
    const s = UI.s;
    if (d.era && d.era !== s.era && d.joined) { /* чужая эпоха — игрок сам увидит предупреждение */ }
    NET.A.welcome({ code: NET.code, era: s.era, date: NET.wDate(), turn: NET.wTurn(), host: NET.me(), sp: NET.speed, left: NET.due ? NET.due - Date.now() : 0, w: await NET.pack(s.world), players: NET.list().map(p => ({ uid: p.uid, name: p.name })) }, pid);
    NET.sys(`${d.name && d.name !== '…' ? d.name : 'Новый игрок'} заходит в комнату`);
    NET.checkAll();
  }
  NET.refresh();
};
NET.onWelcome = async (d, pid) => {
  if (NET.role !== 'client') return;
  NET.hostPeer = pid; NET.status = 'on';
  NET.speed = d.sp || 0; NET.due = NET.speed ? Date.now() + (d.left || NET.SPEEDS[NET.speed] * 1000) : 0;
  const s = UI.s;
  if (!s || !s.mp || s.mp.code !== NET.code) { // новый игрок: дальше — создание героя в эпохе хоста
    NET.welcome = d; NET.refresh(); if (NET.onWelcomeCb) NET.onWelcomeCb(d); return;
  }
  // вернулись в свою комнату: догоняем мир и дату хоста
  try {
    const w = await NET.unpack(d.w);
    if (d.era !== s.era) { NET.sys('У хоста другая эпоха — эта жизнь не подходит к комнате.'); return; }
    NET.applyWorld(s, w);
    if (d.turn !== s.turn) { s.date = d.date; s.turn = d.turn; }
    UI.save(); UI.renderAll(); if (window.MAP && MAP.svg) { MAP.paint(s); UI.legend(); }
    NET.sys('Связь с хостом есть — мир синхронизирован.');
    NET.A.me(NET.me());
  } catch (e) { console.warn('welcome', e); }
};
// создание героя: подставить дату/мир хоста
NET.adopt = async s => {
  const d = NET.welcome; if (!d) return;
  const shift = Date.parse(d.date) - Date.parse(s.date);
  s.ch.birth = new Date(Date.parse(s.ch.birth) + shift).toISOString();
  s.date = d.date; s.turn = d.turn;
  NET.applyWorld(s, await NET.unpack(d.w));
  s.mp = { code: NET.code, role: 'client', uid: NET.uid };
  NET.welcome = null;
};
NET.sys = t => { if (UI.s) UI.appendMp({ sys: 1, t }); NET.chat.push({ sys: 1, t }); NET.refresh(); };
NET.onFeed = (d, pid) => { const p = NET.players[pid] || d; UI.appendMp({ feed: 1, who: d.name || p.name, city: d.cityN, sex: p.sex, look: p.look, said: d.act, title: d.title, ok: d.ok, x: d.text, date: d.date }); NET.refresh(); };
NET.onChat = (d, pid) => { const p = NET.players[pid] || {}; const m = { chat: 1, who: d.name || p.name, t: d.text }; UI.appendMp(m); NET.chat.push(m); if (typeof SFX !== 'undefined') SFX.play('event'); NET.refresh(); };
NET.onMoney = (d, pid) => {
  if (d.to !== NET.uid || !UI.s) return;
  const s = UI.s, sum = Math.max(0, Math.round(+d.amount || 0)); if (!sum) return;
  s.st.money += sum; E.logAdd(s, 'event', `Получил перевод от ${d.name}: ${E.money(sum)}`);
  UI.appendMsg({ k: 'out', ok: true, title: `${d.name} перевёл вам ${E.money(sum)}`, lines: d.note ? ['«' + d.note + '»'] : [] });
  if (typeof SFX !== 'undefined') SFX.play('coin'); UI.renderAll(); UI.save();
};
NET.feed = (title, ok, text, act) => { if (NET.on() && NET.A.feed) NET.A.feed({ uid: NET.uid, name: NET.me().name, cityN: NET.me().cityN, title, ok, text: String(text || '').slice(0, 1500), act: String(act || '').slice(0, 400), date: UI.s && E.dateStr(UI.s.date) }); };
NET.say = text => { text = String(text || '').trim().slice(0, 300); if (!text || !NET.on()) return; NET.A.chat({ uid: NET.uid, name: NET.me().name, text }); const m = { chat: 1, who: 'Вы', t: text, mine: 1 }; UI.appendMp(m); NET.chat.push(m); NET.refresh(); };
NET.send = (uid, amount, note) => {
  const s = UI.s, sum = Math.round(+amount || 0), e = NET.byUid(uid);
  if (!e) return { ok: false, title: 'Игрока нет в комнате' };
  if (sum <= 0) return { ok: false, title: 'Укажите сумму' };
  if (s.st.money < sum) return { ok: false, title: 'Не хватает денег', lines: ['На счету ' + E.money(s.st.money) + '.'] };
  s.st.money -= sum; E.logAdd(s, 'event', `Перевёл ${e[1].name}: ${E.money(sum)}`);
  NET.A.money({ to: uid, amount: sum, name: NET.me().name, note: String(note || '').slice(0, 80) }, e[0]);
  UI.save(); UI.renderAll();
  return { ok: true, title: `Перевод ${e[1].name}: ${E.money(sum)}`, lines: [] };
};

// ---------- ход: все жмут «Готов», хост двигает мир ----------
NET.btnText = () => {
  if (NET.status === 'hostlost') return 'Нет хоста';
  const all = NET.list(), ready = all.filter(p => p.ready).length;
  return NET.readySelf ? `Ждём ${ready}/${all.length}` : `Готов ${UI.ic('play')}`;
};
NET.toggleReady = () => {
  if (NET.role === 'client' && !NET.hostPeer) { UI.toast('Хоста нет в сети — неделя не наступит', 'bad'); return; }
  NET.readySelf = !NET.readySelf;
  NET.A.ready({ on: NET.readySelf, turn: UI.s.turn });
  NET.refresh();
  if (NET.role === 'host') NET.checkAll();
};
NET.checkAll = (force) => {
  if (NET.role !== 'host' || !UI.s) return;
  const all = NET.list();
  if (!NET.readySelf && !force) return;
  if (!force && all.some(p => !p.ready)) return;
  NET.readySelf = false; for (const p of Object.values(NET.players)) p.ready = false;
  NET.hostAdvance();
};
// Хост: мировые часы идут отдельно от его собственной жизни. Мир считается сразу и рассылается всем,
// а своя неделя хоста (события, зарплата, рассказчик) — когда он освободится, как у всех. Поэтому долгий ответ
// нейросети у хоста больше не останавливает время для остальных.
NET.wDate = () => UI.s.mpWorldDate || UI.s.date;
NET.wTurn = () => UI.s.mpTurn === undefined ? UI.s.turn : UI.s.mpTurn;
NET.hostAdvance = async () => {
  if (NET.role !== 'host' || !UI.s || NET._adv) return;
  NET._adv = true;
  try {
    const s = UI.s, prev = NET.wDate(), d = new Date(prev), om = d.getMonth(); d.setDate(d.getDate() + 7);
    const before = s.world.own.slice();
    const sh = { world: s.world, date: d.toISOString(), era: s.era, diff: s.diff, pol: s.pol, flags: s.flags, _fresh: [], chat: [], turn: NET.wTurn() + 1 };
    if (E.ww2(sh)) WD.history(sh);
    const war = WD.week(sh);
    if (d.getMonth() !== om) WD.month(sh);
    s.pol = sh.pol;
    s.mpWorldDate = sh.date; s.mpTurn = sh.turn;
    const news = (sh._fresh || []).map(n => ({ t: n.t, imp: n.imp, c: n.c, kind: n.kind }));
    const tick = { prev, date: sh.date, turn: sh.turn, news, war: (war || []).slice(0, 20), sp: NET.speed };
    const changed = before.map((o, i) => o !== s.world.own[i] ? i : -1).filter(i => i >= 0);
    if (changed.length && window.MAP && MAP.svg) { MAP.paint(s, changed); UI.legend(); }
    if (NET.speed) NET.due = Date.now() + NET.SPEEDS[NET.speed] * 1000;
    NET.A.tick(Object.assign({ w: await NET.pack(s.world) }, tick));
    NET.queue.push(Object.assign({ local: true }, tick)); NET.pump(); // своя неделя хоста — в очередь
    UI.save();
  } catch (e) { console.warn('hostAdvance', e); }
  finally { NET._adv = false; }
};
// хост: сразу после расчёта недели рассылает мир
NET.broadcast = async (prev, rep) => {
  if (NET.role !== 'host' || !NET.on()) return;
  const s = UI.s;
  const news = (rep.news || []).map(n => ({ t: n.t, imp: n.imp, c: n.c, kind: n.kind }));
  const war = (rep.war || []).slice(0, 20);
  NET.A.tick({ prev, date: s.date, turn: s.turn, w: await NET.pack(s.world), news, war, sp: NET.speed });
};
NET.onTick = async (d, pid) => {
  if (NET.role !== 'client' || !UI.s || !UI.s.mp) return;
  NET.hostPeer = pid; NET.status = 'on';
  if (d.sp !== undefined) NET.speed = d.sp;
  NET.due = NET.speed ? Date.now() + NET.SPEEDS[NET.speed] * 1000 : 0;
  // мир применяем сразу (карта, война), а свою неделю — когда освободимся
  try {
    const s = UI.s, w = await NET.unpack(d.w), before = s.world.own.slice();
    NET.applyWorld(s, w); d.world = s.world; delete d.w;
    const changed = before.map((o, i) => o !== s.world.own[i] ? i : -1).filter(i => i >= 0);
    if (changed.length && window.MAP && MAP.svg) { MAP.paint(s, changed); UI.legend(); }
  } catch (e) { console.warn('tick world', e); }
  NET.queue.push(d); NET.pump();
};
NET.pump = async () => {
  if (NET._pumping || UI.busy || !NET.queue.length) { if (NET.queue.length && !NET._pumpT) NET._pumpT = setTimeout(() => { NET._pumpT = 0; NET.pump(); }, 400); return; }
  NET._pumping = true;
  try {
    const d = NET.queue.shift(), s = UI.s;
    if (d.turn <= s.turn) return; // уже было
    const w = d.world || (d.w ? await NET.unpack(d.w) : s.world);
    NET.readySelf = false;
    await UI.nextWeek(NET.queue.length > 0, { tick: d, world: w });
  } catch (e) { console.warn('tick', e); }
  finally { NET._pumping = false; if (NET.queue.length) NET.pump(); }
};
NET.refresh = () => {
  if (!UI.s) return;
  const b = document.getElementById('nextBtn');
  if (b && NET.on()) { b.innerHTML = NET.btnText(); b.classList.toggle('waiting', NET.readySelf); }
  const dk = document.querySelector('[data-dock="room"] em'); if (dk) dk.textContent = NET.on() ? NET.list().length : '';
  if (U.roomOpen && document.querySelector('#modal .room')) U.room();
  if (window.MAP && MAP.svg) MAP.home(UI.s);
};
// раз в неделю — рассказать о себе (город, должность) — для карты и списка
NET.announce = () => { if (NET.on() && NET.A.me) NET.A.me(NET.me()); };

// ---------- скорость времени (как в HOI4): пауза / 1 / 2 / 3 ----------
NET.SPEEDS = [0, 120, 60, 30, 15]; // секунд на неделю
NET.speed = 0; NET.due = 0; // когда наступит следующая неделя (локальные часы)
NET.left = () => NET.speed && NET.due ? Math.max(0, Math.ceil((NET.due - Date.now()) / 1000)) : 0;
NET.setSpeed = sp => {
  if (NET.role !== 'host') { UI.toast('Скорость меняет тот, кто создал комнату', 'bad'); return; }
  NET.speed = sp; NET.due = sp ? Date.now() + NET.SPEEDS[sp] * 1000 : 0;
  if (UI.s && UI.s.mp) { UI.s.mp.speed = sp; UI.save(); }
  NET.A.speed && NET.A.speed({ sp, left: NET.SPEEDS[sp] * 1000 });
  NET.sys(sp ? `Скорость ${sp}: неделя каждые ${NET.SPEEDS[sp]} с` : 'Пауза');
  UI.renderAll();
};
NET.topHtml = () => {
  const host = NET.role === 'host', l = NET.left();
  return `<div class="nextg mpg">
    <button class="btn primary next ${NET.readySelf ? 'waiting' : ''}" id="nextBtn" ${UI.busy ? 'disabled' : ''} title="Отметиться готовым: если готовы все — неделя наступит сразу">${NET.btnText()}</button>
    <div class="speeds" title="${host ? 'Скорость времени' : 'Скорость меняет хост'}">${NET.SPEEDS.map((v, i) => `<button class="${NET.speed === i ? 'on' : ''}" data-sp="${i}" ${host ? '' : 'disabled'} title="${i ? 'Скорость ' + i + ': неделя за ' + NET.SPEEDS[i] + ' с' : 'Пауза'}">${i ? (i < 4 ? '▶'.repeat(i) : '▶▶▶▶') : '❚❚'}</button>`).join('')}</div>
    ${host ? `<button class="btn next2 skipm" id="skipM" ${UI.busy ? 'disabled' : ''} title="Только у хоста: промотать 4 недели для всех">+месяц</button>` : ''}
    <span class="cdown" id="cdown">${NET.speed ? Math.floor(l / 60) + ':' + String(l % 60).padStart(2, '0') : 'пауза'}</span></div>`;
};
NET.bindTop = () => { document.querySelectorAll('[data-sp]').forEach(b => b.onclick = () => NET.setSpeed(+b.dataset.sp)); const sk = document.getElementById('skipM'); if (sk) sk.onclick = NET.skipMonth; };
// хост: промотать месяц (4 недели) для всех
NET.skipMonth = async () => {
  if (NET.role !== 'host' || UI.busy || NET._skip) return;
  NET._skip = true; NET.sys('Хост проматывает месяц…');
  try { for (let k = 0; k < 4; k++) { NET.readySelf = false; for (const p of Object.values(NET.players)) p.ready = false; await NET.hostAdvance(); if (UI.s.over) break; } }
  finally { NET._skip = false; if (NET.speed) NET.due = Date.now() + NET.SPEEDS[NET.speed] * 1000; }
};
NET.timer = setInterval(() => {
  if (!NET.on() || !UI.s) return;
  const el = document.getElementById('cdown'), l = NET.left();
  if (el) el.textContent = NET.speed ? Math.floor(l / 60) + ':' + String(l % 60).padStart(2, '0') : 'пауза';
  // зависание защиты: если интерфейс «занят» слишком долго (нейросеть не ответила) — освобождаем
  if (UI.busy && UI.busySince && Date.now() - UI.busySince > 200000 && !document.querySelector('#modal .eopt')) { console.warn('busy watchdog'); UI.setBusy(false); }
  if (NET.role === 'host' && NET.speed && NET.due && Date.now() >= NET.due) { NET.due = Date.now() + NET.SPEEDS[NET.speed] * 1000; NET.checkAll(true); }
  if (el && NET.speed && l === 0 && NET.role !== 'host') { el.textContent = 'ждём хоста'; el.title = 'Неделя вот-вот наступит: хост рассылает мир'; }
  const q = NET.queue.length; const nb = document.getElementById('nextBtn'); if (nb) nb.title = q ? `Ещё ${q} нед. ждут, пока вы закончите действие` : 'Отметиться готовым: если готовы все — неделя наступит сразу';
}, 500);
// События в мультиплеере на скорости не держат всех: через 25 с выбирается последний вариант
NET.autoPick = () => {
  if (!NET.on() || !NET.speed) return;
  const box = document.querySelector('#modal .ev'); if (!box) return;
  let n = 25; const tag = document.createElement('p'); tag.className = 'autopick'; box.appendChild(tag);
  const t = setInterval(() => {
    if (!document.body.contains(tag)) { clearInterval(t); return; }
    tag.textContent = `Идёт время: автовыбор через ${n} с`;
    if (n-- <= 0) { clearInterval(t); const opts = document.querySelectorAll('#modal .eopt'); if (opts.length) opts[opts.length - 1].click(); }
  }, 1000);
};
NET._connect0 = NET.connect;
NET.connect = (code, role) => {
  const ok = NET._connect0(code, role);
  if (ok && NET.room) {
    const [sendIa, getIa] = NET.room.makeAction('ia'); NET.A.ia = sendIa; getIa((d, pid) => { try { IA.onMsg(d, pid); } catch (e) { console.warn('ia', e); } });
    const [sendH3, getH3] = NET.room.makeAction('h3'); NET.A.h3 = sendH3; getH3((d, pid) => { try { if (typeof H3 !== 'undefined') H3.onNet(d, pid); } catch (e) { console.warn('h3', e); } });
    const [sendGov, getGov] = NET.room.makeAction('gov'); NET.A.gov = sendGov; getGov((d, pid) => { try { if (typeof GOV !== 'undefined') GOV.onNet(d, pid); } catch (e) { console.warn('gov', e); } });
    const [send, get] = NET.room.makeAction('speed'); NET.A.speed = send;
    get(d => { NET.speed = d.sp; NET.due = d.sp ? Date.now() + d.left : 0; if (UI.s) { NET.sys(d.sp ? `Хост включил скорость ${d.sp} (неделя каждые ${NET.SPEEDS[d.sp]} с)` : 'Хост поставил паузу'); UI.renderAll(); } });
    if (role === 'host' && UI.s && UI.s.mp) { NET.speed = UI.s.mp.speed || 0; NET.due = NET.speed ? Date.now() + NET.SPEEDS[NET.speed] * 1000 : 0; }
  }
  return ok;
};

// сколько «досок объявлений» (Nostr-ретрансляторов) доступно — для подсказки при проблемах со связью
NET.relayStat = () => { const s = BUS.stat(); return [s.mqtt[0] + s.nostr[0] + s.own[0], s.mqtt[1] + s.nostr[1] + s.own[1]]; };
NET.netText = () => { const s = BUS.stat(); return `MQTT ${s.mqtt[0]}/${s.mqtt[1]} · Nostr ${s.nostr[0]}/${s.nostr[1]}` + (s.own[1] ? ` · свой сервер ${s.own[0]}/${s.own[1]}` : ''); };
