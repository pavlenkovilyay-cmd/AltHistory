// «Судьба» — живой мир: экономика стран, политика, кризисы, войны между странами, гражданские войны,
// исторические события 1936–1945. Всё считается здесь, карта лишь показывает владельцев провинций.
'use strict';
const WD = {};

// ---------- география ----------
WD.unproj = (x, y) => {
  const W = M().W, H = M().H, my = lat => { const p = lat * Math.PI / 180; return 1.25 * Math.log(Math.tan(Math.PI / 4 + 0.4 * p)); };
  const Y0 = my(82), Y1 = my(-57);
  const m = Y0 - y / H * (Y0 - Y1);
  return [x / W * 360 - 180, (Math.atan(Math.exp(m / 1.25)) - Math.PI / 4) / 0.4 * 180 / Math.PI];
};
WD.iso = i => M().countries[M().provinces[i].c].iso;
WD.ll = i => { const p = M().provinces[i]; return WD.unproj(p.x, p.y); };
WD.dist = (i, j) => { const a = M().provinces[i], b = M().provinces[j]; return Math.hypot(a.x - b.x, a.y - b.y); };

// ---------- создание мира ----------
WD.init = (s, era) => {
  const m = M();
  let src, own;
  if (era === 'ww2') { src = m.ww2.countries; own = m.ww2.own.slice(); }
  else {
    src = m.countries;
    own = m.provinces.map(p => { const c = m.countries[p.c]; const oi = m.countries.findIndex(x => x.id === c.own); return oi >= 0 ? oi : p.c; });
  }
  const cs = src.map((c, i) => ({
    id: c.id, iso: c.iso || '', n: c.n, col: c.col, pw: c.pw, cap: c.cap,
    st: Object.assign({ lead: '', bloc: [] }, JSON.parse(JSON.stringify(c.st))),
    base: 0, pw0: c.pw, gdp0: c.st.gdp, milp0: c.st.milp, pop0: c.st.pop, h: { gdp: [], pop: [], stab: [] }, rel: 0, shock: 0, dead: false, elect: E.ri(6, 60), ev: [],
  }));
  own.forEach(o => cs[o].base++);
  cs.forEach((c, i) => { c.cap0 = c.cap; const ci = c.cap >= 0 ? WD.iso(c.cap) : ''; c.metro0 = own.filter((o, k) => o === i && WD.iso(k) === ci).length; });
  const homeId = '643';
  const home = cs.findIndex(c => c.id === homeId);
  s.world = { era, cs, own, core: own.slice(), home, wars: [], army: 1, gained: 0, lost: 0, annexed: [], news: [], done: {}, cpi: 1, month: 0, startCount: own.filter(o => o === home).length };
  for (const c of cs) if (c.base === 0) c.dead = true;
  if (era === 'ww2') { const j = cs.findIndex(c => c.id === '392'), m = cs.findIndex(c => c.id === 'MAN'); if (j >= 0 && m >= 0) cs[m].puppetOf = j; }
  // отношения с нашей страной
  const H = cs[home];
  cs.forEach((c, i) => {
    if (i === home) return;
    let r = E.ri(-10, 15);
    if (c.st.bloc.some(b => H.st.bloc.includes(b))) r += 40;
    if ((H.st.bloc.includes('ОДКБ') && c.st.bloc.includes('НАТО')) || (H.st.bloc.includes('НАТО') && c.st.bloc.includes('ОДКБ'))) r -= 35;
    if (era === 'ww2') { if (c.st.bloc.includes('Ось')) r -= 45; else if (c.st.bloc.includes('Союзники')) r -= 10; }
    c.rel = E.clamp(r, -100, 100);
  });
  WD.recordAll(s);
};

// Старые сохранения (версия 1)
WD.migrate = s => {
  if (!s.era) s.era = 'modern';
  if (!s.diff) s.diff = 'normal';
  if (!s.world || !s.world.cs || s.world.own.length !== M().provinces.length) {
    const pol = s.pol;
    WD.init(s, s.era);
    if (pol) s.pol = pol;
    s.chat.push({ k: 'sys', t: 'Карта обновлена до новой версии (провинций стало в 3 раза больше).' });
  }
};

// ---------- доступ ----------
E.C = ci => E.cur.world.cs[ci];
E.countryName = ci => E.cur.world.cs[ci] ? E.cur.world.cs[ci].n : '?';
E.alive = s => s.world.cs.map((c, i) => i).filter(i => !s.world.cs[i].dead);
E.power = (s, ci) => {
  const c = s.world.cs[ci]; if (!c) return 0;
  const core = s.world.core || s.world.own;
  let n = 0; s.world.own.forEach((o, i) => { if (o === ci) n += core[i] === ci || c.created ? 1 : 0.3; });
  const mil = Math.min(3.2, Math.sqrt(Math.max(0.3, c.st.milp) / Math.max(0.5, c.milp0)));
  const eco = Math.pow(Math.max(0.2, c.st.gdp / Math.max(0.01, c.gdp0)), 0.3);
  let p = c.pw0 * Math.sqrt(Math.max(n, 0.3) / Math.max(1, c.base)) * mil * eco * (0.6 + c.st.stab / 250) * (1 - Math.min(0.45, (c.wear || 0) * 0.008));
  if (ci === s.world.home) p *= s.world.army;
  return p;
};
WD.atWar = (s, a, b) => s.world.wars.some(w => (w.a === a && w.b === b) || (w.a === b && w.b === a));
WD.enemies = (s, a) => s.world.wars.filter(w => w.a === a || w.b === a).map(w => w.a === a ? w.b : w.a);
WD.allies = (s, a, enemy) => WD.enemies(s, enemy).filter(x => x !== a);

// ---------- новости ----------
WD.news = (s, t, cs, imp, kind) => {
  const n = { d: s.date, t, c: cs || [], imp: imp || 0, kind: kind || '' };
  s.world.news.push(n); if (s.world.news.length > 300) s.world.news.splice(0, s.world.news.length - 300);
  for (const ci of n.c) { const c = s.world.cs[ci]; if (c) { c.ev.push({ d: s.date, t }); if (c.ev.length > 12) c.ev.shift(); } }
  (s._fresh = s._fresh || []).push(n);
  return n;
};
WD.big = (s, ci) => ci === s.world.home || s.world.cs[ci].st.gdp >= (s.world.era === 'ww2' ? 40 : 500) || E.borders(s, s.world.home, ci);

// ---------- история показателей ----------
WD.recordAll = s => {
  for (const c of s.world.cs) {
    if (c.dead) continue;
    const h = c.h;
    h.gdp.push(+c.st.gdp.toFixed(c.st.gdp < 10 ? 2 : 1)); h.pop.push(+c.st.pop.toFixed(c.st.pop < 10 ? 4 : 2)); h.stab.push(Math.round(c.st.stab));
    for (const k in h) if (h[k].length > 120) h[k].shift();
  }
};

// ---------- месяц: экономика и политика ----------
const DEMOC = g => /Республика|Конституционная|Доминион/.test(g || '');
WD.month = s => {
  const W = s.world, era = W.era;
  W.month++;
  const oilUp = W.oil || 0;
  for (let i = 0; i < W.cs.length; i++) {
    const c = W.cs[i]; if (c.dead) continue;
    const st = c.st;
    const war = WD.enemies(s, i).length > 0;
    const pc = st.gdp * 1000 / Math.max(st.pop, 0.001);
    // рост
    let g = st.gr + E.rnd(-1.6, 1.6) + c.shock - (war ? 3.5 : 0) - (st.stab < 30 ? 2.5 : 0) - (st.infl > 40 ? 2 : 0);
    if (OIL.has(c.iso)) g += oilUp * 1.5; else g -= oilUp * 0.3;
    const mg = g / 12 / 100;
    st.gdp = Math.max(0.01, st.gdp * (1 + mg));
    c.shock *= 0.75;
    // цены, работа, долг
    const inflBase = c.inflBase !== undefined ? c.inflBase : (c.inflBase = st.infl);
    st.infl = E.clamp(st.infl + (inflBase - st.infl) * 0.08 + E.rnd(-0.5, 0.5) + (war ? 0.6 : 0) + (c.shock < -2 ? -0.3 : 0), -3, 400);
    st.unemp = E.clamp(st.unemp - (g - 2) * 0.05 + E.rnd(-0.15, 0.15) + (war ? -0.2 : 0), 0.5, 45);
    const def = 2.5 + st.milp * 0.25 + (war ? 4 : 0) - g * 0.4;
    st.debt = E.clamp(st.debt + def / 12 - st.debt * 0.002, 0, 400);
    // население
    const pg = era === 'ww2' ? 1.1 : (pc > 25000 ? 0.25 : pc > 5000 ? 0.8 : 2.4) + (c.iso === 'RU' || c.iso === 'UA' ? -0.6 : 0) + (c.iso === 'JP' ? -0.6 : 0);
    st.pop = Math.max(0.001, st.pop * (1 + pg / 12 / 100));
    // стабильность
    const target = 62 + Math.min(10, g * 2) - st.unemp * 0.6 - Math.min(20, Math.max(0, st.infl - 5) * 0.25) - (war ? 6 + (c.wear || 0) * 0.3 : 0) + (DEMOC(st.gov) ? 6 : 0);
    st.stab = E.clamp(st.stab + (target - st.stab) * 0.06 + E.rnd(-1.2, 1.2), 0, 100);
    // армия
    if (war) { st.milp = Math.min(45, st.milp + (era === 'ww2' ? 1.6 : 0.6)); c.wear = (c.wear || 0) + 1; }
    else { st.milp += (c.milp0 - st.milp) * 0.04; c.wear = Math.max(0, (c.wear || 0) - 2); }
    const armyT = Math.max(1, st.pop * 1000 * Math.min(0.12, 0.002 + st.milp * 0.0028) * (era === 'ww2' ? 1.3 : 0.6));
    st.army = Math.round(st.army + (armyT - st.army) * (war ? 0.12 : 0.03));
    // выборы
    if (DEMOC(st.gov) && --c.elect <= 0) {
      c.elect = E.ri(46, 60);
      if (st.stab > 55 && Math.random() < 0.6) { if (WD.big(s, i)) WD.news(s, `${c.n}: выборы — действующая власть сохранила большинство.`, [i], 0, 'elect'); st.stab += 2; }
      else { if (WD.big(s, i)) WD.news(s, `${c.n}: на выборах победила оппозиция, сменилось правительство.`, [i], 1, 'elect'); st.stab += 5; c.shock += 0.5; if (st.lead) st.lead = ''; }
    }
    // случайные события страны
    WD.countryEvents(s, i, g);
  }
  // мировые события
  WD.globalEvents(s);
  if (W.oil) W.oil *= 0.85;
  // инфляция в нашей стране → цены
  const H = W.cs[W.home];
  if (H && !H.dead) W.cpi *= 1 + Math.max(-0.01, H.st.infl / 12 / 100);
  WD.recordAll(s);
};
const OIL = new Set(['SA', 'RU', 'IR', 'IQ', 'KW', 'AE', 'QA', 'NO', 'VE', 'NG', 'KZ', 'AZ', 'DZ', 'LY', 'OM', 'AO', 'BH']);

WD.countryEvents = (s, i, g) => {
  const W = s.world, c = W.cs[i], st = c.st, era = W.era;
  const big = WD.big(s, i);
  const bad = D.DIFF[s.diff] ? D.DIFF[s.diff].bad : 1;
  const r = Math.random;
  if (r() < 0.006 * (st.debt > 120 ? 2 : 1) * (st.infl > 30 ? 2 : 1) * (i === W.home ? bad : 1)) {
    c.shock -= E.rnd(4, 9); st.unemp += E.rnd(0.5, 2); st.stab -= 4;
    if (big) WD.news(s, `${c.n}: экономический кризис — производство падает, растёт безработица.`, [i], i === W.home ? 2 : 1, 'crisis');
  } else if (r() < 0.005) {
    c.shock += E.rnd(3, 6); st.stab += 2;
    if (big) WD.news(s, `${c.n}: экономический бум — инвестиции и рост зарплат.`, [i], i === W.home ? 1 : 0, 'boom');
  }
  if (r() < 0.003) {
    const t = E.pick(['землетрясение', 'наводнение', 'ураган', 'лесные пожары', 'засуха']);
    st.pop *= 0.9995; c.shock -= E.rnd(0.5, 2); st.stab -= 2;
    if (big) WD.news(s, `${c.n}: ${t}. Есть жертвы и разрушения.`, [i], i === W.home ? 1 : 0, 'disaster');
  }
  if (st.stab < 35 && r() < 0.04) { st.stab -= 3; if (big || r() < 0.3) WD.news(s, `${c.n}: массовые протесты против властей.`, [i], 0, 'protest'); }
  if (st.stab < 20 && i !== W.home && !DEMOC(st.gov) && r() < 0.015 && !WD.enemies(s, i).length) {
    st.gov = 'Военная хунта'; st.lead = ''; st.stab += 12; c.shock -= 2;
    WD.news(s, `${c.n}: военный переворот! Армия взяла власть.`, [i], 1, 'coup');
  } else if (st.stab < 12 && r() < 0.012 && E.countryProvs(s, i).length >= 4 && !WD.enemies(s, i).length) {
    WD.civilWar(s, i);
  }
  if (i === W.home && st.stab < 15 && s.pol && s.pol.id === 'president' && r() < 0.06) s.flags.revolt = true;
};

// ---------- ресурсы ----------
WD.RNAME = code => (window.RESN || {})[code] || code;
WD.resources = (s, ci) => {
  const m = M(), W = s.world, out = {};
  let tot = 0;
  W.own.forEach((o, i) => { if (o !== ci) return; const p = m.provinces[i]; const wt = (p.w || 0.001) * Math.sqrt(m.countries[p.c].st.pop || 1) + 0.002; tot += wt; for (const r of p.r || []) out[r] = (out[r] || 0) + wt; });
  return Object.entries(out).map(([k, v]) => [k, v / Math.max(tot, 1e-9)]).sort((a, b) => b[1] - a[1]);
};
WD.CRIT = ['oil', 'gas', 'coal', 'grain', 'iron'];
WD.shortage = (s, i) => {
  const W = s.world, c = W.cs[i];
  const res = new Map(WD.resources(s, i));
  const lack = WD.CRIT.filter(k => !res.has(k));
  const own = WD.CRIT.filter(k => res.has(k));
  let k, txt;
  if (lack.length && Math.random() < 0.6) { k = E.pick(lack); txt = `${c.n}: перебои с импортом — дефицит: ${WD.RNAME(k).toLowerCase()}.`; }
  else if (own.length) { k = E.pick(own); txt = `${c.n}: ${k === 'grain' ? 'неурожай' : 'авария на месторождениях'} — не хватает: ${WD.RNAME(k).toLowerCase()}.`; }
  else return;
  c.shock -= E.rnd(1, 3); c.st.infl += E.rnd(1, 4); c.st.stab -= 3;
  (c.short = c.short || []).push({ d: s.date, k }); if (c.short.length > 6) c.short.shift();
  if (i === W.home) W.cpi *= 1.01;
  WD.news(s, txt, [i], i === W.home ? 1 : (WD.big(s, i) ? 1 : 0), 'res');
};
WD.globalEvents = s => {
  if (Math.random() < 0.35) { const al = E.alive(s); const i = Math.random() < 0.15 ? s.world.home : E.pick(al); if (i !== undefined && Math.random() < (i === s.world.home ? 0.12 : 0.6)) WD.shortage(s, i); }
  const W = s.world, r = Math.random;
  if (W.era !== 'ww2') {
    if (W.era === 'y2018') WD.history(s);
    if (r() < 0.004) { W.oil = E.pick([-3, -2, 2, 3]); WD.news(s, W.oil > 0 ? 'Нефть резко подорожала: экспортёры богатеют, остальные платят больше.' : 'Нефть резко подешевела: бюджеты нефтяных стран трещат.', [], 1, 'oil'); }
    if (W.era === 'modern' && r() < 0.0008) { for (const c of W.cs) if (!c.dead) { c.shock -= E.rnd(3, 6); c.st.stab -= 4; } WD.news(s, 'Пандемия нового вируса: границы закрываются, мировая экономика падает.', [], 2, 'pandemic'); }
    if (r() < (W.era === 'y2018' ? 0.0025 : 0.012)) WD.randomWar(s);
  } else {
    WD.history(s);
    if (new Date(s.date).getFullYear() >= 1938 && r() < 0.006) WD.randomWar(s);
  }
};

// перенос населения, ВВП и площади вместе с территорией
WD.moveStats = (s, from, to, frac, eff) => {
  const A = s.world.cs[from], B = s.world.cs[to]; if (!A || !B || from === to) return;
  frac = E.clamp(frac, 0, 1); eff = eff === undefined ? 1 : eff;
  const dp = A.st.pop * frac, dg = A.st.gdp * frac, dk = A.st.km * frac, da = A.st.army * frac * 0.5;
  A.st.pop -= dp; A.st.gdp -= dg; A.st.km -= dk; A.st.army -= da;
  B.st.pop += dp; B.st.gdp += dg * eff; B.st.km += dk;
};
// ---------- войны ----------
WD.declare = (s, a, b, opt) => {
  if (a === b || WD.atWar(s, a, b) || s.world.cs[a].dead || s.world.cs[b].dead) return null;
  const w = Object.assign({ a, b, weeks: 0, score: 0, took: 0, lost: 0, start: s.date, total: false, startA: E.countryProvs(s, a).length, startB: E.countryProvs(s, b).length }, opt || {});
  s.world.wars.push(w);
  s.world.cs[a].rel = s.world.home === b ? -100 : s.world.cs[a].rel;
  s.world.cs[b].rel = s.world.home === a ? -100 : s.world.cs[b].rel;
  if (a === s.world.home) s.world.cs[b].rel = -100;
  if (b === s.world.home) s.world.cs[a].rel = -100;
  return w;
};
WD.endWar = (s, w, text, imp) => {
  const i = s.world.wars.indexOf(w); if (i >= 0) s.world.wars.splice(i, 1);
  if (text) WD.news(s, text, [w.a, w.b], imp === undefined ? 1 : imp, 'peace');
};
WD.annex = (s, loser, winner, text) => {
  const W = s.world;
  if (W.cs[loser].puppetOf !== undefined) W.cs.forEach(c => { if (c.puppetOf === loser) c.puppetOf = undefined; });
  const core = W.core || (W.core = W.own.slice());
  WD.moveStats(s, loser, winner, 1, 0.85);
  W.own.forEach((o, i) => { if (o === loser) { W.own[i] = winner; if (core[i] === loser) core[i] = winner; if (winner === W.home) W.gained++; if (loser === W.home) W.lost++; } });
  W.cs[loser].dead = true;
  for (const w of W.wars.slice()) if (w.a === loser || w.b === loser) WD.endWar(s, w);
  if (winner === W.home) W.annexed.push(loser);
  if (text) WD.news(s, text, [loser, winner], 2, 'annex');
};
WD.transfer = (s, filter, to) => {
  const W = s.world; let n = 0;
  const core = W.core || (W.core = W.own.slice());
  const cnt = {}; W.own.forEach((o, i) => { if (o !== to && filter(i, o)) cnt[o] = (cnt[o] || 0) + 1; });
  for (const o in cnt) WD.moveStats(s, +o, to, cnt[o] / Math.max(1, E.countryProvs(s, +o).length), 0.9);
  W.own.forEach((o, i) => { if (o !== to && filter(i, o)) { if (to === W.home) W.gained++; if (o === W.home) W.lost++; W.own[i] = to; core[i] = to; n++; } });
  for (const c of W.cs) if (!c.dead && !W.own.includes(W.cs.indexOf(c))) c.dead = true;
  return n;
};
WD.newCountry = (s, o) => {
  const c = Object.assign({ created: true, puppetOf: o.puppetOf, id: o.id || ('X' + s.world.cs.length), iso: o.iso || '', n: o.n, col: o.col, pw: o.pw || 5, cap: o.cap, st: Object.assign({ pop: 1, gdp: 1, gr: 2, infl: 5, unemp: 8, debt: 30, stab: 50, army: 50, milp: 3, gov: '', lead: '', bloc: [], km: 0 }, o.st || {}), base: 0, pw0: o.pw || 5, gdp0: 1, milp0: 3, pop0: 1, h: { gdp: [], pop: [], stab: [] }, rel: o.rel || 0, shock: 0, dead: false, elect: 50, ev: [] }, {});
  s.world.cs.push(c);
  return s.world.cs.length - 1;
};
// Переносит долю населения/ВВП вместе с провинциями
WD.splitStats = (s, from, to, provs) => {
  const W = s.world, A = W.cs[from], B = W.cs[to];
  const share = provs.length / Math.max(1, E.countryProvs(s, from).length + provs.length);
  for (const k of ['pop', 'gdp', 'army']) { const v = A.st[k] * share; A.st[k] -= v; B.st[k] = (B.st[k] || 0) * 0 + v; }
  B.st.km = Math.round(provs.reduce((a, i) => a + (M().provinces[i].km || 0), 0));
  B.gdp0 = B.st.gdp; B.pop0 = B.st.pop; B.base = provs.length;
};
WD.civilWar = (s, i, name, col) => {
  const W = s.world, c = W.cs[i];
  const provs = E.countryProvs(s, i);
  const cap = c.cap >= 0 && W.own[c.cap] === i ? c.cap : provs[0];
  const far = provs.slice().sort((a, b) => WD.dist(b, cap) - WD.dist(a, cap)).slice(0, Math.max(1, Math.round(provs.length * E.rnd(0.3, 0.45))));
  const r = WD.newCountry(s, { n: name || (c.n + ' (мятежники)'), col: col || WD.darker(c.col), pw: Math.max(2, Math.round(c.pw0 * 0.6)), cap: far[0], st: { gov: 'Повстанцы', stab: 45 } });
  far.forEach(p => { W.own[p] = r; });
  WD.splitStats(s, i, r, far);
  W.cs[r].milp0 = c.st.milp; W.cs[r].st.milp = c.st.milp;
  W.cs[r].rebelOf = i;
  WD.declare(s, r, i, { total: true, civil: true });
  WD.news(s, `${c.n}: началась гражданская война! Мятежники контролируют ${far.length} пров.`, [i, r], i === W.home ? 2 : 1, 'civil');
  return r;
};
WD.darker = col => { const n = parseInt(col.slice(1), 16); const f = v => Math.max(0, Math.round(v * 0.82)); return '#' + [f(n >> 16), f((n >> 8) & 255), f(n & 255)].map(v => v.toString(16).padStart(2, '0')).join(''); };

WD.randomWar = s => {
  const W = s.world;
  const alive = E.alive(s).filter(i => i !== W.home && !WD.enemies(s, i).length);
  const ag = E.pick(alive.filter(i => W.cs[i].st.stab < 50 || W.cs[i].st.milp > 3 || W.cs[i].st.bloc.includes('Ось')));
  if (ag === undefined) return;
  const nb = new Set();
  for (const e of M().edges) { const a = W.own[e.a], b = W.own[e.b]; if (a === ag && b !== ag) nb.add(b); if (b === ag && a !== ag) nb.add(a); }
  const targets = [...nb].filter(t => t !== W.home && !W.cs[t].dead && E.power(s, t) < E.power(s, ag) * 1.1 && !W.cs[t].st.bloc.some(b => W.cs[ag].st.bloc.includes(b)));
  const t = E.pick(targets); if (t === undefined) return;
  WD.declare(s, ag, t, { limited: true });
  WD.news(s, `${W.cs[ag].n} напала на ${WD.acc(W.cs[t].n)}. Начался пограничный конфликт.`, [ag, t], WD.big(s, ag) || WD.big(s, t) ? 1 : 0, 'war');
};
WD.acc = n => n; // падежи не склоняем — названия стран оставляем как есть

// неделя войны
WD.week = s => {
  const W = s.world, out = [];
  const frontLen = {};
  const frs = new Map();
  for (const w of W.wars) { const f = E.fronts(s, w.a, w.b); frs.set(w, f); frontLen[w.a] = (frontLen[w.a] || 0) + f.length; frontLen[w.b] = (frontLen[w.b] || 0) + f.length; }
  const share = (x, w) => 0.5 + 0.5 * (frs.get(w) || []).length / Math.max(1, frontLen[x] || 1);
  const tie = (x, z) => W.cs[x].puppetOf === z || W.cs[z].puppetOf === x;
  for (const w of W.wars.slice()) {
    if (!W.wars.includes(w)) continue;
    w.weeks++;
    if (w.idle && new Date(s.date) < new Date(w.idle)) continue;
    const a = w.a, b = w.b;
    const sideP = (x, y) => E.power(s, x) * share(x, w) + WD.allies(s, x, y).reduce((acc, z) => acc + E.power(s, z) * (tie(x, z) ? 0.6 : E.borders(s, z, y) ? 0.2 : 0.08), 0);
    const core = W.core || W.own;
    const occ = x => { let n = 0; W.own.forEach((o, i) => { if (o === x && core[i] !== x) n++; }); return n; };
    const ov = x => Math.max(0.5, 1 / (1 + occ(x) / (25 + W.cs[x].base)));
    const yr = new Date(s.date).getFullYear();
    const blitz = x => W.era === 'ww2' ? (W.cs[x].id === '276' && yr < 1943 ? 1.6 : W.cs[x].id === '392' && yr < 1943 ? 1.2 : 1) : 1;
    const ovA = ov(a) * blitz(a), ovB = ov(b) * blitz(b);
    const deep = d => W.cs[d].st.pop > 300 ? 0.55 : W.cs[d].st.pop > 120 || W.cs[d].st.km > 3e6 ? 0.75 : 1;
    const mod = (att, def, prov) => (typeof ARMY !== 'undefined' ? ARMY.mod(s, att, def, prov) : 1) * (core[prov] === att ? 1.4 : 1) * (core[prov] === def ? (W.cs[def].base >= 40 ? 0.8 : 1) * deep(def) : 1) * (W.cs[def].cap === prov ? 0.6 : 1) * (att === a ? (w.atkA || 1) * ovA : (w.atkB || 1) * ovB);
    const pa = sideP(a, b), pb = sideP(b, a), p = pa / Math.max(0.01, pa + pb);
    let fr = E.fronts(s, a, b);
    const mine = a === W.home || b === W.home;
    const log = t => { if (mine) out.push(t); };
    const fight = (att, def, prov, mult) => {
      const P = M().provinces[prov];
      const isCap = W.cs[def].cap === prov;
      WD.moveStats(s, def, att, 1 / Math.max(2, E.countryProvs(s, def).length), 0.6);
      W.own[prov] = att;
      if (att === a) { w.took++; w.score++; } else { w.lost++; w.score--; }
      if (att === W.home) W.gained++; if (def === W.home) W.lost++;
      log({ t: (att === W.home ? 'Взята провинция ' : (def === W.home ? 'Потеряна провинция ' : W.cs[att].n + ' взяла ')) + P.n, good: att === W.home, bad: def === W.home, prov });
      // потери
      W.cs[att].st.pop *= 0.9998; W.cs[def].st.pop *= 0.9993;
      if (isCap) WD.capitalFell(s, w, def, att, log);
    };
    if (fr.length) {
      const n = Math.min(fr.length, 1 + Math.floor(fr.length / 10) + E.ri(0, 1) + (p > 0.62 || p < 0.38 ? 1 : 0) + (p > 0.75 || p < 0.25 ? 1 : 0));
      for (let k = 0; k < n; k++) {
        const e = E.pick(fr);
        const pA = W.own[e.a] === a ? e.a : e.b, pB = pA === e.a ? e.b : e.a;
        if (W.own[pA] !== a || W.own[pB] !== b) continue;
        const x = Math.random();
        if (x < p * 0.42 * mod(a, b, pB)) fight(a, b, pB);
        else if (x > 1 - (1 - p) * 0.42 * mod(b, a, pA)) fight(b, a, pA);
        if (!W.wars.includes(w)) break;
      }
    } else if (Math.random() < 0.15) {
      // десант через море: ближайшая к нам (или к союзникам) прибрежная провинция врага
      const [att, def, pp] = Math.random() < p ? [a, b, p] : [b, a, 1 - p];
      const base = W.own.map((o, i) => i).filter(i => W.own[i] === att || WD.allies(s, att, def).includes(W.own[i]));
      const tgt = W.own.map((o, i) => i).filter(i => W.own[i] === def && M().provinces[i].sea && W.cs[def].cap !== i);
      if (base.length && tgt.length && W.cs[att].pw0 >= 30) {
        let best = -1, bd = 1e18;
        for (const t of tgt) for (let k = 0; k < 30; k++) { const q = base[(Math.random() * base.length) | 0]; const d = WD.dist(t, q); if (d < bd) { bd = d; best = t; } }
        if (best >= 0 && bd < 500 && Math.random() < 0.3 * (pp + 0.1) * mod(att, def, best)) fight(att, def, best);
      }
    }
    if (!W.wars.includes(w)) continue;
    // капитуляция по доле потерянной территории
    for (const [x, y, st0] of [[b, a, w.startB], [a, b, w.startA]]) {
      const now = E.countryProvs(s, x).length;
      if (now === 0) { W.cs[x].dead = true; WD.endWar(s, w, `${W.cs[x].n} прекратила существование.`, 2); break; }
      const C = W.cs[x];
      if (!C.created && C.metro0 > 3) {
        const ci = WD.iso(C.cap0); let m = 0; W.own.forEach((o, i) => { if (o === x && (W.core || W.own)[i] === x && WD.iso(i) === ci) m++; });
        if (1 - m / C.metro0 > (C.pw0 >= 40 || C.st.pop > 150 ? 0.72 : 0.6)) { WD.capitulate(s, w, x, y, log); break; }
      }
      if (st0 > 3 && now / st0 < (C.pw0 >= 40 ? 0.2 : 0.3)) { WD.capitulate(s, w, x, y, log); break; }
    }
    if (!W.wars.includes(w)) continue;
    // усталость и мир
    if (w.limited && w.weeks > 6 && Math.random() < 0.035 + w.weeks * 0.002) {
      WD.endWar(s, w, `${W.cs[a].n} и ${W.cs[b].n} подписали перемирие. ${w.took + w.lost ? 'Граница сдвинулась.' : 'Граница осталась прежней.'}`, WD.big(s, a) || WD.big(s, b) ? 1 : 0);
      if (mine) out.push({ t: 'Перемирие с ' + W.cs[a === W.home ? b : a].n, big: true });
      continue;
    }
    if (!w.total && !w.limited && !mine && w.weeks > 20 && Math.random() < 0.015) WD.endWar(s, w, `Мир между ${W.cs[a].n} и ${W.cs[b].n}.`, 0);
    if (w.weeks % 4 === 0) { W.cs[a].st.stab -= 0.6; W.cs[b].st.stab -= 0.6; W.cs[a].shock -= 0.3; W.cs[b].shock -= 0.5; }
  }
  return out;
};
WD.capitalFell = (s, w, def, att, log) => {
  const W = s.world, c = W.cs[def];
  const n = E.countryProvs(s, def).length;
  WD.news(s, `${c.n}: пала столица! Её заняла ${W.cs[att].n}.`, [def, att], WD.big(s, def) ? 2 : 1, 'capital');
  c.st.stab -= 25;
  if (n <= 6 || (W.era !== 'ww2' && n < c.base * 0.5)) WD.capitulate(s, w, def, att, log);
  else {
    // переносим столицу в глубь страны
    const ps = E.countryProvs(s, def); if (!ps.length) return;
    c.cap = ps.slice().sort((x, y) => WD.dist(y, w.capRef || ps[0]) - WD.dist(x, w.capRef || ps[0]))[0];
    c.cap = ps.reduce((best, i) => (M().provinces[i].w || 0) > (M().provinces[best].w || 0) ? i : best, ps[0]);
  }
};
WD.capitulate = (s, w, loser, winner, log) => {
  const W = s.world, L = W.cs[loser];
  if (W.era === 'ww2' && L.id === '250' && W.cs[winner].id === '276' && !W.done.vichy) { WD.vichy(s, loser, winner); return; }
  if (w.civil && L.rebelOf === winner) { WD.annex(s, loser, winner, `${W.cs[winner].n}: гражданская война окончена, мятеж подавлен.`); return; }
  if (w.civil && W.cs[winner].rebelOf === loser) {
    const old = L.n;
    WD.annex(s, loser, winner, `${old}: мятежники победили в гражданской войне и взяли власть.`);
    const R = W.cs[winner]; R.n = old.replace(/ \(мятежники\)$/, ''); R.st.gov = R.st.gov === 'Повстанцы' ? 'Новый режим' : R.st.gov; R.rebelOf = undefined;
    if (loser === W.home) WD.homeTaken(s, winner);
    return;
  }
  const foes = WD.enemies(s, loser).filter(x => !W.cs[x].dead);
  if (foes.length > 1) winner = foes.sort((x, y) => E.power(s, y) * (E.borders(s, y, loser) ? 1 : 0.3) - E.power(s, x) * (E.borders(s, x, loser) ? 1 : 0.3))[0];
  WD.annex(s, loser, winner, `${L.n} капитулировала. Оставшаяся территория отходит к ${W.cs[winner].n}.`);
  if (log) log({ t: `${L.n} капитулировала!`, big: true, good: winner === W.home, bad: loser === W.home });
  if (loser === W.home) WD.homeTaken(s, winner);
};
// Если пала наша страна — играем дальше, но «дом» теперь победитель
WD.homeTaken = (s, winner) => {
  s.world.home = winner;
  if (s.pol) { s.flags.exPol = s.pol.n; s.pol = null; }
  s.world.homeLost = true;
  WD.news(s, `Ваша страна перестала существовать. Теперь вы живёте под властью ${s.world.cs[winner].n}.`, [winner], 2, 'home');
};

// ---------- 1936–1945: история ----------
WD.byId = (s, id) => s.world.cs.findIndex(c => c.id === id && !c.dead);
WD.H = [
  ['1936-03-07', s => { const g = WD.byId(s, '276'); if (g < 0) return; s.world.cs[g].st.stab += 5; s.world.cs[g].pw0 += 3; WD.news(s, 'Германия ввела войска в демилитаризованную Рейнскую область. Франция и Британия ограничились протестами.', [g], 1); }],
  ['1936-05-05', s => { const i = WD.byId(s, '380'), e = WD.byId(s, '231'); if (i < 0 || e < 0) return; WD.annex(s, e, i, 'Итальянские войска вошли в Аддис-Абебу. Эфиопия присоединена к Италии.'); }],
  ['1936-07-18', s => {
    const sp = WD.byId(s, '724'); if (sp < 0) return;
    const provs = E.countryProvs(s, sp).filter(i => { const [lon, lat] = WD.ll(i); return WD.iso(i) !== 'ES' || lon < -4.2 || lat < 37.6; });
    if (!provs.length) return;
    const r = WD.newCountry(s, { id: 'NSP', n: 'Националисты Франко', col: '#d7b36d', pw: 28, cap: provs.slice().sort((x, y) => M().provinces[y].w - M().provinces[x].w)[0], st: { gov: 'Военная хунта', lead: 'Франсиско Франко', bloc: [], stab: 55 }, rel: -40 });
    provs.forEach(p => { s.world.own[p] = r; });
    WD.splitStats(s, sp, r, provs);
    s.world.cs[r].rebelOf = sp; s.world.cs[r].milp0 = 4; s.world.cs[r].st.milp = 4;
    WD.declare(s, r, sp, { total: true, civil: true });
    WD.news(s, 'В Испании мятеж генералов: началась гражданская война. Германия и Италия помогают Франко, СССР — республике.', [sp, r], 2);
  }],
  ['1936-11-25', s => { const g = WD.byId(s, '276'), j = WD.byId(s, '392'); if (g < 0 || j < 0) return; WD.news(s, 'Германия и Япония подписали Антикоминтерновский пакт.', [g, j], 1); }],
  ['1937-07-07', s => {
    const j = WD.byId(s, '392'), c = WD.byId(s, '156'), m = WD.byId(s, 'MAN'); if (j < 0 || c < 0) return;
    WD.declare(s, j, c, { total: true }); if (m >= 0) WD.declare(s, m, c, { total: true });
    WD.news(s, 'Инцидент на мосту Лугоуцяо: Япония начала большую войну против Китая.', [j, c], 2, 'war');
  }],
  ['1937-08-01', s => { if (s.world.home === WD.byId(s, '643')) WD.news(s, 'В СССР усиливаются репрессии: аресты идут по всей стране, под ударом — партийные и военные кадры.', [s.world.home], 1); }],
  ['1938-03-12', s => { const g = WD.byId(s, '276'), a = WD.byId(s, '040'); if (g < 0 || a < 0) return; WD.annex(s, a, g, 'Аншлюс: Австрия присоединена к Германии.'); }],
  ['1938-09-30', s => {
    const g = WD.byId(s, '276'), c = WD.byId(s, 'CZE'); if (g < 0 || c < 0) return;
    const edge = new Set(); for (const e of M().edges) { if (s.world.own[e.a] === c && s.world.own[e.b] === g) edge.add(e.a); if (s.world.own[e.b] === c && s.world.own[e.a] === g) edge.add(e.b); }
    WD.transfer(s, i => edge.has(i) && WD.iso(i) === 'CZ' && i !== s.world.cs[c].cap, g);
    WD.news(s, 'Мюнхенское соглашение: Британия и Франция согласились отдать Германии Судетскую область Чехословакии.', [g, c], 2);
  }],
  ['1939-03-15', s => {
    const g = WD.byId(s, '276'), c = WD.byId(s, 'CZE'), h = WD.byId(s, '348'); if (g < 0 || c < 0) return;
    const sk = E.countryProvs(s, c).filter(i => WD.iso(i) === 'SK'), ua = E.countryProvs(s, c).filter(i => WD.iso(i) === 'UA');
    if (sk.length) { const r = WD.newCountry(s, { id: 'SLO', puppetOf: g, n: 'Словакия', col: '#94b9d8', pw: 3, cap: sk[0], st: { gov: 'Марионеточный режим', bloc: ['Ось'] } }); sk.forEach(i => { s.world.own[i] = r; }); WD.splitStats(s, c, r, sk); }
    if (ua.length && h >= 0) ua.forEach(i => { s.world.own[i] = h; });
    WD.annex(s, c, g, 'Германия оккупировала Чехию. Чехословакия перестала существовать, Словакия стала союзником Германии.');
  }],
  ['1939-04-07', s => { const i = WD.byId(s, '380'), a = WD.byId(s, '008'); if (i < 0 || a < 0) return; WD.annex(s, a, i, 'Италия оккупировала Албанию.'); }],
  ['1939-08-23', s => { const g = WD.byId(s, '276'), u = WD.byId(s, '643'); if (g < 0 || u < 0) return; s.world.cs[g].rel = u === s.world.home ? 20 : s.world.cs[g].rel; WD.news(s, 'СССР и Германия подписали договор о ненападении (пакт Молотова — Риббентропа).', [g, u], 2); }],
  ['1939-09-01', s => {
    const g = WD.byId(s, '276'), p = WD.byId(s, '616'); if (g < 0 || p < 0) return;
    WD.declare(s, g, p, { total: true });
    WD.news(s, 'Германия напала на Польшу. Началась Вторая мировая война.', [g, p], 2, 'war');
  }],
  ['1939-09-03', s => {
    const g = WD.byId(s, '276'); if (g < 0 || !WD.atWar(s, g, WD.byId(s, '616'))) return;
    for (const id of ['826', '250', 'RAJ', '124', '036', '554', '710']) { const x = WD.byId(s, id); if (x >= 0) WD.declare(s, x, g, { total: true, idle: '1940-05-10' }); }
    WD.news(s, 'Великобритания и Франция объявили войну Германии.', [g, WD.byId(s, '826'), WD.byId(s, '250')], 2, 'war');
  }],
  ['1939-09-17', s => {
    const u = WD.byId(s, '643'), p = WD.byId(s, '616'); if (u < 0 || p < 0) return;
    const n = WD.transfer(s, (i, o) => o === p && WD.ll(i)[0] > 23.6, u);
    if (n) WD.news(s, 'Красная армия вошла в восточные районы Польши: Западная Украина и Западная Белоруссия присоединены к СССР.', [u, p], 2);
  }],
  ['1939-11-30', s => { const u = WD.byId(s, '643'), f = WD.byId(s, '246'); if (u < 0 || f < 0) return; WD.declare(s, u, f, { total: false, winter: true, atkA: 0.25 }); WD.news(s, 'Советско-финская («Зимняя») война: СССР напал на Финляндию.', [u, f], 2, 'war'); }],
  ['1940-03-13', s => {
    const u = WD.byId(s, '643'), f = WD.byId(s, '246'); if (u < 0 || f < 0) return;
    const w = s.world.wars.find(x => (x.a === u && x.b === f) || (x.a === f && x.b === u)); if (!w) return;
    WD.transfer(s, (i, o) => o === f && WD.iso(i) !== 'FI', u);
    WD.transfer(s, (i, o) => o === f && WD.iso(i) === 'FI' && WD.ll(i)[0] > 28.6 && WD.ll(i)[1] < 62.4, u);
    WD.endWar(s, w, 'Московский мирный договор: Финляндия уступила СССР Карельский перешеек.', 2);
  }],
  ['1940-04-09', s => {
    const g = WD.byId(s, '276'), d = WD.byId(s, '208'), n = WD.byId(s, '578'), uk = WD.byId(s, '826'); if (g < 0) return;
    if (d >= 0) { WD.transfer(s, (i, o) => o === d && WD.iso(i) !== 'DK', uk >= 0 ? uk : g); WD.annex(s, d, g, 'Германия за несколько часов оккупировала Данию.'); }
    if (n >= 0) { WD.declare(s, g, n, { total: true }); WD.news(s, 'Германия высадилась в Норвегии.', [g, n], 1, 'war'); }
  }],
  ['1940-05-10', s => {
    const g = WD.byId(s, '276'); if (g < 0) return;
    for (const id of ['528', '056']) { const x = WD.byId(s, id); if (x >= 0) WD.declare(s, g, x, { total: true }); }
    const l = WD.byId(s, '442'); if (l >= 0) WD.annex(s, l, g);
    const f = WD.byId(s, '250'); if (f >= 0 && !WD.atWar(s, g, f)) WD.declare(s, g, f, { total: true });
    WD.news(s, 'Германия начала наступление на Западе: удар по Нидерландам, Бельгии, Люксембургу и Франции.', [g, f], 2, 'war');
  }],
  ['1940-06-10', s => { const i = WD.byId(s, '380'), g = WD.byId(s, '276'); if (i < 0 || g < 0 || !WD.enemies(s, g).length) return; for (const id of ['250', '826']) { const x = WD.byId(s, id); if (x >= 0 && WD.atWar(s, g, x)) WD.declare(s, i, x, { total: true }); } WD.news(s, 'Италия вступила в войну на стороне Германии.', [i], 1, 'war'); }],
  ['1940-06-28', s => {
    const u = WD.byId(s, '643'), r = WD.byId(s, '642'); if (u < 0 || r < 0) return;
    const n = WD.transfer(s, (i, o) => o === r && (WD.iso(i) === 'MD' || WD.iso(i) === 'UA'), u);
    if (n) WD.news(s, 'Румыния под давлением СССР уступила Бессарабию и Северную Буковину.', [u, r], 1);
  }],
  ['1940-08-03', s => {
    const u = WD.byId(s, '643'); if (u < 0) return;
    let names = [];
    for (const id of ['233', '428', '440']) { const x = WD.byId(s, id); if (x >= 0) { names.push(s.world.cs[x].n); WD.annex(s, x, u); } }
    if (names.length) WD.news(s, `${names.join(', ')} включены в состав СССР.`, [u], 2);
  }],
  ['1940-09-27', s => { WD.news(s, 'Германия, Италия и Япония подписали Тройственный пакт.', [], 1); }],
  ['1940-10-28', s => { const i = WD.byId(s, '380'), gr = WD.byId(s, '300'); if (i < 0 || gr < 0) return; WD.declare(s, i, gr, { total: true }); WD.news(s, 'Италия напала на Грецию.', [i, gr], 1, 'war'); }],
  ['1941-04-06', s => { const g = WD.byId(s, '276'); if (g < 0) return; for (const id of ['YUG', '300']) { const x = WD.byId(s, id); if (x >= 0) WD.declare(s, g, x, { total: true }); } WD.news(s, 'Германия вторглась в Югославию и Грецию.', [g], 1, 'war'); }],
  ['1941-06-22', s => {
    const g = WD.byId(s, '276'), u = WD.byId(s, '643'); if (g < 0 || u < 0 || WD.atWar(s, g, u)) return;
    WD.declare(s, g, u, { total: true });
    for (const id of ['642', '246', '348', '380', 'SLO']) { const x = WD.byId(s, id); if (x >= 0 && !WD.atWar(s, x, u)) WD.declare(s, x, u, { total: true }); }
    s.world.cs[u].rel = 0;
    WD.news(s, '22 июня 1941 года, 4 часа утра: Германия без объявления войны напала на Советский Союз. Началась Великая Отечественная война.', [g, u], 3, 'war');
  }],
  ['1941-12-07', s => {
    const j = WD.byId(s, '392'); if (j < 0) return;
    for (const id of ['840', '826', '528']) { const x = WD.byId(s, id); if (x >= 0 && !WD.atWar(s, j, x)) WD.declare(s, j, x, { total: true }); }
    WD.news(s, 'Япония атаковала Пёрл-Харбор. США вступили в войну.', [j, WD.byId(s, '840')], 2, 'war');
  }],
  ['1941-12-11', s => { const us = WD.byId(s, '840'); if (us < 0) return; for (const id of ['276', '380']) { const x = WD.byId(s, id); if (x >= 0 && !WD.atWar(s, x, us)) WD.declare(s, x, us, { total: true }); } WD.news(s, 'Германия и Италия объявили войну США.', [us], 1, 'war'); }],
  ['1945-08-08', s => {
    const u = WD.byId(s, '643'), j = WD.byId(s, '392'), m = WD.byId(s, 'MAN'); if (u < 0 || j < 0 || WD.enemies(s, u).some(x => s.world.cs[x].id === '276')) return;
    WD.declare(s, u, j, { total: true }); if (m >= 0) WD.declare(s, u, m, { total: true });
    WD.news(s, 'СССР объявил войну Японии.', [u, j], 2, 'war');
  }],
];
WD.history = s => {
  const d = new Date(s.date);
  for (const [ds, fn] of WD.H) {
    if (s.world.done[ds]) continue;
    const t = new Date(ds + 'T00:00:00');
    if (d >= t) { s.world.done[ds] = 1; try { fn(s); } catch (e) { console.warn('history', ds, e); } }
  }
};
// Капитуляция Франции перед Германией: север — Германии, юг — режим Виши
WD.vichy = (s, f, g) => {
  const W = s.world; W.done.vichy = 1;
  const south = E.countryProvs(s, f).filter(i => WD.iso(i) !== 'FR' || WD.ll(i)[1] < 46.6 && WD.ll(i)[0] > -1.3);
  const north = E.countryProvs(s, f).filter(i => !south.includes(i));
  WD.moveStats(s, f, g, north.length / Math.max(1, north.length + south.length), 0.7);
  north.forEach(i => { W.own[i] = g; });
  const v = WD.newCountry(s, { id: 'VIC', puppetOf: g, n: 'Режим Виши', col: '#a8b8de', pw: 10, cap: south.find(i => WD.iso(i) === 'FR') || south[0], st: { gov: 'Коллаборационистский режим', lead: 'Филипп Петен', bloc: [] } });
  south.forEach(i => { W.own[i] = v; });
  WD.splitStats(s, f, v, south);
  W.cs[f].dead = true;
  for (const w of W.wars.slice()) if (w.a === f || w.b === f) WD.endWar(s, w);
  WD.news(s, 'Франция капитулировала. Север занят Германией, на юге — коллаборационистский режим Виши.', [f, g, v], 2, 'annex');
};

// ---------- политика игрока-лидера ----------
WD.POLICY = [
  { re: /экономик|инвест|инфраструкт|промышл|индустриал|пятилетк|завод|дорог|строительств/, n: 'Программа развития экономики', fx: c => { c.st.gr += 0.3; c.shock += 2; c.st.debt += 3; } },
  { re: /сниз.*налог|налог.*сниз|отмен.*налог/, n: 'Снижение налогов', fx: c => { c.st.stab += 5; c.st.debt += 4; c.shock += 0.6; } },
  { re: /повыс.*налог|налог.*повыс/, n: 'Повышение налогов', fx: c => { c.st.stab -= 6; c.st.debt -= 4; c.shock -= 0.4; } },
  { re: /пенси|зарплат|социальн|медицин|образован|больниц|школ|пособ/, n: 'Социальная программа', fx: c => { c.st.stab += 6; c.st.debt += 3; c.st.infl += 1; } },
  { re: /арми|оборон|вооруж|военн|танк|флот|авиац/, n: 'Усиление армии', fx: c => { c.st.milp += 1; c.st.army = Math.round(c.st.army * 1.05); c.st.debt += 2; c.st.stab -= 1; } },
  { re: /напечат|эмисси|печатн/, n: 'Печать денег', fx: c => { c.st.infl += 10; c.st.stab -= 4; c.st.debt -= 3; } },
  { re: /коррупц/, n: 'Борьба с коррупцией', fx: c => { c.st.stab += 3; c.shock += 0.5; } },
  { re: /стабилиз|бюджет|экономи|сократ.*расход/, n: 'Жёсткий бюджет', fx: c => { c.st.debt -= 5; c.st.stab -= 3; c.shock -= 0.5; c.st.infl -= 1.5; } },
];
WD.policy = (s, text, ok, crit) => {
  const W = s.world, c = W.cs[W.home], t = E.norm(text);
  const ci = E.findCountry(s, t);
  if (/санкци|эмбарго/.test(t) && ci >= 0 && ci !== W.home) {
    if (ok) { W.cs[ci].shock -= 1.5; c.shock -= 0.3; W.cs[ci].rel -= 25; WD.news(s, `${c.n} ввела санкции против ${W.cs[ci].n}.`, [W.home, ci], 1); }
    return { n: 'Санкции против ' + W.cs[ci].n };
  }
  if (/союз|договор|дружб|сотрудничеств|переговор|торгов/.test(t) && ci >= 0 && ci !== W.home) {
    if (ok) { W.cs[ci].rel = E.clamp(W.cs[ci].rel + (crit ? 30 : 15), -100, 100); c.shock += 0.3; WD.news(s, `${c.n} и ${W.cs[ci].n} подписали договор о сотрудничестве.`, [W.home, ci], 1); }
    return { n: 'Переговоры с ' + W.cs[ci].n };
  }
  const p = WD.POLICY.find(x => x.re.test(t)) || WD.POLICY[0];
  if (ok) { p.fx(c); if (crit) p.fx(c); c.st.stab = E.clamp(c.st.stab, 0, 100); WD.news(s, `${c.n}: ${p.n.toLowerCase()} — указ подписан.`, [W.home], 0); }
  else { c.st.stab -= 2; }
  return { n: p.n };
};
