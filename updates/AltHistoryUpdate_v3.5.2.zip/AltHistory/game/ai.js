// «Судьба» — Нейрочат. Локальная модель (llama.cpp server на этом же ПК, порт 8777).
// Две роли: «толкователь» (фраза → JSON-намерение) и «рассказчик» (итог → живой текст).
'use strict';
const AI = {
  base: location.protocol.startsWith('http') ? '' : 'http://127.0.0.1:8777',
  state: 'wait', // wait | loading | ok | off
  model: '',
  onState: null,
  busy: false,
};

AI.set = st => { if (AI.state !== st) { AI.state = st; if (AI.onState) AI.onState(st); if (st === 'ok' && typeof UI !== 'undefined' && UI.s && !UI.busy) setTimeout(() => AI.warm(UI.s), 500); } };

AI.check = async () => {
  try {
    const r = await fetch(AI.base + '/health', { cache: 'no-store' });
    if (r.status === 503) { AI.set('loading'); return false; }
    if (!r.ok) { AI.set('off'); return false; }
    if (!AI.dev) { try { const d = await (await fetch(AI.base + '/device.json', { cache: 'no-store' })).json(); AI.dev = d; } catch (e) { AI.dev = { mode: '' }; } }
    if (!AI.model) {
      try { const m = await (await fetch(AI.base + '/v1/models')).json(); AI.model = ((m.data && m.data[0] && m.data[0].id) || '').replace(/\.gguf$/i, '').replace(/^.*[\\/]/, ''); } catch (e) { }
    }
    AI.set('ok'); return true;
  } catch (e) { AI.set('off'); return false; }
};
AI.watch = () => { AI.check().finally(() => setTimeout(AI.watch, AI.state === 'ok' ? 15000 : 3000)); };

// ---------- описание персонажа для подсказок ----------
AI.brief = s => {
  const a = E.age(s);
  const parts = [
    `${s.ch.name} ${s.ch.surname}, ${s.ch.sex === 'f' ? 'женщина' : 'мужчина'}, ${E.years(a)}, город ${E.cityName(s)}`,
    'положение: ' + E.position(s) + (s.job ? ` (${E.money(s.job.salary)}/мес)` : ''),
    'деньги: ' + E.money(s.st.money),
    'жильё: ' + E.homeName(s).toLowerCase() + (s.car ? ', машина ' + s.car.n : ''),
    'образование: ' + D.EDU[s.ch.edu],
    `счастье ${Math.round(s.st.happy)}/100, здоровье ${Math.round(s.st.health)}/100, репутация ${Math.round(s.st.rep)}/100`,
  ];
  if (s.biz.length) parts.push('бизнес: ' + s.biz.map(b => b.n).join(', '));
  const p = s.rel.find(r => r.role === 'партнёр' || r.role === 'супруг(а)');
  if (p) parts.push((p.role === 'партнёр' ? 'встречается с ' : 'в браке с ') + p.name);
  if (s.study) parts.push('учится: ' + s.study.n);
  if ((s.kids || []).length) parts.push('дети: ' + s.kids.map(k => k.name + ' (' + Math.max(0, L.kidAge(s, k)) + ')').join(', '));
  if (s.crime && s.crime.gang) parts.push('состоит в банде «' + s.crime.gang + '»');
  const wars = E.homeAtWar(s);
  if (wars.length) parts.push('страна воюет с: ' + wars.map(w => E.countryName(w.a === s.world.home ? w.b : w.a)).join(', '));
  parts.push('страна: ' + E.countryName(s.world.home));
  return parts.join('; ');
};

// ---------- запросы ----------
// Qwen иногда «срывается» на китайский. Грамматика запрещает движку даже выбирать иероглифы, японскую и корейскую азбуку
// (для обычного текста), а фильтр ниже вычищает их, если что-то всё же проскочило (например, в JSON).
AI.RU_GRAMMAR = 'root ::= [^\\u2E80-\\u9FFF\\uAC00-\\uD7AF\\uF900-\\uFAFF\\uFE30-\\uFE4F\\uFF00-\\uFFEF]*';
AI.CJK = /[\u2E80-\u9FFF\uAC00-\uD7AF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF]+/g;
AI.clean = t => String(t || '').replace(AI.CJK, '').replace(/ {2,}/g, ' ').replace(/ ([,.!?;:])/g, '$1');
AI.chat = async (messages, opt = {}) => {
  const body = Object.assign({ messages, temperature: 0.7, top_p: 0.9, max_tokens: 300, stream: false, cache_prompt: true }, opt.body || {});
  if (!body.response_format && !body.grammar && AI.useGrammar !== false) body.grammar = AI.RU_GRAMMAR;
  let r = await fetch(AI.base + '/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: opt.signal });
  if (!r.ok && body.grammar && r.status >= 400 && r.status < 500) { // старый движок не понял грамматику — без неё
    AI.useGrammar = false; delete body.grammar;
    r = await fetch(AI.base + '/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: opt.signal });
  }
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const onTok = opt.onToken; if (onTok) opt = Object.assign({}, opt, { onToken: t => onTok(AI.clean(t)) });
  if (!body.stream) { const j = await r.json(); const c = (j.choices[0].message.content || '').trim(); return body.response_format ? c.replace(AI.CJK, '') : AI.clean(c); }
  const rd = r.body.getReader(), dec = new TextDecoder();
  let buf = '', text = '';
  for (;;) {
    const { done, value } = await rd.read(); if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim(); if (data === '[DONE]') return AI.clean(text);
      try { const j = JSON.parse(data); const d = j.choices && j.choices[0] && j.choices[0].delta && j.choices[0].delta.content; if (d) { text += d; if (opt.onToken) opt.onToken(text); } } catch (e) { }
    }
  }
  return AI.clean(text);
};

// ---------- толкователь ----------
AI.SCHEMA = {
  type: 'object',
  properties: {
    type: { type: 'string', enum: E.ACTIONS.concat(['chat']) },
    target: { type: 'string', maxLength: 60 },
    org: { type: 'string', maxLength: 40 },
    person: { type: 'string', maxLength: 30 },
    amount: { type: 'integer' },
    tier: { type: 'integer', enum: [1, 2, 3, 4, 5] },
    skill: { type: 'string', enum: ['str', 'int', 'cha', 'craft', 'biz', 'none'] },
    difficulty: { type: 'string', enum: ['легко', 'средне', 'сложно', 'почти невозможно'] },
    illegal: { type: 'boolean' },
    stakes: { type: 'object', properties: { money: { type: 'integer' }, happy: { type: 'integer' }, rep: { type: 'integer' }, health: { type: 'integer' } }, required: ['money', 'happy', 'rep', 'health'] },
    summary: { type: 'string', maxLength: 80 },
  },
  required: ['type', 'target', 'org', 'person', 'amount', 'tier', 'skill', 'difficulty', 'illegal', 'stakes', 'summary'],
};

AI.SYS_INTERPRET = `Ты — модуль понимания команд в игре-симуляторе жизни. Игрок пишет, что делает его персонаж. Определи ОДНО главное действие и верни JSON.
Типы действий:
job — устроиться на работу (target — профессия, org — место; tier — уровень работы: 1 неквалифицированная, 2 простая, 3 специалист, 4 высококвалифицированная, 5 топ-менеджер)
quit — уволиться
crime — криминал: кража, ограбление, крышевание, контрабанда, мошенничество, вступить в банду, взятка полиции, залечь на дно, завязать (target — что именно)
policy — государственное решение (только для руководителя страны): реформа, налоги, пенсии, программа развития, санкции, договор с другой страной (target — суть решения)
work — усердно работать, остаться сверхурочно, проявить себя на работе
promote — попросить повышение
study — учиться, поступить, пойти на курсы (target — чему учиться)
rest — отдых, развлечения, хобби, сходить куда-то в своём городе
travel — поездка, путешествие (target — куда)
health — сходить к врачу, заняться спортом, бросить вредную привычку
buy — купить вещь (не жильё и не бизнес), target — что
home — снять или купить жильё, ипотека, переехать к родителям
biz_start — открыть бизнес (target — вид бизнеса, org — название, если есть)
biz_sell — продать бизнес
invest — положить на вклад, купить акции или криптовалюту
withdraw — снять деньги со вклада, продать акции
loan — взять кредит
repay — погасить кредит
social — общение с семьёй, друзьями, коллегами (person — с кем)
date — свидание, знакомство, ухаживание (person — с кем)
marry — сделать предложение, пожениться
elect — выдвинуться на выборы, баллотироваться (target — должность)
war — объявить войну другой стране (target — страна); только если игрок прямо этого хочет
peace — заключить мир (target — страна)
army — укрепить армию, увеличить военный бюджет
move — переехать жить в другой город России (target — город)
chat — вопрос к рассказчику, а не действие («сколько у меня денег?», «что мне делать?»)
other — всё остальное. Для other оцени difficulty и stakes: что персонаж может получить при удаче (положительные числа) — деньги в рублях, счастье, репутацию, здоровье от -10 до 10.
Правила:
- amount — сумма в рублях, если игрок её назвал (2 млн = 2000000, 50к = 50000), иначе 0.
- illegal = true, если действие нарушает закон.
- Нереалистичное («за день стал миллиардером», «полетел на Марс») — type other, difficulty «почти невозможно».
- skill — какой навык главный: str сила, int интеллект, cha харизма, craft ремесло, biz деловая хватка, none.
- summary — что делает персонаж, 3–8 слов, в третьем лице.
- Пустые поля — пустая строка.
- Учитывай эпоху: вещей и профессий, которых в это время не было, не бывает (тогда type other, difficulty «почти невозможно»).
- Фраза может ссылаться на прошлое: «ему», «ей», «туда же», «ещё раз», «как в прошлый раз», «соглашаюсь», «отдаю долг». Пойми по разделу «Последнее, что было» и «Люди», о ком и о чём речь: в person пиши настоящее имя человека, в target — конкретную вещь/место/работу из прошлого.
- «Ещё раз», «снова», «пробую опять» — повтори тип прошлого действия игрока.
- Вопросы о прошлом («что было», «помнишь», «кто такой», «сколько я должен») — type chat.`;

AI.interpret = async (s, text) => {
  const people = AI.people(s);
  const hist = AI.transcript(s, s.chat.length - 1, 600, 120);
  const open = (s.open || []).length ? '\nНезавершённые дела: ' + s.open.join('; ') : '';
  const msgs = [
    { role: 'system', content: AI.SYS_INTERPRET },
    { role: 'user', content: `${AI.era(s)}\nПерсонаж: ${AI.brief(s)}${E.isLeader(s) ? '. Персонаж — глава государства' : ''}.` + (people ? '\nЛюди в жизни персонажа: ' + people : '') + open + (hist ? `\nПоследнее, что было (для понимания отсылок):\n${hist}` : '') + `\nФраза игрока: «${text}»` },
  ];
  const ac = new AbortController(), to = setTimeout(() => ac.abort(), 35000); // слишком долго — разберём фразу без нейросети
  let raw; try { raw = await AI.chat(msgs, { signal: ac.signal, body: { temperature: 0, max_tokens: 200, id_slot: 1, response_format: { type: 'json_schema', json_schema: { name: 'intent', schema: AI.SCHEMA } } } }); } finally { clearTimeout(to); }
  const j = JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1));
  j.raw = text;
  if (j.skill === 'none') j.skill = '';
  if (!E.ACTIONS.includes(j.type) && j.type !== 'chat') j.type = 'other';
  return j;
};

// ---------- рассказчик ----------
AI.era = s => E.ww2(s) ? `Эпоха: ${new Date(s.date).getFullYear()} год, СССР (время Сталина, индустриализации и Второй мировой войны). Деньги — советские рубли того времени.` : `Эпоха: ${new Date(s.date).getFullYear()} год, современная Россия.`;
AI.SYS_NARRATE = s => `Ты — рассказчик в текстовой игре-симуляторе жизни «AltHistory». ${AI.era(s)} Пиши с приметами этого времени, без анахронизмов.
Пиши только на русском языке (никаких китайских иероглифов и других языков), обращайся к игроку на «ты», живо и конкретно, 2–4 предложения, без списков, заголовков и смайликов.
Персонаж — ${s.ch.sex === 'f' ? 'женщина: используй женский род («ты пришла», «ты устала»)' : 'мужчина: используй мужской род («ты пришёл», «ты устал»)'}.
Итог действия уже определён игрой (бросок кубика). Опиши именно этот итог и не меняй его: если «неудача» — у персонажа не получилось.
Не придумывай новых сумм, чисел, наград, должностей и покупок — используй только те, что даны в итоге. Не задавай вопросов игроку и не давай советов.
ПАМЯТЬ. Ниже — память игры: летопись по годам, факты, близкие люди и вся недавняя переписка. Это правда о мире, опирайся на неё:
- помни, что уже случилось, и не противоречь этому (кто где работает, кто кому должен, кто с кем поссорился, что обещано);
- если действие связано с прошлым — людьми, местами, обещаниями, прошлыми удачами и провалами — свяжи с ним и назови людей по именам;
- не повторяй дословно свои прошлые фразы;
- чего нет в памяти — не выдумывай как факт прошлого.`;

// ---------- память ----------
// Длина контекста: лаунчер пишет её в device.json (ctx на все слоты, np — число слотов).
AI.tok = t => Math.ceil((t || '').length / 2.3); // русский текст: ~2,3 символа на токен у Qwen
AI.slot = () => { const d = AI.dev || {}; return Math.floor((d.ctx || 8192) / Math.max(1, d.np || 2)); };
// Сколько контекста реально отдаём рассказчику. Больше — не умнее, а медленнее: ~5 тыс. токенов хватает с запасом,
// а длинная память всё равно приходит через летопись, факты и «вспоминается».
AI.cap = () => Math.min(AI.slot(), 5000);
// Фоновые запросы (сжатие памяти, летопись, прогрев) — отменяются, как только игрок что-то делает
AI.bg = null;
AI.bgSignal = () => { if (!AI.bg || AI.bg.signal.aborted) AI.bg = new AbortController(); return AI.bg.signal; };
AI.stopBg = () => { if (AI.bg) { try { AI.bg.abort(); } catch (e) { } AI.bg = null; } };
AI.cut = (t, n) => { t = String(t || '').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1) + '…' : t; };
AI.people = s => {
  const out = [];
  for (const n of (s.npcs || [])) out.push(`${n.name} (${n.role}${n.alive ? '' : ', умер'})`);
  for (const r of (s.rel || [])) if (!r.npc && !out.some(x => x.startsWith(r.name + ' '))) out.push(`${r.name} (${r.role})`);
  for (const k of (s.kids || [])) out.push(`${k.name} (${k.sex === 'f' ? 'дочь' : 'сын'})`);
  return out.join(', ');
};
// Одна запись переписки → строка
AI.line = (m, aiLen) => {
  if (m.k === 'me') return 'Игрок: «' + m.t + '»';
  if (m.k === 'ai') return m.t ? 'Рассказчик: ' + AI.cut(m.t, aiLen || 600) : '';
  if (m.k === 'out') return 'Итог: ' + (m.impossible ? 'невозможно' : m.ok ? (m.crit ? 'блестящий успех' : 'удача') : 'неудача') + ' — ' + m.title + (m.x ? ' [ситуация: ' + AI.cut(m.x, 220) + ']' : '') + (m.lines && m.lines.length ? ' (' + m.lines.slice(0, 5).join('; ') + ')' : '');
  if (m.k === 'sys') return /^Неделя/.test(m.t) ? '— ' + m.t + ' —' : '';
  if (m.k === 'news') return (m.title || 'В мире') + ': ' + m.items.slice(0, 5).map(x => x.t).join('; ');
  if (m.k === 'month') return 'Итоги месяца (' + m.mon + '): ' + (m.r.net >= 0 ? '+' : '') + E.money(m.r.net) + (m.r.evicted ? '; выселили' : '') + (m.r.bankrupt ? '; банкротство: ' + m.r.bankrupt.join(', ') : '');
  if (m.k === 'mp') return m.sys ? '' : m.chat ? `Игрок ${m.who} пишет в чат комнаты: «${m.t}»` : `Другой игрок, ${m.who}${m.city ? ' (' + m.city + ')' : ''}: ${m.t}${m.x ? ' — ' + AI.cut(m.x, 160) : ''}`;
  if (m.k === 'war') return 'Фронт: ' + m.items.slice(0, 3).map(x => x.t).join('; ');
  return '';
};
// Плоская переписка до индекса end (не включая) — для толкователя и запасных случаев
AI.transcript = (s, end, maxChars, aiLen) => {
  const out = []; let len = 0;
  for (let i = Math.min(end, s.chat.length) - 1; i >= 0; i--) {
    const t = AI.line(s.chat[i], aiLen); if (!t) continue;
    if (len + t.length > maxChars) break;
    out.unshift(t); len += t.length + 1;
  }
  return out.join('\n');
};
// Переписка как настоящий диалог: [{role:'user'|'assistant', content}], свежие ходы — целиком, по бюджету токенов
AI.dialog = (s, end, budget, peek) => {
  const turns = []; let cur = null, between = [];
  const chat = s.chat.slice(0, Math.min(end, s.chat.length));
  for (const m of chat) {
    if (m.k === 'me') { cur = { m0: between.m0 || m, u: between.concat(['Игрок: «' + m.t + '»']), a: [] }; between = []; turns.push(cur); continue; }
    if (m.k === 'ai') { if (!m.t) continue; if (cur && !between.length) cur.a.push(m.t); else turns.push(cur = { m0: between.m0 || m, u: between.length ? between : ['(продолжение)'], a: [m.t] }), between = []; continue; }
    const t = AI.line(m); if (!t) continue;
    if (cur && !cur.a.length && m.k === 'out') cur.u.push(t); else { if (!between.length) between.m0 = m; between.push(t); }
  }
  if (peek) return { msgs: [], tail: between.slice(-14) };
  const full = turns.filter(t => t.a.length).map(t => { const u = t.u.join('\n'), a = t.a.join('\n'); return { m0: t.m0, u, a, c: AI.tok(u) + AI.tok(a) + 8 }; });
  // Начало окна сдвигается рывками, а не по одному ходу: тогда движок переиспользует уже прочитанное (кэш) и отвечает быстрее
  let st = full.findIndex(t => t.m0 === AI._anchor);
  const sum = i => full.slice(i).reduce((x, t) => x + t.c, 0);
  if (st < 0 || sum(st) > budget) { st = full.length; let used = 0; while (st > 0 && used + full[st - 1].c <= budget * 0.6) used += full[--st].c; AI._anchor = full[st] && full[st].m0; }
  const msgs = [];
  for (const t of full.slice(st)) msgs.push({ role: 'user', content: t.u }, { role: 'assistant', content: t.a });
  return { msgs, tail: between.slice(-14) }; // tail — то, что случилось после последнего ответа рассказчика
};
// Поиск по всей памяти: старые записи, где встречаются слова из фразы игрока (имена, места, вещи)
AI.stem = w => w.slice(0, Math.min(6, Math.max(3, w.length - 2))); // грубо отрезаем окончание: Миша/Мише/Мишу → миш
AI.STOP = new Set(['котор', 'чтобы', 'потом', 'сейча', 'очень', 'тольк', 'когда', 'можно', 'хочу', 'буду', 'этого', 'этот', 'свой', 'свою', 'своег', 'снова', 'опять', 'ещё', 'еще', 'пошёл', 'пошел', 'пойду', 'делаю', 'сделать', 'иду', 'меня', 'тебя', 'него', 'неё', 'нему', 'него', 'было', 'была', 'были', 'есть', 'тоже', 'когда', 'теперь', 'вместе', 'просто', 'делает', 'хочет', 'стал', 'стала', 'было', 'надо', 'нужно', 'сказал', 'сказала', 'помнишь', 'расскажи', 'какой', 'какая', 'какие', 'сколько', 'почему', 'зачем', 'неделю', 'неделя', 'месяц'].map(w => AI.stem(w.replace(/ё/g, 'е'))));
AI.stems = t => [...new Set(String(t || '').toLowerCase().replace(/ё/g, 'е').split(/[^a-zа-я0-9]+/).filter(w => w.length >= 4).map(AI.stem).filter(w => !AI.STOP.has(w)))];
AI.recall = (s, query, skipFrom, max) => {
  const q = AI.stems(query); if (!q.length) return [];
  const items = [];
  (s.log || []).forEach(l => { if (String(l.d) >= skipFrom || l.kind === 'sys') return; items.push({ d: l.d, t: E.dateStr(l.d) + ': ' + l.text + (l.said ? ' («' + AI.cut(l.said, 100) + '»)' : '') + (l.x ? ' — ' + AI.cut(l.x, 160) : '') + (l.title && l.title !== l.text ? ' → ' + l.title : '') + (l.ok === false ? ' (не вышло)' : '') + (l.lines && l.lines.length ? ' (' + l.lines.slice(0, 3).join('; ') + ')' : '') + (l.nar ? ' | ' + AI.cut(l.nar, 160) : '') }); });
  (s.npcs || []).forEach(n => n.hist.forEach(h => items.push({ d: '', t: n.name + ': ' + h })));
  (s.facts || []).forEach(f => items.push({ d: f.d, t: f.t }));
  const scored = items.map(x => { const st = AI.stems(x.t); let sc = 0; for (const w of q) if (st.some(z => z.startsWith(w) || w.startsWith(z))) sc += w.length >= 4 ? 1 : 0.7; return Object.assign(x, { sc }); }).filter(x => x.sc >= 1);
  scored.sort((a, b) => b.sc - a.sc || String(b.d).localeCompare(String(a.d)));
  const out = [], seen = new Set();
  for (const x of scored) { if (seen.has(x.t)) continue; seen.add(x.t); out.push(x.t); if (out.length >= (max || 6)) break; }
  return out;
};
// Долгая память: летопись по годам + сжатая история + незавершённые дела + факты + близкие
AI.peopleBlock = s => {
  const npcs = (s.npcs || []).map(n => `- ${n.name}, ${n.role}, ${n.age} лет, ${n.trait}; ${n.alive ? 'жив' + (n.sex === 'f' ? 'а' : '') : 'умер' + (n.sex === 'f' ? 'ла' : '')}; ${n.job}; ${n.married ? 'в браке; ' : ''}${n.kids ? 'детей: ' + n.kids + '; ' : ''}${n.flags && n.flags.debt ? 'должен тебе денег; ' : ''}отношение к тебе ${Math.round(n.att)}/100; общая история: ${n.hist.slice(-8).join('; ')}`);
  const rel = (s.rel || []).filter(r => !r.npc).map(r => `- ${r.name} (${r.role}), отношение ${Math.round(r.att)}/100`);
  const kids = (s.kids || []).map(k => `- ${k.name} (${k.sex === 'f' ? 'дочь' : 'сын'}, ${Math.max(0, L.kidAge(s, k))} лет)`);
  const all = npcs.concat(rel, kids);
  return all.length ? 'Близкие люди сейчас:\n' + all.join('\n') + '\n' : '';
};
AI.memory = (s, budget) => {
  const parts = [];
  if ((s.open || []).length) parts.push('Незавершённые дела, обещания, долги:\n' + s.open.map(x => '- ' + x).join('\n'));
  if (s.summary) parts.push('Недавняя история вкратце: ' + s.summary);
  const facts = (s.facts || []).map(f => '- ' + f.t);
  const chron = (s.chron || []).map(c => `${c.y}: ${c.t}`);
  // самое ценное — в первую очередь; старое режем, если не влезает
  let used = AI.tok(parts.join('\n'));
  const take = (arr, cap) => { const out = []; for (let i = arr.length - 1; i >= 0; i--) { const c = AI.tok(arr[i]) + 2; if (used + c > cap) break; out.unshift(arr[i]); used += c; } return out; };
  const f = take(facts, budget * 0.75), ch = take(chron, budget);
  const head = [];
  if (ch.length) head.push('Летопись жизни по годам:\n' + ch.join('\n'));
  if (f.length) head.push('Важные факты:\n' + f.join('\n'));
  return head.concat(parts).join('\n\n');
};

AI.context = s => { // короткая версия — для недели и запасных вызовов
  const news = s.world.news.slice(-3).map(n => '- ' + n.t).join('\n');
  return `Персонаж сейчас: ${AI.brief(s)}.\nСегодня: ${E.dateStr(s.date)}.\n` + (news ? `Новости мира:\n${news}\n` : '');
};

// Сборка запроса рассказчику: правила + память (стабильная часть сверху — её кэширует движок) + диалог + текущее
AI.build = (s, endIdx, finalText, query, maxOut) => {
  const total = AI.cap() - maxOut - 150;
  const sys = AI.SYS_NARRATE(s), ppl = AI.peopleBlock(s), ctx = AI.context(s);
  let rest = total - AI.tok(sys) - AI.tok(finalText) - AI.tok(ctx) - AI.tok(ppl) - 60;
  // Память «замораживаем» вместе с началом окна диалога: пока окно не сдвинулось, начало запроса не меняется
  // и движок берёт его из кэша — читает только новое. Свежие факты идут в конец запроса.
  const snapMem = () => { AI._snap = { s, anchor: AI._anchor, mem: AI.memory(s, Math.max(250, rest * 0.35)), nf: (s.facts || []).length, sum: s.summary || '', open: (s.open || []).join('|'), sys }; };
  if (!AI._snap || AI._snap.s !== s || AI._snap.sys !== sys) snapMem();
  let mem = AI._snap.mem;
  const rec = AI.recall(s, query, new Date(Date.parse(s.date) - 14 * 864e5).toISOString(), 5).map(x => AI.cut(x, 240));
  let recTxt = rec.length ? 'Вспоминается из прошлого (связано с тем, что сейчас):\n' + rec.map(x => '- ' + x).join('\n') + '\n' : '';
  const dlg0 = AI.dialog(s, endIdx, 0, true); // только чтобы узнать хвост
  const tail = dlg0.tail.length ? 'С прошлого ответа произошло:\n' + dlg0.tail.join('\n') + '\n' : '';
  const fresh = () => {
    const S = AI._snap, out = [];
    const nf = (s.facts || []).slice(S.nf).map(f => '- ' + f.t); if (nf.length) out.push('Новые факты:\n' + nf.slice(-8).join('\n'));
    if ((s.summary || '') !== S.sum && s.summary) out.push('Недавняя история вкратце (обновлено): ' + s.summary);
    if ((s.open || []).join('|') !== S.open && (s.open || []).length) out.push('Незавершённые дела (обновлено):\n' + s.open.map(x => '- ' + x).join('\n'));
    return out.length ? out.join('\n') + '\n' : '';
  };
  let upd = fresh();
  const left = () => Math.max(150, rest - AI.tok(mem) - AI.tok(recTxt) - AI.tok(tail) - AI.tok(upd));
  let dlg = AI.dialog(s, endIdx, left());
  if (AI._anchor !== AI._snap.anchor) { snapMem(); mem = AI._snap.mem; upd = fresh(); dlg = AI.dialog(s, endIdx, left()); AI._snap.anchor = AI._anchor; }
  return [{ role: 'system', content: sys + '\n\n=== ПАМЯТЬ ИГРЫ ===\n' + mem }].concat(dlg.msgs, [{ role: 'user', content: upd + recTxt + tail + ppl + ctx + '\n' + finalText }]);
};

AI.narrate = (s, text, out, onToken) => {
  let res;
  if (out.chat) res = 'Игрок спрашивает рассказчика: «' + text + '». Ответь по делу, опираясь на память игры (летопись, факты, близких, переписку), 1–4 предложения. Если в памяти этого нет — честно скажи, что не помнишь.';
  else {
    const verdict = out.impossible ? 'НЕВОЗМОЖНО (игра не позволила)' : (out.ok ? (out.crit ? 'БЛЕСТЯЩИЙ УСПЕХ' : 'УСПЕХ') : (out.roll && out.roll.fail ? 'ПРОВАЛ' : 'НЕУДАЧА'));
    res = `Игрок пишет: «${text}»\nИтог: ${verdict} — ${out.title}.` + (out.lines && out.lines.length ? '\nПодробности: ' + out.lines.join('; ') + '.' : '') + (out.caught ? '\nПерсонажа поймали на нарушении закона.' : '') + '\nОпиши, что произошло, с учётом всего, что было раньше.';
  }
  // текущий ход уже лежит в чате (сообщение игрока, итог, пустой ответ) — в историю берём всё до сообщения игрока
  let end = s.chat.length; for (let i = s.chat.length - 1; i >= 0; i--) if (s.chat[i].k === 'me') { end = i; break; }
  const msgs = AI.build(s, end, res, text + ' ' + (out.title || '') + ' ' + (out.person || ''), 300);
  const ac = new AbortController(), to = setTimeout(() => ac.abort(), 150000);
  return AI.chat(msgs, { signal: ac.signal, body: { stream: true, temperature: 0.7, max_tokens: 260, repeat_penalty: 1.08, id_slot: 0 }, onToken }).finally(() => clearTimeout(to));
};

AI.narrateWeek = (s, items, onToken) => {
  const res = 'Прошла неделя. Главное:\n' + items.map(x => '- ' + x).join('\n') + '\nКоротко (2–3 предложения) опиши эту неделю как рассказчик, связав с тем, что было раньше.';
  const msgs = AI.build(s, s.chat.length - 1, res, items.join(' '), 220);
  return AI.chat(msgs, { body: { stream: true, temperature: 0.7, max_tokens: 200, id_slot: 0 }, onToken });
};

// ---------- память: сжатие истории ----------
AI.SUM_SCHEMA = { type: 'object', properties: { story: { type: 'string', maxLength: 1400 }, open: { type: 'array', maxItems: 8, items: { type: 'string', maxLength: 120 } } }, required: ['story', 'open'] };
AI.logLine = l => '- ' + E.dateStr(l.d) + ': ' + l.text + (l.said ? ' (игрок: «' + AI.cut(l.said, 120) + '»)' : '') + (l.x ? ' — ' + AI.cut(l.x, 140) : '') + (l.title && l.title !== l.text ? ' → ' + l.title : '') + (l.ok === false ? ' (не вышло)' : '') + (l.lines && l.lines.length ? ' (' + l.lines.slice(0, 4).join('; ') + ')' : '') + (l.nar ? ' | ' + AI.cut(l.nar, 200) : '');
// Упаковать записи журнала в лимит символов: если не влезает — сначала выкидываем мелочи (быт), потом укорачиваем
AI.pack = (logs, maxChars) => {
  logs = logs.filter(l => l.kind !== 'sys');
  let lines = logs.map(AI.logLine);
  if (lines.join('\n').length > maxChars) lines = logs.filter(l => l.kind !== 'life').map(AI.logLine);
  if (lines.join('\n').length > maxChars) lines = logs.filter(l => l.kind !== 'life').map(l => AI.cut(AI.logLine(l), 150));
  let t = lines.join('\n');
  if (t.length > maxChars) t = '…\n' + t.slice(t.length - maxChars);
  return t;
};
AI.summarize = async s => {
  const fresh = AI.pack(s.log.slice(s.sumAt), 4200);
  if (!fresh) return;
  const msgs = [
    { role: 'system', content: 'Ты ведёшь память персонажа игры. Верни JSON.\nstory — сжатая недавняя история: старое резюме + новые события, 6–10 коротких предложений на русском. Сохраняй имена, места, работу, суммы долгов, важные решения, удачи и провалы, чем закончились события.\nopen — список незавершённого (до 8 пунктов): обещания, долги (кто кому сколько), начатые дела, ссоры, планы, ожидания ответа. Закрытые пункты из старого списка убирай, актуальные оставляй.' },
    { role: 'user', content: `Персонаж: ${AI.brief(s)}.\nСтарое резюме: ${s.summary || '(нет)'}\nСтарый список незавершённого: ${(s.open || []).join('; ') || '(пусто)'}\nНовые события:\n${fresh}` },
  ];
  const raw = await AI.chat(msgs, { signal: AI.bgSignal(), body: { temperature: 0.2, max_tokens: 520, id_slot: 1, response_format: { type: 'json_schema', json_schema: { name: 'mem', schema: AI.SUM_SCHEMA } } } });
  const j = JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1));
  if (j.story && j.story.length > 40) { s.summary = j.story.slice(0, 1600); s.open = (j.open || []).filter(Boolean).slice(0, 8); s.sumAt = s.log.length; }
};
// Летопись года: когда год закончился, его события сжимаются в 4–6 предложений и хранятся всегда
AI.chronicle = async (s, year) => {
  s.chron = s.chron || [];
  if (s.chron.some(c => c.y === year)) return;
  const ev = s.log.filter(l => new Date(l.d).getFullYear() === year && l.kind !== 'sys');
  if (!ev.length) return;
  const txt = AI.pack(ev, 5000);
  const msgs = [
    { role: 'system', content: 'Ты летописец жизни персонажа игры. Сожми события года в 4–6 коротких предложений на русском: работа, деньги, жильё, семья и друзья (по именам), важные удачи и провалы, что изменилось к концу года. Только текст.' },
    { role: 'user', content: `Персонаж: ${s.ch.name} ${s.ch.surname}. Год: ${year}.\nСобытия:\n${txt}` },
  ];
  const t = (await AI.chat(msgs, { signal: AI.bgSignal(), body: { temperature: 0.2, max_tokens: 360, id_slot: 1 } })).trim();
  if (t.length > 30 && !s.chron.some(c => c.y === year)) { s.chron.push({ y: year, t: t.slice(0, 900) }); s.chron.sort((a, b) => a.y - b.y); }
};

// ---------- запасной рассказчик (без нейросети) ----------
AI.template = (s, text, out) => {
  const f = s.ch.sex === 'f';
  if (out.chat) return `${E.position(s)}, ${E.years(E.age(s))}. На счету ${E.money(s.st.money)}, доход около ${E.money(E.monthlyIncome(s))} в месяц, расходы — ${E.money(E.monthlyCost(s))}.`;
  if (out.impossible) return E.pick(['Не выйдет: ', 'Пока это невозможно. ', 'Увы: ']) + (out.lines[0] || out.title).replace(/\.$/, '') + '.';
  const okP = [f ? 'Ты собралась с духом — и всё получилось.' : 'Ты собрался с духом — и всё получилось.', 'Неделя началась удачно.', 'Удача сегодня на твоей стороне.', 'Всё прошло лучше, чем ты ожидал' + (f ? 'а.' : '.')];
  const badP = ['Не задалось.', 'Сегодня явно не твой день.', 'Как ни старайся — не вышло.', 'Обидно, но так бывает.'];
  return (out.ok ? E.pick(okP) : E.pick(badP)) + ' ' + out.title + '.';
};

// ---------- прогрев: заранее «читаем» правила, память и переписку, чтобы первый ответ был быстрым ----------
AI.warm = s => {
  if (AI.state !== 'ok' || !s || s.over) return;
  try {
    const sig = AI.bgSignal();
    const msgs = AI.build(s, s.chat.length, 'Прогрев памяти. Ответь одним словом: «готов».', '', 4);
    AI.chat(msgs, { signal: sig, body: { max_tokens: 1, temperature: 0, id_slot: 0 } }).catch(() => { });
    AI.chat([{ role: 'system', content: AI.SYS_INTERPRET }, { role: 'user', content: 'Фраза игрока: «прогрев»' }], { signal: sig, body: { max_tokens: 1, temperature: 0, id_slot: 1 } }).catch(() => { });
  } catch (e) { }
};
