// «Судьба» v3 — бизнес: отрасли, сотрудники и зарплаты, уровни здания, филиалы, покупка объектов,
// заводы (потребительская и военная продукция), лицензии и контракты с государствами.
'use strict';
const B = {};
B.IND = s => D.IND[E.EV(s)];
B.ind = (s, id) => B.IND(s).find(x => x.id === id) || B.IND(s)[0];
B.money = (s, v) => Math.round(v * E.cpi(s) * (E.ww2(s) ? 1 : Math.pow(E.city(s).cost, 0.6)));
B.mkt = (s, role) => { // рыночная зарплата должности
  if (!E.ww2(s) && B.RSAL[role]) return E.salary(s, B.RSAL[role]);
  const ws = E.norm(role).split(/[\s-]+/), GEN = /^(начальн|старш|главн|помощн|младш|ведущ|мастер|зам|оператор)/; const stem = (ws.find(w => !GEN.test(w) && w.length > 3) || ws[0]).slice(0, 5);
  const j = D.JOBS.find(x => (x.ladder.concat([x.n])).some(t => E.norm(t).split(/[\s-]+/).some(w => w.startsWith(stem))));
  const base = j ? j.sal : (E.ww2(s) ? 36000 : 50000);
  return E.salary(s, base * (/Начальник|Инженер|Технолог|Менеджер|Юрист|Аналитик|Прораб|Мастер цеха|Управляющ|Конструктор/.test(role) ? 1.4 : /Уборщ|Помощник|Подсоб|Подручн|Подмастерь|Грузчик/.test(role) ? 0.75 : 1));
};
B.RSAL = { 'Продавец': 50000, 'Кассир': 45000, 'Кладовщик': 55000, 'Повар': 60000, 'Официант': 45000, 'Бариста': 45000, 'Уборщица': 35000, 'Мастер': 65000, 'Администратор': 55000, 'Помощник': 40000, 'Разработчик': 120000, 'Дизайнер': 90000, 'Тестировщик': 80000, 'Менеджер проектов': 110000, 'Рабочий': 60000, 'Прораб': 110000, 'Сметчик': 80000, 'Электрик': 75000, 'Водитель': 75000, 'Диспетчер': 55000, 'Грузчик': 50000, 'Механик': 70000, 'Агроном': 70000, 'Тракторист': 65000, 'Работник фермы': 45000, 'Ветеринар': 60000, 'Мастер цеха': 95000, 'Технолог': 90000, 'Сварщик': 85000, 'Инженер': 95000, 'Начальник смены': 90000, 'Инженер-конструктор': 110000, 'Контролёр ОТК': 60000, 'Начальник цеха': 130000, 'Кредитный специалист': 70000, 'Аналитик': 100000, 'Юрист': 110000, 'Операционист': 50000 };
B.FN = { m: ['Алексей', 'Дмитрий', 'Сергей', 'Иван', 'Олег', 'Павел', 'Игорь', 'Роман', 'Тимур', 'Артур', 'Максим', 'Виктор', 'Руслан', 'Никита'], f: ['Анна', 'Ольга', 'Елена', 'Мария', 'Наталья', 'Ирина', 'Светлана', 'Юлия', 'Дарья', 'Карина', 'Татьяна', 'Алина'] };
B.SN = ['Иванов', 'Смирнов', 'Кузнецов', 'Попов', 'Соколов', 'Лебедев', 'Козлов', 'Новиков', 'Морозов', 'Волков', 'Зайцев', 'Павлов', 'Семёнов', 'Голубев', 'Виноградов', 'Богданов', 'Воробьёв', 'Фёдоров', 'Михайлов', 'Беляев'];
B.person = (s, role, r) => {
  r = r || Math.random;
  const sex = r() < 0.5 ? 'm' : 'f', sn = B.SN[Math.floor(r() * B.SN.length)];
  const sk = Math.round(20 + r() * 75);
  const mkt = B.mkt(s, role);
  return { n: B.FN[sex][Math.floor(r() * B.FN[sex].length)] + ' ' + (sex === 'f' ? sn.replace(/(ов|ев|ёв|ин)$/, '$1а') : sn), role, sk, sal: Math.round(mkt * (0.78 + sk / 160) / (E.ww2(s) ? 1 : 500)) * (E.ww2(s) ? 1 : 500), mor: 65, m: 0 };
};
B.need = b => Math.max(1, Math.round(b.staffPer * b.level * b.branches));
B.cap = (s, b) => {
  const I = B.ind(s, b.ind);
  const boost = (b.assets || []).reduce((a, id) => { const x = D.ASSETS[E.EV(s)].find(z => z.id === id); return a + (x && x.boost || 0); }, 0);
  const big = Math.max(1, E.citySal(s) / (E.ww2(s) ? 1 : Math.pow(E.city(s).cost, 0.6))); // в большом городе больше клиентов — иначе зарплаты съедают всё
  return B.money(s, I.rev) * big * Math.pow(b.level, 0.92) * b.branches * (1 + boost) * (E.ww2(s) ? 0.88 : 1);
};
B.prod = (s, b) => {
  const need = B.need(b);
  const extra = (b.assets || []).reduce((a, id) => { const x = D.ASSETS[E.EV(s)].find(z => z.id === id); return a + (x && x.prod || 0); }, 0);
  const work = b.staff.reduce((a, p) => a + (0.7 + p.sk / 200) * (0.7 + p.mor / 250), 0);
  // вы сами тоже работаете — но если вы ещё и на работе или бизнесов несколько, вас на всё не хватает
  const busy = (s.job ? 0.55 : 1) / Math.max(1, Math.sqrt((s.biz || []).length));
  const owner = (0.65 + E.sk(s, 'biz') / 250) * busy;
  return Math.min(1.25, (work + owner) / (need + 1) + extra);
};
// Создание
B.create = (s, indId, name, product) => {
  const I = B.ind(s, indId);
  if (I.req) for (const k in I.req) if (E.sk(s, k) < I.req[k]) return { ok: false, impossible: true, title: 'Не хватает опыта', lines: [D.SKILLS[k] + ': нужно ' + I.req[k] + ', у вас ' + E.sk(s, k) + '.'] };
  if (E.age(s) < 18) return { ok: false, impossible: true, title: 'Бизнес — с 18 лет', lines: [] };
  const cost = B.money(s, I.start);
  if (s.st.money < cost) return { ok: false, impossible: true, title: 'Не хватает стартового капитала', lines: [I.n + ': нужно ' + E.money(cost) + ', у вас ' + E.money(s.st.money) + '.'] };
  const r = E.roll(s, E.chance(s, 62, 'biz', 0));
  s.st.money -= cost;
  const b = { v3: 1, id: 'b' + Date.now().toString(36), n: (name || I.ex).slice(0, 40), ind: I.id, type: I.n, level: 1, branches: 1, staffPer: I.staff, staff: [], price: 1, mkt: 0, health: r.ok ? 60 : 42, q: r.crit ? 1.25 : r.ok ? 1 : 0.8, months: 0, value: Math.round(cost * 0.75), lastProfit: 0, lastRev: 0, lastCost: 0, hist: [], assets: [], lic: {}, contracts: [], product: product || (I.factory ? D.PRODUCTS.consumer[0] : ''), line: 'consumer', illegal: !!I.illegal, city: s.ch.city };
  // стартовая команда
  const rr = L.rng(L.hash(b.id));
  for (let k = 0; k < Math.max(1, I.staff - 1); k++) b.staff.push(B.person(s, I.roles[k % I.roles.length], rr));
  s.biz.push(b);
  if (I.illegal) s.flags.illegalBiz = true;
  E.fact(s, `${E.monthStr(s.date)}: открыл ${I.n.toLowerCase()} «${b.n}», вложил ${E.money(cost)}.`);
  return { ok: r.ok, roll: r, title: (r.ok ? 'Открыли: ' : 'Открылись с трудом: ') + b.n, lines: [I.n, 'Вложено: ' + E.money(cost), 'Нанято сотрудников: ' + b.staff.length + ' из ' + B.need(b), 'Управление — кнопка «Бизнес» сверху.'], fx: { happy: 8, stress: 12, biz: 2 } };
};
// Миграция бизнесов из v2
B.migrate = s => {
  s.biz = (s.biz || []).map(b => {
    if (b.v3) return b;
    const I = B.IND(s).find(x => E.norm(x.n + ' ' + x.kw.join(' ')).includes(E.norm(b.type || '').slice(0, 5))) || B.IND(s)[0];
    const nb = { v3: 1, id: 'b' + Math.random().toString(36).slice(2, 8), n: b.n, ind: I.id, type: I.n, level: 1, branches: 1, staffPer: I.staff, staff: [], price: 1, mkt: 0, health: b.health || 55, q: b.q || 1, months: b.months || 0, value: b.value || 0, lastProfit: b.lastProfit || 0, lastRev: 0, lastCost: 0, hist: [], assets: [], lic: {}, contracts: [], product: '', line: 'consumer', illegal: !!b.illegal, city: s.ch.city };
    for (let k = 0; k < I.staff; k++) nb.staff.push(B.person(s, I.roles[k % I.roles.length]));
    return nb;
  });
};

// ---------- месяц ----------
B.month = (s, r) => {
  const H = s.world.cs[s.world.home];
  const gh = H.h.gdp, g = gh.length > 1 ? gh[gh.length - 1] / gh[gh.length - 2] - 1 : 0;
  const econ = E.clamp(1 + g * 8 + (H.st.stab - 60) / 300 - (H.st.unemp - 6) / 100, 0.6, 1.3);
  for (const b of s.biz) {
    const I = B.ind(s, b.ind);
    b.months++;
    const cap = B.cap(s, b), prod = B.prod(s, b);
    const priceEff = Math.pow(b.price, -1.35);
    const mktEff = 1 + Math.min(0.35, Math.sqrt(b.mkt / Math.max(1, cap * 0.04)) * 0.18);
    // клиентская база: новый бизнес никто не знает — растёт от рекламы, качества и умения вести дела
    if (b.base == null) b.base = b.months > 6 ? 1 : 0.45;
    b.base = E.clamp(b.base + 0.045 + Math.min(0.06, b.mkt / Math.max(1, cap * 0.05) * 0.04) + (b.q - 1) * 0.05 + (E.sk(s, 'biz') - 40) / 2000 - (b.price > 1.15 ? 0.03 : 0), 0.3, 1);
    const season = 1 + 0.08 * Math.sin((new Date(s.date).getMonth() - 2) / 12 * Math.PI * 2) * (['food', 'agro', 'service', 'shoe', 'fish'].includes(I.id) ? 1.6 : 0.6);
    const demand = econ * priceEff * (0.6 + b.health / 250) * mktEff * b.q * b.base * season * (typeof Y18 !== 'undefined' ? Y18.demand(s, I) : 1) * (s.world.cityBoost && s.world.cityBoost[s.ch.city] && s.date < s.world.cityBoost[s.ch.city] ? 1.05 : 1) * E.rnd(0.85, 1.15);
    let rev = cap * Math.min(prod, demand) * b.price;
    // военные контракты
    let crev = 0;
    for (const c of b.contracts) {
      if (c.left <= 0) continue;
      const pay = Math.round(c.monthly * Math.min(1, prod / 0.8));
      crev += pay; c.left--; c.got = (c.got || 0) + pay;
      const buyer = s.world.cs[c.ci]; if (buyer && !buyer.dead) buyer.st.milp += 0.02;
    }
    b.contracts = b.contracts.filter(c => c.left > 0);
    if (I.lic && !b.lic[I.lic]) rev *= I.lic === 'fin' ? 0.1 : (b.line === 'military' ? 0 : 0.45);
    rev += crev;
    const sal = b.staff.reduce((a, p) => a + p.sal, 0);
    const mat = rev * I.mat * (b.line === 'military' ? 1.05 : 1) * (typeof Y18 !== 'undefined' ? Y18.mat(s) : 1);
    const rent = B.money(s, I.rent) * b.level * b.branches * (b.owned ? 0.25 : 1);
    // коммуналка, бухгалтерия, касса, связь, охрана — растут с размером
    const over = B.money(s, I.rent) * 0.3 * Math.pow(b.level, 0.9) * b.branches + sal * 0.05;
    // неприятности месяца: поломки, недостачи, штрафы, возвраты (реже при высоком навыке)
    let inc = 0, incT = '';
    if (Math.random() < 0.18 - E.sk(s, 'biz') / 700) { const IN = E.ww2(s) ? ['сломался инструмент', 'недостача', 'штраф от фининспектора', 'испорчено сырьё'] : ['сломалось оборудование', 'недостача на складе', 'штраф от проверки', 'возвраты и брак', 'протечка и ремонт', 'клиент отсудил компенсацию']; incT = IN[Math.floor(Math.random() * IN.length)]; inc = Math.round(rev * E.rnd(0.02, 0.07)); r.bizInc = (r.bizInc || []).concat('«' + b.n + '»: ' + incT + ' (−' + E.money(inc) + ')'); }
    const pre = rev - sal - mat - rent - b.mkt - over - inc;
    const tb = s.world.taxBreak && s.world.taxBreak[s.world.home] && s.date < s.world.taxBreak[s.world.home] ? 0.5 : 1;
    const tax = (Math.max(0, pre) * (E.ww2(s) ? 0.1 : 0.15) + (E.ww2(s) ? 0 : rev * 0.01)) * tb;
    const profit = Math.round(pre - tax);
    b.lastRev = Math.round(rev); b.lastCost = Math.round(sal + mat + rent + b.mkt + tax + over + inc); b.lastProfit = profit; b.lastProd = prod; b.lastDemand = demand;
    b.cost = { sal, mat: Math.round(mat), rent: Math.round(rent), mkt: b.mkt, tax: Math.round(tax), contracts: crev, over: Math.round(over), inc, incT };
    b.hist.push(profit); if (b.hist.length > 24) b.hist.shift();
    r.inc.push(['Бизнес «' + b.n + '»', profit]);
    // сотрудники: мораль от зарплаты, нагрузки
    const ovl = B.need(b) / Math.max(1, b.staff.length);
    for (const p of b.staff) {
      const m = B.mkt(s, p.role);
      p.mor = E.clamp(p.mor + (p.sal / m - 1) * 25 - (ovl > 1.3 ? 6 : 0) + (profit > 0 ? 1 : -2) + E.rnd(-3, 3), 0, 100);
      p.m++; if (p.m % 6 === 0) p.sk = Math.min(100, p.sk + 2);
    }
    const quit = b.staff.filter(p => p.mor < 22 && Math.random() < 0.45);
    if (quit.length) { b.staff = b.staff.filter(p => !quit.includes(p)); r.quit = (r.quit || []).concat(quit.map(p => p.n + ' уволился из «' + b.n + '» (мало платите)')); }
    // репутация бизнеса
    b.health = E.clamp(b.health + (prod >= demand ? 1 : -2) + (b.price > 1.2 ? -1.5 : b.price < 0.9 ? 1 : 0) + (E.sk(s, 'biz') - 40) / 30 + E.rnd(-2, 2) - I.risk * 3 * Math.random(), 0, 100);
    b.value = Math.max(0, Math.round(b.value * 0.995 + Math.max(0, profit) * 1.2 + (b.level - 1) * 0));
    if (b.illegal && Math.random() < 0.08 * E.dif(s).bad) { b.health = 0; r.raid = b.n; }
  }
  const dead = s.biz.filter(b => b.health <= 3 || (b.hist.length >= 6 && b.hist.slice(-6).every(p => p < 0) && s.st.money < 0));
  for (const b of dead) { E.fact(s, `${E.monthStr(s.date)}: бизнес «${b.n}» закрылся.`); r.bankrupt = (r.bankrupt || []).concat(b.n); }
  s.biz = s.biz.filter(b => !dead.includes(b));
};

// ---------- управление ----------
B.get = (s, id) => s.biz.find(b => b.id === id);
B.candidates = (s, b) => {
  const I = B.ind(s, b.ind), rr = L.rng(L.hash(b.id, s.turn));
  return I.roles.flatMap(role => [B.person(s, role, rr), B.person(s, role, rr)]);
};
B.hire = (s, id, cand) => {
  const b = B.get(s, id); if (!b) return null;
  if (b.staff.length >= B.need(b) * 1.5) return { ok: false, title: 'Мест больше нет', lines: ['Расширьте бизнес, чтобы нанять больше людей.'] };
  b.staff.push(Object.assign({}, cand, { mor: 70, m: 0 }));
  return { ok: true, title: 'Нанят: ' + cand.n, lines: [cand.role + ', ' + E.money(cand.sal) + '/мес'] };
};
B.fire = (s, id, idx) => { const b = B.get(s, id); const p = b && b.staff[idx]; if (!p) return null; b.staff.splice(idx, 1); for (const q of b.staff) q.mor = Math.max(0, q.mor - 4); return { ok: true, title: 'Уволен: ' + p.n, lines: ['Остальные напряглись (мораль −4).'] }; };
B.setSal = (s, id, idx, mult) => { const b = B.get(s, id); const p = b && b.staff[idx]; if (!p) return; const old = p.sal; p.sal = Math.max(1, Math.round(p.sal * mult / (E.ww2(s) ? 1 : 100)) * (E.ww2(s) ? 1 : 100)); p.mor = E.clamp(p.mor + (p.sal > old ? 8 : -12), 0, 100); };
B.upCost = (s, b) => Math.round(B.money(s, B.ind(s, b.ind).start) * 0.55 * Math.pow(b.level, 1.45));
B.upgrade = (s, id) => {
  const b = B.get(s, id); if (!b) return null;
  if (b.level >= 10) return { ok: false, title: 'Максимальный уровень' };
  const c = B.upCost(s, b);
  if (s.st.money < c) return { ok: false, title: 'Не хватает денег', lines: ['Расширение до уровня ' + (b.level + 1) + ': ' + E.money(c)] };
  s.st.money -= c; b.level++; b.value += Math.round(c * 0.7);
  return { ok: true, title: '«' + b.n + '» — уровень ' + b.level, lines: ['Мощность выросла. Нужно людей: ' + B.need(b), 'Потрачено: ' + E.money(c)] };
};
B.branchCost = (s, b) => Math.round(B.money(s, B.ind(s, b.ind).start) * 0.8 * Math.pow(b.level, 0.8));
B.branch = (s, id) => {
  const b = B.get(s, id); if (!b) return null;
  const c = B.branchCost(s, b);
  if (s.st.money < c) return { ok: false, title: 'Не хватает денег', lines: ['Новая точка: ' + E.money(c)] };
  s.st.money -= c; b.branches++; b.value += Math.round(c * 0.7);
  return { ok: true, title: 'Открыт ' + b.branches + '-й объект', lines: ['Потрачено: ' + E.money(c), 'Нужно людей: ' + B.need(b)] };
};
B.buyOwn = (s, id) => { // выкупить помещение — аренда падает в 4 раза
  const b = B.get(s, id); if (!b || b.owned) return null;
  const c = Math.round(B.money(s, B.ind(s, b.ind).rent) * b.level * b.branches * 60);
  if (s.st.money < c) return { ok: false, title: 'Не хватает денег', lines: ['Выкуп помещений: ' + E.money(c)] };
  s.st.money -= c; b.owned = true; b.value += c;
  return { ok: true, title: 'Помещения выкуплены', lines: ['Аренда сократилась в 4 раза. Потрачено ' + E.money(c)] };
};
B.assetCost = (s, b, a) => Math.round(B.money(s, B.ind(s, b.ind).start) * a.cost * Math.pow(b.level, 0.6));
B.buyAsset = (s, id, aid) => {
  const b = B.get(s, id), a = D.ASSETS[E.EV(s)].find(x => x.id === aid); if (!b || !a) return null;
  if ((b.assets || []).includes(aid) && !a.br) return { ok: false, title: 'Уже куплено' };
  const c = B.assetCost(s, b, a);
  if (s.st.money < c) return { ok: false, title: 'Не хватает денег', lines: [a.n + ': ' + E.money(c)] };
  s.st.money -= c; if (!a.br || a.boost) (b.assets = b.assets || []).push(aid); if (a.br) b.health = E.clamp(b.health + a.br, 0, 100);
  b.value += Math.round(c * 0.5);
  return { ok: true, title: 'Куплено: ' + a.n, lines: ['Потрачено: ' + E.money(c)] };
};
B.sell = (s, id) => {
  const b = B.get(s, id); if (!b) return null;
  const v = Math.round(b.value * (0.75 + b.health / 300));
  s.biz.splice(s.biz.indexOf(b), 1); s.st.money += v;
  E.fact(s, `${E.monthStr(s.date)}: продал бизнес «${b.n}» за ${E.money(v)}.`);
  return { ok: true, title: 'Продан «' + b.n + '»', lines: ['Выручка: ' + E.money(v)] };
};

// ---------- лицензии и оружейные контракты ----------
B.licCost = (s, kind) => Math.round(E.m(s, kind === 'mil' ? 5000000 : 20000000));
B.license = (s, id, kind, bribe) => {
  const b = B.get(s, id); if (!b) return null;
  if (b.lic[kind]) return { ok: false, title: 'Лицензия уже есть' };
  if (b.lic[kind + 'Wait']) return { ok: false, title: 'Заявка на рассмотрении', lines: ['Решение придёт через ' + Math.max(1, b.lic[kind + 'Wait'] - s.turn) + ' нед.'] };
  const c = B.licCost(s, kind) * (bribe ? 2 : 1);
  if (s.st.money < c) return { ok: false, title: 'Не хватает денег', lines: ['Госпошлина и проверки: ' + E.money(c)] };
  s.st.money -= c;
  b.lic[kind + 'Wait'] = s.turn + (bribe ? 2 : 6); b.lic[kind + 'Bribe'] = !!bribe;
  if (bribe) { L.crimeInit(s); s.crime.heat = E.clamp(s.crime.heat + 10, 0, 100); }
  return { ok: true, title: 'Заявка подана', lines: ['Ждите ответа ' + (bribe ? '2 недели (с «ускорением»)' : '6 недель') + '.', 'Потрачено: ' + E.money(c)] };
};
B.licWeek = s => {
  const out = [];
  for (const b of s.biz) for (const kind of ['mil', 'fin']) {
    const w = b.lic[kind + 'Wait']; if (!w || s.turn < w) continue;
    delete b.lic[kind + 'Wait'];
    const ch = 35 + s.st.rep * 0.4 + E.sk(s, 'biz') * 0.3 + (b.lic[kind + 'Bribe'] ? 25 : 0) + (s.pol ? 15 : 0) + E.dif(s).chance - (s.crime && s.crime.on ? 20 : 0);
    if (Math.random() * 100 < ch) { b.lic[kind] = true; out.push(`«${b.n}»: получена ${kind === 'mil' ? 'лицензия на производство и экспорт вооружений' : 'банковская лицензия'}!`); }
    else out.push(`«${b.n}»: в лицензии отказано. Можно подать снова.`);
  }
  return out;
};
B.setLine = (s, id, line, product) => { const b = B.get(s, id); if (!b) return; if (line === 'military' && !b.lic.mil) return { ok: false, title: 'Нужна лицензия' }; b.line = line; b.product = product; return { ok: true, title: 'Линия переналажена: ' + product }; };
// Предложения от стран
B.offers = (s, b) => {
  if (!b || b.line !== 'military') return [];
  const W = s.world, home = W.home, rr = L.rng(L.hash('arms', b.id, Math.floor(s.turn / 4)));
  const pr = D.PRODUCTS.military.find(p => p.n === b.product) || D.PRODUCTS.military[0];
  const enemies = new Set(WD.enemies(s, home));
  const buyers = E.alive(s).filter(i => i !== home && !enemies.has(i) && W.cs[i].st.gdp > 5);
  const pool = buyers.sort((a, c) => (WD.enemies(s, c).length * 3 + W.cs[c].st.milp) - (WD.enemies(s, a).length * 3 + W.cs[a].st.milp) + (rr() - 0.5) * 6).slice(0, 6);
  if (WD.enemies(s, home).length) pool.unshift(home);
  return pool.slice(0, 6).map(ci => {
    const C = W.cs[ci];
    const monthly = Math.round(B.cap(s, b) * pr.k * (0.25 + rr() * 0.45) * (WD.enemies(s, ci).length ? 1.5 : 1));
    const legal = ci === home || C.rel > -30;
    return { ci, n: C.n, monthly, months: 6 + Math.floor(rr() * 18), war: WD.enemies(s, ci).length > 0, legal, rel: C.rel, gov: ci === home };
  });
};
B.sign = (s, id, ci) => {
  const b = B.get(s, id); if (!b) return null;
  if (!b.lic.mil) return { ok: false, title: 'Нужна лицензия', lines: ['Без лицензии оружие продавать нельзя.'] };
  const o = B.offers(s, b).find(x => x.ci === ci); if (!o) return { ok: false, title: 'Предложение больше не действует' };
  if (b.contracts.length >= Math.max(1, Math.floor(b.level / 2))) return { ok: false, title: 'Мощностей не хватит', lines: ['Одновременно — не больше ' + Math.max(1, Math.floor(b.level / 2)) + ' контрактов. Расширьте завод.'] };
  b.contracts.push({ ci, n: o.n, monthly: o.monthly, left: o.months, months: o.months, product: b.product });
  const W = s.world, C = W.cs[ci];
  if (ci !== W.home) {
    C.rel = E.clamp(C.rel + 8, -100, 100);
    for (const e of WD.enemies(s, ci)) W.cs[e].rel = E.clamp(W.cs[e].rel - 10, -100, 100);
    if (!o.legal) { L.crimeInit(s); s.crime.heat = E.clamp(s.crime.heat + 25, 0, 100); }
    WD.news(s, `${b.n} подписал контракт на поставку «${b.product.toLowerCase()}» в ${C.n}.`, [W.home, ci], 0);
  }
  return { ok: true, title: 'Контракт: ' + C.n, lines: [b.product + ' — ' + E.money(o.monthly) + '/мес на ' + o.months + ' мес.'].concat(o.legal ? [] : ['Сделка на грани закона — к вам присматриваются.']) };
};
// Чат-команды
E.A.biz_start = (s, it) => {
  const t = E.norm([it.target, it.org, it.raw].join(' '));
  const I = B.IND(s).find(x => x.kw.some(k => t.includes(k))) || B.IND(s).find(x => x.id === (E.ww2(s) ? 'artel' : 'retail'));
  const nm = (it.org || '').trim();
  return B.create(s, I.id, nm ? nm.replace(/^./, c => c.toUpperCase()) : '', /оруж|военн|боеприпас/.test(t) ? D.PRODUCTS.military[0].n : '');
};
E.A.biz_sell = (s, it) => {
  if (!s.biz.length) return { ok: false, impossible: true, apCost: 0, title: 'Бизнеса нет', lines: [] };
  const t = E.norm(it.target || it.raw || '');
  const b = s.biz.find(x => t.includes(E.norm(x.n).slice(0, 5)) || t.includes(E.norm(x.type).slice(0, 5))) || s.biz[0];
  return B.sell(s, b.id);
};
