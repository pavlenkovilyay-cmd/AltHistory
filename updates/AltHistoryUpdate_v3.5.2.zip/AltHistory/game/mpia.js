// «Судьба» — взаимодействия между игроками в мультиплеере.
// Схема: игрок А предлагает → у Б всплывает окно «Принять / Отказаться» → А бросает кубик (если нужно) → оба получают итог.
// Деньги переходят через перевод, долги, доли в бизнесе и аренда — платятся сами раз в месяц.
'use strict';
const IA = { pending: {}, incoming: [], cat: 'Общение', target: null };
IA.rel = uid => { const s = UI.s; s.mpRel = s.mpRel || {}; return s.mpRel[uid] = s.mpRel[uid] || { att: 50, hist: [] }; };
IA.bump = (uid, d, note) => { const r = IA.rel(uid); r.att = E.clamp(r.att + d, 0, 100); if (note) { r.hist.push(note + ' (' + E.monthStr(UI.s.date) + ')'); if (r.hist.length > 20) r.hist.shift(); } };
IA.links = () => (UI.s.mpLinks = UI.s.mpLinks || []);
IA.M = v => { const x = E.m(UI.s, v); return x >= 10000 ? Math.round(x / 1000) * 1000 : Math.round(x); };
IA.money = v => E.money(Math.round(v));
const iaJob = s => s.job && !s.job.army ? s.job : null;

// ---------- все взаимодействия ----------
IA.DEFS = [
  // ===== Общение =====
  { id: 'meet', cat: 'Общение', n: 'Встретиться', d: 'Посидеть, поговорить. Оба становитесь счастливее, дружба крепнет.', ap: 1,
    text: () => 'зовёт встретиться и провести время вместе',
    done: (s, p) => ({ fx: { happy: 4, stress: -3 }, rel: 6, note: 'встречались' }), fin: () => ({ fx: { happy: 4, stress: -3 }, rel: 6, note: 'встречались' }) },
  { id: 'trip', cat: 'Общение', n: 'Поехать отдыхать вместе', d: 'Каждый платит за себя. Много счастья и минус стресс.', ap: 1,
    cost: () => IA.M(45000),
    need: (s) => s.st.money < IA.M(45000) ? 'Нужно ' + IA.money(IA.M(45000)) : null,
    text: () => `зовёт вместе поехать отдыхать (каждый платит ~${IA.money(IA.M(45000))})`,
    accept: s => s.st.money < IA.M(45000) ? 'Не хватает денег на поездку' : null,
    done: () => ({ fx: { money: -IA.M(45000), happy: 12, stress: -12, health: 2 }, rel: 10, note: 'вместе отдыхали' }), fin: () => ({ fx: { money: -IA.M(45000), happy: 12, stress: -12, health: 2 }, rel: 10, note: 'вместе отдыхали' }) },
  { id: 'visit', cat: 'Общение', n: 'Позвать в гости', d: 'Ужин у вас дома. Чем уютнее дом — тем лучше вечер.',
    text: s => `зовёт в гости (${E.homeName(s).toLowerCase()})`,
    done: s => ({ fx: { happy: 3 }, rel: 5, note: 'был в гостях' }), fin: (s, d) => ({ fx: { happy: 3 + Math.round((d.comfort || 40) / 25) }, rel: 6, note: 'ходил в гости' }), data: s => ({ comfort: Math.round(E.comfort(s)) }) },
  { id: 'gift', cat: 'Общение', n: 'Сделать подарок', d: 'Подарок на сумму, которую вы выберете.', fields: [{ k: 'sum', label: 'Сумма', type: 'money', def: 10000 }],
    need: (s, p, f) => s.st.money < (f.sum || 0) ? 'Не хватает денег' : null,
    text: (s, f) => `хочет сделать вам подарок на ${IA.money(f.sum)}`,
    done: (s, p, f) => ({ fx: { money: -f.sum, happy: 2 }, rel: 6, note: 'подарил подарок' }), fin: (s, d, f) => ({ fx: { money: f.sum, happy: Math.min(12, 3 + Math.round(f.sum / IA.M(15000))) }, rel: 8, note: 'подарок' }) },
  { id: 'teach', cat: 'Общение', n: 'Научить навыку', d: 'Поделиться тем, что умеете. Нужно уметь это хорошо (40+).', ap: 1,
    fields: [{ k: 'sk', label: 'Навык', type: 'select', opts: () => Object.keys(D.SKILLS).map(k => [k, D.SKILLS[k]]) }],
    need: (s, p, f) => E.sk(s, f.sk || 'int') < 40 ? 'Ваш навык слишком слабый (нужно 40+)' : null,
    text: (s, f) => `предлагает научить: ${D.SKILLS[f.sk].toLowerCase()} (у него ${Math.round(E.sk(s, f.sk))})`,
    data: (s, f) => ({ lvl: Math.round(E.sk(s, f.sk)) }),
    done: () => ({ fx: { happy: 2 }, rel: 4, note: 'учил' }), fin: (s, d, f) => { const g = Math.max(1, Math.min(6, Math.round((d.lvl - E.sk(s, f.sk)) / 8))); return { fx: { [f.sk]: g }, rel: 5, note: 'учился у друга' }; } },
  { id: 'intro', cat: 'Общение', n: 'Познакомить с нужными людьми', d: 'Ваша репутация открывает другу двери. Нужна репутация 30+.',
    need: s => s.st.rep < 30 ? 'Нужна репутация 30+' : null,
    text: () => 'хочет познакомить вас с нужными людьми',
    done: () => ({ fx: { rep: -1 }, rel: 4, note: 'познакомил с людьми' }), fin: () => ({ fx: { rep: 5, cha: 1 }, rel: 5, note: 'новые знакомства' }) },
  // ===== Деньги =====
  { id: 'loan', cat: 'Деньги', n: 'Дать в долг', d: 'Друг вернёт сумму +10% частями каждый месяц — автоматически.',
    fields: [{ k: 'sum', label: 'Сумма', type: 'money', def: 50000 }, { k: 'mon', label: 'Срок', type: 'select', opts: () => [[3, '3 месяца'], [6, '6 месяцев'], [12, 'год']] }],
    need: (s, p, f) => s.st.money < (f.sum || 0) ? 'Не хватает денег' : null,
    text: (s, f) => `предлагает в долг ${IA.money(f.sum)} на ${f.mon} мес. (вернуть ${IA.money(f.sum * 1.1)} — по ${IA.money(f.sum * 1.1 / f.mon)}/мес)`,
    done: (s, p, f) => { IA.links().push({ t: 'credit', uid: p.uid, n: p.name, left: Math.round(f.sum * 1.1) }); return { fx: { money: -f.sum }, rel: 3, note: 'дал в долг ' + IA.money(f.sum) }; },
    fin: (s, d, f, from) => { IA.links().push({ t: 'debt', uid: from.uid, n: from.name, left: Math.round(f.sum * 1.1), pay: Math.round(f.sum * 1.1 / f.mon) }); return { fx: { money: f.sum }, rel: 4, note: 'взял в долг ' + IA.money(f.sum), lines: ['Долг ' + IA.money(f.sum * 1.1) + ' — будет списываться по ' + IA.money(f.sum * 1.1 / f.mon) + ' в месяц'] }; } },
  { id: 'ask', cat: 'Деньги', n: 'Попросить денег', d: 'Друг решит сам, дать или нет.', fields: [{ k: 'sum', label: 'Сумма', type: 'money', def: 20000 }],
    text: (s, f) => `просит у вас ${IA.money(f.sum)}`,
    accept: (s, f) => s.st.money < f.sum ? 'У вас нет такой суммы' : null,
    onAccept: (s, f) => ({ fx: { money: -f.sum }, rel: 2, note: 'выручил деньгами' }),
    done: (s, p, f) => ({ fx: { money: f.sum, happy: 3 }, rel: 6, note: 'выручил деньгами' }), fin: () => null },
  { id: 'bet', cat: 'Деньги', n: 'Поспорить на деньги', d: 'Пари 50 на 50. Победитель забирает обе ставки.', fields: [{ k: 'sum', label: 'Ставка', type: 'money', def: 5000 }],
    need: (s, p, f) => s.st.money < (f.sum || 0) ? 'Не хватает денег на ставку' : null,
    text: (s, f) => `предлагает пари: ставка ${IA.money(f.sum)} с каждого`,
    accept: (s, f) => s.st.money < f.sum ? 'Не хватает денег на ставку' : null,
    roll: () => ({ chance: 50 }),
    done: (s, p, f, r) => ({ fx: { money: r.ok ? f.sum : -f.sum, happy: r.ok ? 4 : -3 }, rel: 1, note: r.ok ? 'выиграл пари' : 'проиграл пари' }),
    fin: (s, d, f, from, r) => ({ fx: { money: r.ok ? -f.sum : f.sum, happy: r.ok ? -3 : 4 }, rel: 1, note: r.ok ? 'проиграл пари' : 'выиграл пари' }) },
  { id: 'cards', cat: 'Деньги', n: 'Сыграть в карты на деньги', d: 'Кто умнее и хитрее — у того и шанс выше.', ap: 1, fields: [{ k: 'sum', label: 'Ставка', type: 'money', def: 3000 }],
    need: (s, p, f) => s.st.money < (f.sum || 0) ? 'Не хватает денег на ставку' : null,
    text: (s, f) => `зовёт сыграть в карты по ${IA.money(f.sum)}`,
    accept: (s, f) => s.st.money < f.sum ? 'Не хватает денег на ставку' : null,
    reply: s => ({ sk: Math.round((E.sk(s, 'int') + E.sk(s, 'cha')) / 2) }),
    roll: (s, rp) => ({ chance: E.clamp(50 + Math.round(((E.sk(s, 'int') + E.sk(s, 'cha')) / 2 - (rp.sk || 30)) / 2), 15, 85) }),
    done: (s, p, f, r) => ({ fx: { money: r.ok ? f.sum : -f.sum, happy: r.ok ? 3 : -2 }, rel: 2, note: r.ok ? 'обыграл в карты' : 'проиграл в карты' }),
    fin: (s, d, f, from, r) => ({ fx: { money: r.ok ? -f.sum : f.sum, happy: r.ok ? -2 : 3 }, rel: 2, note: r.ok ? 'проиграл в карты' : 'выиграл в карты' }) },
  // ===== Работа и бизнес =====
  { id: 'blat', cat: 'Работа и бизнес', n: 'Устроить по блату', d: 'Взять друга к себе: на свою работу, в свой бизнес или в администрацию. Шанс зависит от вашей должности и репутации.',
    fields: [{ k: 'src', label: 'Куда', type: 'select', opts: s => [iaJob(s) && iaJob(s).level >= 1 ? ['job', 'К себе на работу: ' + iaJob(s).org] : null, s.biz.length ? ['biz', 'В свой бизнес: «' + s.biz[0].n + '»'] : null, s.pol ? ['pol', 'В администрацию (' + s.pol.n + ')'] : null].filter(Boolean) }],
    need: (s, p, f) => !(iaJob(s) && iaJob(s).level >= 1) && !s.biz.length && !s.pol ? 'Нужна должность (повышение 1+), свой бизнес или власть' : !f.src ? 'Выберите, куда' : null,
    pos: (s, f) => {
      if (f.src === 'biz') { const b = s.biz[0], I = B.ind(s, b.ind), role = I.roles[Math.min(1, I.roles.length - 1)]; return { title: role, org: '«' + b.n + '»', sal: Math.round(B.mkt(s, role) * 1.1), chance: 95, biz: b.id }; }
      if (f.src === 'pol') return { title: 'Помощник (' + s.pol.n.toLowerCase() + ')', org: 'Администрация', sal: IA.M(95000), chance: E.clamp(55 + Math.round(s.st.rep / 3), 40, 92) };
      const j = iaJob(s), lvl = Math.max(0, j.level - 1);
      return { title: (j.ladder || [j.title])[lvl] || j.title, org: j.org || 'место работы друга', jid: j.id, lvl, sal: Math.round(j.salary * (lvl < j.level ? 0.75 : 1)), chance: E.clamp(30 + j.level * 12 + Math.round(s.st.rep / 5) + Math.round(IA.rel(IA.target).att / 6), 20, 90) };
    },
    text: (s, f, d) => `зовёт по блату: ${d.title} — ${d.org}, ${IA.money(d.sal)}/мес. Шанс, что возьмут: ${d.chance}%`,
    data: (s, f) => IA.DEF.blat.pos(s, f),
    roll: (s, rp, f, d) => ({ chance: d.chance }),
    done: (s, p, f, r, d) => {
      if (r.ok && d.biz) { const b = s.biz.find(x => x.id === d.biz); if (b) b.staff.push({ n: p.name, role: d.title, sk: 60, sal: d.sal, mor: 85, m: 0, friend: p.uid }); }
      return { fx: r.ok ? { rep: 1 } : { rep: -1 }, rel: r.ok ? 8 : 2, note: r.ok ? 'устроил по блату' : 'пытался устроить по блату' };
    },
    fin: (s, d, f, from, r) => {
      if (!r.ok) return { fx: { happy: -2 }, rel: 2, note: 'не взяли по блату', lines: ['Не взяли — кадровик упёрся. Друг старался.'] };
      const j = D.JOBS.find(x => x.id === d.jid);
      s.job = { id: d.jid || 'blat', title: d.title, org: d.org, salary: d.sal, level: d.lvl || 0, perf: 55, months: 0, weeks: 0, sk: j ? j.sk : 'cha', ladder: j ? j.ladder : [d.title, 'Старший ' + d.title.toLowerCase(), 'Руководитель'], blat: from.uid };
      E.fact(s, `${E.monthStr(s.date)}: по блату устроился — ${d.title}, ${d.org} (помог ${from.name}).`);
      return { fx: { happy: 8 }, rel: 10, note: 'устроил по блату', lines: ['Новая работа: ' + d.title + ' — ' + d.org + ', ' + IA.money(d.sal) + '/мес'] };
    } },
  { id: 'jbiz', cat: 'Работа и бизнес', n: 'Открыть общий бизнес', d: 'Стартовый капитал пополам, прибыль пополам — каждый месяц автоматически. Управляет тот, кто предложил.',
    fields: [{ k: 'ind', label: 'Отрасль', type: 'select', opts: s => B.IND(s).filter(I => !I.req || Object.keys(I.req).every(k => E.sk(s, k) >= I.req[k])).map(I => [I.id, I.n + ' — старт ' + E.short(B.money(s, I.start))]) }, { k: 'name', label: 'Название', type: 'text', def: '' }],
    need: (s, p, f) => { if (!f.ind) return 'Нет доступных отраслей (не хватает опыта)'; const c = B.money(s, B.ind(s, f.ind).start); return s.st.money < c / 2 ? 'Нужна ваша половина: ' + IA.money(c / 2) : E.age(s) < 18 ? 'Бизнес — с 18 лет' : null; },
    data: (s, f) => { const I = B.ind(s, f.ind); return { half: Math.round(B.money(s, I.start) / 2), indN: I.n }; },
    text: (s, f, d) => `предлагает открыть общий бизнес: ${d.indN.toLowerCase()}${f.name ? ' «' + f.name + '»' : ''}. Вложить ${IA.money(d.half)}, прибыль пополам`,
    accept: (s, f, d) => s.st.money < d.half ? 'Нужно ' + IA.money(d.half) : E.age(s) < 18 ? 'Бизнес — с 18 лет' : null,
    onAccept: (s, f, d) => ({ fx: { money: -d.half } }),
    done: (s, p, f, r, d) => {
      s.st.money += d.half;
      const res = B.create(s, f.ind, f.name || ''); if (res.ok === false) { s.st.money -= d.half; NET.A.money({ to: p.uid, amount: d.half, name: NET.me().name, note: 'возврат: общий бизнес не открылся' }, p.uid); return { fail: res.title, rel: 0, lines: res.lines }; }
      const b = s.biz[s.biz.length - 1]; b.partner = { uid: p.uid, n: p.name, pct: 50 };
      IA.links().push({ t: 'bizshare', uid: p.uid, n: p.name, biz: b.id, bizN: b.n, pct: 50 });
      return { rel: 8, note: 'открыли общий бизнес «' + b.n + '»', lines: ['Общий бизнес «' + b.n + '» с ' + p.name + ': 50/50'], out: { bizN: b.n }, pub: `${NET.me().name} и ${p.name} открыли общий бизнес «${b.n}»` };
    },
    fin: (s, d, f, from, r, out) => { IA.links().push({ t: 'bizpart', uid: from.uid, n: from.name, bizN: out.bizN, pct: 50 }); E.fact(s, `${E.monthStr(s.date)}: стал совладельцем «${out.bizN}» (50%, партнёр — ${from.name}).`); return { fx: { happy: 5 }, rel: 8, note: 'общий бизнес «' + out.bizN + '»', lines: ['Вы совладелец «' + out.bizN + '» (50%). Прибыль будет приходить каждый месяц.'] }; } },
  { id: 'share', cat: 'Работа и бизнес', n: 'Продать долю в бизнесе', d: 'Друг покупает часть вашего бизнеса и получает эту долю прибыли каждый месяц.',
    fields: [{ k: 'biz', label: 'Бизнес', type: 'select', opts: s => s.biz.map(b => [b.id, b.n]) }, { k: 'pct', label: 'Доля', type: 'select', opts: () => [[10, '10%'], [20, '20%'], [30, '30%'], [49, '49%']] }, { k: 'sum', label: 'Цена', type: 'money', def: 300000 }],
    need: (s, p, f) => !s.biz.length ? 'Нет своего бизнеса' : null,
    data: (s, f) => { const b = s.biz.find(x => x.id === f.biz) || s.biz[0]; return { bizN: b.n, profit: b.lastProfit }; },
    text: (s, f, d) => `предлагает купить ${f.pct}% бизнеса «${d.bizN}» за ${IA.money(f.sum)} (прибыль сейчас ${IA.money(d.profit)}/мес)`,
    accept: (s, f) => s.st.money < f.sum ? 'Не хватает денег' : null,
    onAccept: (s, f) => ({ fx: { money: -f.sum } }),
    done: (s, p, f, r, d) => { IA.links().push({ t: 'bizshare', uid: p.uid, n: p.name, biz: f.biz, bizN: d.bizN, pct: f.pct }); return { fx: { money: f.sum }, rel: 5, note: 'продал долю «' + d.bizN + '»' }; },
    fin: (s, d, f, from) => { IA.links().push({ t: 'bizpart', uid: from.uid, n: from.name, bizN: d.bizN, pct: f.pct }); return { rel: 5, note: 'купил долю «' + d.bizN + '»', lines: ['Вам принадлежит ' + f.pct + '% «' + d.bizN + '»'] }; } },
  // ===== Жильё =====
  { id: 'movein', cat: 'Жильё', n: 'Пустить пожить к себе', d: 'Друг переезжает к вам. Если вы снимаете — он платит половину аренды каждый месяц.',
    need: s => ['parents'].includes(s.home.type) ? 'Вы живёте с родителями' : null,
    data: s => ({ home: Object.assign({}, s.home, { furn: [] }), share: s.home.owned ? 0 : Math.round(E.homeRent(s) / 2), cityN: E.cityName(s), city: s.ch.city }),
    text: (s, f, d) => `зовёт жить к себе: ${E.homeName(s).toLowerCase()}, ${d.cityN}${d.share ? '. Половина аренды — ' + IA.money(d.share) + '/мес' : '. Бесплатно'}`,
    onAccept: (s, f, d, from) => {
      const lines = []; L.leave(s, lines);
      if (d.city !== s.ch.city) { s.ch.city = d.city; s.ch.cityName = ''; if (s.job && !s.job.army) { lines.push('Работу в старом городе пришлось оставить'); s.job = null; } }
      s.home = Object.assign({}, d.home, { owned: false, rent: d.share, value: 0, shared: from.uid, furn: s.home.furn || [] });
      if (d.share) IA.links().push({ t: 'rentout', uid: from.uid, n: from.name, pay: d.share });
      return { fx: { happy: 4 }, rel: 6, note: 'живём вместе', lines: ['Вы переехали к ' + from.name].concat(lines) };
    },
    done: (s, p, f, r, d) => { if (d.share) IA.links().push({ t: 'rentin', uid: p.uid, n: p.name, pay: d.share }); return { fx: { happy: 3 }, rel: 6, note: 'живём вместе', pub: `${p.name} переехал к ${NET.me().name}` }; }, fin: () => null },
  { id: 'buyhome', cat: 'Жильё', n: 'Купить жильё вместе', d: 'Делите цену пополам и живёте вместе в своём жилье.',
    fields: [{ k: 'lid', label: 'Объявление', type: 'select', opts: s => L.listings(s).filter(l => l.deal !== 'rent' && l.deal !== 'order' && l.price).slice(0, 10).map(l => [l.id, `${l.n}, ${l.area} м² — ${E.short(l.price)} (по ${E.short(l.price / 2)})`]) }],
    need: (s, p, f) => { const l = L.listings(s).find(x => x.id === f.lid); return !l ? 'Нет объявлений о продаже' : s.st.money < l.price / 2 ? 'Нужна ваша половина: ' + IA.money(l.price / 2) : null; },
    data: (s, f) => { const l = L.listings(s).find(x => x.id === f.lid); return { half: Math.round(l.price / 2), n: l.n, area: l.area, cityN: E.cityName(s) }; },
    text: (s, f, d) => `предлагает купить вместе: ${d.n.toLowerCase()}, ${d.area} м², ${d.cityN}. Ваша половина — ${IA.money(d.half)}`,
    accept: (s, f, d) => s.st.money < d.half ? 'Нужно ' + IA.money(d.half) : null,
    onAccept: (s, f, d) => ({ fx: { money: -d.half } }),
    done: (s, p, f, r, d) => {
      s.st.money += d.half; const res = L.take(s, f.lid, 'sale');
      if (!res || res.ok === false) { s.st.money -= d.half; NET.A.money({ to: p.uid, amount: d.half, name: NET.me().name, note: 'возврат: покупка сорвалась' }, p.uid); return { fail: (res && res.title) || 'Покупка сорвалась', rel: 0 }; }
      s.home.co = { uid: p.uid, n: p.name };
      return { rel: 10, note: 'купили жильё вместе', out: { home: Object.assign({}, s.home, { furn: [] }), city: s.ch.city }, pub: `${NET.me().name} и ${p.name} купили жильё вместе` };
    },
    fin: (s, d, f, from, r, out) => {
      const lines = []; L.leave(s, lines);
      if (out.city !== s.ch.city) { s.ch.city = out.city; s.ch.cityName = ''; if (s.job && !s.job.army) { lines.push('Работу в старом городе пришлось оставить'); s.job = null; } }
      s.home = Object.assign({}, out.home, { owned: true, value: d.half, rent: 0, co: { uid: from.uid, n: from.name }, furn: s.home.furn || [] });
      return { fx: { happy: 10 }, rel: 10, note: 'купили жильё вместе', lines: ['Своё жильё (половина ваша): ' + d.n.toLowerCase()].concat(lines) };
    } },
  // ===== Семья =====
  { id: 'date', cat: 'Семья', n: 'Предложить встречаться', d: 'Нужно хорошее отношение (40+) и чтобы оба были свободны.',
    need: (s, p) => IA.rel(p.uid).att < 40 ? 'Отношение должно быть 40+ (сейчас ' + Math.round(IA.rel(p.uid).att) + ')' : s.rel.some(r => r.role === 'партнёр' || r.role === 'супруг(а)') ? 'У вас уже есть пара' : null,
    text: () => 'предлагает встречаться ❤',
    accept: s => s.rel.some(r => r.role === 'партнёр' || r.role === 'супруг(а)') ? 'У вас уже есть пара' : null,
    onAccept: (s, f, d, from) => { s.rel.push({ name: from.name.split(' ')[0], role: 'партнёр', att: 75, mp: from.uid }); return { fx: { happy: 10 }, rel: 10, note: 'встречаемся' }; },
    done: (s, p) => { s.rel.push({ name: p.name.split(' ')[0], role: 'партнёр', att: 75, mp: p.uid }); return { fx: { happy: 10 }, rel: 10, note: 'встречаемся', pub: `${NET.me().name} и ${p.name} теперь пара` }; }, fin: () => null },
  { id: 'marry', cat: 'Семья', n: 'Сделать предложение', d: 'Если вы пара и отношение 65+.',
    need: (s, p) => !s.rel.some(r => r.mp === p.uid && r.role === 'партнёр') ? 'Сначала нужно встречаться' : IA.rel(p.uid).att < 65 ? 'Отношение должно быть 65+' : null,
    text: () => 'делает вам предложение руки и сердца 💍',
    onAccept: (s, f, d, from) => { const r = s.rel.find(x => x.mp === from.uid); if (r) r.role = 'супруг(а)'; E.fact(s, `${E.monthStr(s.date)}: свадьба с ${from.name}.`); return { fx: { happy: 20, money: -IA.M(80000) }, rel: 12, note: 'свадьба', lines: ['Свадьба! Половина расходов — ' + IA.money(IA.M(80000))] }; },
    done: (s, p) => { const r = s.rel.find(x => x.mp === p.uid); if (r) r.role = 'супруг(а)'; E.fact(s, `${E.monthStr(s.date)}: свадьба с ${p.name}.`); return { fx: { happy: 20, money: -IA.M(80000) }, rel: 12, note: 'свадьба', pub: `Свадьба! ${NET.me().name} и ${p.name} поженились` }; }, fin: () => null },
  // ===== Криминал =====
  { id: 'gang', cat: 'Криминал', n: 'Позвать в банду', d: 'Только если вы сами в банде.',
    need: s => !(s.crime && s.crime.on && s.crime.gang) ? 'Вы не в банде' : null,
    data: s => ({ gang: s.crime.gang }),
    text: (s, f, d) => `зовёт в банду «${d.gang}»`,
    onAccept: (s, f, d) => { L.crimeInit(s); Object.assign(s.crime, { on: true, gang: d.gang, rank: s.crime.rank || 0 }); s.crime.heat = (s.crime.heat || 0) + 5; return { rel: 6, note: 'в одной банде', lines: ['Теперь вы в банде «' + d.gang + '»'] }; },
    done: () => ({ fx: {}, rel: 6, note: 'привёл в банду' }), fin: () => null },
  { id: 'heist', cat: 'Криминал', n: 'Провернуть дело вместе', d: 'Вдвоём надёжнее. Добычу — пополам. Провал — розыск и штраф обоим.', ap: 1,
    need: s => !(s.crime && s.crime.on) ? 'Вы не на тёмной стороне' : null,
    text: () => 'предлагает провернуть одно дело вместе. Добыча пополам',
    accept: s => !(s.crime && s.crime.on) ? 'Вы не на тёмной стороне' : null,
    reply: s => ({ str: Math.round(E.sk(s, 'str')) }),
    roll: (s, rp) => ({ chance: E.clamp(40 + Math.round((E.sk(s, 'str') + (rp.str || 30)) / 6), 25, 80) }),
    data: () => ({ loot: IA.M(120000 + Math.random() * 280000) }),
    done: (s, p, f, r, d) => { s.crime.heat = (s.crime.heat || 0) + (r.ok ? 12 : 25); return { fx: r.ok ? { money: Math.round(d.loot / 2), happy: 4 } : { money: -IA.M(30000), happy: -6 }, rel: r.ok ? 6 : -2, note: r.ok ? 'провернули дело' : 'попались на деле' }; },
    fin: (s, d, f, from, r) => { s.crime.heat = (s.crime.heat || 0) + (r.ok ? 12 : 25); return { fx: r.ok ? { money: Math.round(d.loot / 2), happy: 4 } : { money: -IA.M(30000), happy: -6 }, rel: r.ok ? 6 : -2, note: r.ok ? 'провернули дело' : 'попались на деле', lines: [r.ok ? 'Ваша доля: ' + IA.money(d.loot / 2) : 'Попались. Штраф и розыск.'] }; } },
  { id: 'cover', cat: 'Криминал', n: 'Прикрыть перед полицией', d: 'Вы заносите кому надо — с друга снимают часть розыска.',
    cost: () => IA.M(60000), need: s => s.st.money < IA.M(60000) ? 'Нужно ' + IA.money(IA.M(60000)) : null,
    text: () => 'предлагает «решить вопрос» с полицией за свой счёт',
    done: () => ({ fx: { money: -IA.M(60000) }, rel: 8, note: 'прикрыл перед полицией' }),
    fin: s => { if (s.crime) s.crime.heat = Math.max(0, (s.crime.heat || 0) - 30); return { rel: 8, note: 'прикрыли перед полицией', lines: ['Розыск снизился'] }; } },
  // ===== Власть =====
  { id: 'vote', cat: 'Власть', n: 'Поддержать на выборах', d: 'Деньги и связи на кампанию друга. Работает, если он сейчас идёт на выборы.', fields: [{ k: 'sum', label: 'Вклад в кампанию', type: 'money', def: 100000 }],
    need: (s, p, f) => s.st.money < (f.sum || 0) ? 'Не хватает денег' : null,
    text: (s, f) => `хочет вложить ${IA.money(f.sum)} в вашу предвыборную кампанию`,
    accept: s => !s.election ? 'Вы сейчас не участвуете в выборах' : null,
    done: (s, p, f) => ({ fx: { money: -f.sum }, rel: 6, note: 'поддержал на выборах' }),
    fin: (s, d, f) => { const add = Math.min(15, Math.max(2, Math.round(f.sum / IA.M(40000)))); s.flags.campaign = Math.min(30, (s.flags.campaign || 0) + add); return { rel: 6, note: 'поддержка на выборах', lines: ['Шанс на выборах +' + add + '%'] }; } },
  // ===== Развлечения =====
  { id: 'chess', cat: 'Развлечения', n: 'Сыграть в шахматы', d: 'Побеждает тот, у кого интеллект выше (но удача тоже нужна).',
    text: () => 'вызывает сыграть партию в шахматы',
    reply: s => ({ int: Math.round(E.sk(s, 'int')) }), roll: (s, rp) => ({ chance: E.clamp(50 + Math.round((E.sk(s, 'int') - (rp.int || 30)) / 2), 15, 85) }),
    done: (s, p, f, r) => ({ fx: { happy: r.ok ? 4 : 1, int: 1 }, rel: 3, note: r.ok ? 'обыграл в шахматы' : 'проиграл в шахматы' }),
    fin: (s, d, f, from, r) => ({ fx: { happy: r.ok ? 1 : 4, int: 1 }, rel: 3, note: r.ok ? 'проиграл в шахматы' : 'обыграл в шахматы' }) },
  { id: 'gym', cat: 'Развлечения', n: 'Сходить вместе в зал', d: 'Здоровье и сила обоим.', ap: 1,
    text: () => 'зовёт вместе на тренировку',
    done: () => ({ fx: { health: 3, str: 1, stress: -4 }, rel: 4, note: 'тренировались вместе' }), fin: () => ({ fx: { health: 3, str: 1, stress: -4 }, rel: 4, note: 'тренировались вместе' }) },
  { id: 'fight', cat: 'Развлечения', n: 'Побороться по-дружески', d: 'Кто сильнее? Проигравший — с синяками.',
    text: () => 'вызывает побороться (по-дружески)',
    reply: s => ({ str: Math.round(E.sk(s, 'str')) }), roll: (s, rp) => ({ chance: E.clamp(50 + Math.round((E.sk(s, 'str') - (rp.str || 30)) / 2), 15, 85) }),
    done: (s, p, f, r) => ({ fx: r.ok ? { happy: 3, rep: 1 } : { health: -6, happy: -2 }, rel: 1, note: r.ok ? 'победил в борьбе' : 'проиграл в борьбе' }),
    fin: (s, d, f, from, r) => ({ fx: r.ok ? { health: -6, happy: -2 } : { happy: 3, rep: 1 }, rel: 1, note: r.ok ? 'проиграл в борьбе' : 'победил в борьбе' }) },
];
IA.CATS = ['Общение', 'Деньги', 'Работа и бизнес', 'Жильё', 'Семья', 'Криминал', 'Власть', 'Развлечения'];
// ===== Подлянки (без согласия жертвы; жертва узнаёт, кто это, только иногда) =====
IA.def = d => ({ infl: Math.round(d.infl || 0), guard: d.guard || 0 });
IA.HOST = [
  { id: 'h_rumor', n: 'Распустить слухи', d: 'Бесплатно. Репутация и настроение жертвы падают.', chance: (s, rp) => 65 + Math.round((s.st.infl - (rp.infl || 0)) / 6),
    hit: () => ({ fx: { rep: -3, happy: -3 }, lines: ['О вас по городу ходят гадкие слухи'] }) },
  { id: 'h_pr', n: 'Чёрный пиар', d: 'Статьи и посты против человека и его бизнеса.', cost: 250000, chance: (s, rp) => 55 + Math.round((s.st.infl - (rp.infl || 0)) / 5),
    hit: s => { const b = s.biz[0]; if (b) b.pr = (b.pr || 0) - 0.08; return { fx: { rep: -6 }, lines: ['Про вас вышли разгромные статьи' + (b ? '; клиенты «' + b.n + '» напуганы' : '')] }; } },
  { id: 'h_inspect', n: 'Наслать проверку на бизнес', d: 'Налоговая и санэпиднадзор нагрянут к жертве.', cost: 150000, needBiz: true,
    chance: (s, rp) => 55 + Math.round(s.st.infl / 4) - Math.round((rp.infl || 0) / 4) - (rp.noInspect ? 40 : 0),
    hit: s => { const b = s.biz.slice().sort((a, c) => c.lastRev - a.lastRev)[0]; b.health = E.clamp(b.health - 15, 5, 100); const fine = Math.round(E.m(s, 100000)); return { fx: { money: -fine, stress: 8 }, lines: [`Проверка в «${b.n}»: штраф ${E.money(fine)}, состояние −15`] }; } },
  { id: 'h_thugs', n: 'Нанять спортиков', d: 'Братки «объяснят» жертве, кто тут главный. Розыск вам +15. Охрана жертвы мешает.', cost: 400000, heat: 15,
    chance: (s, rp) => 55 + Math.round(s.st.infl / 6) - Math.round((rp.guard || 0) / 2),
    hit: s => { const b = s.biz[0]; if (b) { b.health = E.clamp(b.health - 25, 5, 100); return { fx: { stress: 12, happy: -4 }, lines: [`«Гости» разнесли «${b.n}»: состояние −25`] }; } return { fx: { health: -10, happy: -6, stress: 12 }, lines: ['Подкараулили у подъезда. Синяки и испуг.'] }; } },
  { id: 'h_poach', n: 'Переманить сотрудников', d: 'Двое лучших людей жертвы уйдут к вам (нужен свой бизнес).', cost: 150000, needBiz: true, mineBiz: true,
    chance: (s, rp) => 55 + Math.round(E.sk(s, 'biz') / 6) - Math.round((rp.infl || 0) / 8),
    hit: s => { const b = s.biz[0], top = b.staff.filter(p => !p.hr).sort((a, c) => c.sk - a.sk).slice(0, 2); b.staff = b.staff.filter(p => !top.includes(p)); return { fx: { stress: 5 }, lines: ['Из «' + b.n + '» ушли: ' + (top.map(p => p.n).join(', ') || 'никто')], out: { staff: top } }; },
    gain: (s, out) => { const b = s.biz[0]; for (const p of (out.staff || [])) b.staff.push(Object.assign({}, p, { mor: 70 })); return (out.staff || []).length ? ['К вам перешли: ' + out.staff.map(p => p.n).join(', ')] : []; } },
  { id: 'h_snitch', n: 'Сдать полиции', d: 'Сработает, только если жертва и правда на тёмной стороне.', chance: (s, rp) => rp.crime ? 70 : 8,
    hit: s => { L.crimeInit(s); s.crime.heat = E.clamp((s.crime.heat || 0) + 25, 0, 100); return { fx: { stress: 10 }, lines: ['Полиция получила наводку на вас. Розыск +25'] }; } },
  { id: 'h_sue', n: 'Подать в суд', d: 'Юристы и связи. Если выиграете — жертва заплатит вам компенсацию.', cost: 100000,
    chance: (s, rp) => 40 + Math.round(E.sk(s, 'biz') / 5 + s.st.infl / 5) - Math.round((rp.infl || 0) / 5),
    hit: (s, from) => { const sum = Math.min(Math.max(0, s.st.money), Math.round(E.m(s, 300000))); if (sum > 0) { NET.A.money({ to: from.uid, amount: sum, name: NET.me().name, note: 'компенсация по суду' }, from.uid); } return { fx: { money: -sum, stress: 10 }, lines: ['Суд проигран: компенсация ' + E.money(sum)] }; } },
];
for (const h of IA.HOST) {
  IA.DEFS.push({ id: h.id, cat: 'Подлянки', n: h.n, d: h.d + (h.cost ? ' Цена: ' + E.money(h.cost) + ' (в рублях эпохи — меньше).' : ''), hostile: true,
    need: s => h.cost && s.st.money < IA.M(h.cost) ? 'Нужно ' + IA.money(IA.M(h.cost)) : h.mineBiz && !s.biz.length ? 'Нужен свой бизнес' : null,
    text: () => h.n.toLowerCase(),
    accept: s => h.needBiz && !s.biz.length ? 'У него нет бизнеса' : null,
    reply: s => ({ infl: Math.round(s.st.infl || 0), guard: Math.max(0, ...s.biz.map(b => b.guard || 0), (s.lux || []).some(l => l.id === 'guard') ? 30 : 0), crime: !!(s.crime && s.crime.on), noInspect: s.flags.noInspect > s.turn }),
    roll: (s, rp) => ({ chance: E.clamp(h.chance(s, rp), 5, 92) }),
    done: (s, p, f, r) => {
      const fx = {}; if (h.cost) fx.money = -IA.M(h.cost);
      if (h.heat) { L.crimeInit(s); s.crime.heat = E.clamp((s.crime.heat || 0) + h.heat, 0, 100); }
      return { fx, rel: -15, note: r.ok ? h.n.toLowerCase() + ' — получилось' : h.n.toLowerCase() + ' — сорвалось', lines: [r.ok ? 'Получилось.' : 'Не вышло — деньги ушли впустую.'], out: { reveal: Math.random() < (r.ok ? 0.3 : 0.6) } };
    },
    fin: (s, d, f, from, r, out) => {
      const who = out.reveal ? from.name : 'неизвестный недоброжелатель';
      if (!r.ok) return { rel: out.reveal ? -10 : 0, note: out.reveal ? 'пытался навредить' : null, lines: ['Кто-то пытался: ' + h.n.toLowerCase() + ', — но не вышло.' + (out.reveal ? ' Это был ' + from.name + '.' : '')], fx: {} };
      const hit = h.hit(s, from);
      if (h.id === 'h_poach' && hit.out) IA.send('loot', from.uid, { k: h.id, out: hit.out });
      return Object.assign(hit, { rel: out.reveal ? -20 : 0, note: out.reveal ? h.n.toLowerCase() + ' против вас' : null, lines: [(out.reveal ? from.name : 'Неизвестный недоброжелатель') + ': ' + h.n.toLowerCase() + '.'].concat(hit.lines || []), who });
    } });
}
IA.CATS.push('Подлянки');
IA.DEF = {}; for (const d of IA.DEFS) IA.DEF[d.id] = d;

// ---------- применение итога ----------
IA.apply = (res, uid, who, title, ok) => {
  if (!res) return;
  const s = UI.s, lines = (res.lines || []).slice();
  if (res.fx) lines.push(...E.apply(s, res.fx));
  if (res.rel) IA.bump(uid, res.rel, res.note);
  if (res.note) E.logAdd(s, 'event', `${who}: ${res.note}`, { lines: lines.slice(0, 4) });
  UI.appendMsg({ k: 'out', ok: ok !== false && !res.fail, title: res.fail ? title + ': ' + res.fail : title, lines });
  if (typeof SFX !== 'undefined') SFX.play(ok === false || res.fail ? 'bad' : 'good', true);
  UI.renderAll(); UI.save();
};

// ---------- сеть ----------
IA.send = (op, to, body) => NET.A.ia && NET.A.ia(Object.assign({ op, from: { uid: NET.uid, name: NET.me().name } }, body), to);
IA.offer = (uid, id, f) => {
  const s = UI.s, def = IA.DEF[id], p = NET.byUid(uid); if (!p) return UI.toast('Игрок не в сети', 'bad');
  const pl = Object.assign({ uid }, p[1]);
  IA.target = uid;
  const why = def.need && def.need(s, pl, f); if (why) return UI.toast(why, 'bad');
  if (def.ap && s.ap <= 0) return UI.toast('На этой неделе сил больше нет', 'bad');
  const data = def.data ? def.data(s, f) : {};
  const id2 = NET.rid();
  IA.pending[id2] = { id, uid, f, data, t: Date.now(), name: pl.name };
  IA.send('offer', uid, { id: id2, k: id, f, data, text: def.text(s, f, data) });
  UI.toast('Предложение отправлено: ' + pl.name);
  if (IA.open._on) IA.open(uid);
};
IA.onMsg = (m, pid) => {
  if (!UI.s || !m || !m.op) return;
  const def = IA.DEF[m.k || (IA.pending[m.id] || {}).id];
  if (m.op === 'offer') { if (!def) return; if (def.hostile) { IA.answer(m, true, true); return; } IA.incoming.push(m); IA.showIncoming(); UI.renderAll(); return; }
  if (m.op === 'loot') { const h = IA.HOST.find(x => x.id === m.k); if (h && h.gain) { const l = h.gain(UI.s, m.out || {}); if (l.length) UI.appendMsg({ k: 'out', ok: true, title: 'Переманили людей', lines: l }); UI.save(); } return; }
  if (m.op === 'reply') { // ответ на моё предложение
    const pd = IA.pending[m.id]; if (!pd) return; delete IA.pending[m.id];
    const d = IA.DEF[pd.id];
    if (!m.ok) { UI.appendMsg({ k: 'out', ok: false, title: d.hostile ? `${d.n}: не получится` : `${m.from.name} отказался: ${d.n.toLowerCase()}`, lines: m.why ? [m.why] : [] }); if (!d.hostile) IA.bump(pd.uid, -1); UI.save(); return; }
    if (d.ap) UI.s.ap = Math.max(0, UI.s.ap - 1);
    let r = { ok: true };
    if (d.roll) { const rr = d.roll(UI.s, m.rp || {}, pd.f, pd.data); r = E.roll(UI.s, rr.chance); }
    const res = d.done(UI.s, { uid: pd.uid, name: pd.name }, pd.f, r, pd.data, m.rp || {}) || {};
    IA.apply(res, pd.uid, pd.name, `${d.n} — ${pd.name}` + (d.roll ? (r.ok ? ': удача' : ': не вышло') : ''), d.roll ? r.ok : true);
    IA.send('fin', pd.uid, { id: m.id, k: pd.id, f: pd.f, data: pd.data, r: { ok: r.ok, roll: r.roll, chance: r.chance }, out: res.out || {}, fail: res.fail || null });
    if (res.pub) NET.feed(res.pub, true, '', '');
    if (IA.open._on) IA.open(pd.uid);
    return;
  }
  if (m.op === 'fin') { // итог того, что я принял
    if (!def) return;
    if (m.fail) { UI.appendMsg({ k: 'out', ok: false, title: `${def.n} с ${m.from.name} сорвалось`, lines: [m.fail] }); return; }
    const res = def.fin && def.fin(UI.s, m.data || {}, m.f || {}, m.from, m.r || { ok: true }, m.out || {});
    if (res && def.hostile) IA.apply(res, m.from.uid, res.who || 'неизвестный', m.r.ok ? 'На вас наехали: ' + def.n.toLowerCase() : 'Против вас что-то затевали', !m.r.ok);
    else if (res) IA.apply(res, m.from.uid, m.from.name, `${def.n} — ${m.from.name}` + (def.roll ? (m.r.ok ? '' : ': не вышло') : ''), true);
    else UI.save();
  }
};
IA.answer = (m, ok, silent) => {
  IA.incoming = IA.incoming.filter(x => x !== m);
  const s = UI.s, def = IA.DEF[m.k];
  if (!ok) { IA.send('reply', m.from.uid, { id: m.id, ok: false }); UI.renderAll(); return; }
  const why = def.accept && def.accept(s, m.f || {}, m.data || {});
  if (why) { if (!silent) UI.toast(why, 'bad'); IA.send('reply', m.from.uid, { id: m.id, ok: false, why }); if (!silent) UI.renderAll(); return; }
  if (def.onAccept) { const r = def.onAccept(s, m.f || {}, m.data || {}, m.from); if (r) IA.apply(r, m.from.uid, m.from.name, `${def.n} — ${m.from.name}`, true); }
  IA.send('reply', m.from.uid, { id: m.id, ok: true, rp: def.reply ? def.reply(s) : {} });
  UI.renderAll(); UI.save();
};
// входящее предложение — окно, как у событий (если ничего не открыто)
IA.showIncoming = () => {
  const m = IA.incoming[0]; if (!m) return;
  if (!$('#modal').classList.contains('hidden')) { UI.toast(`${UI.esc(m.from.name)} что-то предлагает — кнопка «Взаимодействие»`); return; }
  const def = IA.DEF[m.k];
  UI.modal(`<div class="ev iaev"><div class="evpic ev-friend">${UI.ic('hand')}</div><h3>${UI.esc(m.from.name)}</h3><p>${UI.esc(m.from.name.split(' ')[0])} ${UI.esc(m.text)}.</p><small class="iacat">${UI.esc(def.cat)} · ${UI.esc(def.n)}</small>
    <div class="eopts"><button class="eopt" data-a="1"><b>Принять</b></button><button class="eopt" data-a="0"><b>Отказаться</b></button></div></div>`);
  if (typeof NET !== 'undefined') NET.autoPick();
  $$('#modal [data-a]').forEach(b => b.onclick = () => { UI.closeModal(); IA.answer(m, b.dataset.a === '1'); setTimeout(IA.showIncoming, 300); });
};

// ---------- ежемесячные платежи между игроками ----------
IA.monthly = () => {
  const s = UI.s; if (!s || !NET.on()) return;
  const send = (uid, sum, note) => { const e = NET.byUid(uid); if (!e || sum <= 0) return false; NET.A.money({ to: uid, amount: Math.round(sum), name: NET.me().name, note }, e[0]); return true; };
  const lines = [];
  for (const l of IA.links().slice()) {
    if (l.t === 'debt') {
      const pay = Math.min(l.pay, l.left);
      if (s.st.money >= pay && send(l.uid, pay, 'возврат долга')) { s.st.money -= pay; l.left -= pay; lines.push(`Долг ${l.n}: −${IA.money(pay)} (осталось ${IA.money(l.left)})`); if (l.left <= 0) { IA.links().splice(IA.links().indexOf(l), 1); lines.push('Долг ' + l.n + ' погашен!'); } }
      else lines.push(`Долг ${l.n}: платёж пропущен (${s.st.money < pay ? 'нет денег' : 'друг не в сети'})`);
    } else if (l.t === 'bizshare') {
      const b = s.biz.find(x => x.id === l.biz);
      if (!b) { IA.links().splice(IA.links().indexOf(l), 1); continue; }
      const pay = Math.round(Math.max(0, b.lastProfit) * l.pct / 100);
      if (pay > 0 && send(l.uid, pay, `доля прибыли «${b.n}» (${l.pct}%)`)) { s.st.money -= pay; lines.push(`Доля ${l.n} в «${b.n}»: −${IA.money(pay)}`); }
    } else if (l.t === 'rentout') {
      if (!s.home.shared || s.home.shared !== l.uid) { IA.links().splice(IA.links().indexOf(l), 1); continue; }
      if (s.st.money >= l.pay && send(l.uid, l.pay, 'половина аренды')) { s.st.money -= l.pay; lines.push(`Аренда ${l.n}: −${IA.money(l.pay)}`); }
    }
  }
  if (lines.length) UI.appendMsg({ k: 'news', title: 'Расчёты с друзьями', items: lines.map(t => ({ t })) });
};

// ---------- окно «Взаимодействие» ----------
IA.open = uid => {
  IA.open._on = true;
  const s = UI.s, ps = Object.entries(NET.players).map(([pid, p]) => Object.assign({ pid }, p)).filter(p => p.uid);
  if (!NET.on() || !ps.length) { UI.modal(`${U.head('hand', 'Взаимодействие')}<p class="note" style="padding:16px 18px">${NET.on() ? 'В комнате пока нет других игроков. Отправьте друзьям код комнаты.' : 'Взаимодействие работает в мультиплеере: создайте комнату или войдите по коду (кнопка «Мультиплеер»).'}</p>`); return; }
  IA.target = uid && ps.some(p => p.uid === uid) ? uid : (IA.target && ps.some(p => p.uid === IA.target) ? IA.target : ps[0].uid);
  const p = ps.find(x => x.uid === IA.target), r = IA.rel(p.uid);
  const inc = IA.incoming, pend = Object.values(IA.pending).filter(x => Date.now() - x.t < 600000);
  const links = IA.links().filter(l => l.uid === p.uid);
  const LT = { debt: l => `Вы должны: ${IA.money(l.left)} (по ${IA.money(l.pay)}/мес)`, credit: l => `Вам должны: ${IA.money(l.left)}`, bizshare: l => `Доля ${l.pct}% в вашем «${l.bizN}»`, bizpart: l => `Ваша доля ${l.pct}% в «${l.bizN}»`, rentout: l => `Платите за жильё: ${IA.money(l.pay)}/мес`, rentin: l => `Платит вам за жильё: ${IA.money(l.pay)}/мес` };
  const field = (d, fd) => {
    const v = (IA._f[d.id] || {})[fd.k];
    if (fd.type === 'select') { const o = fd.opts(s); return `<label>${fd.label}<select data-f="${d.id}:${fd.k}">${o.map(x => `<option value="${x[0]}" ${String(v) === String(x[0]) ? 'selected' : ''}>${UI.esc(x[1])}</option>`).join('')}</select></label>`; }
    if (fd.type === 'money') return `<label>${fd.label}, ₽<input type="number" min="1" data-f="${d.id}:${fd.k}" value="${v || IA.M(fd.def)}"></label>`;
    return `<label>${fd.label}<input data-f="${d.id}:${fd.k}" maxlength="40" value="${UI.esc(v || '')}" placeholder="необязательно"></label>`;
  };
  const vals = d => { const f = Object.assign({}, IA._f[d.id] || {}); for (const fd of d.fields || []) { if (f[fd.k] === undefined) { if (fd.type === 'select') { const o = fd.opts(s); f[fd.k] = o.length ? o[0][0] : ''; } else if (fd.type === 'money') f[fd.k] = IA.M(fd.def); else f[fd.k] = ''; } if (fd.type === 'money' || (fd.type === 'select' && typeof f[fd.k] === 'string' && /^\d+$/.test(f[fd.k]))) f[fd.k] = +f[fd.k]; } return f; };
  const cards = IA.DEFS.filter(d => d.cat === IA.cat).map(d => {
    const f = vals(d); let why = null; try { why = d.need ? d.need(s, p, f) : null; } catch (e) { why = 'Недоступно'; }
    return `<div class="iac ${why ? 'off' : ''}"><b>${d.n}</b><small>${d.d}</small>${(d.fields || []).map(fd => field(d, fd)).join('')}
      ${why ? `<em class="iawhy">${UI.esc(why)}</em>` : ''}<button class="btn ${why ? '' : 'primary'} small" data-go="${d.id}" ${why ? 'disabled' : ''}>${d.ap ? '1 действие · ' : ''}Предложить</button></div>`;
  }).join('');
  UI.modal(`${U.head('hand', 'Взаимодействие', 'Предложения другим игрокам: они принимают или отказываются')}
    <div class="ia">
      <aside class="iapl">${ps.map(x => { const rr = IA.rel(x.uid); return `<button class="${x.uid === p.uid ? 'on' : ''}" data-u="${x.uid}">${UI.avatar({ sex: x.sex || 'm', look: x.look || 1 }, 34)}<div><b>${UI.esc(x.name)}</b><small>${UI.esc(x.pos || '')}${x.cityN ? ' · ' + UI.esc(x.cityN) : ''}</small>${UI.bar(rr.att, rr.att >= 70 ? 'good' : rr.att < 35 ? 'bad' : '')}</div></button>`; }).join('')}
        <div class="iainfo"><h5>${UI.esc(p.name.split(' ')[0])} и вы</h5><div class="kv"><span>Отношение</span><b>${Math.round(r.att)}/100</b></div>
          ${links.map(l => `<div class="ialk">${UI.esc((LT[l.t] || (() => ''))(l))}</div>`).join('')}
          ${r.hist.length ? `<div class="nhist">${r.hist.slice(-6).map(h => `<span>${UI.esc(h)}</span>`).join('')}</div>` : ''}</div>
        ${inc.length ? `<div class="iainc"><h5>Вам предлагают</h5>${inc.map((m, i) => `<div><b>${UI.esc(m.from.name)}</b> ${UI.esc(m.text)}<div class="row"><button class="btn small primary" data-in="${i}:1">Принять</button><button class="btn small" data-in="${i}:0">Нет</button></div></div>`).join('')}</div>` : ''}
        ${pend.length ? `<div class="iainc"><h5>Ждут ответа</h5>${pend.map(x => `<div class="small">${UI.esc(IA.DEF[x.id].n)} → ${UI.esc(x.name)}</div>`).join('')}</div>` : ''}
      </aside>
      <div class="iamain"><nav class="mtabs iatabs">${IA.CATS.map(c => `<button class="${c === IA.cat ? 'on' : ''}" data-c="${c}">${c}</button>`).join('')}</nav><div class="iagrid">${cards}</div></div>
    </div>`);
  $('#modal .mbox').classList.add('wide');
  const mclose = $('#modal .mhead .close'); if (mclose) mclose.onclick = () => { IA.open._on = false; UI.closeModal(); };
  $$('#modal [data-u]').forEach(b => b.onclick = () => IA.open(b.dataset.u));
  $$('#modal [data-c]').forEach(b => b.onclick = () => { IA.cat = b.dataset.c; IA.open(p.uid); });
  $$('#modal [data-f]').forEach(el => el.onchange = () => { const [id, k] = el.dataset.f.split(':'); (IA._f[id] = IA._f[id] || {})[k] = el.value; IA.open(p.uid); });
  $$('#modal [data-go]').forEach(b => b.onclick = () => { const d = IA.DEF[b.dataset.go]; IA.offer(p.uid, d.id, vals(d)); });
  $$('#modal [data-in]').forEach(b => b.onclick = () => { const [i, a] = b.dataset.in.split(':'); IA.answer(inc[+i], a === '1'); IA.open(p.uid); });
};
IA._f = {};
