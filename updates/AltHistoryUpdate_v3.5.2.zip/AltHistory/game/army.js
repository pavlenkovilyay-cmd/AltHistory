// «Судьба» — дивизии на карте. Глава государства сам формирует дивизии (нужны военные очки от бюджета армии
// и люди из резерва), обучает их и водит по провинциям: кликнул по значку дивизии → кликнул по провинции.
// Вражеская провинция — штурм: сила атаки против обороны гарнизона и чужих дивизий. Победа — провинция ваша.
// Дивизии на границе держат оборону: без них враг продвигается быстрее.
'use strict';
const ARMY = {};
(() => {
  const cl = E.clamp;
  ARMY.T = {
    modern: {
      inf: { n: 'Стрелковая дивизия', s: 'СД', atk: 6, def: 10, spd: 1, mp: 10, mil: 6, wk: 5, oil: 0 },
      mot: { n: 'Мотострелковая дивизия', s: 'МСД', atk: 9, def: 11, spd: 2, mp: 10, mil: 10, wk: 7, oil: 1 },
      tank: { n: 'Танковая дивизия', s: 'ТД', atk: 18, def: 8, spd: 2, mp: 8, mil: 18, wk: 9, oil: 2 },
      art: { n: 'Артиллерийская бригада', s: 'АБр', atk: 13, def: 5, spd: 1, mp: 5, mil: 9, wk: 5, oil: 0 },
      air: { n: 'Десантно-штурмовая дивизия', s: 'ДШД', atk: 11, def: 9, spd: 2, mp: 7, mil: 13, wk: 8, oil: 1 },
    },
    ww2: {
      inf: { n: 'Стрелковая дивизия', s: 'СД', atk: 5, def: 9, spd: 1, mp: 12, mil: 5, wk: 5, oil: 0 },
      mot: { n: 'Моторизованная дивизия', s: 'МД', atk: 8, def: 9, spd: 2, mp: 11, mil: 9, wk: 7, oil: 1 },
      tank: { n: 'Танковая дивизия', s: 'ТД', atk: 16, def: 7, spd: 2, mp: 9, mil: 16, wk: 9, oil: 2 },
      art: { n: 'Артиллерийский полк', s: 'АП', atk: 11, def: 4, spd: 1, mp: 5, mil: 7, wk: 5, oil: 0 },
      air: { n: 'Горнострелковая дивизия', s: 'ГСД', atk: 9, def: 10, spd: 1, mp: 10, mil: 9, wk: 7, oil: 0 },
    },
  };
  ARMY.tpl = s => ARMY.T[E.ww2(s) ? 'ww2' : 'modern'];
  ARMY.all = s => (s.world.divs = s.world.divs || []);
  ARMY.of = (s, c) => ARMY.all(s).filter(d => d.c === c);
  ARMY.at = (s, p, c) => ARMY.all(s).filter(d => d.p === p && (c === undefined || d.c === c));
  ARMY.uid = () => 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
  ARMY.friend = (s, c, o) => o === c || (GOV.get(s, c) && (GOV.get(s, c).pacts[o] || {}).t === 'alliance') || (s.world.cs[o] && s.world.cs[o].puppetOf === c) || WD.enemies(s, c).some(e => WD.enemies(s, o).includes(e) && WD.atWar(s, o, e));
  ARMY.name = (s, c, t) => { const n = ARMY.of(s, c).filter(d => d.t === t).length + 1; return n + '-я ' + ARMY.tpl(s)[t].n.toLowerCase(); };
  // ---------- стартовая армия, когда игрок пришёл к власти ----------
  ARMY.seed = (s, c) => {
    if (ARMY.of(s, c).length) return;
    const W = s.world, C = W.cs[c], P = M().provinces;
    const n = cl(Math.round(Math.sqrt(Math.max(1, C.st.army)) * 0.55), 3, 22);
    const mine = P.map((p, i) => i).filter(i => W.own[i] === c);
    const border = mine.filter(i => P[i].nb.some(j => W.own[j] !== c && W.own[j] !== undefined));
    const hot = border.filter(i => P[i].nb.some(j => WD.atWar(s, c, W.own[j])));
    const pick = [];
    for (let k = 0; k < n; k++) { const pool = k < n * 0.6 ? (hot.length ? hot : border.length ? border : mine) : [C.cap].filter(x => x >= 0 && W.own[x] === c).concat(mine); pick.push(pool[Math.floor(Math.random() * pool.length)]); }
    const types = ['inf', 'inf', 'mot', 'inf', 'tank', 'art', 'inf', 'mot', 'air'];
    pick.forEach((p, k) => { const t = types[k % types.length]; ARMY.all(s).push({ id: ARMY.uid() + k, c, t, n: ARMY.name(s, c, t), str: 100, org: 80, xp: 10, p, path: [], train: 0 }); });
  };
  // ---------- операции (в мультиплеере идут через хоста) ----------
  ARMY.OPS = {
    seed: (s, a) => ARMY.seed(s, a.c),
    create: (s, a) => {
      const G = GOV.get(s, a.c), T = ARMY.tpl(s)[a.t]; if (!G || !T) return 'Нет правительства';
      if ((G.mil || 0) < T.mil) return 'Не хватает военных очков: нужно ' + T.mil + ', есть ' + Math.floor(G.mil || 0);
      if ((G.mp || 0) < T.mp) return 'Не хватает людей в резерве: нужно ' + T.mp + ' тыс., есть ' + Math.floor(G.mp || 0);
      G.mil -= T.mil; G.mp -= T.mp;
      ARMY.all(s).push({ id: a.id, c: a.c, t: a.t, n: ARMY.name(s, a.c, a.t), str: 100, org: 30, xp: 0, p: a.p, path: [], train: T.wk });
      return '';
    },
    order: (s, a) => { for (const d of ARMY.all(s)) if (a.ids.includes(d.id)) d.path = a.path.slice(); },
    stop: (s, a) => { for (const d of ARMY.all(s)) if (a.ids.includes(d.id)) d.path = []; },
    disband: (s, a) => { const G = GOV.get(s, a.c); s.world.divs = ARMY.all(s).filter(d => { if (a.ids.includes(d.id)) { if (G) G.mp = (G.mp || 0) + Math.round(ARMY.tpl(s)[d.t].mp * d.str / 100 * 0.8); return false; } return true; }); },
  };
  ARMY.op = (name, a) => {
    const s = UI.s; let r;
    try { r = ARMY.OPS[name](s, a); } catch (e) { console.warn('army op', e); }
    if (typeof NET !== 'undefined' && NET.on() && NET.role === 'client' && NET.A.gov) NET.A.gov({ k: 'army', name, a });
    ARMY.draw();
    return r;
  };
  ARMY.onNet = d => { try { ARMY.OPS[d.name](UI.s, d.a); } catch (e) { console.warn(e); } ARMY.draw(); };
  // ---------- путь по провинциям ----------
  ARMY.route = (s, c, from, to) => {
    const W = s.world, P = M().provinces;
    const ok = i => { const o = W.own[i]; return ARMY.friend(s, c, o) || WD.atWar(s, c, o); };
    if (!ok(to)) return null;
    const prev = new Int32Array(P.length).fill(-2); prev[from] = -1; const q = [from];
    for (let h = 0; h < q.length; h++) { const u = q[h]; if (u === to) break; for (const v of P[u].nb) if (prev[v] === -2 && ok(v)) { prev[v] = u; q.push(v); } if (q.length > 12000) break; }
    if (prev[to] === -2) return null;
    const path = []; for (let v = to; v !== from && v >= 0; v = prev[v]) path.unshift(v);
    return path;
  };
  // ---------- неделя ----------
  ARMY.garrison = (s, o, p) => {
    const W = s.world, C = W.cs[o]; if (!C) return 1;
    const front = M().provinces.filter((q, i) => W.own[i] === o).length;
    const base = 5 + Math.sqrt(E.power(s, o)) * 1.6 / Math.pow(Math.max(1, front), 0.15);
    return base * (C.cap === p ? 1.7 : 1) * ((W.core || W.own)[p] === o ? 1.15 : 0.85) * (M().provinces[p].lat && Math.abs(M().provinces[p].lat) > 60 ? 1.2 : 1);
  };
  ARMY.atk = (s, d) => { const T = ARMY.tpl(s)[d.t], G = GOV.get(s, d.c), F = G ? GOV.FORMS[G.form] || {} : {}; let oil = 1; if (T.oil && G) { const r = GOV.res(s, d.c).energy; if (r.bal < 0) oil = 0.65; } return T.atk * d.str / 100 * (0.35 + d.org / 100 * 0.65) * (1 + d.xp / 200) * (F.mil || 1) * oil; };
  ARMY.dfn = (s, d) => { const T = ARMY.tpl(s)[d.t]; return T.def * d.str / 100 * (0.45 + d.org / 100 * 0.55) * (1 + d.xp / 250); };
  ARMY.capture = (s, att, def, p, log) => {
    const W = s.world, w = W.wars.find(x => (x.a === att && x.b === def) || (x.b === att && x.a === def));
    WD.moveStats(s, def, att, 1 / Math.max(2, E.countryProvs(s, def).length), 0.6);
    const isCap = W.cs[def].cap === p;
    W.own[p] = att;
    if (w) { if (w.a === att) { w.took++; w.score++; } else { w.lost++; w.score--; } }
    if (att === W.home) W.gained++; if (def === W.home) W.lost++;
    // чужие дивизии отходят или гибнут
    for (const e of ARMY.at(s, p).filter(x => x.c === def)) { const back = M().provinces[p].nb.find(j => W.own[j] === def); if (back !== undefined) { e.p = back; e.org = Math.max(0, e.org - 30); e.path = []; } else e.str = 0; }
    log({ t: (att === W.home ? 'Наши дивизии взяли ' : W.cs[att].n + ' взяла ') + M().provinces[p].n, good: att === W.home, bad: def === W.home, prov: p });
    if (isCap && w) WD.capitalFell(s, w, def, att, x => log(x));
  };
  ARMY.week = s => {
    const W = s.world, out = [], log = x => out.push(typeof x === 'string' ? { t: x } : x);
    const divs = ARMY.all(s); if (!divs.length) return out;
    const fought = new Set();
    for (const d of divs) {
      if (d.str <= 0) continue;
      if (d.train > 0) { d.train--; d.org = Math.min(100, d.org + 8); continue; }
      const T = ARMY.tpl(s)[d.t]; const G = GOV.get(s, d.c);
      let steps = T.spd + (d.path.length && ARMY.friend(s, d.c, W.own[d.path[0]]) ? 1 : 0);
      while (steps-- > 0 && d.path.length && !fought.has(d.id)) {
        const nx = d.path[0], o = W.own[nx];
        if (ARMY.friend(s, d.c, o)) { d.p = nx; d.path.shift(); continue; }
        if (!WD.atWar(s, d.c, o)) { d.path = []; if (d.c === W.home) log({ t: d.n + ': нельзя войти в ' + W.cs[o].n + ' без войны', bad: true }); break; }
        if (d.org < 25) { d.path = []; if (d.c === W.home) log({ t: d.n + ' выдохлась и остановилась (организация ' + Math.round(d.org) + ')', bad: true }); break; }
        // штурм: все наши, кто стоит рядом и идёт туда же
        const grp = divs.filter(x => x.c === d.c && x.p === d.p && x.path[0] === nx && x.train <= 0 && x.str > 0 && !fought.has(x.id));
        const enemyDivs = ARMY.at(s, nx).filter(x => x.c === o && x.str > 0);
        const A = grp.reduce((a, x) => a + ARMY.atk(s, x), 0);
        const Dv = ARMY.garrison(s, o, nx) + enemyDivs.reduce((a, x) => a + ARMY.dfn(s, x), 0);
        const pw = Math.pow(A, 1.3) / (Math.pow(A, 1.3) + Math.pow(Dv, 1.3));
        const win = Math.random() < pw;
        for (const x of grp) { fought.add(x.id); x.xp = Math.min(100, x.xp + 2); x.org = Math.max(0, x.org - (win ? E.rnd(12, 22) : E.rnd(28, 40))); x.str = Math.max(0, x.str - E.rnd(2, 6) * (win ? 1 : 1.8) * Math.min(2.5, Dv / Math.max(1, A))); }
        for (const e of enemyDivs) { e.org = Math.max(0, e.org - E.rnd(15, 30)); e.str = Math.max(0, e.str - E.rnd(2, 7) * Math.min(2.5, A / Math.max(1, Dv))); }
        if (win) { ARMY.capture(s, d.c, o, nx, log); for (const x of grp) { x.p = nx; x.path.shift(); } }
        else { if (d.c === W.home) log({ t: 'Штурм провинции ' + M().provinces[nx].n + ' отбит (шанс был ~' + Math.round(pw * 100) + '%)', bad: true, prov: nx }); }
        break;
      }
      if (!fought.has(d.id)) { d.org = Math.min(100, d.org + 12); const own = W.own[d.p] === d.c; if (own && d.str < 100 && G && (G.mp || 0) > 1) { const add = Math.min(4, 100 - d.str); d.str += add; G.mp -= add * T.mp / 100; } }
    }
    // погибшие дивизии
    for (const d of divs.filter(x => x.str <= 3)) { if (d.c === W.home) log({ t: d.n + ' разгромлена', bad: true, prov: d.p }); }
    s.world.divs = divs.filter(x => x.str > 3);
    return out;
  };
  // влияние дивизий на обычный ход войны (world.js → mod)
  ARMY.mod = (s, att, def, prov) => {
    const W = s.world; let k = 1;
    if (!W.divs || !W.divs.length) return 1;
    const defs = W.divs.filter(d => d.p === prov && d.c === def && d.train <= 0);
    if (defs.length) { const D = defs.reduce((a, d) => a + ARMY.dfn(s, d), 0); k *= Math.exp(-D / 22); for (const d of defs) { d.org = Math.max(0, d.org - E.rnd(3, 8)); d.str = Math.max(1, d.str - E.rnd(0, 2)); } }
    else if (GOV.get(s, def) && GOV.get(s, def).uid && ARMY.of(s, def).length) k *= 1.25; // дыра во фронте
    if (GOV.get(s, att) && GOV.get(s, att).uid && ARMY.of(s, att).length) k *= 0.35; // наступает игрок — дивизиями
    return k;
  };
  const _week = WD.week;
  WD.week = s => { let a = []; try { a = ARMY.week(s); } catch (e) { console.warn('army week', e); } const r = _week(s) || []; return a.concat(r); };

  // ---------- чат: «сформировать танковую дивизию», «укрепить армию» ----------
  E.A.army = (s, it) => {
    if (!E.isLeader(s)) return { ok: false, impossible: true, title: 'Армией командует глава государства', lines: [], apCost: 0 };
    const G = GOV.ensure(s); ARMY.op('seed', { c: s.world.home });
    const t = E.norm([it.target, it.raw].join(' '));
    const k = /танк|бронетанк/.test(t) ? 'tank' : /мото|механиз/.test(t) ? 'mot' : /артил/.test(t) ? 'art' : /десант|вдв|горн|штурм/.test(t) ? 'air' : 'inf';
    const C = s.world.cs[s.world.home], p = C.cap >= 0 && s.world.own[C.cap] === s.world.home ? C.cap : E.countryProvs(s, s.world.home)[0];
    const err = ARMY.op('create', { c: s.world.home, t: k, p, id: ARMY.uid() });
    if (err) return { ok: false, impossible: true, title: 'Дивизию не сформировать', lines: [err, 'Военные очки копятся каждый месяц от бюджета армии (Правительство → Бюджет).'], apCost: 0 };
    const T = ARMY.tpl(s)[k];
    return { ok: true, title: 'Формируется: ' + T.n, lines: ['Обучение ' + T.wk + ' нед., место — ' + M().provinces[p].n, 'Потом её можно водить по карте: клик по значку дивизии → клик по провинции.'] };
  };

  // ---------- карта ----------
  ARMY.sel = null; // { p, ids }
  ARMY.my = () => UI.s && E.isLeader(UI.s) ? UI.s.world.home : -1;
  ARMY.draw = () => {
    if (!window.MAP || !MAP.svg || !UI.s) return;
    const s = UI.s, W = s.world, divs = W.divs || [];
    let g = MAP.svg.querySelector('g.divs'); if (!g) { g = MAP.el('g', { class: 'divs' }, MAP.svg); }
    let gp = MAP.svg.querySelector('g.dpaths'); if (!gp) { gp = MAP.el('g', { class: 'dpaths' }, MAP.svg); MAP.svg.insertBefore(gp, g); }
    const z = MAP.z || 1, k = 1 / z, P = M().provinces, me = ARMY.my();
    const stacks = new Map(); for (const d of divs) { const key = d.p + ':' + d.c; if (!stacks.has(key)) stacks.set(key, []); stacks.get(key).push(d); }
    let html = '', paths = '';
    for (const [key, ds] of stacks) {
      const [p, c] = key.split(':').map(Number), Pr = P[p]; if (!Pr) continue;
      const C = W.cs[c], mine = c === me, sel = ARMY.sel && ARMY.sel.p === p && mine;
      const str = Math.round(ds.reduce((a, d) => a + d.str, 0) / ds.length), org = Math.round(ds.reduce((a, d) => a + d.org, 0) / ds.length);
      const tr = ds.every(d => d.train > 0);
      const ty = ds.some(d => d.t === 'tank') ? 'tank' : ds.some(d => d.t === 'mot') ? 'mot' : ds[0].t;
      const sym = ty === 'tank' ? '<ellipse cx="-6" cy="0" rx="5" ry="3" fill="none" stroke="#fff" stroke-width="1.3"/>' : ty === 'art' ? '<circle cx="-6" cy="0" r="2.2" fill="#fff"/>' : ty === 'mot' ? '<path d="M-11-4L-1 4M-1-4L-11 4" stroke="#fff" stroke-width="1.3"/><circle cx="-6" cy="5" r="1" fill="#fff"/>' : ty === 'air' ? '<path d="M-11 1q2.5-4 5 0q2.5-4 5 0" stroke="#fff" fill="none" stroke-width="1.3"/>' : '<path d="M-11-4L-1 4M-1-4L-11 4" stroke="#fff" stroke-width="1.3"/>';
      const off = mine ? 0 : 8;
      html += `<g class="dv ${mine ? 'mine' : ''} ${sel ? 'sel' : ''} ${tr ? 'tr' : ''}" data-p="${p}" data-c="${c}" transform="translate(${Pr.x},${Pr.y}) scale(${k.toFixed(4)}) translate(${off},${off})"><rect x="-14" y="-8" width="28" height="16" rx="3" fill="${C.col}" class="dvb"/><rect x="-12.5" y="-6.5" width="12" height="13" rx="1.5" fill="rgba(0,0,0,.35)"/>${sym}<text x="7" y="4" text-anchor="middle">${ds.length}</text><rect x="-14" y="9" width="28" height="2.5" fill="rgba(0,0,0,.35)"/><rect x="-14" y="9" width="${(28 * str / 100).toFixed(1)}" height="2.5" fill="${str > 60 ? '#7bd389' : str > 30 ? '#f0c24d' : '#e06b5f'}"/><rect x="-14" y="12" width="${(28 * org / 100).toFixed(1)}" height="1.6" fill="#9fd0ff"/>${tr ? '<text x="0" y="-11" text-anchor="middle" class="dvt">обучение</text>' : ''}</g>`;
      if (mine) for (const d of ds) if (d.path.length) { const pts = [Pr].concat(d.path.map(i => P[i])); paths += `<polyline points="${pts.map(q => q.x + ',' + q.y).join(' ')}" class="dpath ${sel ? 'sel' : ''}"/><circle cx="${P[d.path[d.path.length - 1]].x}" cy="${P[d.path[d.path.length - 1]].y}" r="${(3.5 * k).toFixed(2)}" class="dtgt"/>`; }
    }
    g.innerHTML = html; gp.innerHTML = paths;
    ARMY.bar();
  };
  ARMY.click = p => {
    const s = UI.s, me = ARMY.my(); if (me < 0) return false;
    const ds = ARMY.at(s, p, me); if (!ds.length) return false;
    if (ARMY.sel && ARMY.sel.p === p) ARMY.sel = null; else ARMY.sel = { p, ids: ds.filter(d => d.train <= 0).map(d => d.id) };
    if (typeof SFX !== 'undefined') SFX.play('tab');
    ARMY.draw(); return true;
  };
  ARMY.target = p => {
    const s = UI.s, me = ARMY.my(); if (!ARMY.sel || me < 0) return false;
    if (p === ARMY.sel.p) { ARMY.sel = null; ARMY.draw(); return true; }
    const path = ARMY.route(s, me, ARMY.sel.p, p);
    if (!path) { UI.toast('Туда не пройти: чужая страна без войны или нет сухопутного пути', 'bad'); return true; }
    if (!ARMY.sel.ids.length) { UI.toast('Выбранные дивизии ещё обучаются', 'bad'); return true; }
    ARMY.op('order', { ids: ARMY.sel.ids, path });
    const o = s.world.own[p], enemy = WD.atWar(s, me, o);
    UI.toast(`Приказ: ${ARMY.sel.ids.length} див. → ${M().provinces[p].n} (${path.length} пров.)${enemy ? ' — штурм!' : ''}`);
    if (typeof SFX !== 'undefined') SFX.play('send');
    ARMY.sel = null; ARMY.draw(); return true;
  };
  ARMY.bar = () => {
    let b = document.getElementById('armyBar');
    const s = UI.s;
    if (!ARMY.sel || !s) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement('div'); b.id = 'armyBar'; const host = document.querySelector('.mapwrap') || document.getElementById('map') || document.body; host.appendChild(b); }
    const ds = ARMY.at(s, ARMY.sel.p, ARMY.my()), T = ARMY.tpl(s);
    b.innerHTML = `<div class="abh"><b>${M().provinces[ARMY.sel.p].n}: ${ds.length} дивиз.</b><button class="gx" id="abX">✕</button></div>
      <div class="abl">${ds.map(d => `<label class="${d.train > 0 ? 'off' : ''}"><input type="checkbox" data-id="${d.id}" ${ARMY.sel.ids.includes(d.id) ? 'checked' : ''} ${d.train > 0 ? 'disabled' : ''}><span>${UI.esc(d.n)}</span><i title="Численность"><em style="width:${d.str}%"></em></i><i class="o" title="Организация"><em style="width:${d.org}%"></em></i><small>${d.train > 0 ? 'обучение ' + d.train + ' нед.' : d.path.length ? '→ ' + M().provinces[d.path[d.path.length - 1]].n : 'стоит'}</small></label>`).join('')}</div>
      <div class="abf"><span>Кликните провинцию — туда пойдут. Вражеская — штурм.</span><button class="btn small" id="abStop">Стоп</button></div>`;
    b.querySelector('#abX').onclick = () => { ARMY.sel = null; ARMY.draw(); };
    b.querySelector('#abStop').onclick = () => { ARMY.op('stop', { ids: ARMY.sel.ids }); };
    b.querySelectorAll('input[data-id]').forEach(x => x.onchange = () => { const id = x.dataset.id; ARMY.sel.ids = x.checked ? ARMY.sel.ids.concat(id) : ARMY.sel.ids.filter(y => y !== id); });
  };
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && ARMY.sel) { ARMY.sel = null; ARMY.draw(); } });
  // перерисовка при зуме и после хода
  document.addEventListener('DOMContentLoaded', () => {
    if (!window.MAP) return;
    const _sz = MAP.sizeLabels; MAP.sizeLabels = () => { _sz(); ARMY.draw(); };
    const _paint = MAP.paint; MAP.paint = (...a) => { const r = _paint(...a); ARMY.draw(); return r; };
  });
})();
