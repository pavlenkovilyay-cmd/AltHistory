// «Судьба» — игровой движок. Нейросеть только понимает намерение и рассказывает историю;
// возможность, шанс, кубик и все цифры считает этот файл (так нельзя «написать себе миллиард»).
'use strict';
const E = {};
const M = () => window.MAPDATA;

// ---------- утилиты ----------
E.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
E.rnd = (a, b) => a + Math.random() * (b - a);
E.ri = (a, b) => Math.floor(E.rnd(a, b + 1));
E.pick = a => a[Math.floor(Math.random() * a.length)];
E.money = v => (v < 0 ? '−' : '') + Math.round(Math.abs(v)).toLocaleString('ru-RU').replace(/,/g, ' ') + ' ₽';
E.short = v => {
  const a = Math.abs(v), s = v < 0 ? '−' : '';
  if (a >= 1e9) return s + (a / 1e9).toFixed(a >= 1e10 ? 0 : 1).replace('.', ',') + ' млрд';
  if (a >= 1e6) return s + (a / 1e6).toFixed(a >= 1e7 ? 0 : 1).replace('.', ',') + ' млн';
  if (a >= 1e4) return s + Math.round(a / 1e3) + ' тыс';
  return s + Math.round(a).toLocaleString('ru-RU');
};
E.norm = t => (t || '').toLowerCase().replace(/ё/g, 'е');
const MONTHS = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
const MONTHS1 = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
E.dateStr = d => { d = new Date(d); return d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear(); };
E.monthGen = d => { d = new Date(d); return MONTHS[d.getMonth()] + ' ' + d.getFullYear(); };
E.monthStr = d => { d = new Date(d); return MONTHS1[d.getMonth()] + ' ' + d.getFullYear(); };
E.age = s => { const b = new Date(s.ch.birth), d = new Date(s.date); let a = d.getFullYear() - b.getFullYear(); if (d.getMonth() < b.getMonth() || (d.getMonth() === b.getMonth() && d.getDate() < b.getDate())) a--; return a; };
E.years = n => { const m10 = n % 10, m100 = n % 100; return n + ' ' + (m10 === 1 && m100 !== 11 ? 'год' : (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14) ? 'года' : 'лет')); };
E.he = (s, m, f) => (s.ch.sex === 'f' ? f : m);
E.trait = (s, id) => s.ch.traits.includes(id);
E.tmod = (s, key, def = 0) => s.ch.traits.reduce((a, id) => { const t = D.TRAITS.find(x => x.id === id); return t && t.mod[key] !== undefined ? (typeof def === 'number' && def === 1 ? a * t.mod[key] : a + t.mod[key]) : a; }, def);
E.city = s => M().start[s.ch.city] || M().start[0];
E.startName = (s, c) => (s && s.era === 'ww2' && c.n2) || c.n;
E.cityName = s => s.ch.cityName || E.startName(s, E.city(s));
E.k = s => (D.ERA[s.era || 'modern'] || D.ERA.modern).k;
E.dif = s => D.DIFF[s.diff || 'normal'] || D.DIFF.normal;
E.cpi = s => (s.world && s.world.cpi) || 1;
E.m = (s, v) => v * E.k(s) * E.cpi(s); // «современные» рубли → рубли эпохи с учётом инфляции
E.cityCost = s => 1 + (E.city(s).cost - 1) * (E.ww2(s) ? 0.4 : 0.65);
E.citySal = s => 1 + (E.city(s).sal - 1) * (E.ww2(s) ? 0.3 : 0.65);
E.price = (s, base) => { const v = base * E.cityCost(s) * E.k(s) * E.cpi(s) * E.dif(s).cost; return v >= 100 ? Math.round(v) : Math.round(v * 100) / 100; };
E.salary = (s, base, fixed) => { const v = base * (fixed ? 1 : E.citySal(s)) * E.k(s) * Math.pow(E.cpi(s), 0.9) * E.dif(s).sal; return v >= 100 ? Math.round(v) : Math.round(v * 100) / 100; };
E.ww2 = s => s.era === 'ww2';
E.sk = (s, k) => s.st.sk[k] || 0;

// ---------- новая игра ----------
E.newGame = o => {
  const era = o.era || 'modern'; D.useEra(era);
  const bg = D.BACKGROUND[o.bg] || D.BACKGROUND.mid;
  const st0 = D.ERA[era].start;
  const start = new Date(st0[0], st0[1], st0[2]); // понедельник
  const birth = new Date(start); birth.setFullYear(start.getFullYear() - o.age); birth.setDate(birth.getDate() - E.ri(10, 300));
  const sk = { str: 30, int: 30, cha: 30, craft: 20, biz: 10 };
  sk.int += [0, 0, 5, 10, 18, 25][o.edu] || 0;
  if (o.age > 25) { sk.craft += 8; sk.biz += 5; }
  for (const id of o.traits) { const t = D.TRAITS.find(x => x.id === id); if (!t) continue; for (const k of Object.keys(D.SKILLS)) if (t.mod[k]) sk[k] += t.mod[k]; }
  for (const k in sk) sk[k] = E.clamp(sk[k] + E.ri(-4, 4), 5, 95);
  const s = {
    v: 2, era, diff: o.diff || 'normal', turn: 0, ap: 3, date: start.toISOString(), over: false,
    ch: { name: o.name, surname: o.surname, sex: o.sex, birth: birth.toISOString(), city: o.city, cityName: o.cityName || '', bg: o.bg, edu: o.edu, traits: o.traits, bio: o.bio || '', look: E.ri(0, 9999) },
    st: { money: Math.round(bg.money * D.ERA[era].k * D.DIFF[o.diff || 'normal'].sal), happy: bg.happy, health: E.clamp(80 + (E.trait({ ch: o }, 'strong') ? 12 : 0) - (E.trait({ ch: o }, 'sickly') ? 18 : 0) - Math.max(0, o.age - 40) * 0.5, 20, 100), rep: 10, stress: 20, sk },
    job: null, pol: null, election: null, study: null,
    home: { type: o.age < 18 ? 'parents' : (o.age >= 25 && bg.home === 'parents' ? 'room' : bg.home) },
    biz: [], props: [], loans: [], items: [], inv: { deposit: 0, stocks: 0, crypto: 0 },
    rel: [{ name: 'Мама', role: 'мать', att: 75 }, { name: 'Папа', role: 'отец', att: 65 }],
    focus: null, focusDone: [], flags: {},
    log: [], chat: [], facts: [], summary: '', sumAt: 0, open: [], chron: [],
    world: null, monthReport: null,
  };
  if (s.home.type === 'flat_rent') s.flags.startRent = true;
  E.fact(s, `${o.name} ${o.surname}, ${E.years(o.age)}, ${o.sex === 'f' ? 'родилась' : 'родился'} в городе ${E.cityName(s)}; ${bg.n.toLowerCase()}; образование: ${D.EDU[o.edu]}.`);
  if (o.traits.length) E.fact(s, 'Черты характера: ' + o.traits.map(id => D.TRAITS.find(t => t.id === id).n.toLowerCase()).join(', ') + '.');
  if (o.bio) E.fact(s, 'О себе: ' + o.bio.slice(0, 300));
  E.cur = s;
  WD.init(s, era);
  L.startHome(s); L.init(s);
  if (era === 'ww2') s.rel.push({ name: 'Профорг', role: 'коллега', att: 50 });
  return s;
};

E.fact = (s, t) => { if (!t) return; s.facts.push({ d: s.date, t }); if (s.facts.length > 40) s.facts.splice(2, s.facts.length - 40); };
E.logAdd = (s, kind, text, extra) => { s.log.push(Object.assign({ d: s.date, kind, text }, extra || {})); if (s.log.length > 1500) s.log.shift(); };

// ---------- мир (карта, владельцы провинций, войны) ----------
E.countryProvs = (s, ci) => s.world.own.reduce((a, o, i) => (o === ci ? (a.push(i), a) : a), []);
E.findCountry = (s, text) => {
  const t = E.norm(text); if (!t) return -1;
  const cs = s.world.cs; let best = -1, bl = 0;
  cs.forEach((c, i) => {
    const n = E.norm(c.n);
    const stem = n.length > 5 ? n.slice(0, n.length - 2) : n;
    if ((t.includes(stem) || n.includes(t)) && stem.length > bl && E.countryProvs(s, i).length) { best = i; bl = stem.length; }
  });
  // прилагательные: «украинский», «немецкий»…
  const ADJ = { 'сша': 'США', 'америк': 'США', 'штат': 'США', 'герман': 'Германия', 'немец': 'Германия', 'украин': 'Украина', 'польш': 'Польша', 'польск': 'Польша', 'китай': 'Китай', 'китаи': 'Китай', 'америк': 'Соединённые Штаты Америки', 'сша': 'Соединённые Штаты Америки', 'штат': 'Соединённые Штаты Америки', 'франц': 'Франция', 'британ': 'Великобритания', 'англи': 'Великобритания', 'япон': 'Япония', 'турц': 'Турция', 'казах': 'Казахстан', 'белорус': 'Беларусь', 'беларус': 'Беларусь', 'грузи': 'Грузия', 'финлянд': 'Финляндия', 'финск': 'Финляндия', 'эстон': 'Эстония', 'латви': 'Латвия', 'литв': 'Литва', 'монгол': 'Монголия', 'норвег': 'Норвегия', 'швец': 'Швеция', 'итал': 'Италия', 'испан': 'Испания', 'иран': 'Иран', 'инди': 'Индия', 'корей': 'Республика Корея', 'канад': 'Канада', 'бразил': 'Бразилия', 'мексик': 'Мексика', 'азербайдж': 'Азербайджан', 'армян': 'Армения', 'армени': 'Армения', 'узбек': 'Узбекистан', 'молдав': 'Молдова', 'румын': 'Румыния' };
  if (best < 0) for (const k in ADJ) if (t.includes(k)) { const i = cs.findIndex((c, j) => !c.dead && E.norm(c.n).startsWith(E.norm(ADJ[k]).slice(0, 6))); if (i >= 0) return i; }
  if (best < 0 && /ссср|совет/.test(t)) best = cs.findIndex(c => c.id === '643' && !c.dead);
  if (best < 0 && /рейх|немц|герман/.test(t)) best = cs.findIndex(c => c.id === '276' && !c.dead);
  return best;
};
E.borders = (s, a, b) => M().edges.some(e => { const oa = s.world.own[e.a], ob = s.world.own[e.b]; return (oa === a && ob === b) || (oa === b && ob === a); });
E.fronts = (s, a, b) => M().edges.filter(e => { const oa = s.world.own[e.a], ob = s.world.own[e.b]; return (oa === a && ob === b) || (oa === b && ob === a); });

// ---------- экономика ----------
E.homeRent = s => { const h = D.HOMES[s.home.type]; return h ? E.price(s, h.rent) : 0; };
E.living = s => Math.round(E.price(s, s.home.type === 'parents' ? 9000 : 17000) * E.tmod(s, 'thrift', 1) * (s.world && s.world.wars.some(w => w.a === s.world.home || w.b === s.world.home) && E.ww2(s) ? 1.4 : 1));
E.loanPay = s => s.loans.reduce((a, l) => a + l.monthly, 0);
E.upkeep = s => s.items.reduce((a, i) => a + (i.upkeep || 0), 0) + (s.flags.gym ? E.price(s, 3000) : 0);
E.monthlyCost = s => E.living(s) + E.homeRent(s) + E.loanPay(s) + E.upkeep(s) + (s.study ? Math.round(s.study.monthly || 0) : 0) + (E.utilities ? E.utilities(s) + E.transit(s) + E.carUp(s) + L.kidCost(s) : 0);
E.jobPay = s => (s.job ? s.job.salary : 0) + (s.pol ? E.salary(s, D.POL_SAL[s.pol.id] || 0) : 0);
E.bizIncome = s => s.biz.reduce((a, b) => a + b.lastProfit, 0) + s.props.reduce((a, p) => a + (p.rentOut ? p.rentIncome : 0), 0);
E.depRate = s => E.ww2(s) ? 0.03 : 0.12;
E.monthlyIncome = s => E.jobPay(s) + E.bizIncome(s) + Math.round(s.inv.deposit * E.depRate(s) / 12) + (L.spouseIncome ? L.spouseIncome(s) : 0);
E.netWorth = s => (s.car ? s.car.value * 0.7 : 0) + (s.home.owned ? s.home.value || 0 : 0) * 0 + s.st.money + s.inv.deposit + s.inv.stocks + s.inv.crypto + s.biz.reduce((a, b) => a + b.value, 0) + s.props.reduce((a, p) => a + p.value, 0) + s.items.reduce((a, i) => a + i.value * 0.5, 0) - s.loans.reduce((a, l) => a + l.left, 0) + (s.home.owned ? s.home.value || 0 : 0);
E.position = s => s.pol && !(s.pol.id === 'mundep' && s.job) ? s.pol.n : (s.job ? s.job.title : (s.study ? 'Учится' : (E.age(s) >= 65 ? 'Пенсионер' : 'Безработный')));

// ---------- шанс и кубик ----------
// base — сложность «по умолчанию» (0..100: чем выше, тем легче), к нему навыки, черты, репутация
E.chance = (s, base, sk, extra = 0) => {
  let c = base + extra + E.tmod(s, 'luck', 0) + E.dif(s).chance;
  if (sk) c += (E.sk(s, sk) - 40) * 0.45;
  if (s.st.stress > 70) c -= 6;
  if (s.st.health < 30) c -= 8;
  return Math.round(E.clamp(c, s.diff === 'hard' ? 2 : 3, s.diff === 'hard' ? 92 : 96));
};
E.roll = (s, chance) => {
  let r = E.ri(1, 100);
  if (E.trait(s, 'risky')) r = Math.random() < 0.5 ? Math.max(1, r - 8) : Math.min(100, r + 8);
  return { chance, roll: r, ok: r <= chance, crit: r <= Math.max(2, chance / 6), fail: r >= 97 };
};

// ---------- эффекты ----------
// fx: money, happy, health, rep, stress, perf, навыки (str,int,cha,craft,biz), moneyJob (доля зарплаты), moneyPct, bizHealth, newPartner
E.apply = (s, fx, why) => {
  const lines = [];
  if (!fx) return lines;
  const st = s.st;
  const add = (k, v, lo, hi, label) => { if (!v) return; const o = st[k]; st[k] = E.clamp(o + v, lo, hi); const d = Math.round(st[k] - o); if (d) lines.push(label + ' ' + (d > 0 ? '+' : '') + d); };
  if (fx.moneyJob && s.job) fx = Object.assign({}, fx, { money: (fx.money || 0) + Math.round(s.job.salary * fx.moneyJob) });
  if (fx.moneyPct) fx = Object.assign({}, fx, { money: (fx.money || 0) + Math.round(Math.max(0, st.money) * fx.moneyPct) });
  if (fx.money) { st.money += Math.round(fx.money); lines.push('Деньги ' + (fx.money > 0 ? '+' : '') + E.money(fx.money)); }
  add('happy', fx.happy, 0, 100, 'Счастье');
  add('health', fx.health ? fx.health * (fx.health < 0 && E.trait(s, 'strong') ? 0.7 : 1) * (fx.health < 0 && E.trait(s, 'sickly') ? 1.3 : 1) : 0, 0, 100, 'Здоровье');
  add('rep', fx.rep, 0, 100, 'Репутация');
  if (fx.stress) st.stress = E.clamp(st.stress + fx.stress * (fx.stress > 0 ? E.tmod(s, 'stress', 1) : 1), 0, 100);
  if (fx.perf && s.job) s.job.perf = E.clamp(s.job.perf + fx.perf, 0, 100);
  for (const k of Object.keys(D.SKILLS)) if (fx[k]) { const o = st.sk[k]; st.sk[k] = E.clamp(o + fx[k], 0, 100); const d = Math.round(st.sk[k] - o); if (d) lines.push(D.SKILLS[k] + ' ' + (d > 0 ? '+' : '') + d); }
  if (fx.bizHealth) for (const b of s.biz) b.health = E.clamp(b.health + fx.bizHealth, 0, 100);
  if (fx.newPartner && !s.rel.some(r => r.role === 'партнёр' || r.role === 'супруг(а)')) {
    const nm = E.pick(s.ch.sex === 'f' ? ['Артём', 'Максим', 'Илья', 'Денис', 'Кирилл', 'Антон', 'Егор', 'Роман'] : ['Алина', 'Дарья', 'Полина', 'Ксения', 'Вика', 'Аня', 'Маша', 'Лера']);
    s.rel.push({ name: nm, role: 'знакомая(ый)', att: 45 }); lines.push('Новое знакомство: ' + nm);
  }
  return lines;
};

// ---------- поиск по справочникам ----------
E.match = (list, text) => {
  const t = E.norm(text); if (!t) return null;
  let best = null, bl = 0;
  for (const it of list) for (const k of it.kw) if (t.includes(k) && k.length > bl) { best = it; bl = k.length; }
  if (!best) for (const it of list) if (t.includes(E.norm(it.n).slice(0, 6))) return it;
  return best;
};

// ============================================================================
//  ДЕЙСТВИЯ. intent: {type, target, amount, tier, org, person, difficulty, illegal, stakes}
//  Возвращает исход: {ok, title, lines[], roll?, apCost, note (для рассказчика)}
// ============================================================================
E.ACTIONS = ['crime', 'policy', 'job', 'quit', 'work', 'promote', 'study', 'rest', 'travel', 'health', 'buy', 'home', 'biz_start', 'biz_sell', 'invest', 'withdraw', 'loan', 'repay', 'social', 'date', 'marry', 'elect', 'war', 'peace', 'army', 'move', 'other'];

E.act = (s, it) => {
  if (s.over) return { ok: false, title: 'Жизнь окончена', lines: [], apCost: 0 };
  if (s.ap <= 0 && it.type !== 'chat') return { ok: false, blocked: true, title: 'На этой неделе сил больше нет', lines: ['Нажмите «Следующая неделя», чтобы продолжить.'], apCost: 0 };
  if (s.mp && s.mp.role === 'client' && ['war', 'peace', 'army', 'policy'].includes(it.type)) return { ok: false, impossible: true, title: 'В мультиплеере это решает хост', lines: ['Войны, мир, армия и государственные указы меняют общий мир — их пока может делать только тот, кто создал комнату.'], apCost: 0 };
  const fn = E.A[it.type] || E.A.other;
  const out = fn(s, it) || { ok: false, title: 'Ничего не вышло', lines: [] };
  if (s.election && out.ok && ['work', 'social', 'other', 'date'].includes(it.type)) { s.flags.campaign = Math.min(20, (s.flags.campaign || 0) + 3); out.lines = (out.lines || []).concat(['Предвыборная кампания: шанс +3%']); }
  if (out.apCost === undefined) out.apCost = 1;
  s.ap = Math.max(0, s.ap - out.apCost);
  if (out.fx) out.lines = (out.lines || []).concat(E.apply(s, out.fx));
  if (out.factAdd) E.fact(s, out.factAdd);
  E.checkFocus(s, out);
  E.checkDeath(s, out);
  return out;
};

E.A = {};
E.A.chat = () => ({ ok: true, chat: true, title: '', lines: [], apCost: 0 });
const fail = (title, lines, extra) => Object.assign({ ok: false, title, lines: lines || [], apCost: 0, impossible: true }, extra || {});

E.A.job = (s, it) => {
  const age = E.age(s);
  if (age < 14) return fail('Слишком рано работать', ['Официально работать можно с 14 лет.']);
  const text = [it.target, it.org, it.raw].join(' ');
  let job = E.match(D.JOBS, text);
  let title, base, diff, req = {};
  if (job) { title = job.ladder[0]; base = job.sal; diff = job.diff; req = job.req || {}; }
  else {
    const tier = E.clamp(Math.round(it.tier || 2), 1, 5), T = D.TIERS[tier];
    title = (it.target || 'Сотрудник').replace(/^./, c => c.toUpperCase()).slice(0, 40); base = T.sal; diff = T.diff; req = { edu: T.edu };
  }
  if (s.job && job && s.job.id === job.id) return fail('Вы уже работаете здесь', ['Должность: ' + s.job.title]);
  if (req.age && age < req.age) return fail('Не берут по возрасту', ['Нужно ' + E.years(req.age) + ' и старше.']);
  if (req.edu && s.ch.edu < req.edu) return fail('Не подходит образование', ['Требуется: ' + D.EDU[req.edu] + '. У вас: ' + D.EDU[s.ch.edu] + '.', 'Сначала стоит поучиться.']);
  for (const k of Object.keys(D.SKILLS)) if (req[k] && E.sk(s, k) < req[k] - 10) return fail('Не хватает навыка', [D.SKILLS[k] + ': нужно около ' + req[k] + ', у вас ' + E.sk(s, k) + '.']);
  const r = E.roll(s, E.chance(s, 88 - diff, job ? job.sk : 'cha', (E.sk(s, 'cha') - 40) * 0.15 + s.st.rep * 0.1 + (age < 18 ? -10 : 0)));
  if (!r.ok) return { ok: false, title: 'Отказ', roll: r, lines: ['Работодатель выбрал другого кандидата.'], fx: { happy: -3, stress: 3 } };
  const fixedJ = job && job.fixed;
  const sal = E.ww2(s) ? Math.round(E.salary(s, base, fixedJ) * E.rnd(0.92, 1.1) * (r.crit ? 1.12 : 1)) : Math.round(E.salary(s, base, fixedJ) * E.rnd(0.92, 1.1) * (r.crit ? 1.12 : 1) / 100) * 100;
  if (s.job) L.careerAdd(s);
  const old = s.job;
  s.job = { id: job ? job.id : 'custom', title, org: (it.org || '').slice(0, 40), salary: sal, level: 0, perf: 45, months: 0, weeks: 0, sk: job ? job.sk : 'cha', ladder: job ? job.ladder : [title, 'Старший ' + title.toLowerCase(), 'Руководитель'], risky: job && job.risky, army: !!(job && job.army) };
  return { ok: true, crit: r.crit, title: 'Приняты на работу', roll: r, lines: [title + (s.job.org ? ' — ' + s.job.org : ''), 'Зарплата: ' + E.money(sal) + ' в месяц' + (old ? ' (прежнюю работу оставили)' : '')], fx: { happy: 6 + (r.crit ? 4 : 0), stress: 4 }, factAdd: `С ${E.monthGen(s.date)} работает: ${title}${s.job.org ? ' (' + s.job.org + ')' : ''}, ${E.money(sal)}/мес.` };
};

E.A.quit = s => {
  if (!s.job) return fail('Вы и так не работаете', []);
  const t = s.job.title; s.job = null;
  return { ok: true, title: 'Уволились', lines: ['Больше не ' + t.toLowerCase()], fx: { happy: 3, stress: -10 }, factAdd: `${E.monthStr(s.date)}: уволился с должности «${t}».` };
};

E.A.work = s => {
  if (!s.job && !s.pol) return fail('Работы нет', ['Сначала найдите работу.']);
  const r = E.roll(s, E.chance(s, 70, s.job ? s.job.sk : 'cha', E.tmod(s, 'work', 0)));
  if (s.pol && !s.job) { const fx = r.ok ? { rep: E.ri(2, 4), stress: 6 } : { rep: -1, stress: 8 }; return { ok: r.ok, roll: r, title: r.ok ? 'Плодотворная неделя' : 'Неделя впустую', lines: [r.ok ? 'Встречи, указы, поездки по району.' : 'Бумаги, совещания и ничего толком.'], fx }; }
  const sk = {}; sk[s.job.sk] = r.ok ? 1 : 0;
  return { ok: r.ok, roll: r, title: r.ok ? 'Работали на совесть' : 'Старались, но день не задался', lines: [r.ok ? 'Начальство заметило старания.' : 'Ошибка в работе, пришлось переделывать.'], fx: Object.assign({ perf: r.ok ? E.ri(8, 15) : -4, stress: 7, health: -0.5, happy: r.ok ? 1 : -2 }, sk) };
};

E.A.promote = s => {
  if (s.pol) return fail('Повышение — только через выборы', ['Используйте «Баллотироваться».']);
  const j = s.job; if (!j) return fail('Работы нет', []);
  if (j.level >= j.ladder.length - 1) return fail('Выше этой должности здесь некуда', ['Можно сменить работу, открыть бизнес или пойти в политику.']);
  if (j.months < 3) return fail('Рано просить повышение', ['Вы на этой должности меньше трёх месяцев.']);
  const r = E.roll(s, E.chance(s, 18 + j.perf * 0.55 + Math.min(j.months, 12) * 1.5 - j.level * 7, j.sk, (E.sk(s, 'cha') - 40) * 0.2));
  if (!r.ok) return { ok: false, roll: r, title: 'Повышения не дали', lines: ['«Поработайте ещё, посмотрим».'], fx: { happy: -4, perf: -5 } };
  j.level++; j.title = j.ladder[j.level]; j.months = 0; j.perf = 40;
  const jd = D.JOBS.find(x => x.id === j.id);
  if (jd && jd.lsal) j.salary = E.salary(s, jd.lsal[Math.min(j.level, jd.lsal.length - 1)]);
  else { const inc = E.rnd(1.2, 1.35); j.salary = E.ww2(s) ? Math.round(j.salary * inc) : Math.round(j.salary * inc / 100) * 100; }
  return { ok: true, roll: r, crit: r.crit, title: 'Повышение!', lines: ['Новая должность: ' + j.title, 'Зарплата: ' + E.money(j.salary)], fx: { happy: 10, rep: 3 }, factAdd: `${E.monthStr(s.date)}: повышен до «${j.title}» (${E.money(j.salary)}/мес).` };
};

E.A.study = (s, it) => {
  if (s.study) return fail('Вы уже учитесь', [s.study.n + ': осталось ' + s.study.weeks + ' нед.']);
  const c = E.match(D.COURSES, [it.target, it.raw].join(' ')) || D.COURSES.find(x => x.id === 'eng');
  if (c.reqEdu && s.ch.edu < c.reqEdu) return fail('Не примут', ['Нужно образование: ' + D.EDU[c.reqEdu] + '.']);
  if (c.edu && s.ch.edu >= c.edu) return fail('Такое образование у вас уже есть', []);
  const cost = E.price(s, c.cost);
  const upfront = c.weeks > 40 ? Math.round(cost / Math.ceil(c.weeks / 4.33)) : cost;
  if (s.st.money < upfront) return fail('Не хватает денег на учёбу', ['Нужно ' + E.money(upfront) + (c.weeks > 40 ? ' (первый платёж)' : '') + '.']);
  const weeks = Math.round(c.weeks / E.tmod(s, 'study', 1));
  s.study = { id: c.id, n: c.n, weeks, total: weeks, gain: c.gain, edu: c.edu || 0, flag: c.flag || null, monthly: c.weeks > 40 ? upfront : 0 };
  return { ok: true, title: 'Поступили: ' + c.n, lines: ['Срок: ' + weeks + ' нед.', c.weeks > 40 ? 'Оплата: ' + E.money(upfront) + ' в месяц' : 'Оплачено: ' + E.money(cost), 'Учёба отнимает одно действие в неделю.'], fx: { money: -upfront, happy: 2 }, factAdd: `${E.monthStr(s.date)}: начал учёбу — ${c.n}.` };
};

E.A.rest = (s, it) => {
  const t = E.norm([it.target, it.raw].join(' '));
  let cost = 0, happy = 5, stress = -12, title = 'Отдохнули';
  if (/отпуск|море|турци|египет|за границ|путешеств/.test(t)) { cost = E.price(s, 80000); happy = 16; stress = -35; title = 'Отпуск'; }
  else if (/бар|клуб|ресторан|вечеринк|тусов/.test(t)) { cost = E.price(s, 4000); happy = 7; stress = -10; title = 'Вечер в городе'; }
  else if (/кино|театр|концерт|музей/.test(t)) { cost = E.price(s, 1800); happy = 6; stress = -8; title = 'Культурный вечер'; }
  else if (/дач|рыбалк|природ|лес|поход/.test(t)) { cost = E.price(s, 1500); happy = 7; stress = -14; title = 'На природе'; }
  if (it.amount > 0) cost = Math.min(it.amount, Math.max(cost * 3, 5000));
  if (s.st.money < cost) return fail('Не хватает денег', ['Нужно ' + E.money(cost) + '.']);
  return { ok: true, title, lines: [], fx: { money: -cost, happy, stress, health: 0.5 } };
};

E.A.travel = (s, it) => {
  const cost = it.amount > 0 ? E.clamp(it.amount, E.m(s, 20000), E.m(s, 600000)) : E.price(s, 120000);
  if (s.st.money < cost) return fail('Поездка не по карману', ['Нужно около ' + E.money(cost) + '.']);
  const lm = M().landmarks.find(l => E.norm(it.target || '').includes(E.norm(l.n).slice(0, 5)));
  return { ok: true, title: 'Путешествие' + (it.target ? ': ' + it.target : ''), lines: lm ? ['Повидали: ' + lm.n] : [], fx: { money: -cost, happy: 18, stress: -35, int: 1 }, apCost: 2, factAdd: `${E.monthStr(s.date)}: путешествовал — ${it.target || 'поездка'}.`, landmark: lm ? lm.n : null };
};

E.A.health = (s, it) => {
  const t = E.norm([it.target, it.raw].join(' '));
  if (/врач|больниц|поликлин|лечи|обследов|анализ|стоматолог|зуб/.test(t)) {
    const cost = E.price(s, 6000);
    if (s.st.money < cost) return { ok: true, title: 'Поликлиника по полису', lines: ['Очередь, талончик, но врача всё-таки увидели.'], fx: { health: E.ri(2, 6), stress: 3 } };
    return { ok: true, title: 'Сходили к врачу', lines: [], fx: { money: -cost, health: E.ri(6, 14), stress: -3 } };
  }
  if (/курить|пить|алкогол|сигарет/.test(t)) return { ok: true, title: 'Решили завязать', lines: [], fx: { health: 4, happy: -2, stress: 6 } };
  s.flags.gym = true;
  return { ok: true, title: 'Начали заниматься спортом', lines: ['Абонемент: ' + E.money(E.price(s, 3000)) + ' в месяц'], fx: { health: 3, str: 2, stress: -6, happy: 2 } };
};

E.A.buy = (s, it) => {
  const tt = E.norm([it.target, it.raw].join(' '));
  const car = L.CARS(s).find(c => tt.includes(E.norm(c.n).split(/[ (]/)[0].slice(0, 5)) || (c.id === 'granta' && /лад|машин|авто/.test(tt) && !/б\/у|подерж/.test(tt)) || (c.id === 'priora' && /б\/у|подерж/.test(tt)));
  if (car && /машин|авто|лад|ваз|kia|киа|haval|хавал|тойот|toyot|bmw|бмв|мерс|mercedes|велосипед|мотоцикл|эмк|газ|зис/.test(tt)) { const r = L.buyCar(s, car.id); return r.ok ? r : Object.assign({ impossible: true, apCost: 0 }, r); }
  const fu = L.FURN(s).find(f => tt.includes(E.norm(f.n).split(' ')[0].slice(0, 5)));
  if (fu) { const tier = /премиум|дорог|лучш|элит/.test(tt) ? 'pre' : /дешев|эконом|б\/у/.test(tt) ? 'eco' : 'std'; const r = L.buyFurn(s, fu.id, tier); return r.ok ? r : Object.assign({ impossible: true, apCost: 0 }, r); }
  const cat = E.match(D.ITEMS, [it.target, it.raw].join(' '));
  let price = cat ? E.price(s, cat.price) : E.price(s, 20000);
  if (it.amount > 0) price = cat ? E.clamp(it.amount, price * 0.4, price * 4) : E.clamp(it.amount, E.m(s, 1000), E.m(s, 300000));
  const name = cat ? cat.n : (it.target || 'Покупка').slice(0, 30);
  if (s.st.money < price) return fail('Не хватает денег', [name + ' стоит около ' + E.money(price) + ', у вас ' + E.money(s.st.money) + '.', 'Можно взять кредит.']);
  const inc = Math.max(E.m(s, 20000), E.monthlyIncome(s));
  const happy = Math.round(E.clamp((cat ? cat.happy : 3) * Math.min(1.6, Math.sqrt(price / inc)), 1, 18));
  s.items.push({ n: name, value: price, upkeep: cat && cat.upkeep ? E.price(s, cat.upkeep) : 0, d: s.date });
  return { ok: true, title: 'Покупка: ' + name, lines: ['Цена: ' + E.money(price)].concat(cat && cat.upkeep ? ['Содержание: ' + E.money(E.price(s, cat.upkeep)) + '/мес'] : []), fx: Object.assign({ money: -price, happy }, cat && cat.skill ? cat.skill : {}), factAdd: price > 100000 ? `${E.monthStr(s.date)}: купил ${name.toLowerCase()} за ${E.money(price)}.` : null };
};

E.A.home = (s, it) => {
  const t = E.norm([it.target, it.raw].join(' '));
  if (/родител|к маме|домой к/.test(t)) { if (s.home.type === 'parents') return fail('Вы и так живёте с родителями', []); return Object.assign(L.toParents(s), { fx: { happy: -3 } }); }
  const kind = /дом|коттедж|изб|особняк|дач/.test(t) && !/домой/.test(t) ? 'house' : /комнат|коммунал/.test(t) ? 'room' : 'flat';
  const cls = /хрущ|дешев|дряхл|стар|бедн|убит|эконом/.test(t) ? 'poor' : /элит|богат|красив|роскош|бизнес-класс|премиум|сталинк|пентхаус|коттедж|особняк/.test(t) ? 'rich' : 'mid';
  const buy = /куп|ипотек|приобрес|в собственн/.test(t), mort = /ипотек|кредит/.test(t);
  const ls = L.listings(s).filter(l => l.kind === kind && (kind === 'room' || l.cls === cls) && (buy ? l.deal !== 'rent' && l.deal !== 'order' : l.deal !== 'sale'));
  const l = ls[0] || L.listings(s).filter(l => l.kind === kind && (buy ? l.deal !== 'rent' : l.deal !== 'sale'))[0];
  if (!l) return fail('Подходящих объявлений нет', ['Откройте раздел «Жильё» — там все варианты в разных городах.']);
  const mode = buy ? 'sale' : (l.deal === 'order' ? 'order' : 'rent');
  const r = L.take(s, l.id, mode, mort);
  if (!r.ok) return Object.assign({ impossible: !r.roll, apCost: r.roll ? 1 : 0 }, r);
  return r;
};

E.A.biz_start = (s, it) => {
  const b = E.match(D.BIZ, [it.target, it.raw].join(' ')) || { id: 'custom', n: (it.target || 'Своё дело').slice(0, 30), cost: 800000, profit: 80000, risk: 0.35 };
  if (b.req) for (const k in b.req) if (E.sk(s, k) < b.req[k]) return fail('Не хватает опыта', [D.SKILLS[k] + ': нужно ' + b.req[k] + ', у вас ' + E.sk(s, k) + '.']);
  if (E.age(s) < 18) return fail('Бизнес — с 18 лет', []);
  const cost = Math.round(E.price(s, b.cost) * (it.amount > 0 ? E.clamp(it.amount / E.price(s, b.cost), 0.6, 2) : 1));
  if (s.st.money < cost) return fail('Не хватает стартового капитала', [b.n + ': нужно около ' + E.money(cost) + ', у вас ' + E.money(s.st.money) + '.', 'Можно взять кредит на бизнес.']);
  const r = E.roll(s, E.chance(s, 60, 'biz', 0));
  const quality = r.crit ? 1.35 : (r.ok ? E.rnd(0.9, 1.15) : E.rnd(0.35, 0.7));
  const nm = (it.org || it.target || b.n).slice(0, 40);
  if (b.illegal) s.flags.illegalBiz = true;
  s.biz.push({ illegal: !!b.illegal, id: b.id, type: b.n, n: nm.replace(/^./, c => c.toUpperCase()), value: Math.round(cost * 0.8), base: Math.round(E.price(s, b.profit) * (cost / E.price(s, b.cost))), q: quality, risk: b.risk, health: r.ok ? 70 : 45, months: 0, lastProfit: 0 });
  return { ok: r.ok, roll: r, title: r.ok ? 'Открыли: ' + b.n.toLowerCase() : 'Открылись, но старт тяжёлый', lines: ['Вложено: ' + E.money(cost), r.ok ? 'Место удачное, первые клиенты уже есть.' : 'Место так себе, поставщики подвели.'], fx: { money: -cost, happy: r.ok ? 8 : 2, stress: 12, biz: 2 }, factAdd: `${E.monthStr(s.date)}: открыл бизнес «${nm}» (${b.n.toLowerCase()}), вложил ${E.money(cost)}.` };
};

E.A.biz_sell = (s, it) => {
  if (!s.biz.length) return fail('Бизнеса нет', []);
  const t = E.norm(it.target || it.raw || '');
  const b = s.biz.find(x => t.includes(E.norm(x.n).slice(0, 5)) || t.includes(E.norm(x.type).slice(0, 5))) || s.biz[0];
  const price = Math.round(b.value * (0.7 + b.health / 250));
  s.biz.splice(s.biz.indexOf(b), 1);
  return { ok: true, title: 'Продали бизнес «' + b.n + '»', lines: ['Выручка: ' + E.money(price)], fx: { money: price, stress: -10 }, factAdd: `${E.monthStr(s.date)}: продал бизнес «${b.n}» за ${E.money(price)}.` };
};

E.A.invest = (s, it) => {
  const t = E.norm([it.target, it.raw].join(' '));
  let kind = /крипт|биткоин|bitcoin|эфир/.test(t) ? 'crypto' : (/акци|бирж|облигац|фонд|заём|заем/.test(t) ? 'stocks' : 'deposit');
  if (E.ww2(s) && kind === 'crypto') return fail('Такого ещё не изобрели', ['На дворе ' + new Date(s.date).getFullYear() + ' год. Есть сберкасса и облигации госзайма.']);
  const amt = Math.round(it.amount > 0 ? it.amount : s.st.money * 0.3);
  if (amt <= 0 || s.st.money < amt) return fail('Нечего вкладывать', ['Свободных денег: ' + E.money(s.st.money)]);
  s.inv[kind] += amt;
  const n = E.ww2(s) ? { deposit: 'вклад в сберкассе', stocks: 'облигации госзайма' }[kind] : { deposit: 'вклад в банке (12% годовых)', stocks: 'акции', crypto: 'криптовалюта' }[kind];
  return { ok: true, title: 'Вложили ' + E.money(amt), lines: ['Куда: ' + n], fx: { money: -amt, happy: 1 } };
};

E.A.withdraw = (s, it) => {
  const t = E.norm([it.target, it.raw].join(' '));
  const kind = /крипт/.test(t) ? 'crypto' : (/акци/.test(t) ? 'stocks' : (s.inv.deposit > 0 ? 'deposit' : (s.inv.stocks > 0 ? 'stocks' : 'crypto')));
  const amt = Math.round(Math.min(s.inv[kind], it.amount > 0 ? it.amount : s.inv[kind]));
  if (amt <= 0) return fail('Там пусто', []);
  s.inv[kind] -= amt;
  return { ok: true, title: 'Сняли ' + E.money(amt), lines: [], fx: { money: amt } };
};

E.A.loan = (s, it) => {
  if (E.ww2(s)) return fail('Банки не дают кредитов частным лицам', ['В 1930-е можно разве что занять у знакомых — попробуйте написать это словами.']);
  const inc = E.monthlyIncome(s);
  const max = Math.round(Math.max(0, inc * 12 - E.loanPay(s) * 12) * (0.6 + s.st.rep / 200));
  const amt = Math.round(it.amount > 0 ? it.amount : Math.min(max, E.m(s, 300000)));
  if (max < E.m(s, 10000) || inc <= 0) return fail('Банк отказал', ['Без постоянного дохода кредит не дают.']);
  if (amt > max) return fail('Банк одобрит максимум ' + E.money(max), ['Ваш доход: ' + E.money(inc) + '/мес.']);
  const r = E.roll(s, E.chance(s, 72, null, s.st.rep * 0.15));
  if (!r.ok) return { ok: false, roll: r, title: 'Банк отказал', lines: ['Скоринг не прошёл.'], fx: { happy: -2 } };
  const monthly = Math.round(amt * 0.052);
  s.loans.push({ n: 'Кредит', left: Math.round(amt * 1.22), monthly, rate: 0.22 });
  return { ok: true, roll: r, title: 'Кредит одобрен', lines: [E.money(amt) + ' на 2 года', 'Платёж: ' + E.money(monthly) + '/мес'], fx: { money: amt, stress: 5 }, factAdd: `${E.monthStr(s.date)}: взял кредит ${E.money(amt)}.` };
};

E.A.repay = (s, it) => {
  if (!s.loans.length) return fail('Долгов нет', []);
  const l = s.loans[0];
  const amt = Math.round(Math.min(l.left, it.amount > 0 ? it.amount : s.st.money, s.st.money));
  if (amt <= 0) return fail('Нечем гасить', []);
  l.left -= amt; if (l.left <= 0) s.loans.shift();
  return { ok: true, title: 'Погасили ' + E.money(amt), lines: [l.left <= 0 ? l.n + ' закрыт!' : 'Осталось: ' + E.money(l.left)], fx: { money: -amt, happy: l.left <= 0 ? 6 : 2, stress: -4 } };
};

E.findRel = (s, name) => { const t = E.norm(name || ''); if (!t) return null; return s.rel.find(r => t.includes(E.norm(r.name)) || E.norm(r.name).includes(t) || t.includes(E.norm(r.role).slice(0, 4))); };
E.A.social = (s, it) => {
  const who = it.person || it.target || '';
  let r0 = E.findRel(s, who) || E.findRel(s, it.raw || '');
  const npc = r0 && r0.npc ? L.npc(s, r0.npc) : null;
  if (npc && !npc.alive) return fail(npc.name + ' больше нет с нами', ['Можно сходить на кладбище, вспомнить.']);
  if (!r0 && who && who.length < 30) { r0 = { name: who.replace(/^./, c => c.toUpperCase()), role: 'знакомый', att: 40 }; s.rel.push(r0); if (s.rel.length > 14) s.rel.splice(2, 1); }
  const r = E.roll(s, E.chance(s, 72, 'cha', E.tmod(s, 'social', 0)));
  const d = r.ok ? E.ri(5, 12) : -E.ri(3, 8);
  if (r0) r0.att = E.clamp(r0.att + d, 0, 100);
  if (npc) { npc.att = r0.att; if (r.ok && Math.random() < 0.5) npc.hist.push((it.summary || 'провели время вместе').slice(0, 60) + ' (' + E.monthStr(s.date) + ')'); if (npc.hist.length > 20) npc.hist.splice(1, 1); }
  return { ok: r.ok, roll: r, title: r.ok ? 'Хорошо провели время' : 'Разговор не задался', lines: r0 ? [r0.name + ': отношение ' + (d > 0 ? '+' : '') + d] : [], fx: { happy: r.ok ? 6 : -3, stress: r.ok ? -8 : 3, money: -E.price(s, 1500) } };
};

E.A.date = (s, it) => {
  if (E.age(s) < 16) return fail('Рановато для свиданий', []);
  const who = it.person || it.target || '';
  let p = E.findRel(s, who) || s.rel.find(r => ['партнёр', 'знакомая(ый)'].includes(r.role));
  if (!p) { p = { name: who && who.length < 25 ? who.replace(/^./, c => c.toUpperCase()) : E.pick(s.ch.sex === 'f' ? ['Артём', 'Илья', 'Денис'] : ['Алина', 'Дарья', 'Полина']), role: 'знакомая(ый)', att: 40 }; s.rel.push(p); }
  const r = E.roll(s, E.chance(s, 62, 'cha', E.tmod(s, 'social', 0) + (p.att - 50) * 0.3 + (s.st.money > E.m(s, 50000) ? 4 : -4)));
  p.att = E.clamp(p.att + (r.ok ? E.ri(8, 16) : -E.ri(6, 14)), 0, 100);
  let extra = [];
  if (r.ok && p.att >= 65 && p.role !== 'партнёр' && p.role !== 'супруг(а)') { p.role = 'партнёр'; extra.push('Теперь вы пара!'); }
  return { ok: r.ok, roll: r, title: r.ok ? 'Свидание удалось' : 'Свидание не задалось', lines: [p.name + ': симпатия ' + p.att].concat(extra), fx: { happy: r.ok ? 9 : -5, money: -E.price(s, 3500), stress: r.ok ? -8 : 4 }, factAdd: extra.length ? `${E.monthStr(s.date)}: начал встречаться с ${p.name}.` : null };
};

E.A.marry = s => {
  const p = s.rel.find(r => r.role === 'партнёр');
  if (!p) return fail('Не с кем', ['Сначала нужны отношения.']);
  if (E.age(s) < 18) return fail('Жениться можно с 18', []);
  const r = E.roll(s, E.chance(s, 25 + p.att * 0.7, 'cha'));
  if (!r.ok) return { ok: false, roll: r, title: p.name + ' попросил(а) подождать', lines: ['«Давай не будем торопиться».'], fx: { happy: -6 }, };
  p.role = 'супруг(а)';
  const cost = E.price(s, 150000);
  return { ok: true, roll: r, title: 'Свадьба!', lines: ['Вы теперь в браке с ' + p.name + '.', 'Торжество: ' + E.money(Math.min(cost, Math.max(0, s.st.money)))], fx: { money: -Math.min(cost, Math.max(0, s.st.money)), happy: 20, stress: 8 }, factAdd: `${E.monthStr(s.date)}: женился(вышла замуж) — ${p.name}.` };
};

E.A.elect = (s, it) => {
  if (s.election) return fail('Кампания уже идёт', ['Выборы: ' + s.election.n + ', через ' + s.election.weeks + ' нед.']);
  const cur = s.pol ? D.POLITICS.findIndex(p => p.id === s.pol.id) : -1;
  const tt = E.norm([it.target, it.raw].join(' '));
  const hits = D.POLITICS.filter(p => E.norm(p.n).split(/\s+/).some(w => w.length >= 4 && tt.includes(w.slice(0, 5))));
  let target = hits.find(p => D.POLITICS.indexOf(p) > cur) || hits[0];
  if (!target || D.POLITICS.indexOf(target) <= cur) target = D.POLITICS[cur + 1];
  if (!target) return fail('Выше — только небо', ['Вы уже президент.']);
  const ti = D.POLITICS.indexOf(target);
  if (ti > cur + 1) return fail('Слишком высоко для начала', ['Сначала: ' + D.POLITICS[cur + 1].n + '.', 'В политике идут по ступеням.']);
  const age = E.age(s);
  if (age < target.age) return fail('Не проходите по возрасту', ['Нужно ' + E.years(target.age) + '.']);
  if (s.pol && s.pol.months < target.months) return fail('Рано', ['Нужно отработать на текущей должности ' + target.months + ' мес. (сейчас ' + s.pol.months + ').']);
  if (s.st.rep < target.rep - 15) return fail('Вас мало кто знает', ['Репутация ' + Math.round(s.st.rep) + ', а нужно хотя бы ' + (target.rep - 15) + '.', 'Поднимайте её работой, делами для людей, известностью.']);
  const cost = E.price(s, target.cost);
  if (s.st.money < cost) return fail('Нет денег на кампанию', ['Нужно ' + E.money(cost) + '.']);
  const ch = E.chance(s, 100 - target.diff + (s.st.rep - target.rep) * 0.9, 'cha', E.tmod(s, 'social', 0));
  if (target.appoint) {
    const r = E.roll(s, ch);
    if (!r.ok) return { ok: false, roll: r, title: 'Назначения не дали', lines: ['В Кремле решили иначе.'], fx: { happy: -5, rep: -2 } };
    E.takeOffice(s, target);
    return { ok: true, roll: r, title: 'Назначены: ' + target.n, lines: [], fx: { happy: 12, rep: 4 } };
  }
  s.election = { id: target.id, n: target.n, weeks: 4, chance: ch, spent: cost };
  return { ok: true, title: 'Кампания началась: ' + target.n, lines: ['Потрачено на кампанию: ' + E.money(cost), 'Выборы через 4 недели. Шанс сейчас: ~' + ch + '%', 'Работа и встречи с людьми на неделе повышают шансы.'], fx: { money: -cost, stress: 10 }, factAdd: `${E.monthStr(s.date)}: выдвинулся на выборы — ${target.n}.` };
};
E.takeOffice = (s, p) => {
  s.pol = { id: p.id, n: p.n, months: 0 };
  if (p.id !== 'mundep') s.job = null;
  E.fact(s, `${E.monthStr(s.date)}: стал(а) — ${p.n}.`);
};

E.isLeader = s => s.pol && s.pol.id === 'president';
E.A.war = (s, it) => {
  if (!E.isLeader(s)) return fail('Войну объявляет только глава государства', [E.ww2(s) ? 'Сначала нужно стать генсеком.' : 'Сначала нужно стать президентом.']);
  const ci = E.findCountry(s, [it.target, it.raw].join(' '));
  if (ci < 0) return fail('Не понятно, с кем воевать', ['Назовите страну.']);
  if (ci === s.world.home) return fail('Это ваша страна', []);
  if (WD.atWar(s, s.world.home, ci)) return fail('Война уже идёт', []);
  const border = E.borders(s, s.world.home, ci);
  WD.declare(s, s.world.home, ci, {});
  const C = s.world.cs[ci];
  WD.news(s, `${E.countryName(s.world.home)} объявила войну: ${C.n}.`, [s.world.home, ci], 2, 'war');
  return { ok: true, title: 'Объявлена война: ' + C.n, lines: ['Силы: вы ' + Math.round(E.power(s, s.world.home)) + ' — противник ' + Math.round(E.power(s, ci)), border ? 'Фронт откроется на следующей неделе.' : 'Общей границы нет — воевать придётся десантами через море.'], fx: { rep: C.pw0 > 40 ? -12 : -6, happy: -4, stress: 15 }, factAdd: `${E.dateStr(s.date)}: объявил войну — ${C.n}.`, war: ci };
};

E.A.peace = (s, it) => {
  const mine = s.world.wars.filter(w => w.a === s.world.home || w.b === s.world.home);
  if (!mine.length) return fail('Войн нет', []);
  if (!E.isLeader(s)) return fail('Мир заключает только глава государства', []);
  const ci = E.findCountry(s, [it.target, it.raw].join(' '));
  const w = mine.find(x => x.a === ci || x.b === ci) || mine[0];
  const en = w.a === s.world.home ? w.b : w.a;
  const score = w.a === s.world.home ? w.score : -w.score;
  const r = E.roll(s, E.chance(s, 38 + score * 3 + (s.world.cs[en].wear || 0) * 0.5, 'cha', w.total ? -15 : 0));
  if (!r.ok) return { ok: false, roll: r, title: 'Мир отвергнут', lines: [E.countryName(en) + ' продолжает войну.'], fx: { rep: -2 } };
  WD.endWar(s, w, `${E.countryName(s.world.home)} и ${E.countryName(en)} заключили мир.`, 2);
  s.world.cs[en].rel = -40;
  return { ok: true, roll: r, title: 'Мир с ' + E.countryName(en), lines: ['Занятые провинции остаются за теми, кто их держит.'], fx: { rep: 5, happy: 6, stress: -15 }, factAdd: `${E.dateStr(s.date)}: заключил мир — ${E.countryName(en)}.`, map: true };
};

E.A.army = (s, it) => {
  if (!E.isLeader(s)) return fail('Армией командует глава государства', []);
  if (s.world.army >= 2.2) return fail('Армия и так на пределе', []);
  s.world.army = Math.min(2.2, s.world.army + 0.15);
  const c = s.world.cs[s.world.home]; c.st.milp += 0.5; c.st.debt += 1;
  return { ok: true, title: 'Укрепили армию', lines: ['Мощь армии: ×' + s.world.army.toFixed(2), 'Военные расходы: ' + c.st.milp.toFixed(1) + '% ВВП'], fx: { rep: -1, happy: -1 } };
};

E.A.policy = (s, it) => {
  if (!s.pol || !['president', 'minister'].includes(s.pol.id)) return fail('Государственные решения принимает руководство страны', [E.ww2(s) ? 'Нужно быть наркомом или генсеком.' : 'Нужно быть министром или президентом.']);
  const r = E.roll(s, E.chance(s, 66, 'int', (E.sk(s, 'cha') - 40) * 0.2));
  const p = WD.policy(s, [it.target, it.raw].join(' '), r.ok, r.crit);
  const c = s.world.cs[s.world.home];
  return { ok: r.ok, roll: r, title: (r.ok ? '' : 'Провал: ') + p.n, lines: r.ok ? ['Стабильность: ' + Math.round(c.st.stab) + '%', 'Госдолг: ' + Math.round(c.st.debt) + '% ВВП'] : ['Решение саботировали, вышло хуже, чем задумывали.'], fx: { rep: r.ok ? 2 : -2, stress: 5 } };
};

E.A.move = (s, it) => {
  const t = E.norm([it.target, it.raw].join(' '));
  const i = M().start.findIndex(c => !(E.ww2(s) && c.no36) && [c.n, c.n2 || ''].some(n => n && t.includes(E.norm(n).slice(0, Math.max(4, n.length - 2)))) && s.world.own[c.prov] === s.world.home);
  if (i < 0) return fail('Не понятно, куда переезжать', ['Можно в один из городов из списка при создании персонажа.']);
  if (i === s.ch.city) return fail('Вы уже здесь', []);
  const cost = E.price(s, 40000);
  if (s.st.money < cost) return fail('Не хватает на переезд', ['Нужно ' + E.money(cost) + '.']);
  const old = E.cityName(s);
  s.ch.city = i; s.ch.cityName = ''; s.job = null; if (!s.home.owned) s.home = { type: 'room' };
  return { ok: true, title: 'Переезд: ' + E.startName(s, M().start[i]), lines: ['Работу придётся искать заново.'], fx: { money: -cost, happy: 4, stress: 12 }, factAdd: `${E.monthStr(s.date)}: переехал из города ${old} в город ${E.startName(s, M().start[i])}.`, map: true };
};

// Свободное действие: сложность и ставки предлагает нейросеть, движок жёстко ограничивает
E.A.other = (s, it) => {
  const DIFF = { 'легко': 80, 'средне': 58, 'сложно': 35, 'почти невозможно': 9 };
  const base = DIFF[it.difficulty] || 58;
  const sk = it.skill && D.SKILLS[it.skill] ? it.skill : null;
  const r = E.roll(s, E.chance(s, base, sk, 0));
  const st = it.stakes || {};
  const inc = Math.max(E.m(s, 30000), E.monthlyIncome(s));
  const capGain = Math.round(Math.min(inc * 0.3, E.m(s, 40000)));
  const cl = (v, a) => E.clamp(Math.round(v || 0), -a, a);
  let fx = {};
  if (r.ok) fx = { money: E.clamp(Math.round(st.money || 0), -Math.max(0, s.st.money), capGain), happy: cl(Math.abs(st.happy || 4), 10), rep: cl(st.rep, 4), health: cl(st.health, 5) };
  else fx = { money: E.clamp(-Math.abs(Math.round(st.money || 0)) * (st.money < 0 ? 1 : 0.3), -Math.max(0, s.st.money) * 0.5, 0), happy: -Math.min(8, Math.abs(st.happy || 3)), rep: cl(-Math.abs(st.rep || 0), 4), health: cl(-Math.abs(st.health || 0), 8) };
  if (it.illegal) {
    const caught = Math.random() < (r.ok ? 0.12 : 0.45);
    if (caught) { const fine = Math.round(Math.min(Math.max(0, s.st.money), E.price(s, 30000) + s.st.money * 0.1)); fx = { money: -fine, rep: -10, happy: -10, stress: 18 }; return { ok: false, roll: r, title: 'Поймали', lines: ['Штраф: ' + E.money(fine), 'Пятно на репутации.'], fx, caught: true, factAdd: `${E.monthStr(s.date)}: попался на нарушении закона (${(it.summary || it.raw || '').slice(0, 60)}).` }; }
  }
  return { ok: r.ok, roll: r, title: r.ok ? (r.crit ? 'Получилось блестяще' : 'Получилось') : (r.fail ? 'Провал' : 'Не получилось'), lines: [], fx };
};

// ---------- цели ----------
E.checkFocus = (s, out) => {
  if (!s.focus) return;
  const f = D.FOCUS.find(x => x.id === s.focus.id);
  if (f && f.test(s)) {
    s.focusDone.push(f.id); s.focus = null;
    const lines = E.apply(s, { happy: f.reward.happy, rep: f.reward.rep, str: f.reward.str, int: f.reward.int, biz: f.reward.biz, cha: f.reward.cha });
    if (out) { out.focusDone = f.n; out.lines = (out.lines || []).concat(['Цель выполнена: ' + f.n]).concat(lines); }
    E.fact(s, `${E.monthStr(s.date)}: достиг цели «${f.n}».`);
    E.logAdd(s, 'focus', 'Цель выполнена: ' + f.n);
  }
};

E.checkDeath = (s, out) => {
  if (s.st.health <= 0 && !s.over) { s.over = true; s.overReason = 'здоровье'; if (out) out.dead = true; }
};

// ---------- неделя ----------
E.nextWeek = (s, ext) => { // ext — мультиплеер: мир посчитал хост, здесь только своя жизнь
  if (s.over) return { lines: [] };
  const rep = { lines: [], events: [], monthly: null, war: [] };
  const d = new Date(s.date), oldMonth = d.getMonth();
  d.setDate(d.getDate() + 7); s.date = d.toISOString(); s.turn++;
  s.ap = 3;
  // учёба
  if (s.study) {
    s.ap = 2; s.study.weeks--;
    if (s.study.weeks <= 0) {
      const st = s.study; s.study = null;
      const l = E.apply(s, Object.assign({ happy: 6 }, st.gain));
      if (st.edu) s.ch.edu = Math.max(s.ch.edu, st.edu);
      if (st.flag) s.flags[st.flag] = true;
      rep.events.push({ sys: true, t: 'Учёба окончена', x: st.n + (st.edu ? ' — теперь у вас ' + D.EDU[st.edu] + '.' : ' — пройдено!'), lines: l });
      E.fact(s, `${E.monthStr(s.date)}: окончил — ${st.n}.`);
    }
  }
  // работа
  if (s.job) { s.job.weeks++; s.job.perf = E.clamp(s.job.perf + E.rnd(-1.5, 1.2), 0, 100); }
  s.st.stress = E.clamp(s.st.stress - 2 + (s.job ? 1 : 0) + (s.study ? 1 : 0) + (s.world.wars.length ? 2 : 0), 0, 100);
  // выборы
  if (s.election) {
    s.election.weeks--;
    if (s.election.weeks <= 0) {
      const el = s.election; s.election = null;
      const r = E.roll(s, E.clamp(el.chance + (s.flags.campaign || 0), 3, 95)); s.flags.campaign = 0;
      const p = D.POLITICS.find(x => x.id === el.id);
      if (r.ok) { E.takeOffice(s, p); E.apply(s, { happy: 15, rep: 6 }); rep.events.push({ sys: true, big: true, t: 'Победа на выборах!', x: `Подсчёт голосов закончен. Вы — ${p.n}.${p.id === 'president' ? ' Теперь вам подчиняется армия: можно объявлять войны и заключать мир.' : ''}`, roll: r }); }
      else { E.apply(s, { happy: -10, rep: -3 }); rep.events.push({ sys: true, t: 'Поражение на выборах', x: `Выборы (${p.n}) проиграны. Можно попробовать снова, когда подрастёт репутация.`, roll: r }); E.fact(s, `${E.monthStr(s.date)}: проиграл выборы — ${p.n}.`); }
    }
  }
  // мир: войны, история
  if (ext) rep.war = ext.war || [];
  else { if (E.ww2(s)) WD.history(s); rep.war = WD.week(s); }
  // месяц
  if (d.getMonth() !== oldMonth) { rep.monthly = E.monthEnd(s); if (!ext) WD.month(s); E.homeEconomy(s, rep); }
  E.worldPersonal(s, rep);
  E.lifeWeek(s, rep, d.getMonth() !== oldMonth);
  rep.news = ext ? (ext.news || []) : (s._fresh || []); s._fresh = [];
  // случайное событие (~13%)
  if (!rep.events.length && Math.random() < 0.2 * (0.7 + 0.3 * E.dif(s).bad)) {
    const pool = D.EVENTS.concat(E.ww2(s) ? D.EV_WW2 : D.EV_MOD).concat(D.EV_LIFE).filter(e => { try { return !e.when || e.when(s); } catch (x) { return false; } });
    if (pool.length) rep.events.push({ ev: E.pick(pool).id });
  }
  // увольнение за лень
  if (s.job && s.job.perf < 12 && Math.random() < 0.15) { const t = s.job.title; s.job = null; rep.events.push({ sys: true, t: 'Вас уволили', x: 'Начальство решило, что вы не справляетесь (' + t + ').' }); E.apply(s, { happy: -10, rep: -3 }); E.fact(s, `${E.monthStr(s.date)}: уволен с должности «${t}».`); }
  E.checkFocus(s, null);
  E.checkDeath(s, null);
  return rep;
};

E.monthEnd = s => {
  const r = { inc: [], exp: [] };
  // доходы
  if (s.job) { r.inc.push(['Зарплата: ' + s.job.title, s.job.salary]); s.job.months++; }
  if (s.pol) { s.pol.months++; const ps = E.salary(s, D.POL_SAL[s.pol.id] || 0); if (ps) r.inc.push(['Жалованье: ' + s.pol.n, ps]); }
  B.month(s, r);
  const spI = L.spouseIncome(s); if (spI) r.inc.push(['Зарплата супруга(и)', spI]);
  if (typeof RENT !== 'undefined') { RENT.month(s, r); RENT.tax(s, r); } else for (const p of s.props) if (p.rentOut) r.inc.push(['Аренда: ' + p.n, p.rentIncome]);
  if (s.inv.deposit > 0) { const v = Math.round(s.inv.deposit * E.depRate(s) / 12); s.inv.deposit += 0; r.inc.push(['Проценты по вкладу', v]); }
  if (s.inv.stocks > 0) { const ch = Math.round(s.inv.stocks * (E.ww2(s) ? E.rnd(-0.01, 0.012) : E.rnd(-0.07, 0.085))); s.inv.stocks = Math.max(0, s.inv.stocks + ch); r.stocks = ch; }
  if (s.inv.crypto > 0) { const ch = Math.round(s.inv.crypto * E.rnd(-0.28, 0.3)); s.inv.crypto = Math.max(0, s.inv.crypto + ch); r.crypto = ch; }
  // расходы
  r.exp.push(['Еда, связь, быт', E.living(s)]);
  if (E.homeRent(s)) r.exp.push([s.home.type === 'parents' ? 'Помощь родителям' : (s.home.owned ? 'Квартплата' : (E.ww2(s) ? 'Квартплата: ' : 'Аренда: ') + E.homeName(s).toLowerCase()), E.homeRent(s)]);
  if (E.utilities(s)) r.exp.push(['Коммунальные услуги', E.utilities(s)]);
  if (E.transit(s)) r.exp.push(['Проездной', E.transit(s)]);
  if (E.carUp(s)) r.exp.push([s.car.n + ': бензин, страховка, ремонт', E.carUp(s)]);
  if (L.kidCost(s)) r.exp.push(['Дети', L.kidCost(s)]);
  for (const l of s.loans) { const pay = Math.min(l.monthly, l.left); r.exp.push([l.n, pay]); l.left -= pay; }
  s.loans = s.loans.filter(l => l.left > 0);
  if (E.upkeep(s)) r.exp.push(['Содержание вещей, спорт', E.upkeep(s)]);
  if (s.study && s.study.monthly) r.exp.push(['Учёба: ' + s.study.n, s.study.monthly]);
  const inc = r.inc.reduce((a, x) => a + x[1], 0), exp = r.exp.reduce((a, x) => a + x[1], 0);
  s.st.money += inc - exp;
  r.net = inc - exp;
  // счастье тянется к «фону жизни»
  const age = E.age(s);
  let target = 48 + E.homeHappy(s) + (s.car ? Math.min(6, s.car.happy * 0.4) : 0) + ((s.kids || []).length ? 5 : 0) + (s.npcs || []).filter(n => n.alive && n.att > 60).length * 2 + (s.job || s.pol ? 6 : (s.study || age < 18 || age >= 65 ? 0 : -10))
    + (s.st.money > E.monthlyCost(s) * 3 ? 6 : (s.st.money < 0 ? -15 : 0)) + (s.rel.some(x => x.role === 'партнёр' || x.role === 'супруг(а)') ? 8 : 0)
    - s.st.stress / 6 + (s.st.health < 40 ? -8 : 0) + (s.pol ? 4 : 0);
  s.st.happy = E.clamp(s.st.happy + (target - s.st.happy) * 0.25, 0, 100);
  // здоровье с возрастом
  let dh = (age > 40 ? -0.25 : 0) + (age > 60 ? -0.7 : 0) + (age > 75 ? -1.5 : 0) + (s.st.stress > 70 ? -1.2 : 0) + (s.flags.gym ? 0.8 : 0) + E.tmod(s, 'health', 0) * 0.3;
  if (age < 35 && s.st.health < 85) dh += 0.6;
  s.st.health = E.clamp(s.st.health + dh, 0, 100);
  s.flags.healthyMonths = s.st.health >= 85 ? (s.flags.healthyMonths || 0) + 1 : 0;
  // долги
  if (s.st.money < 0) { s.flags.debtMonths = (s.flags.debtMonths || 0) + 1; s.st.rep = E.clamp(s.st.rep - 1, 0, 100); } else s.flags.debtMonths = 0;
  if (s.flags.debtMonths >= 4) r.collectors = true;
  if (s.flags.debtMonths >= 3 && !s.home.owned && ['flat', 'room', 'house'].includes(s.home.type)) {
    s.home = { v3: 1, type: E.age(s) < 30 ? 'parents' : 'dorm', furn: s.home.furn || [] }; r.evicted = E.homeName(s);
    E.fact(s, `${E.monthStr(s.date)}: из-за долгов съехал — ${r.evicted.toLowerCase()}.`);
  }
  // естественная смерть в глубокой старости
  if (age > 72 && Math.random() < (age - 70) * 0.004 * (1.6 - s.st.health / 100)) { s.over = true; s.overReason = 'старость'; }
  // родители стареют
  s.monthReport = r;
  return r;
};

// ---------- война: неделя боёв ----------
E.eventResolve = (s, evId, optIndex) => {
  if (evId && typeof evId === 'object' && evId.ev === 'npc') return L.npcResolve(s, evId, optIndex);
  const ev = E.findEv(evId); const o = ev.opts[optIndex];
  let lines = [], roll = null;
  const fxs = fx => { if (!fx) return []; const f = Object.assign({}, fx); if (f.money) f.money = Math.round(E.m(s, f.money)); if (f.rub) { f.money = (f.money || 0) + Math.round(f.rub * E.cpi(s)); delete f.rub; } if (typeof f.do === 'string') { const k = f.do; f.do = s2 => E.DO(s2, k); } if (f.flag) { s.flags[f.flag] = true; delete f.flag; } if (f.purge) { delete f.purge; return E.purge(s).concat(E.apply(s, f)); } if (f.do) { const d = f.do; delete f.do; const l = E.apply(s, f); return (d(s) || []).concat(l); } return E.apply(s, f); };
  if (o.fx) lines = lines.concat(fxs(o.fx));
  if (o.roll) {
    const ch = o.roll.luck !== undefined ? E.clamp(o.roll.luck + E.dif(s).luck * 0.5, 1, 95) : E.chance(s, 100 - o.roll.diff, o.roll.sk);
    roll = E.roll(s, ch);
    lines = lines.concat(fxs(roll.ok ? o.ok : o.bad));
  }
  E.logAdd(s, 'event', E.evText(s, ev.t) + ': ' + E.evText(s, o.n), { lines, x: E.evText(s, ev.x), ok: roll ? roll.ok : undefined });
  E.checkFocus(s, null); E.checkDeath(s, null);
  return { lines, roll, ok: roll ? roll.ok : true };
};

// ---------- разбор фразы без нейросети (запасной вариант) ----------
E.parseLocal = text => {
  const t = E.norm(text);
  const num = (() => { const m = t.match(/(\d[\d\s]*)(\s*(тыс|к\b|млн|миллион))?/); if (!m) return 0; let v = parseInt(m[1].replace(/\s/g, '')); if (m[3]) v *= /млн|миллион/.test(m[3]) ? 1e6 : 1e3; return v; })();
  const R = [
    [/указ|реформ|налог|санкци|нацпроект|пятилетк|индустриализ|бюджет страны/, 'policy'],
    [/ограб|украс|кража|банд|крыш|рэкет|контрабанд|мошенн|взятк|подкуп|залечь|на дно|наезд|разборк|завяз|грабёж|грабеж|афер|угнат/, 'crime'],
    [/объяв.*войн|напасть на|войн[ау] (с|против)|вторгнуть/, 'war'], [/мир с|перемири|заключить мир/, 'peace'], [/укрепить армию|военный бюджет/, 'army'],
    [/уволи|ухожу с работы|бросаю работу/, 'quit'], [/повышен|прибавк|повысить/, 'promote'],
    [/выбор|баллотир|депутат|мэр|губернатор|президент|министр/, 'elect'],
    [/устро|иду работать|найти работу|ищу работу|подработ/, 'job'], [/усердно|пахать|работаю|сверхуроч|переработ/, 'work'],
    [/продать бизнес|продаю бизнес|продать (свой |мой )?(ларёк|ларек|магазин|кафе|кофейню)/, 'biz_sell'],
    [/снять (деньги )?(со вклада|с вклада)|продать акци|забрать (деньги )?(со|с) вклад/, 'withdraw'],
    [/погасить|вернуть долг|закрыть кредит/, 'repay'], [/ипотек/, 'home'], [/кредит|занять/, 'loan'],
    [/вклад|инвест|акци|крипт|биткоин/, 'invest'],
    [/открыть|бизнес|своё дело|свое дело|ларёк|ларек|кофейн/, 'biz_start'],
    [/поступ|учиться|курсы|колледж|универ|институт|школ|выучить/, 'study'],
    [/путешеств|поехать в|слетать|съездить|отпуск/, 'travel'], [/отдых|бар|клуб|кино|театр|концерт|рыбалк|гуля/, 'rest'],
    [/врач|больниц|спорт|зал|бегать|здоров|курить/, 'health'],
    [/переехать в|переезжаю в/, 'move'],
    [/квартир|дом|комнат|общежит|к родителям|съехать/, 'home'],
    [/женить|замуж|свадьб|предложение/, 'marry'], [/свидани|познаком|девушк|парн/, 'date'],
    [/друз|родител|мам|пап|семь|позвонить|встретиться/, 'social'],
    [/куп/, 'buy'], [/\?|как (у меня|мои)|сколько/, 'chat'],
  ];
  let type = 'other';
  for (const [re, ty] of R) if (re.test(t)) { type = ty; break; }
  return { type, target: text, amount: num, raw: text, difficulty: 'средне', summary: text };
};


// ---------- мир и жизнь игрока ----------
E.homeAtWar = s => s.world.wars.filter(w => w.a === s.world.home || w.b === s.world.home);
E.purge = s => {
  const lines = ['Арестованы по ложному доносу. Через полгода вас освободили — без должности и сбережений.'];
  if (s.pol) { lines.push('Должность потеряна: ' + s.pol.n); s.pol = null; }
  s.job = null; s.st.money = Math.round(s.st.money * 0.2); s.election = null;
  E.apply(s, { health: -22, happy: -30, rep: -35, stress: 30 });
  E.fact(s, `${E.monthStr(s.date)}: арестован по ложному доносу, освобождён через полгода, лишился должности.`);
  const d = new Date(s.date); d.setMonth(d.getMonth() + 6); s.date = d.toISOString();
  return lines;
};
// Особые события, которые запускает мир (не случайные)
E.SPECIAL = {
  mobil: { id: 'mobil', t: 'Повестка', x: 'В почтовом ящике — повестка из военкомата. Страна воюет, и армии нужны люди.', opts: [
    { n: 'Явиться в военкомат', fx: { do: s => { E.draft(s); return ['Вы теперь служите: ' + s.job.title]; }, rep: 4, stress: 15 } },
    { n: 'Попробовать получить бронь', roll: { sk: 'cha', diff: 62 }, ok: { stress: 5 }, bad: { do: s => { E.draft(s); return ['Брони не дали. Вы теперь служите: ' + s.job.title]; }, rep: -3, stress: 18 } }] },
  occupied: { id: 'occupied', t: 'Город занят врагом', x: 'Фронт прошёл через ваш город. Улицы перекрыты, по радио — чужая речь. Можно уйти с последним эшелоном на восток.', opts: [
    { n: 'Эвакуироваться', fx: { do: s => E.evacuate(s), stress: 15, happy: -8 } },
    { n: 'Остаться', fx: { happy: -18, stress: 25, rep: -2 } }] },
  layoff: { id: 'layoff', t: 'Сокращение', x: 'В стране кризис. На работе объявили сокращение штата, и вы — в списке.', opts: [
    { n: 'Уйти с выходным пособием', fx: { do: s => { const t = s.job ? s.job.title : ''; s.job = null; return ['Работы больше нет (' + t + ')']; }, moneyJob: 0, happy: -8, stress: 10 } },
    { n: 'Уговорить начальство оставить', roll: { sk: 'cha', diff: 55 }, ok: { perf: -5, stress: 5 }, bad: { do: s => { s.job = null; return ['Не уговорили — вы уволены']; }, happy: -10, stress: 12 } }] },
  revolt: { id: 'revolt', t: 'Народ на улицах', x: 'Стабильность в стране рухнула. На площадях — сотни тысяч людей, генералы колеблются.', opts: [
    { n: 'Пойти на уступки и реформы', fx: { do: s => { const c = s.world.cs[s.world.home]; c.st.stab += 15; c.st.debt += 5; return ['Стабильность +15']; }, rep: -5 } },
    { n: 'Уйти в отставку', fx: { do: s => { const p = s.pol.n; s.pol = null; return ['Вы больше не ' + p.toLowerCase()]; }, rep: -10, happy: -15 } }] },
};
E.draft = s => {
  const j = (D.JOBS.find(x => x.army || x.id === 'army') || D.MOD.JOBS[0]);
  s.job = { id: j.id, title: j.ladder[0], org: '', salary: E.salary(s, j.sal, j.fixed), level: 0, perf: 50, months: 0, weeks: 0, sk: j.sk, ladder: j.ladder, risky: true, army: true };
  s.flags.drafted = s.date;
  E.fact(s, `${E.monthStr(s.date)}: призван в армию.`);
};
E.evacuate = s => {
  const ok = M().start.map((c, i) => i).filter(i => !(E.ww2(s) && M().start[i].no36) && i !== s.ch.city && s.world.own[M().start[i].prov] === s.world.home);
  if (!ok.length) return ['Эвакуироваться некуда.'];
  const here = E.city(s), d = i => Math.hypot(M().start[i].x - here.x, M().start[i].y - here.y);
  const east = ok.filter(i => M().start[i].x > here.x + 120).sort((a, b) => d(a) - d(b));
  const i = east.length ? east[Math.min(east.length - 1, E.ri(0, 2))] : ok.sort((a, b) => d(b) - d(a))[0];
  const old = E.cityName(s);
  s.ch.city = i; s.ch.cityName = ''; if (s.job && !s.job.army) s.job = null; if (!s.home.owned) s.home = { type: 'dorm' };
  E.fact(s, `${E.monthStr(s.date)}: эвакуирован из города ${old} в город ${E.cityName(s)}.`);
  return ['Эвакуированы в город ' + E.cityName(s)];
};
// Месячные последствия экономики страны для игрока
E.homeEconomy = (s, rep) => {
  const c = s.world.cs[s.world.home]; if (!c) return;
  const h = c.h.gdp, g = h.length > 1 ? h[h.length - 1] / h[h.length - 2] - 1 : 0;
  if (s.job && !s.job.army && g < -0.004 && Math.random() < 0.06 * E.dif(s).bad) rep.events.push({ ev: 'layoff' });
  // индексация зарплат в январе
  if (new Date(s.date).getMonth() === 0 && s.job && c.st.infl > 1) { const k = 1 + c.st.infl / 100 * 0.7; s.job.salary = Math.round(s.job.salary * k); }
  // незаконный бизнес
  if (s.biz.some(b => b.illegal) && Math.random() < 0.08 * E.dif(s).bad) {
    const b = s.biz.find(x => x.illegal); s.biz.splice(s.biz.indexOf(b), 1);
    const fine = Math.round(Math.max(0, s.st.money) * 0.5);
    s.st.money -= fine; E.apply(s, { rep: -15, happy: -15, stress: 20 });
    rep.events.push({ sys: true, t: 'ОБХСС', x: `Незаконную торговлю «${b.n}» раскрыли. Товар конфискован, штраф ${E.money(fine)}.` });
    E.fact(s, `${E.monthStr(s.date)}: попался на незаконной торговле, лавку закрыли.`);
  }
  if (s.flags.revolt && E.isLeader(s)) { s.flags.revolt = false; rep.events.push({ ev: 'revolt' }); }
};
// Еженедельно: мобилизация, фронт, оккупация
E.worldPersonal = (s, rep) => {
  const wars = E.homeAtWar(s), age = E.age(s);
  const total = wars.some(w => w.total || (s.world.cs[w.a === s.world.home ? w.b : w.a].pw0 >= 30));
  if (wars.length && !s.pol && !(s.job && s.job.army) && age >= 18 && age <= 50 && s.ch.sex === 'm' && !s.flags['mob' + wars[0].start] && Math.random() < (total ? (E.ww2(s) ? 0.2 : 0.06) : 0.02)) {
    s.flags['mob' + wars[0].start] = 1; rep.events.push({ ev: 'mobil' });
  }
  if (s.job && s.job.army && wars.length) {
    const risk = (E.ww2(s) ? 1 : 0.5) * E.dif(s).death;
    const r = Math.random();
    if (r < 0.006 * risk) { s.st.health = 0; s.over = true; s.overReason = 'фронт'; rep.events.push({ sys: true, big: true, t: 'Погиб на фронте', x: 'Похоронка пришла через месяц.' }); }
    else if (r < 0.04 * risk) { E.apply(s, { health: -E.ri(15, 35), happy: -8 }); rep.events.push({ sys: true, t: 'Ранение', x: 'Осколок. Госпиталь, перевязки, долгие недели.' }); }
    else if (r < 0.1) { E.apply(s, { rep: 3 }); s.job.perf = E.clamp(s.job.perf + 10, 0, 100); if (Math.random() < 0.25) rep.events.push({ sys: true, t: 'Награда', x: 'За храбрость в бою вас представили к медали.' }); }
  }
  // демобилизация
  if (s.job && s.job.army && !wars.length && s.flags.drafted && Math.random() < 0.08) { s.flags.drafted = null; const t = s.job.title; s.job = null; rep.events.push({ sys: true, t: 'Демобилизация', x: 'Война для вас окончена. Вы вернулись домой (' + t + ').' }); E.apply(s, { happy: 12, rep: 4 }); }
  // город занят
  const prov = E.city(s).prov;
  if (prov >= 0 && s.world.own[prov] !== s.world.home && !s.flags['occ' + prov + s.world.own[prov]]) { s.flags['occ' + prov + s.world.own[prov]] = 1; rep.events.push({ ev: 'occupied' }); }
};


// ---------- v3: справочник событий, действия событий ----------
E.findEv = id => D.EVENTS.find(e => e.id === id) || (D.EV_MOD || []).find(e => e.id === id) || (D.EV_WW2 || []).find(e => e.id === id) || (D.EV_LIFE || []).find(e => e.id === id) || E.SPECIAL[id] || (D.MOD.EVENTS || []).find(e => e.id === id) || (D.WW2.EVENTS || []).find(e => e.id === id);
E.evText = (s, t) => {
  if (!t) return t;
  const sp = s.rel.find(r => r.role === 'супруг(а)');
  const kid = (s.kids || []).find(k => { const a = L.kidAge(s, k); return a >= 0 && a <= 17; });
  const miss = E.missingWife(s);
  const g = s._gadget || (s._gadget = E.pick(L.GADGETS[E.EV(s)]));
  return t.replace(/\{sp\}/g, sp ? sp.name : 'Супруг(а)').replace(/\{item\}/g, miss ? miss.n.toLowerCase() : 'техникой').replace(/\{kid\}/g, kid ? kid.name : 'Ребёнок')
    .replace(/\{kidg\}/g, kid ? L.gen(kid.name) : 'ребёнка').replace(/\{gadget\}/g, g[0]).replace(/\{mil\}/g, s.ch.sex === 'f' ? 'свекровь' : 'тёща').replace(/\{broke\}/g, () => { const it = L.FURN(s).find(x => x.id === s._broke); return it ? it.n.toLowerCase() : 'прибор'; });
};
E.DO = (s, k) => {
  const sp = s.rel.find(r => r.role === 'супруг(а)');
  const kid = (s.kids || []).find(x => { const a = L.kidAge(s, x); return a >= 0 && a <= 17; });
  let m;
  if ((m = k.match(/^spouse([+-]\d+)$/))) { if (sp) sp.att = E.clamp(sp.att + +m[1], 0, 100); return sp ? [sp.name + ': отношение ' + m[1]] : []; }
  if ((m = k.match(/^kid([+-]\d+)$/))) { if (kid) kid.att = E.clamp((kid.att || 70) + +m[1], 0, 100); return kid ? [kid.name + ': ' + (+m[1] > 0 ? 'доволен' : 'обижен') + ' (' + m[1] + ')'] : []; }
  switch (k) {
    case 'raise25': case 'raise10': case 'raise7': { if (!s.job) return []; const p = { raise25: 1.25, raise10: 1.1, raise7: 1.07 }[k]; s.job.salary = Math.round(s.job.salary * p); return ['Зарплата: ' + E.money(s.job.salary)]; }
    case 'promote': { const j = s.job; if (!j || j.level >= j.ladder.length - 1) return []; j.level++; j.title = j.ladder[j.level]; j.salary = Math.round(j.salary * 1.25); return ['Новая должность: ' + j.title]; }
    case 'rent10': case 'rent15': { if (s.home.rent) s.home.rent = Math.round(s.home.rent * (k === 'rent10' ? 1.1 : 1.15)); return ['Аренда теперь ' + E.money(s.home.rent) + '/мес']; }
    case 'moveout': { const r = L.toParents(s); return r.lines.concat(['Пока живёте у родителей. Новое жильё — в разделе «Жильё»']); }
    case 'furnsale': { const miss = L.FURN(s).filter(x => x.tech && !(s.home.furn || []).some(f => f.id === x.id)); const it = miss[0]; if (!it) return ['Всё уже есть — сэкономили']; const pr = Math.round(L.furnPrice(s, it, 'std') * 0.65); if (s.st.money < pr) return ['Денег не хватило даже со скидкой']; s.st.money -= pr; s.home.furn.push({ id: it.id, tier: 'std', d: s.date }); return ['Куплено со скидкой: ' + it.n + ' за ' + E.money(pr)]; }
    case 'pet': { s.items.push({ n: 'Котёнок', value: 0, upkeep: E.price(s, 3000), d: s.date }); return ['У вас теперь котёнок']; }
    case 'orderflat': { const l = L.listings(s).find(x => x.kind === 'flat' && x.cls === 'mid') || L.listings(s).find(x => x.kind === 'flat'); if (!l) return []; const lines = []; L.leave(s, lines); s.home = L.fromListing(s, l, false); s.home.rent = Math.max(5, l.rent); return lines.concat(['Отдельная квартира, ' + l.area + ' м², квартплата ' + E.money(s.home.rent) + '/мес']); }
    case 'losefurn': { const n = (s.home.furn || []).length; s.home.furn = (s.home.furn || []).filter(() => Math.random() < 0.4); return ['Сгорело вещей: ' + (n - s.home.furn.length)]; }
    case 'losecar': { const n = s.car ? s.car.n : ''; s.car = null; return [n + ' пропал'] ; }
    case 'buywife': { const it = E.missingWife(s); if (!it) return []; const r = L.buyFurn(s, it.id, 'std'); if (sp && r && r.ok) sp.att = E.clamp(sp.att + 8, 0, 100); return r ? [r.title].concat(r.lines || []) : []; }
    case 'buygadget': { const g = s._gadget || E.pick(L.GADGETS[E.EV(s)]); s._gadget = null; const pr = Math.round(E.ww2(s) ? g[1] * E.cpi(s) : E.m(s, g[1])); if (s.st.money < pr) return ['Денег не хватило']; s.st.money -= pr; if (kid) kid.att = E.clamp((kid.att || 70) + 12, 0, 100); return ['Куплено: ' + g[0] + ' (' + E.money(pr) + ')']; }
    case 'baby': return L.baby(s);
    case 'carfix': { if (!s.car) return []; const c = Math.round(s.car.value * E.rnd(0.02, 0.08)); s.st.money -= c; return ['Ремонт: ' + E.money(c)]; }
  }
  return [];
};
// Особое событие: сломалась техника
E.SPECIAL.broke = { id: 'broke', t: 'Сломалось: {broke}', x: 'Утром {broke} издал странный звук — и замолчал навсегда. Или не навсегда?', opts: [
  { n: 'Починить', fx: { do: s => { const f = s.home.furn.find(x => x.id === s._broke); if (!f) return []; const it = L.FURN(s).find(x => x.id === f.id); const c = Math.round(L.furnPrice(s, it, f.tier || 'std') * 0.25); s.st.money -= c; f.broken = false; return ['Мастер починил за ' + E.money(c)]; } } },
  { n: 'Купить новый', fx: { do: s => { const f = s.home.furn.find(x => x.id === s._broke); if (!f) return []; const it = L.FURN(s).find(x => x.id === f.id); const c = L.furnPrice(s, it, f.tier || 'std'); s.st.money -= c; f.broken = false; f.d = s.date; return ['Новый — ' + E.money(c)]; }, happy: 2 } },
  { n: 'Жить без него', fx: { do: s => { s.home.furn = s.home.furn.filter(x => x.id !== s._broke); return ['Выбросили']; }, happy: -3 } }] };

// Еженедельная жизнь: вакансии, лицензии, друзья, техника, семья, криминал, газеты
E.lifeWeek = (s, rep, newMonth) => {
  rep.life = [];
  // отклики
  for (const t of L.hhWeek(s)) rep.life.push(t);
  for (const t of B.licWeek(s)) rep.life.push(t);
  // друг: раз в квартал
  if (s.turn % 13 === 6) { const e = L.npcQuarter(s); if (e) rep.events.push({ npc: e }); }
  if (newMonth) {
    L.npcFront(s);
    if (new Date(s.date).getMonth() === new Date(s.ch.birth).getMonth()) L.npcYear(s);
    // поломка техники
    const tech = (s.home.furn || []).filter(f => !f.broken && (L.FURN(s).find(x => x.id === f.id) || {}).tech);
    if (tech.length && Math.random() < 0.05 * tech.length / 4) { const f = E.pick(tech); f.broken = true; s._broke = f.id; rep.events.push({ ev: 'broke' }); }
    // криминал
    if (s.crime) L.crimeMonth(s, rep);
    // газета мира
    L.addPaper(s, L.worldPaper(s));
    // друзья и родные медленно остывают без общения
    for (const r of s.rel) if (r.npc && Math.random() < 0.5) r.att = Math.max(0, r.att - 0.5);
    L.npcSync(s);
  }
  if (s._arrest) { s._arrest = false; rep.events.push({ ev: 'arrest' }); }
  if (rep.monthly && rep.monthly.quit) rep.life.push(...rep.monthly.quit);
  // городская газета каждую неделю
  L.addPaper(s, L.cityPaper(s, rep));
};
