// «Судьба» — ЗНАКОМЫЕ. Живая социальная сеть: одноклассники, коллеги, соседи, друзья друзей и влиятельные люди.
// Люди связаны между собой: ссорятся, влюбляются, расходятся, распускают слухи, травят слабых в школе и избегают друг друга
// во взрослой жизни, попадают в хорошие и плохие истории. Через знакомых можно выйти на тех, кто повыше: директора, депутаты, министры.
'use strict';
const SOC = {};
(() => {
  const r = a => a[Math.floor(Math.random() * a.length)];
  const ri = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const cl = (x, a, b) => Math.max(a, Math.min(b, x));
  const TRAITS = ['весёлый', 'надёжный', 'сплетник', 'завистливый', 'добрый', 'вспыльчивый', 'хитрый', 'застенчивый', 'душа компании', 'карьерист', 'мечтатель', 'честный'];
  const SUR = () => (typeof NAMES !== 'undefined' ? NAMES.s : ['Иванов', 'Смирнов', 'Петров', 'Соколов', 'Попов', 'Волков']);
  const first = sex => r(typeof NAMES !== 'undefined' ? NAMES[sex] : D.NPC_NAMES[sex]);
  const sur = sex => { const x = r(SUR()); return sex === 'f' ? UI.fem(x) : x; };
  // влиятельные люди (скрыты, пока вас не познакомят)
  const BIG = {
    mod: [['Владелец автосалона', 42], ['Начальник отдела в мэрии', 46], ['Главврач городской больницы', 48], ['Директор завода', 55], ['Майор полиции', 50], ['Ректор университета', 58], ['Владелец сети магазинов', 62], ['Известный блогер (2 млн подписчиков)', 60], ['Депутат городской думы', 64], ['Банкир', 70], ['Заместитель губернатора', 76], ['Генерал', 78], ['Олигарх', 86], ['Министр', 90]],
    ww2: [['Директор МТС', 42], ['Председатель колхоза', 44], ['Начальник цеха', 46], ['Главврач госпиталя', 48], ['Директор завода', 56], ['Майор НКВД', 62], ['Секретарь райкома', 66], ['Командир дивизии', 72], ['Секретарь обкома', 80], ['Нарком', 90]],
  };
  const RUM = {
    school: ['вы списываете у всех контрольные', 'вы стукач и всё рассказываете учителям', 'вы влюблены в {x}', 'вас оставят на второй год', 'вы украли телефон из раздевалки'],
    adult: ['вы набрали кредитов и не отдаёте', 'вас скоро уволят', 'вы купили диплом', 'вы встречаетесь с чужим партнёром', 'вы стучите начальству', 'вы наврали всем про зарплату', 'у вас огромные долги'],
  };
  const name = p => /^(Тётя|Тетя|Баба|Дядя|Дед)/.test(p.name) ? p.name : p.name.split(' ')[0];
  const G = (p, m, f) => p && p.sex === 'f' ? f : m; // род: «познакомил» / «познакомила»
  const fx = (s, f) => { try { return E.apply(s, f) || []; } catch (e) { return []; } };
  const age = s => E.age(s);
  const kid = s => age(s) < 18;
  SOC.label = a => a >= 80 ? 'близкий друг' : a >= 62 ? 'друг' : a >= 40 ? 'знакомый' : a >= 22 ? 'прохладно' : 'враг';
  SOC.cls = a => a >= 62 ? 'good' : a < 30 ? 'bad' : '';

  // ---------- создание сети ----------
  const P = (s, o) => {
    const S = s.soc, sex = o.sex || (Math.random() < 0.5 ? 'm' : 'f');
    const p = Object.assign({ id: 's' + (S.n++), name: first(sex) + ' ' + sur(sex), sex, age: age(s), role: 'знакомый', circle: 'misc', att: ri(40, 60), infl: ri(4, 22), trait: r(TRAITS), job: '', known: true, links: {}, partner: '', hist: [], alive: true, seen: s.turn, flags: {}, met: E.monthStr(s.date) }, o);
    p.sex = sex; S.people.push(p); return p;
  };
  const link = (a, b, w) => { if (!a || !b || a === b) return; a.links[b.id] = w; b.links[a.id] = w; };
  const jobs = (s, a) => a < 18 ? 'школьник' : a < 23 && Math.random() < 0.5 ? 'студент' : r(E.ww2(s) ? ['рабочий', 'колхозник', 'шофёр', 'учётчица', 'медсестра', 'слесарь', 'учитель'] : ['менеджер', 'курьер', 'продавец', 'программист', 'водитель', 'бухгалтер', 'медсестра', 'учитель', 'мастер на стройке', 'официант', 'инженер', 'риелтор', 'дизайнер']);
  SOC.group = (s, n, kind, ids) => { const g = { id: 'g' + (s.soc.n++), n, kind, members: ids.slice(), mine: true, tone: ri(45, 75), hist: [] }; s.soc.groups.push(g); return g; };
  SOC.init = s => {
    if (s.soc) return s.soc;
    const S = s.soc = { people: [], groups: [], feed: [], n: 1, cool: 2, jobKey: s.job ? s.job.title : '', school: kid(s) };
    const a = age(s);
    // друг детства и соседка из старой системы — тоже часть сети
    for (const n of s.npcs || []) P(s, { id: 'n_' + n.id, name: n.name, sex: n.sex, age: n.age, role: n.role, circle: n.id === 'friend' ? 'yard' : 'home', att: n.att, trait: n.trait, job: n.job || '', npc: n.id, infl: n.id === 'neighbor' ? 6 : 12 });
    const fr = S.people.find(p => p.npc === 'friend');
    if (a < 18) {
      const ids = [];
      const bully = P(s, { sex: 'm', role: 'одноклассник', circle: 'school', trait: 'задира', att: ri(25, 40), job: 'школьник', infl: 18 }); bully.flags.bully = 1;
      const star = P(s, { role: 'одноклассни' + (Math.random() < 0.5 ? 'к' : 'ца'), circle: 'school', trait: 'душа компании', att: ri(45, 60), job: 'школьник', infl: 22 });
      const quiet = P(s, { role: 'одноклассник', circle: 'school', trait: 'застенчивый', att: ri(40, 55), job: 'школьник', infl: 3 }); quiet.flags.victim = 1;
      ids.push(bully.id, star.id, quiet.id);
      for (let i = 0; i < 5; i++) { const p = P(s, { circle: 'school', job: 'школьник', att: ri(35, 65), infl: ri(4, 14) }); p.role = p.sex === 'f' ? 'одноклассница' : 'одноклассник'; ids.push(p.id); }
      const tch = P(s, { role: 'классный руководитель', circle: 'school', age: ri(35, 58), att: ri(40, 60), job: 'учитель', infl: 30, sex: 'f' });
      if (fr) ids.push(fr.id);
      for (const x of ids) for (const y of ids) if (x < y && Math.random() < 0.45) link(S.people.find(p => p.id === x), S.people.find(p => p.id === y), ri(30, 80));
      link(bully, star, 70);
      SOC.group(s, E.ww2(s) ? 'Класс в школе' : 'Класс «Б»', 'school', ids);
      link(tch, star, 40);
    } else {
      const ids = [];
      for (let i = 0; i < 4; i++) { const p = P(s, { role: 'бывш. однокласс' + (Math.random() < 0.5 ? 'ник' : 'ница'), circle: 'school', age: a + ri(-1, 1), att: ri(35, 70) }); p.role = 'бывш. однокласс' + (p.sex === 'f' ? 'ница' : 'ник'); p.job = jobs(s, p.age); ids.push(p.id); }
      const lucky = S.people.find(p => p.id === ids[0]); lucky.job = E.ww2(s) ? 'начальник цеха' : 'владелец автомойки'; lucky.infl = 38; lucky.trait = 'карьерист';
      if (fr) ids.push(fr.id);
      for (const x of ids) for (const y of ids) if (x < y && Math.random() < 0.55) link(S.people.find(p => p.id === x), S.people.find(p => p.id === y), ri(35, 75));
      SOC.group(s, 'Школьные друзья', 'school', ids);
      if (s.job) SOC.newWork(s);
    }
    for (let i = 0; i < 2; i++) { const p = P(s, { role: 'сосед' + (Math.random() < 0.5 ? '' : 'ка'), circle: 'home', age: ri(25, 70), att: ri(35, 60) }); p.role = p.sex === 'f' ? 'соседка' : 'сосед'; p.job = jobs(s, p.age); }
    // скрытые влиятельные люди: цепочка «знакомый → средний → большой человек»
    const big = (E.ww2(s) ? BIG.ww2 : BIG.mod).map(([role, infl]) => P(s, { role, circle: 'elite', age: ri(38, 64), att: ri(30, 50), infl: infl + ri(-3, 3), known: false, job: role }));
    const known = S.people.filter(p => p.known);
    big.sort((x, y) => x.infl - y.infl).forEach((b, i) => {
      if (b.infl < 52) { const k = r(known.filter(p => p.circle !== 'elite')); link(b, k, ri(45, 70)); if (Math.random() < 0.5) link(b, r(known), ri(35, 60)); }
      else { const lower = big.filter(x => x.infl < b.infl && x.infl >= b.infl - 22); link(b, r(lower.length ? lower : big.slice(0, 3)), ri(45, 70)); if (lower.length > 1) link(b, r(lower), ri(35, 60)); }
    });
    SOC.sync(s);
    return S;
  };
  SOC.newWork = s => {
    const S = s.soc, ids = [];
    S.people.filter(p => p.circle === 'work').forEach(p => { p.circle = 'oldwork'; p.role = 'бывший коллега'; });
    S.groups.filter(g => g.kind === 'work').forEach(g => { g.kind = 'oldwork'; g.n = 'Бывшие коллеги'; g.mine = false; });
    const boss = P(s, { role: 'начальник', circle: 'work', age: ri(35, 55), att: ri(40, 55), infl: ri(32, 45), trait: r(['карьерист', 'вспыльчивый', 'честный', 'хитрый']), job: 'руководитель' }); ids.push(boss.id);
    for (let i = 0; i < 4; i++) { const p = P(s, { circle: 'work', age: age(s) + ri(-6, 12), att: ri(38, 62), infl: ri(6, 20) }); p.role = p.sex === 'f' ? 'коллега' : 'коллега'; p.job = s.job ? s.job.title : 'коллега'; ids.push(p.id); }
    for (const x of ids) for (const y of ids) if (x < y && Math.random() < 0.6) link(S.people.find(p => p.id === x), S.people.find(p => p.id === y), ri(30, 70));
    const elite = S.people.filter(p => !p.known && p.infl < 60); if (elite.length) link(boss, r(elite), ri(40, 60));
    SOC.group(s, 'Коллеги' + (s.job && s.job.org ? ' · ' + s.job.org : ''), 'work', ids);
    S.jobKey = s.job ? s.job.title : '';
  };
  // связь с «близкими» из старого досье
  SOC.sync = s => {
    const S = s.soc; if (!S) return;
    for (const p of S.people) if (p.npc) { const n = L.npc(s, p.npc); if (n) { if (Math.abs(n.att - p.att) > 0.1) { if (p._a !== undefined && Math.abs(p._a - p.att) > 0.1) n.att = p.att; else p.att = n.att; } p._a = p.att; p.alive = n.alive; p.age = n.age; } }
    for (const x of s.rel) if (x.soc) { const p = SOC.get(s, x.soc); if (p) { if (Math.abs(x.att - p.att) > 0.1) p.att = x.att = Math.max(x.att, p.att) === x.att ? x.att : p.att; p.role = x.role; } }
  };
  SOC.get = (s, id) => (s.soc ? s.soc.people.find(p => p.id === id) : null);
  SOC.known = s => s.soc.people.filter(p => p.known && p.alive);
  SOC.byName = (s, t) => { const n = E.norm(t || ''); if (!n || !s.soc) return null; return SOC.known(s).find(p => n.includes(E.norm(name(p)).slice(0, Math.max(3, name(p).length - 1))) || n.includes(E.norm(p.name))); };
  const feed = (s, t, imp) => { s.soc.feed.push({ t, d: E.monthStr(s.date), turn: s.turn, imp: imp || 0 }); if (s.soc.feed.length > 80) s.soc.feed.shift(); };
  const hist = (p, t, s) => { p.hist.push(t + ' (' + E.monthStr(s.date) + ')'); if (p.hist.length > 12) p.hist.shift(); };
  const att = (p, d) => { p.att = cl(p.att + d, 0, 100); };
  const linked = (s, p, min) => Object.keys(p.links).filter(id => p.links[id] >= (min || 0)).map(id => SOC.get(s, id)).filter(x => x && x.alive);
  const groupOf = (s, p) => s.soc.groups.find(g => g.members.includes(p.id) && g.mine);

  // ---------- неделя: люди живут своей жизнью ----------
  SOC.week = (s, rep) => {
    const S = SOC.init(s); SOC.sync(s);
    const a = age(s);
    if (S.school && a >= 18) { S.school = false; S.groups.filter(g => g.kind === 'school').forEach(g => g.n = 'Бывшие одноклассники'); S.people.filter(p => p.circle === 'school' && /^одноклассни/.test(p.role)).forEach(p => p.role = 'бывш. ' + p.role); feed(s, 'Школа позади. Класс разлетелся кто куда — но связи остались.', 1); }
    if (s.job && S.jobKey !== s.job.title && (!S.jobKey || !s.job.title.includes(S.jobKey))) { SOC.newWork(s); feed(s, 'Новая работа — новые коллеги и начальник.', 1); }
    if (!s.job && S.jobKey) S.jobKey = '';
    // остывание без общения
    for (const p of SOC.known(s)) {
      if (p.flags.family) continue;
      if (s.turn - (p.seen || 0) > 10) { const t = p.att > 70 ? 0.12 : 0.25; if (p.att > 45) att(p, -t); else if (p.att < 40) att(p, t * 0.6); }
      if (p.att < 20 && !p.flags.avoid && Math.random() < 0.08) { p.flags.avoid = 1; feed(s, `${p.name} при встрече делает вид, что вас не знает.`, 1); rep.life.push(`${name(p)} теперь избегает вас.`); }
      if (p.att >= 35 && p.flags.avoid) delete p.flags.avoid;
      if (Math.random() < 1 / 52 / 2) p.age++;
    }
    // фоновые события между знакомыми (новости, без вопросов)
    if (Math.random() < 0.45) { const t = SOC.bg(s); if (t) { feed(s, t); if (Math.random() < 0.6) rep.life.push(t); } }
    // события с выбором — примерно раз в 3–4 недели
    S.cool = (S.cool || 0) - 1;
    if (S.cool <= 0 && !rep.events.some(e => e.npc || e.soc) && Math.random() < 0.55) { const ev = SOC.pick(s); if (ev) { rep.events.push({ soc: ev }); S.cool = ri(3, 5); } }
  };
  // ---- фоновые истории ----
  SOC.bg = s => {
    const ks = SOC.known(s).filter(p => !p.flags.family);
    if (ks.length < 2) return null;
    const roll = Math.random();
    const A = r(ks);
    // ссора двух знакомых
    if (roll < 0.18) { const B = linked(s, A, 40).filter(p => p.known)[0]; if (!B) return null; A.links[B.id] = B.links[A.id] = Math.max(0, (A.links[B.id] || 50) - 40); return `${A.name} и ${B.name} разругались вдрызг — ${r(['из-за денег', 'из-за девушки', 'из-за ерунды в чате', 'из-за сплетни', 'из-за долга', 'на дне рождения'])}. Теперь не здороваются.`; }
    // роман
    if (roll < 0.34) { if (A.partner || A.age < 15) return null; const B = ks.find(p => p !== A && !p.partner && p.sex !== A.sex && Math.abs(p.age - A.age) < 7 && p.age >= 15 && (A.links[p.id] || 0) > 25); if (!B) return null; A.partner = B.id; B.partner = A.id; link(A, B, 90); hist(A, 'встречается с ' + name(B), s); hist(B, 'встречается с ' + name(A), s); return `${A.name} и ${B.name} теперь встречаются! ${r(['Вся компания в шоке.', 'Давно было видно.', 'Никто не ожидал.'])}`; }
    // расставание
    if (roll < 0.42) { const B = A.partner && SOC.get(s, A.partner); if (!B) return null; A.partner = B.partner = ''; A.links[B.id] = B.links[A.id] = 15; return `${A.name} и ${B.name} расстались. ${r(['Со скандалом.', 'Тихо, без драм.', 'Друзьям теперь приходится выбирать сторону.'])}`; }
    // сплетни о других
    if (roll < 0.54) { const B = linked(s, A, 0).filter(p => p.known && p !== A)[0]; if (!B) return null; for (const C of linked(s, B, 30)) if (C.links[B.id]) C.links[B.id] = Math.max(0, C.links[B.id] - 8); return `${A.name} рассказывает всем, что ${name(B)} ${r(['много врёт', 'по уши в долгах', 'изменяет', 'подсиживает коллег', G(B, 'зазнался', 'зазналась'), 'всё делает за спиной'])}. ${r(['Похоже на правду.', 'Многие поверили.', 'Слухи ползут.'])}`; }
    // хорошее
    if (roll < 0.72) { const f = A.sex === 'f', t = r(kid(s) && A.age < 18 ? [[f ? 'выиграла олимпиаду' : 'выиграл олимпиаду', 3], [f ? 'стала капитаном команды' : 'стал капитаном команды', 2], [f ? 'получила новый телефон' : 'получил новый телефон', 0]] : [[f ? 'получила повышение' : 'получил повышение', 6], [f ? 'вышла замуж' : 'женился', 0], [f ? 'стала мамой' : 'стал отцом', 0], [f ? 'выиграла в лотерею' : 'выиграл в лотерею', 2], [f ? 'открыла своё дело' : 'открыл своё дело', 8], [f ? 'купила машину' : 'купил машину', 1], [f ? 'переехала в квартиру получше' : 'переехал в квартиру получше', 1]]); A.infl = cl(A.infl + t[1], 0, 100); hist(A, t[0], s); if (/женил|замуж/.test(t[0])) A.married = true; return `${A.name} ${t[0]}.`; }
    // плохое
    if (roll < 0.9) { const f = A.sex === 'f', t = r(kid(s) && A.age < 18 ? [f ? 'попала к директору' : 'попал к директору', f ? 'подралась на перемене' : 'подрался на перемене', f ? 'завалила контрольную' : 'завалил контрольную'] : [f ? 'потеряла работу' : 'потерял работу', f ? 'попала в больницу' : 'попал в больницу', f ? 'развелась' : 'развёлся', f ? 'влезла в долги' : 'влез в долги', f ? 'попала в аварию' : 'попал в аварию', f ? 'задержана за драку' : 'задержан за драку']); A.infl = cl(A.infl - 3, 0, 100); hist(A, t, s); return `${A.name} ${t}.`; }
    // новое знакомство в жизни
    if (SOC.known(s).length < 40) { const p = P(s, { role: r(kid(s) ? ['ребята со двора', 'с секции', 'из лагеря'] : ['познакомились в спортзале', 'сосед по даче', 'знакомый знакомых', 'попутчик в поезде', 'новый сосед']), circle: 'misc', att: ri(40, 55) }); p.job = jobs(s, p.age = kid(s) ? age(s) + ri(-1, 1) : ri(20, 50)); link(p, r(ks), ri(20, 50)); return `Новое знакомство: ${p.name} (${p.role}).`; }
    return null;
  };
  // ---- события с выбором ----
  SOC.pick = s => {
    const ks = SOC.known(s).filter(p => !p.flags.family), pool = [];
    const a = age(s);
    // школа: травля
    if (s.soc.school) { const bully = ks.find(p => p.flags.bully && p.circle === 'school'); if (bully && Math.random() < 0.5) { const victim = ks.find(p => p.flags.victim); pool.push(Math.random() < 0.5 || !victim ? { k: 'bullyme', p: bully.id } : { k: 'bullyother', p: bully.id, v: victim.id }); } }
    // слух о вас
    const src = ks.filter(p => p.att < 45 || ['сплетник', 'завистливый'].includes(p.trait)); if (src.length && Math.random() < 0.4) pool.push({ k: 'rumor', p: r(src).id, t: r(kid(s) ? RUM.school : RUM.adult).replace('{x}', name(r(ks))) });
    // двое ваших друзей поссорились
    const fr = ks.filter(p => p.att >= 55); if (fr.length >= 2) { const A = r(fr), B = fr.find(p => p !== A && (A.links[p.id] || 0) > 20); if (B) pool.push({ k: 'quarrel', p: A.id, v: B.id, why: r(['из-за денег, которые один занял у другого', 'из-за девушки', 'из-за обидной шутки', 'из-за того, кто кого подвёл']) }); }
    // знакомый в беде
    const tr = ks.filter(p => p.att >= 45 && p.age >= 16); if (tr.length && a >= 16) pool.push({ k: 'trouble', p: r(tr).id, t: r(['потерял работу и не может платить за квартиру', 'попал в больницу, нужны деньги на лечение', 'влез в долги к неприятным людям', 'разводится и ему негде жить']), sum: Math.round(E.m(s, ri(15, 60) * 1000)) });
    // праздник / вечеринка
    const gs = s.soc.groups.filter(g => g.mine && g.members.length >= 3); if (gs.length) { const g = r(gs); const host = SOC.get(s, r(g.members)); if (host && host.known) pool.push({ k: 'party', p: host.id, g: g.id, what: r(a < 18 ? ['день рождения', 'вписка', 'поход на речку'] : ['день рождения', 'свадьба', 'шашлыки на даче', 'новоселье', 'корпоратив']) }); }
    // знакомство с влиятельным
    for (const p of ks.filter(p => p.att >= 62)) { const h = Object.keys(p.links).map(id => SOC.get(s, id)).find(x => x && !x.known && x.infl > p.infl); if (h) { pool.push({ k: 'intro', p: p.id, v: h.id }); break; } }
    // влиятельный знакомый предлагает
    const vip = ks.filter(p => p.infl >= 40 && p.att >= 60); if (vip.length && a >= 18) pool.push({ k: 'offer', p: r(vip).id, t: r(['job', 'deal', 'support']) });
    // взрослые: бывший друг избегает
    const cold = ks.filter(p => p.att < 25 && !kid(s)); if (cold.length) pool.push({ k: 'avoid', p: r(cold).id });
    // симпатия
    const cr = ks.filter(p => !p.partner && p.sex !== s.ch.sex && Math.abs(p.age - a) < 6 && p.age >= 15 && a >= 15 && p.att >= 50 && !s.rel.some(x => ['партнёр', 'супруг(а)'].includes(x.role))); if (cr.length) pool.push({ k: 'crush', p: r(cr).id });
    return pool.length ? r(pool) : null;
  };
  // текст события и варианты
  SOC.view = (s, e) => {
    const p = SOC.get(s, e.p), v = e.v ? SOC.get(s, e.v) : null; if (!p) return null;
    const N = p.name, n = name(p), sx = p.sex === 'f';
    switch (e.k) {
      case 'bullyme': return { t: `${n} опять цепляется`, x: `${N} при всём классе отпускает шуточки в ваш адрес, толкает в коридоре. Половина класса смеётся.`, o: [['Дать отпор', 'str', 50], ['Отшутиться так, чтобы смеялись над ним', 'cha', 50], ['Рассказать учителю'], ['Терпеть и молчать']] };
      case 'bullyother': return { t: `Травят ${name(v)}`, x: `${N} с компанией зажали ${v.name} у раздевалки: отобрали рюкзак, снимают на телефон. Вокруг смеются.`, o: [['Заступиться', 'str', 45], ['Позвать взрослых'], ['Пройти мимо'], ['Посмеяться вместе со всеми']] };
      case 'rumor': return { t: 'Про вас пошёл слух', x: `По знакомым ходит слух, что ${e.t}. Кто-то уже косо смотрит.`, o: [['Публично опровергнуть', 'cha', 45], ['Выяснить, кто распустил', 'int', 45], ['Посмеяться над этим', 'cha', 55], ['Не обращать внимания']] };
      case 'quarrel': return { t: `${n} и ${name(v)} поссорились`, x: `Ваши друзья ${N} и ${v.name} разругались ${e.why}. Оба ждут, что вы встанете на их сторону.`, o: [[`Поддержать ${n}`], [`Поддержать ${name(v)}`], ['Помирить их', 'cha', 45], ['Не лезть']] };
      case 'trouble': return { t: `${n} в беде`, x: `${N} ${sx ? e.t.replace('потерял', 'потеряла').replace('попал', 'попала').replace('влез', 'влезла').replace(' ему ', ' ей ') : e.t}. Просит помочь: ${E.money(e.sum)}.`, o: [[`Дать ${E.money(e.sum)}`], ['Поддержать словом и делом'], ['Отказать']] };
      case 'party': { const g = s.soc.groups.find(x => x.id === e.g); return { t: `${n} зовёт: ${e.what}`, x: `${N} собирает всех из компании «${g ? g.n : 'друзья'}». Будут все свои и пара новых людей.`, o: [['Пойти (подарок ' + E.money(Math.round(E.m(s, 3000))) + ')'], ['Пойти и стать душой вечера', 'cha', 50], ['Не пойти']] }; }
      case 'intro': return { t: `${n} предлагает познакомить`, x: `${N}: «Слушай, у меня есть знакомый — ${v.role.toLowerCase()}, ${v.name}. Хочешь, сведу вас?»`, o: [['Да, познакомь'], ['Произвести впечатление', 'cha', 45], ['Не сейчас']] };
      case 'offer': { const T = { job: `${N} (${p.role.toLowerCase()}) может устроить вас на хорошую должность к себе.`, deal: `${N} (${p.role.toLowerCase()}) предлагает вложиться в его дело: «Верная тема, отобьёшь вдвое».`, support: `${N} (${p.role.toLowerCase()}) готов замолвить за вас слово в нужных кругах.` }; return { t: `Предложение от ${n}`, x: T[e.t], o: e.t === 'deal' ? [['Вложить ' + E.money(Math.round(E.m(s, 80000))), 'biz', 50], ['Отказаться вежливо']] : [['Согласиться'], ['Отказаться вежливо']] }; }
      case 'avoid': return { t: `${n} вас избегает`, x: `${N} перешёл${sx ? 'а' : ''} на другую сторону улицы, едва вас заметив. Раньше вы были ближе.`, o: [['Догнать и поговорить начистоту', 'cha', 45], ['Передать мириться через общих знакомых'], ['Ну и ладно']] };
      case 'crush': return { t: `${n} явно к вам неравнодуш${sx ? 'на' : 'ен'}`, x: `${N} всё чаще пишет первым${sx ? 'и' : ''}, зовёт куда-нибудь вдвоём. Друзья уже шутят.`, o: [['Позвать на свидание', 'cha', 50], ['Остаться друзьями'], ['Держать дистанцию']] };
    }
    return null;
  };
  SOC.resolve = (s, e, i) => {
    const p = SOC.get(s, e.p), v = e.v ? SOC.get(s, e.v) : null, V = SOC.view(s, e), o = V.o[i], lines = [];
    let roll = null, ok = true;
    if (o[1]) { roll = E.roll(s, E.chance(s, 100 - (o[2] || 50), o[1])); ok = roll.ok; }
    const A = (x, d) => { if (!x || !d) return; att(x, d); lines.push(x.name + ': отношение ' + (d > 0 ? '+' : '') + d); };
    const grp = (x, d) => { const g = groupOf(s, x); if (!g) return; for (const id of g.members) { const q = SOC.get(s, id); if (q && q !== x && q.known) att(q, d); } lines.push('Компания «' + g.n + '»: ' + (d > 0 ? '+' : '') + d); };
    p.seen = s.turn;
    switch (e.k) {
      case 'bullyme':
        if (i === 0) { if (ok) { A(p, -8); grp(p, 4); p.flags.backoff = (p.flags.backoff || 0) + 1; if (p.flags.backoff >= 2) delete p.flags.bully; lines.push(...fx(s, { happy: 6, rep: 2 })); lines.push(n2(p) + G(p, ' отстал', ' отстала') + '. Класс зауважал.'); } else lines.push(...fx(s, { health: -4, happy: -8, stress: 6 })); }
        if (i === 1) { if (ok) { grp(p, 3); A(p, -5); lines.push('Смеялись уже над ним.'); lines.push(...fx(s, { happy: 5 })); } else { lines.push(...fx(s, { happy: -6 })); } }
        if (i === 2) { A(p, -15); grp(p, -3); if (Math.random() < 0.6) { delete p.flags.bully; lines.push('Его вызвали к директору — отстал.'); } else lines.push('Учительница пожурила его. Стало только хуже.'); s.soc.flagSnitch = s.turn; }
        if (i === 3) lines.push(...fx(s, { happy: -6, stress: 6 }));
        break;
      case 'bullyother':
        if (i === 0) { if (ok) { A(v, 25); A(p, -12); grp(v, 3); lines.push(...fx(s, { happy: 6, rep: 2 })); delete v.flags.victim; } else { A(v, 15); A(p, -8); lines.push(...fx(s, { health: -5, happy: -4 })); } }
        if (i === 1) { A(v, 12); A(p, -10); }
        if (i === 2) { A(v, -6); lines.push(...fx(s, { happy: -2 })); }
        if (i === 3) { A(p, 10); A(v, -30); lines.push(...fx(s, { happy: -3 })); v.flags.hate = 1; hist(v, 'вы смеялись над ' + G(v, 'ним', 'ней') + ' вместе со всеми', s); }
        break;
      case 'rumor':
        if (i === 0) { if (ok) { grp(p, 2); lines.push('Вам поверили.'); } else { grp(p, -4); lines.push('Стало только хуже: «оправдывается — значит правда».'); } }
        if (i === 1) { if (ok) { A(p, -20); p.flags.src = 1; lines.push(G(p, 'Слух пустил ', 'Слух пустила ') + p.name + '. Теперь вы знаете, кому не доверять.'); } else lines.push('Концов найти не удалось.'); }
        if (i === 2) { if (ok) { grp(p, 2); lines.push(...fx(s, { happy: 3 })); } else grp(p, -2); }
        if (i === 3) { grp(p, -2); lines.push('Через пару недель слух сам затих.'); }
        break;
      case 'quarrel':
        if (i === 0) { A(p, 12); A(v, -15); }
        if (i === 1) { A(v, 12); A(p, -15); }
        if (i === 2) { if (ok) { A(p, 6); A(v, 6); p.links[v.id] = v.links[p.id] = 60; lines.push('Помирились — пьют чай вместе.'); } else { A(p, -4); A(v, -4); lines.push('Досталось и вам: «а ты вообще не лезь».'); } }
        if (i === 3) { A(p, -3); A(v, -3); }
        break;
      case 'trouble':
        if (i === 0) { if (s.st.money < e.sum) { lines.push('Не хватает денег — помогли, чем смогли.'); A(p, 4); } else { s.st.money -= e.sum; lines.push('−' + E.money(e.sum)); A(p, 18); for (const q of linked(s, p, 40)) if (q.known) att(q, 3); lines.push('Его друзья это запомнили: +3'); hist(p, 'вы выручили деньгами', s); p.flags.owes = 1; } }
        if (i === 1) { A(p, 8); lines.push(...fx(s, { stress: 3 })); }
        if (i === 2) { A(p, -12); hist(p, 'вы отказали в трудную минуту', s); }
        break;
      case 'party': {
        const gift = Math.round(E.m(s, 3000));
        if (i < 2) { s.st.money -= gift; lines.push('−' + E.money(gift)); grp(p, i === 1 && ok ? 6 : 3); A(p, 4); lines.push(...fx(s, { happy: i === 1 && ok ? 10 : 6, stress: -6 })); if (Math.random() < 0.55) { const nw = meet(s, p); if (nw) lines.push('Познакомились: ' + nw.name + ' — ' + nw.role.toLowerCase()); } if (i === 1 && !ok) lines.push('Перестарались — над вами посмеивались.'); }
        else grp(p, -1);
        break;
      }
      case 'intro':
        if (i < 2) { v.known = true; v.via = p.id; v.seen = s.turn; v.met = E.monthStr(s.date); v.att = cl(30 + p.att * 0.25 + (i === 1 ? (ok ? 12 : -8) : 0), 0, 100); lines.push('Новое знакомство: ' + v.name + ', ' + v.role.toLowerCase() + ' (влияние ' + v.infl + ')'); feed(s, `${p.name} ${G(p, 'познакомил', 'познакомила')} вас: ${v.name} (${v.role.toLowerCase()}).`, 2); A(p, 2); }
        else A(p, -2);
        break;
      case 'offer':
        if (e.t === 'job' && i === 0) { const res = favorJob(s, p); lines.push(...res); A(p, -6); }
        if (e.t === 'support' && i === 0) { s.st.rep = cl(s.st.rep + Math.round(p.infl / 12), 0, 100); s.flags.campaign = (s.flags.campaign || 0) + Math.round(p.infl / 10); lines.push('Репутация +' + Math.round(p.infl / 12) + (s.election ? ', шанс на выборах +' + Math.round(p.infl / 10) + '%' : '')); A(p, -4); }
        if (e.t === 'deal' && i === 0) { const sum = Math.round(E.m(s, 80000)); if (s.st.money < sum) lines.push('Не хватило денег — сделка ушла другим.'); else { s.st.money -= sum; if (ok) { s.st.money += sum * 2; lines.push('Сделка выгорела: +' + E.money(sum)); A(p, 6); } else { lines.push('Деньги пропали: −' + E.money(sum) + '. «Ну, рынок…»'); A(p, -4); } } }
        if (i === 1) A(p, -2);
        break;
      case 'avoid':
        if (i === 0) { if (ok) { A(p, 25); delete p.flags.avoid; lines.push('Поговорили. Обиды позади.'); } else { A(p, -5); lines.push('Разговора не вышло.'); } }
        if (i === 1) { const mid = linked(s, p, 50).find(q => q.known && q.att >= 55); if (mid) { A(p, 14); delete p.flags.avoid; lines.push(mid.name + G(mid, ' передал', ' передала') + ' — лёд тронулся.'); } else lines.push('Общих знакомых, кто бы взялся, не нашлось.'); }
        if (i === 2) A(p, -3);
        break;
      case 'crush':
        if (i === 0) { if (ok) { att(p, 15); p.partner = 'me'; s.rel.push({ name: p.name, role: 'партнёр', att: p.att, soc: p.id }); lines.push('Теперь вы пара!'); lines.push(...fx(s, { happy: 12 })); feed(s, `Вы и ${p.name} теперь вместе.`, 2); } else { att(p, -5); lines.push('Свидание вышло неловким.'); } }
        if (i === 1) A(p, 2);
        if (i === 2) A(p, -6);
        break;
    }
    feed(s, V.t + ' — ' + o[0].toLowerCase());
    E.logAdd(s, 'event', V.t + ': ' + o[0], { lines, ok: roll ? roll.ok : undefined });
    SOC.sync(s);
    return { lines, roll, ok, title: V.t + ': ' + o[0].toLowerCase(), x: V.x };
  };
  const n2 = p => name(p);
  const meet = (s, via) => {
    const hid = Object.keys(via.links).map(id => SOC.get(s, id)).find(x => x && !x.known);
    if (hid) { hid.known = true; hid.via = via.id; hid.seen = s.turn; hid.met = E.monthStr(s.date); hid.att = ri(35, 50); return hid; }
    const p = P(s, { role: 'друг ' + (via.sex === 'f' ? 'подруги ' : 'друга ') + name(via), circle: 'misc', age: via.age + ri(-3, 3), att: ri(38, 55) }); p.job = jobs(s, p.age); link(p, via, ri(50, 80)); p.via = via.id; return p;
  };
  const favorJob = (s, p) => {
    if (s.job && !s.job.army) { s.job.perf = cl((s.job.perf || 50) + 15, 0, 100); s.job.salary = Math.round((s.job.salary || 0) * 1.15); return ['Начальству позвонили: зарплата +15%, к вам присматриваются для повышения.']; }
    const j = E.pick(D.JOBS.filter(x => !x.req || !x.req.edu || x.req.edu <= s.ch.edu)); s.job = { id: j.id, title: j.ladder[Math.min(1, j.ladder.length - 1)], org: '', salary: Math.round(E.salary(s, j.sal) * 1.2), level: Math.min(1, j.ladder.length - 1), perf: 60, months: 0, weeks: 0, sk: j.sk, ladder: j.ladder };
    return ['Вас взяли без собеседования: ' + s.job.title + ', ' + E.money(s.job.salary) + '/мес'];
  };

  // ---------- действия из окна ----------
  const spend = s => { if (s.ap <= 0) { UI.toast('На этой неделе сил больше нет — нажмите «Неделя»', 'bad'); return false; } s.ap--; return true; };
  const done = (title, lines, ok, roll) => { UI.appendMsg({ k: 'out', ok: ok !== false, title, lines, roll: roll ? { roll: roll.roll, chance: roll.chance } : null }); UI.save(); UI.renderAll(); };
  SOC.act = (id, what, arg) => {
    const s = UI.s, p = SOC.get(s, id); if (!p) return;
    const lines = []; let roll = null, ok = true, title = '';
    if (what === 'intro') {
      const v = SOC.get(s, arg); if (!v || v.known) return; if (!spend(s)) return;
      const ch = cl(35 + (p.att - 50) * 0.9 + (p.links[v.id] || 40) * 0.25 - Math.max(0, v.infl - p.infl - 15) * 0.6 + (E.sk(s, 'cha') - 40) * 0.3, 5, 92);
      roll = E.roll(s, Math.round(ch)); ok = roll.ok; title = ok ? `${name(p)} ${G(p, 'познакомил', 'познакомила')} вас: ${v.name}, ${v.role.toLowerCase()}` : `${name(p)} не ${G(p, 'стал', 'стала')} вас сводить`;
      if (ok) { v.known = true; v.via = p.id; v.seen = s.turn; v.met = E.monthStr(s.date); v.att = cl(30 + p.att * 0.25, 0, 100); lines.push(v.role + ', влияние ' + v.infl); feed(s, `${p.name} ${G(p, 'познакомил', 'познакомила')} вас: ${v.name} (${v.role.toLowerCase()}).`, 2); att(p, -2); }
      else { lines.push('«Неудобно мне его дёргать по пустякам»'); att(p, -3); }
    }
    if (what === 'favor') {
      if (!spend(s)) return; const ch = cl(30 + (p.att - 50) * 1.1 + p.infl * 0.2, 5, 90); roll = E.roll(s, Math.round(ch)); ok = roll.ok;
      title = ok ? `${name(p)} ${G(p, 'помог', 'помогла')}` : `${name(p)} ${G(p, 'отказал', 'отказала')}`;
      if (ok) { if (arg === 'job') lines.push(...favorJob(s, p)); if (arg === 'money') { const sum = Math.round(E.m(s, p.infl * 2500)); s.st.money += sum; lines.push(G(p, 'Одолжил ', 'Одолжила ') + E.money(sum) + ' — без процентов, «по-дружески»'); p.flags.lent = sum; } if (arg === 'rep') { const d = Math.round(p.infl / 10); s.st.rep = cl(s.st.rep + d, 0, 100); s.flags.campaign = (s.flags.campaign || 0) + Math.round(p.infl / 12); lines.push(G(p, 'Замолвил', 'Замолвила') + ' словечко: репутация +' + d); } att(p, -10); lines.push(p.name + ': «Теперь ты мне должен» (отношение −10)'); }
      else { att(p, -4); lines.push('«Не могу, извини»'); }
    }
    if (what === 'gossip') {
      if (!spend(s)) return; roll = E.roll(s, E.chance(s, 55, 'cha')); ok = roll.ok; title = ok ? `Слух про ${name(p)} пошёл` : 'Слух не прижился';
      if (ok) { for (const q of linked(s, p, 0)) { q.links[p.id] = Math.max(0, (q.links[p.id] || 40) - 12); } p.infl = cl(p.infl - 3, 0, 100); lines.push('Его друзья отдалились, влияние −3'); }
      if (Math.random() < (ok ? 0.3 : 0.55)) { att(p, -35); p.flags.src = 0; lines.push(`${name(p)} ${G(p, 'узнал', 'узнала')}, что это вы. Отношение −35`); hist(p, G(p, 'узнал', 'узнала') + ', что вы распускали слухи', s); }
    }
    if (what === 'quarrel') { att(p, -30); title = 'Поссорились с ' + name(p); lines.push(p.name + ': отношение −30'); hist(p, 'поссорились с вами', s); for (const q of linked(s, p, 60)) if (q.known) att(q, -4); lines.push('Его близкие друзья на его стороне: −4'); }
    if (what === 'makeup') { if (!spend(s)) return; roll = E.roll(s, E.chance(s, 45 + (p.att - 30) * 0.5, 'cha')); ok = roll.ok; title = ok ? 'Помирились с ' + name(p) : name(p) + G(p, ' пока не готов', ' пока не готова') + ' мириться'; if (ok) { att(p, 22); delete p.flags.avoid; } else att(p, -2); }
    if (what === 'gift') { const sum = Math.round(E.m(s, 10000)); if (s.st.money < sum) { UI.toast('Не хватает денег', 'bad'); return; } s.st.money -= sum; att(p, 8); title = 'Помогли деньгами: ' + p.name; lines.push('−' + E.money(sum), 'отношение +8'); hist(p, 'вы помогли деньгами', s); }
    if (what === 'join' || what === 'kick') {
      let g = s.soc.groups.find(x => x.kind === 'mine');
      if (what === 'join') { if (!g) g = SOC.group(s, 'Моя компания', 'mine', []); if (!g.members.includes(p.id)) g.members.push(p.id); title = p.name + ' теперь в вашей компании'; for (const id of g.members) { const q = SOC.get(s, id); if (q && q !== p) link(p, q, Math.max(p.links[q.id] || 0, 45)); } }
      else if (g) { g.members = g.members.filter(x => x !== p.id); title = p.name + ' больше не в вашей компании'; att(p, -6); }
    }
    p.seen = s.turn; SOC.sync(s);
    done(title, lines, ok, roll); SOC.ui(SOC._tab, SOC._sel);
  };
  SOC.gather = gid => {
    const s = UI.s, g = s.soc.groups.find(x => x.id === gid); if (!g || !spend(s)) return;
    const cost = Math.round(E.m(s, 2500 + g.members.length * 600)); s.st.money -= cost;
    const lines = ['Посидели всей компанией: −' + E.money(cost)];
    for (const id of g.members) { const q = SOC.get(s, id); if (q && q.known) { att(q, 3); q.seen = s.turn; } }
    lines.push('Все в компании: +3', ...fx(s, { happy: 8, stress: -8 }));
    if (Math.random() < 0.35) { const via = SOC.get(s, r(g.members)); const nw = via && meet(s, via); if (nw) lines.push('Кто-то привёл друга: ' + nw.name); }
    if (Math.random() < 0.25) { const ids = g.members.filter(x => SOC.get(s, x)); if (ids.length >= 2) { const A = SOC.get(s, ids[0]), B = SOC.get(s, ids[1]); lines.push(`${name(A)} и ${name(B)} под конец вечера поругались. Неловко.`); A.links[B.id] = B.links[A.id] = Math.max(0, (A.links[B.id] || 50) - 20); } }
    feed(s, `Собрались компанией «${g.n}».`, 1);
    done('Собрали компанию «' + g.n + '»', lines, true); SOC.ui('groups');
  };
  SOC.leave = gid => { const s = UI.s, g = s.soc.groups.find(x => x.id === gid); if (!g) return; g.mine = false; for (const id of g.members) { const q = SOC.get(s, id); if (q) att(q, -4); } feed(s, `Вы отдалились от компании «${g.n}».`, 1); UI.save(); SOC.ui('groups'); };
  SOC.rejoin = gid => { const s = UI.s, g = s.soc.groups.find(x => x.id === gid); if (!g || !spend(s)) return; g.mine = true; UI.save(); SOC.ui('groups'); };

  // ---------- окно «Знакомые» ----------
  const CIRC = { all: 'Все', school: 'Школа', work: 'Работа', oldwork: 'Бывшая работа', home: 'Соседи', yard: 'Двор', misc: 'Разные', elite: 'Влиятельные' };
  const avatar = p => UI.avatar({ sex: p.sex, look: L.hash(p.name) % 9999 }, 48);
  SOC.ui = (tab, sel) => {
    const s = UI.s; SOC.init(s); SOC.sync(s); SOC._tab = tab = tab || 'people'; SOC._sel = sel;
    const ks = SOC.known(s), S = s.soc;
    const fam = s.rel.filter(r => ['мать', 'отец', 'супруг(а)', 'партнёр'].includes(r.role));
    const tabs = [['people', 'Люди · ' + ks.length], ['groups', 'Компании · ' + S.groups.filter(g => g.mine).length], ['net', 'Выйти на людей'], ['feed', 'Что происходит']];
    let body = '';
    if (tab === 'people') {
      const f = sel || 'all', list = ks.filter(p => f === 'all' || p.circle === f).sort((a, b) => b.att - a.att);
      body = `<div class="soc-filter">${Object.keys(CIRC).filter(k => k === 'all' || ks.some(p => p.circle === k)).map(k => `<button class="${k === f ? 'on' : ''}" data-f="${k}">${CIRC[k]}</button>`).join('')}</div>
      <div class="soc-grid">${list.map(p => card(s, p)).join('') || '<p class="small">Пока никого.</p>'}</div>
      <div class="soc-fam"><h4>Семья</h4>${fam.map(r => `<div class="kv"><span>${UI.esc(r.name)} <small>${r.role}</small></span>${UI.bar(r.att, 'good')}</div>`).join('')}${(s.kids || []).map(k => `<div class="kv"><span>${UI.esc(k.name)} <small>${k.sex === 'm' ? 'сын' : 'дочь'}</small></span>${UI.bar(k.att || 70, 'good')}</div>`).join('') || ''}</div>`;
    }
    if (tab === 'groups') {
      body = `<div class="soc-groups">${S.groups.map(g => { const ms = g.members.map(id => SOC.get(s, id)).filter(Boolean); const avg = ms.length ? Math.round(ms.reduce((a, p) => a + p.att, 0) / ms.length) : 0;
        const pairs = []; for (const a of ms) if (a.partner) { const b = ms.find(x => x.id === a.partner); if (b && a.id < b.id) pairs.push(name(a) + ' ❤ ' + name(b)); }
        const fights = []; for (const a of ms) for (const b of ms) if (a.id < b.id && a.links[b.id] !== undefined && a.links[b.id] < 20) fights.push(name(a) + ' ⚡ ' + name(b));
        return `<div class="soc-group ${g.mine ? '' : 'off'}"><div class="sgh"><b>${UI.esc(g.n)}</b><small>${ms.length} чел. · к вам в среднем ${avg}${g.mine ? '' : ' · вы отдалились'}</small></div>
          <div class="sgm">${ms.map(p => `<span class="sgp ${SOC.cls(p.att)}" title="${UI.esc(p.name)} — ${SOC.label(p.att)}">${avatar(p)}<i>${UI.esc(name(p))}</i></span>`).join('')}</div>
          ${pairs.length ? `<div class="sgx">Пары: ${pairs.join(', ')}</div>` : ''}${fights.length ? `<div class="sgx bad">В ссоре: ${fights.slice(0, 4).join(', ')}</div>` : ''}
          <div class="nbtn">${g.mine ? `<button class="btn small primary" data-gather="${g.id}">Собрать всех</button><button class="btn small" data-leave="${g.id}">Отдалиться</button>` : `<button class="btn small" data-rejoin="${g.id}">Вернуться в компанию</button>`}</div></div>`; }).join('')}</div>
        <p class="note">Свою компанию можно собрать: на карточке человека нажмите «В мою компанию».</p>`;
    }
    if (tab === 'net') {
      const rows = [];
      for (const p of ks) for (const id of Object.keys(p.links)) { const v = SOC.get(s, id); if (v && !v.known && v.alive) rows.push([p, v]); }
      rows.sort((a, b) => b[1].infl - a[1].infl);
      body = `<p class="note">Знакомые знакомых. Чем лучше к вам относится посредник и чем ближе он к нужному человеку — тем выше шанс, что вас сведут. Большие люди знакомы только с теми, кто тоже не из простых — поднимайтесь по цепочке.</p>
      <div class="soc-net">${rows.map(([p, v]) => `<div class="snr"><span>${avatar(p)}<b>${UI.esc(p.name)}</b><small>${SOC.label(p.att)} · влияние ${p.infl}</small></span><span class="arr">→</span><span><b>${UI.esc(v.name)}</b><small>${UI.esc(v.role)} · влияние ${v.infl}</small></span><button class="btn small" data-intro="${p.id}" data-v="${v.id}">Попросить познакомить</button></div>`).join('') || '<p class="small">Пока не на кого выходить — заводите знакомства, ходите на праздники.</p>'}</div>`;
    }
    if (tab === 'feed') body = `<ul class="soc-feed">${S.feed.slice().reverse().map(f => `<li class="${f.imp >= 2 ? 'imp' : ''}"><small>${f.d}</small>${UI.esc(f.t)}</li>`).join('') || '<li>Пока тихо.</li>'}</ul>`;
    U.big(`${U.head('user', 'Знакомые', 'Все, кого вы знаете: они дружат, ссорятся и влюбляются между собой — и помнят, что вы для них сделали')}
      <div class="soc-tabs">${tabs.map(([k, n]) => `<button class="${k === tab ? 'on' : ''}" data-tab="${k}">${n}</button>`).join('')}</div><div class="soc-body">${body}</div>`);
    $$('#modal [data-tab]').forEach(b => b.onclick = () => SOC.ui(b.dataset.tab));
    $$('#modal [data-f]').forEach(b => b.onclick = () => SOC.ui('people', b.dataset.f));
    $$('#modal [data-act]').forEach(b => b.onclick = () => SOC.act(b.dataset.id, b.dataset.act, b.dataset.arg));
    $$('#modal [data-intro]').forEach(b => b.onclick = () => SOC.act(b.dataset.intro, 'intro', b.dataset.v));
    $$('#modal [data-fill]').forEach(b => b.onclick = () => { const p = SOC.get(s, b.dataset.id); if (p) p.seen = s.turn; UI.closeModal(); UI.fill(b.dataset.fill); });
    $$('#modal [data-gather]').forEach(b => b.onclick = () => SOC.gather(b.dataset.gather));
    $$('#modal [data-leave]').forEach(b => b.onclick = () => SOC.leave(b.dataset.leave));
    $$('#modal [data-rejoin]').forEach(b => b.onclick = () => SOC.rejoin(b.dataset.rejoin));
    $$('#modal [data-more]').forEach(b => b.onclick = () => { const el = b.closest('.npc').querySelector('.more'); el.classList.toggle('open'); });
  };
  const card = (s, p) => {
    const via = p.via && SOC.get(s, p.via), part = p.partner && p.partner !== 'me' && SOC.get(s, p.partner);
    const unknownLinks = Object.keys(p.links).map(id => SOC.get(s, id)).filter(v => v && !v.known && v.alive);
    const mineG = s.soc.groups.find(g => g.kind === 'mine'), inMine = mineG && mineG.members.includes(p.id);
    const canFavor = p.infl >= 30 && p.att >= 55 && age(s) >= 16;
    const date = !kid(s) || age(s) >= 15 ? (p.sex !== s.ch.sex && p.age >= 16 && Math.abs(p.age - age(s)) < 12 && !p.partner) : false;
    return `<div class="npc soc ${SOC.cls(p.att)} ${p.flags.avoid ? 'avoid' : ''}">
      <div class="nh">${avatar(p)}<div><b>${UI.esc(p.name)}</b><small>${UI.esc(p.role)} · ${E.years(p.age)}</small><small>${UI.esc(p.job || '')}${p.trait ? ' · ' + p.trait : ''}</small></div></div>
      <div class="kv"><span>К вам</span><b>${SOC.label(p.att)} · ${Math.round(p.att)}</b></div>${UI.bar(p.att, SOC.cls(p.att))}
      <div class="kv"><span>Влияние</span><b>${p.infl}</b></div>
      ${part ? `<div class="kv"><span>Встречается</span><b>${UI.esc(part.name)}</b></div>` : p.partner === 'me' ? `<div class="kv"><span>Встречается</span><b>с вами</b></div>` : ''}
      ${via ? `<div class="kv"><span>Познакомил(а)</span><b>${UI.esc(via.name)}</b></div>` : ''}
      ${p.flags.avoid ? '<div class="sgx bad">Избегает вас</div>' : ''}${p.flags.bully ? '<div class="sgx bad">Задира — цепляется к слабым</div>' : ''}${p.flags.src ? '<div class="sgx bad">Распускал(а) про вас слухи</div>' : ''}
      ${p.hist.length ? `<div class="nhist">${p.hist.slice().reverse().slice(0, 4).map(h => `<span>${UI.esc(h)}</span>`).join('')}</div>` : ''}
      <div class="nbtn"><button class="btn small" data-id="${p.id}" data-fill="Звоню ${UI.esc(name(p))}, болтаем обо всём">Позвонить</button><button class="btn small" data-id="${p.id}" data-fill="Встречаюсь с ${UI.esc(p.name)}, гуляем и общаемся">Встретиться</button>${date ? `<button class="btn small" data-id="${p.id}" data-fill="Приглашаю ${UI.esc(p.name)} на свидание">На свидание</button>` : ''}<button class="btn small" data-more="1">Ещё…</button></div>
      <div class="more nbtn">
        <button class="btn small" data-act="gift" data-id="${p.id}">Помочь деньгами</button>
        ${unknownLinks.map(v => `<button class="btn small" data-act="intro" data-id="${p.id}" data-arg="${v.id}">Познакомь с: ${UI.esc(v.role.toLowerCase())}</button>`).join('')}
        ${canFavor ? `<button class="btn small" data-act="favor" data-id="${p.id}" data-arg="job">Помочь с работой</button><button class="btn small" data-act="favor" data-id="${p.id}" data-arg="money">Одолжить денег</button><button class="btn small" data-act="favor" data-id="${p.id}" data-arg="rep">Замолвить слово</button>` : ''}
        <button class="btn small" data-act="${inMine ? 'kick' : 'join'}" data-id="${p.id}">${inMine ? 'Из моей компании' : 'В мою компанию'}</button>
        ${p.att < 45 ? `<button class="btn small" data-act="makeup" data-id="${p.id}">Помириться</button>` : `<button class="btn small" data-act="quarrel" data-id="${p.id}">Поссориться</button>`}
        <button class="btn small" data-act="gossip" data-id="${p.id}">Пустить слух о нём</button>
      </div></div>`;
  };
  // событие с выбором — окно как у других событий
  SOC.modal = e => new Promise(res => {
    const s = UI.s, V = SOC.view(s, e), p = SOC.get(s, e.p); if (!V) { res(); return; }
    UI.modal(`<div class="ev"><div class="evpic ev-friend">${UI.avatar({ sex: p.sex, look: L.hash(p.name) % 9999 }, 84)}</div><h3>${UI.esc(V.t)}</h3><p>${UI.esc(V.x)}</p><div class="eopts">${V.o.map((o, i) => `<button class="eopt" data-i="${i}"><b>${UI.esc(o[0])}</b>${o[1] ? `<span class="roll">${({ str: 'сила', cha: 'харизма', int: 'интеллект', biz: 'деловая хватка' })[o[1]] || ''} · шанс ~${E.chance(s, 100 - (o[2] || 50), o[1])}%</span>` : ''}</button>`).join('')}</div></div>`);
    if (typeof NET !== 'undefined') NET.autoPick();
    $$('#modal .eopt').forEach(b => b.onclick = () => {
      const out = SOC.resolve(s, e, +b.dataset.i); UI.closeModal(); if (out.roll && typeof SFX !== 'undefined') SFX.play(out.ok ? 'good' : 'bad', true);
      UI.appendMsg({ k: 'out', title: out.title, x: out.x, ok: out.ok, lines: out.lines, roll: out.roll ? { roll: out.roll.roll, chance: out.roll.chance } : null });
      UI.renderAll(); res();
    });
  });
  // для нейросети: кратко о круге общения
  SOC.brief = s => {
    if (!s.soc) return '';
    const ks = SOC.known(s), fr = ks.filter(p => p.att >= 62).sort((a, b) => b.att - a.att).slice(0, 5), en = ks.filter(p => p.att < 22).slice(0, 3), vip = ks.filter(p => p.infl >= 40).sort((a, b) => b.infl - a.infl).slice(0, 3);
    const parts = [];
    if (fr.length) parts.push('друзья: ' + fr.map(p => p.name + ' (' + p.role + ')').join(', '));
    if (en.length) parts.push('в ссоре: ' + en.map(p => p.name).join(', '));
    if (vip.length) parts.push('влиятельные знакомые: ' + vip.map(p => p.name + ' — ' + p.role.toLowerCase()).join(', '));
    const last = s.soc.feed.slice(-2).map(f => f.t); if (last.length) parts.push('недавно: ' + last.join(' '));
    return parts.join('; ');
  };

  // ---------- подключение ----------
  const _nw = E.nextWeek;
  E.nextWeek = (s, ext) => { const rep = _nw(s, ext); if (!s.over && rep && rep.events) { try { SOC.week(s, rep); } catch (e) { console.warn('SOC.week', e); } } return rep; };
  // «Позвонить Серёге», «встречаюсь с Катей» — находим среди знакомых
  const _fr = E.findRel;
  E.findRel = (s, who) => { const x = _fr(s, who); if (x) return x; if (!s.soc) return null; const p = SOC.byName(s, who); if (p) { p.seen = s.turn; return p; } return null; };
  const _soc = E.A.social;
  E.A.social = (s, it) => {
    if (s.soc) { const p = SOC.byName(s, [it.person, it.target, it.raw].join(' ')); if (p && p.flags.avoid && p.att < 25) return { ok: false, title: name(p) + ' не берёт трубку', lines: ['Похоже, вас избегают. Попробуйте помириться через общих знакомых (окно «Знакомые»).'], apCost: 1, fx: { happy: -2 } }; }
    return _soc(s, it);
  };
  const _date = E.A.date;
  E.A.date = (s, it) => { const out = _date(s, it); try { if (s.soc && out && out.ok) { const p = SOC.byName(s, [it.person, it.target, it.raw].join(' ')); if (p && p.role === 'партнёр' && !s.rel.some(x => x.soc === p.id)) { s.rel.push({ name: p.name, role: 'партнёр', att: p.att, soc: p.id }); p.partner = 'me'; } } } catch (e) { } return out; };
  document.addEventListener('DOMContentLoaded', () => {
    if (typeof U !== 'undefined') U.people = () => SOC.ui('people');
    if (typeof AI !== 'undefined' && AI.brief) { const _b = AI.brief; AI.brief = s => { const b = _b(s), x = SOC.brief(s); return x ? b + '; круг общения — ' + x : b; }; }
    // новая игра/загрузка старой: сеть знакомых создаётся сама
    if (typeof UI !== 'undefined' && UI.game) { const _g = UI.game; UI.game = (...a) => { try { if (UI.s) SOC.init(UI.s); } catch (e) { console.warn('SOC.init', e); } return _g(...a); }; }
  });
})();
