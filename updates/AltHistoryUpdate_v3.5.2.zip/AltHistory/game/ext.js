// «Судьба» — расширения: взятки, роскошь и благотворительность, своя ОПГ (вплоть до отделения региона),
// усталость и баланс жизни (проблемы со здоровьем от одной работы), влияние, бизнес-войны и HR-отдел.
'use strict';
const EXT = {};
const xn = t => E.norm(t || '');
const xr = (a, b) => a + Math.random() * (b - a);

// ===================== каталоги =====================
D.LUX = {
  modern: [
    { id: 'watch', n: 'Швейцарские часы', price: 1500000, up: 0, happy: 6, rep: 2, infl: 1, kw: /час(ы|ов)|ролекс|rolex|патек/ },
    { id: 'supercar', n: 'Суперкар', price: 28000000, up: 150000, happy: 14, rep: 5, infl: 2, kw: /суперкар|ламборг|lambo|феррари|ferrari|порше|porsche|бугатти|maybach|майбах/ },
    { id: 'yacht', n: 'Яхта', price: 180000000, up: 1500000, happy: 18, rep: 8, infl: 4, kw: /яхт/ },
    { id: 'jet', n: 'Частный самолёт', price: 900000000, up: 6000000, happy: 16, rep: 10, infl: 8, kw: /самол[её]т|джет|jet/ },
    { id: 'mansion', n: 'Особняк на Рублёвке', price: 450000000, up: 1200000, happy: 18, rep: 8, infl: 5, kw: /особняк|рублевк|дворец|поместь/ },
    { id: 'island', n: 'Свой остров', price: 1200000000, up: 3000000, happy: 22, rep: 12, infl: 6, kw: /остров/ },
    { id: 'art', n: 'Коллекция картин', price: 60000000, up: 200000, happy: 6, rep: 6, infl: 3, kw: /картин|искусств|коллекц|галере/ },
    { id: 'club', n: 'Футбольный клуб', price: 2500000000, up: 25000000, happy: 15, rep: 20, infl: 14, kw: /футбольн|хоккейн|спортивн.*клуб|клуб.*(футбол|хоккей)|команд/ },
    { id: 'media', n: 'Своё СМИ (газета и телеканал)', price: 800000000, up: 10000000, happy: 4, rep: 6, infl: 20, kw: /телеканал|сми\b|медиа|газет|радиостанц/ },
    { id: 'guard', n: 'Личная охрана', price: 0, up: 600000, happy: 2, rep: 1, infl: 2, guard: 30, kw: /охран|телохран|секьюрит/ },
    { id: 'chef', n: 'Личный повар', price: 0, up: 250000, happy: 5, rep: 0, infl: 0, health: 1, kw: /повар/ },
    { id: 'party', n: 'Вечеринка со звёздами', price: 15000000, up: 0, once: true, happy: 15, rep: 4, infl: 2, cha: 2, kw: /вечеринк|тусовк|звезд|банкет/ },
    { id: 'doctor', n: 'Личный врач и клиника', price: 0, up: 400000, happy: 2, rep: 0, infl: 0, health: 2, kw: /личн.*врач|клиник|частн.*медиц/ },
  ],
  ww2: [
    { id: 'watch', n: 'Золотые часы', price: 1500000, up: 0, happy: 6, rep: 2, infl: 1, kw: /час(ы|ов)/ },
    { id: 'dacha', n: 'Дача в Подмосковье', price: 60000000, up: 300000, happy: 14, rep: 6, infl: 4, kw: /дач|особняк|усадьб/ },
    { id: 'piano', n: 'Рояль «Беккер»', price: 9000000, up: 0, happy: 8, rep: 3, infl: 1, kw: /роял|пианино/ },
    { id: 'art', n: 'Коллекция картин', price: 25000000, up: 100000, happy: 6, rep: 5, infl: 3, kw: /картин|коллекц/ },
    { id: 'driver', n: 'Персональный шофёр', price: 0, up: 300000, happy: 6, rep: 4, infl: 3, kw: /шофер|водител/ },
    { id: 'guard', n: 'Охрана', price: 0, up: 500000, happy: 2, rep: 1, infl: 2, guard: 30, kw: /охран/ },
    { id: 'fur', n: 'Шуба и драгоценности', price: 6000000, up: 0, happy: 8, rep: 2, infl: 0, kw: /шуб|драгоцен|бриллиант/ },
    { id: 'party', n: 'Банкет в «Метрополе»', price: 4000000, up: 0, once: true, happy: 12, rep: 4, infl: 2, cha: 2, kw: /банкет|ресторан|вечер/ },
  ],
};
EXT.lux = s => D.LUX[E.ww2(s) ? 'ww2' : 'modern'];

// ===================== инициализация =====================
EXT.init = s => {
  if (s.st.fatigue === undefined) s.st.fatigue = 20;
  if (s.st.infl === undefined) s.st.infl = Math.round(s.st.rep * 0.3 + 3);
  s.lux = s.lux || []; s.grind = s.grind || 0;
};
const _Linit = L.init; L.init = s => { _Linit(s); EXT.init(s); };

// ===================== усталость и баланс жизни =====================
EXT.WORK = { work: 9, promote: 4, biz_start: 6, study: 4, job: 2, crime: 3, bribe: 1, opg: 5, bizwar: 4, elect: 4, policy: 3 };
EXT.REST = { rest: -12, travel: -25, social: -7, date: -9, health: -10, marry: -6, lux: -6, charity: -3 };
const _act = E.act;
E.act = (s, it) => {
  EXT.init(s);
  const tired = s.st.fatigue >= 80;
  const out = _act(s, it);
  if (out && !out.impossible && !out.blocked && out.apCost) {
    const t = it.type, d = EXT.WORK[t] || 0, rec = EXT.REST[t] || 0;
    s.st.fatigue = E.clamp(s.st.fatigue + d * 0.25 + rec, 0, 100); // работа утомляет в 4 раза меньше (v3.4.2)
    (s.wk = s.wk || []).push(t);
    if (tired && d > 0) { out.lines = (out.lines || []).concat(['Вы вымотаны: голова не варит, всё идёт тяжелее. Пора отдохнуть.']); if (s.job) s.job.perf = E.clamp(s.job.perf - 3, 0, 100); }
  }
  return out;
};
EXT.SICK = [
  ['Скачет давление', 'Голова раскалывается, в глазах темнеет. Врач говорит: «Вы себя загоняете».'],
  ['Бессонница', 'Третью неделю не спится: мысли о работе крутятся по кругу.'],
  ['Сорвали спину', 'Сидячая работа без передышки — и вот спину не разогнуть.'],
  ['Гастрит', 'Еда на бегу и кофе вместо обеда сделали своё дело.'],
  ['Нервный срыв', 'Сорвались на коллег из-за ерунды. Организм требует остановиться.'],
  ['Сердце шалит', 'Покалывает в груди. Кардиолог велит сбавить обороты.'],
];
const _nw = E.nextWeek;
E.nextWeek = (s, ext) => {
  EXT.init(s);
  const wk = s.wk || []; s.wk = [];
  const rep = _nw(s, ext);
  if (s.over || !rep.events) return rep;
  try { EXT.week(s, rep, wk); } catch (e) { console.warn('EXT.week', e); }
  return rep;
};
EXT.week = (s, rep, wk) => {
  rep.life = rep.life || [];
  const load = (s.job ? 3 : 0) + Math.min(6, s.biz.length * 1.5) + (s.pol ? 3 : 0) + (s.opg ? 2 : 0) + (s.study ? 1 : 0);
  // v3.5: неделя, которую просто пропустили (без действий), — обычная жизнь с выходными: усталость и «одна работа» не копятся
  const worked = wk.some(t => EXT.WORK[t]);
  const dF = load - 7; s.st.fatigue = E.clamp(s.st.fatigue + (worked ? (dF > 0 ? dF * 0.25 : dF) : -3), 0, 100);
  const lifey = wk.some(t => EXT.REST[t] !== undefined);
  const busy = worked && (s.job || s.biz.length || s.pol || s.opg);
  if (busy && !lifey) s.grind++; else s.grind = Math.max(0, s.grind - (lifey ? 8 : 1));
  if (s.st.fatigue >= 85) { if (Math.random() < 0.3) s.st.health = E.clamp(s.st.health - 1, 0, 100); s.st.happy = E.clamp(s.st.happy - 1, 0, 100); if (Math.random() < 0.25) rep.life.push('Усталость копится (' + Math.round(s.st.fatigue) + '/100). Стоит отдохнуть или провести время с близкими.'); }
  if (s.grind >= 16 && s.grind % 8 === 0 && Math.random() < 0.5) rep.life.push(`Уже ${s.grind} нед. ничего, кроме работы. Близкие жалуются, что вас не видно.`);
  if (s.grind >= 24 && Math.random() < 0.03 + (s.grind - 24) * 0.005 + (s.st.fatigue > 85 ? 0.02 : 0) && !rep.events.some(e => e.sys)) {
    const [t, x] = E.pick(EXT.SICK);
    const l = E.apply(s, { health: -E.ri(8, 16), happy: -6, stress: 10 });
    rep.events.push({ sys: true, t: 'Проблемы со здоровьем: ' + t.toLowerCase(), x: x + ' Нужен отдых: отпуск, врач, время с близкими.', lines: l });
    E.fact(s, `${E.monthStr(s.date)}: проблемы со здоровьем (${t.toLowerCase()}) — от работы без отдыха.`);
    s.grind = 12; s.flags.sickWeeks = 2;
  }
  if (s.flags.sickWeeks > 0) { s.flags.sickWeeks--; s.ap = Math.max(1, s.ap - 1); rep.life.push('Плохо себя чувствуете — на этой неделе меньше сил.'); }
  // влияние: репутация, власть, бизнес, роскошь, ОПГ
  const polRank = s.pol ? Math.max(1, (D.POLITICS || []).findIndex(p => p.id === s.pol.id) + 1) : 0;
  const luxI = s.lux.reduce((a, l) => a + (EXT.lux(s).find(x => x.id === l.id) || {}).infl || 0, 0);
  const target = s.st.rep * 0.35 + polRank * 7 + Math.min(20, s.biz.length * 4 + s.biz.reduce((a, b) => a + b.level, 0)) + luxI + (s.opg ? s.opg.infl * 0.4 : 0);
  s.st.infl = E.clamp(s.st.infl + (target - s.st.infl) * 0.08, 0, 100);
  // HR-отделы ищут людей каждую неделю
  for (const b of s.biz) if (b.hr) EXT.hrWeek(s, b, rep);
  if (rep.monthly) EXT.month(s, rep);
};
EXT.month = (s, rep) => {
  const m = rep.monthly;
  // содержание роскоши
  let up = 0; for (const l of s.lux) { const d = EXT.lux(s).find(x => x.id === l.id); if (!d) continue; up += E.m(s, d.up); if (d.health) s.st.health = E.clamp(s.st.health + d.health, 0, 100); }
  for (const b of s.biz) if (b.guard) up += E.m(s, b.guard * 4000);
  if (up > 0) { up = Math.round(up); s.st.money -= up; m.exp.push(['Роскошь и охрана: содержание', up]); m.net -= up; }
  // ОПГ: доход, розыск, облавы
  const o = s.opg;
  if (o && !o.gone) {
    o.months = (o.months || 0) + 1;
    const inc = Math.round(E.m(s, 2500) * o.members * (1 + o.terr * 0.25));
    s.st.money += inc; m.inc.push(['ОПГ «' + o.name + '»', inc]); m.net += inc;
    L.crimeInit(s); s.crime.on = true; s.crime.heat = E.clamp((s.crime.heat || 0) + 2 + o.terr - o.infl / 25, 0, 100);
    o.infl = E.clamp(o.infl + o.terr * 0.6 - 1, 0, 100);
    if (s.crime.heat > 60 && Math.random() < (s.crime.heat - 50) / 120) {
      const lost = Math.round(o.members * xr(0.1, 0.3)); o.members = Math.max(5, o.members - lost);
      rep.life.push(`Облава на ОПГ «${o.name}»: задержаны ${lost} человек. Розыск растёт.`);
      if (Math.random() < 0.3 && o.terr > 1) { o.terr--; rep.life.push('Потеряли один район.'); }
    }
  }
  // бизнес-войны: конкуренты огрызаются, доля рынка возвращается к норме
  for (const b of s.biz) {
    const rv = EXT.rivals(s, b);
    for (const r of rv) r.str = E.clamp(r.str + 2, 5, 95);
    b.pr = (b.pr || 0) * 0.6;
    const angry = rv.filter(r => r.angry > 0);
    if (angry.length && Math.random() < 0.35 - (b.guard || 0) / 300) {
      const r = E.pick(angry); r.angry--;
      const dmg = E.ri(6, 16); b.health = E.clamp(b.health - dmg, 5, 100);
      rep.life.push(`Конкурент «${r.n}» ответил: ${E.pick(['наслал проверку', 'переманил клиентов', 'запустил грязные слухи', 'прислал «гостей» в офис'])} — «${b.n}» −${dmg} к состоянию.`);
    }
  }
};

// ===================== доля рынка в бизнесе =====================
EXT.rivals = (s, b) => {
  if (!b.rivals) {
    const r = L.rng(L.hash(b.id + 'rv')), names = ['Альфа', 'Восток', 'Меридиан', 'Престиж', 'Феникс', 'Северный', 'Гранд', 'Империя', 'Форвард', 'Лидер', 'Магистраль', 'Союз'];
    b.rivals = [0, 1, 2].map(k => ({ n: names[Math.floor(r() * names.length)] + (k ? '-' + (k + 1) : ''), str: Math.round(45 + r() * 35), angry: 0 }));
  }
  return b.rivals;
};
EXT.share = b => E.clamp(1 + (b.rivals || []).reduce((a, r) => a + (60 - r.str) / 260, 0) + (b.pr || 0), 0.6, 1.8);
const _bm = B.month;
B.month = (s, r) => {
  _bm(s, r);
  for (const b of s.biz) {
    EXT.rivals(s, b);
    const k = EXT.share(b) - 1;
    if (Math.abs(k) > 0.01 && b.lastRev > 0) {
      const extra = Math.round(b.lastRev * k * 0.35);
      r.inc.push(['«' + b.n + '»: ' + (extra >= 0 ? 'отбитая у конкурентов доля рынка' : 'конкуренты отъели долю рынка'), extra]);
      b.lastProfit += extra; if (b.hist.length) b.hist[b.hist.length - 1] = b.lastProfit;
    }
  }
};

// ===================== новые действия =====================
E.ACTIONS.push('bribe', 'lux', 'charity', 'opg', 'bizwar');
const xfail = (title, lines) => ({ ok: false, impossible: true, title, lines: lines || [], apCost: 0 });

// ---------- взятка ----------
EXT.BRIBE = [
  ['job', /работ|устро|должност|возьмут|приня|начальник|директор|ваканс|без опыта|возраст/, 150000, 'чтобы взяли на работу'],
  ['study', /вуз|универ|институт|поступ|диплом|экзамен|сесси|аттестат|училищ/, 300000, 'за поступление'],
  ['police', /полиц|мент|розыск|дело|следовател|опер|милици|нквд/, 200000, 'чтобы закрыли глаза'],
  ['army', /военкомат|арми|призыв|мобилиз|фронт|отсроч/, 250000, 'за отсрочку от армии'],
  ['court', /суд|прокур|приговор|штраф/, 500000, 'чтобы дело замяли'],
  ['license', /лиценз|разреш/, 1000000, 'за лицензию'],
  ['inspect', /проверк|налогов|санэпид|пожарн|инспектор/, 120000, 'чтобы проверки обходили стороной'],
  ['official', /чиновник|мэр|администрац|депутат|министр|губернатор|обком|райком/, 1000000, 'за нужные связи наверху'],
  ['election', /выбор|избирком|голос|бюллетен/, 3000000, 'за «правильный» подсчёт голосов'],
];
E.A.bribe = (s, it) => {
  const t = xn([it.target, it.raw].join(' '));
  const kind = EXT.BRIBE.find(k => k[1].test(t)) || ['other', null, 100000, 'чтобы решить вопрос'];
  const base = E.m(s, kind[2] * (kind[0] === 'job' ? Math.max(1, (it.tier || 2) - 1) : 1));
  const sum = it.amount > 0 ? Math.round(it.amount) : Math.round(base);
  if (s.st.money < sum) return xfail('Не хватает на взятку', ['Нужно около ' + E.money(sum) + ', у вас ' + E.money(s.st.money) + '.']);
  const ratio = Math.max(0.2, sum / base);
  const ch = E.clamp(Math.round(32 + 18 * Math.log2(ratio) + s.st.infl * 0.35 + (E.sk(s, 'cha') - 40) * 0.25 + (s.crime && s.crime.on ? 5 : 0) - (E.ww2(s) ? 12 : 0)), 4, 93);
  const r = E.roll(s, ch);
  if (!r.ok) {
    if (Math.random() < 0.5) { L.crimeInit(s); s.crime.heat = E.clamp((s.crime.heat || 0) + 20, 0, 100); return { ok: false, roll: r, caught: true, title: 'Попались на взятке', lines: ['Конверт взяли — и тут же вызвали кого надо.', 'Штраф: ' + E.money(sum)], fx: { money: -sum, rep: -8, stress: 15 }, factAdd: `${E.monthStr(s.date)}: попался на взятке (${kind[3]}).` }; }
    return { ok: false, roll: r, title: 'Взятку не взяли', lines: ['«Вы что себе позволяете?» — конверт вернули. Повезло, что без последствий.'], fx: { stress: 6, happy: -2 } };
  }
  const lines = ['Ушло: ' + E.money(sum) + ' (' + kind[3] + ')']; let title = 'Взятка сработала', extra = {};
  s.st.money -= sum;
  if (kind[0] === 'job') { const j = E.A.job(s, Object.assign({}, it, { type: 'job', force: true })); title = j.ok ? 'По знакомству: ' + j.title.toLowerCase() : j.title; lines.push(...(j.lines || [])); extra = j.fx || {}; if (j.factAdd) E.fact(s, j.factAdd + ' (за взятку)'); }
  else if (kind[0] === 'study') { const j = E.A.study(s, Object.assign({}, it, { type: 'study', force: true })); title = j.ok ? j.title + ' (за взятку)' : j.title; lines.push(...(j.lines || [])); extra = j.fx || {}; }
  else if (kind[0] === 'police') { L.crimeInit(s); s.crime.heat = Math.max(0, (s.crime.heat || 0) - 40); lines.push('Розыск заметно снизился'); }
  else if (kind[0] === 'army') { s.flags.noDraft = true; if (s.job && s.job.army) { s.job = null; lines.push('Вас тихо комиссовали'); } lines.push('Отсрочка от армии оформлена'); }
  else if (kind[0] === 'court') { L.crimeInit(s); s.crime.heat = Math.max(0, (s.crime.heat || 0) - 25); lines.push('Дело замяли'); }
  else if (kind[0] === 'license') { const b = s.biz.find(x => { const I = B.ind(s, x.ind); return I.lic && !x.lic[I.lic]; }); if (b) { const I = B.ind(s, b.ind); b.lic[I.lic] = true; lines.push('Лицензия для «' + b.n + '» — получена'); } else lines.push('Бумаги на будущее подписаны (+влияние)'); s.st.infl += 3; }
  else if (kind[0] === 'inspect') { s.flags.noInspect = s.turn + 26; for (const b of s.biz) b.health = E.clamp(b.health + 8, 0, 100); lines.push('Проверки полгода будут обходить ваш бизнес стороной'); }
  else if (kind[0] === 'official') { s.st.infl = E.clamp(s.st.infl + 8, 0, 100); lines.push('Влияние +8: теперь вам «идут навстречу»'); }
  else if (kind[0] === 'election') { if (s.election) { s.flags.campaign = Math.min(35, (s.flags.campaign || 0) + 12); lines.push('Шанс на выборах +12%'); } else { s.st.infl += 5; lines.push('Выборов пока нет — но в избиркоме вас запомнили (+влияние)'); } }
  else { s.st.infl = E.clamp(s.st.infl + 3, 0, 100); lines.push('Вопрос решился'); }
  return { ok: true, roll: r, title, lines, fx: Object.assign({ stress: 3 }, extra) };
};
// работа и учёба «за взятку» — без проверки возраста, образования и опыта
const _job = E.A.job;
E.A.job = (s, it) => {
  if (!it.force) return _job(s, it);
  const age = E.age(s); const ed = s.ch.edu; const sk = Object.assign({}, s.st.sk);
  s.ch.edu = 9; for (const k in s.st.sk) s.st.sk[k] = Math.max(s.st.sk[k], 95);
  const fakeAge = age < 18 ? 18 - age : 0; if (fakeAge) s.ch.birth = new Date(Date.parse(s.ch.birth) - fakeAge * 3.2e10).toISOString();
  let out; try { out = _job(s, it); } finally { s.ch.edu = ed; s.st.sk = sk; if (fakeAge) s.ch.birth = new Date(Date.parse(s.ch.birth) + fakeAge * 3.2e10).toISOString(); }
  return out;
};
const _study = E.A.study;
E.A.study = (s, it) => { if (!it.force) return _study(s, it); const ed = s.ch.edu; const c = E.match(D.COURSES, [it.target, it.raw].join(' ')); if (c && c.reqEdu && s.ch.edu < c.reqEdu) s.ch.edu = c.reqEdu; try { return _study(s, it); } finally { if (s.ch.edu === (c && c.reqEdu)) s.ch.edu = Math.max(ed, s.study && s.study.id === (c && c.id) ? ed : ed); } };

// ---------- роскошь и благотворительность ----------
E.A.lux = (s, it) => {
  const t = xn([it.target, it.raw].join(' ')), C = EXT.lux(s);
  const d = C.find(x => x.kw.test(t));
  if (!d) return xfail('Что именно купить?', ['Можно: ' + C.map(x => x.n.toLowerCase() + (x.price ? ' (' + E.short(E.m(s, x.price)) + ')' : ' (' + E.short(E.m(s, x.up)) + '/мес)')).join(', ') + '.']);
  if (!d.once && s.lux.some(l => l.id === d.id)) return xfail('Уже есть', [d.n + ' у вас уже есть.']);
  const price = Math.round(E.m(s, d.price));
  if (s.st.money < price) return xfail('Не по карману', [d.n + ': ' + E.money(price) + ', у вас ' + E.money(s.st.money) + '.']);
  if (!d.once) s.lux.push({ id: d.id, n: d.n, since: s.date });
  s.st.infl = E.clamp(s.st.infl + (d.infl || 0), 0, 100);
  const lines = [price ? 'Потрачено: ' + E.money(price) : 'Нанят(а)', d.up ? 'Содержание: ' + E.money(E.m(s, d.up)) + ' в месяц' : ''].filter(Boolean);
  return { ok: true, title: d.once ? d.n : 'Теперь у вас: ' + d.n.toLowerCase(), lines, fx: Object.assign({ money: -price, happy: d.happy, rep: d.rep }, d.cha ? { cha: d.cha } : {}), factAdd: d.once ? `${E.monthStr(s.date)}: закатил ${d.n.toLowerCase()} на ${E.money(price)}.` : `${E.monthStr(s.date)}: купил — ${d.n.toLowerCase()}${price ? ' за ' + E.money(price) : ''}.` };
};
E.A.charity = (s, it) => {
  const sum = Math.round(it.amount > 0 ? it.amount : E.m(s, 1000000));
  if (s.st.money < sum) return xfail('Не хватает денег', ['На счету ' + E.money(s.st.money) + '.']);
  const k = sum / E.m(s, 500000);
  s.st.infl = E.clamp(s.st.infl + Math.min(10, k), 0, 100);
  return { ok: true, title: 'Благотворительность', lines: ['Пожертвовано: ' + E.money(sum), 'О вас написали в газетах'], fx: { money: -sum, rep: Math.round(Math.min(15, 1 + k * 1.5)), happy: 4 }, factAdd: `${E.monthStr(s.date)}: пожертвовал ${E.money(sum)} на благотворительность.` };
};

// ---------- своя ОПГ ----------
EXT.opgName = (s, it) => { const m = String(it.raw || '').match(/[«"]([^»"]{2,30})[»"]/); return m ? m[1] : (it.org && it.org.length > 2 ? it.org : E.pick(['Северные', 'Заводские', 'Тихие', 'Речные', 'Волки', 'Синдикат', 'Бригада', 'Братство']) + ' ' + s.ch.surname.slice(0, 1) + '.'); };
E.A.opg = (s, it) => {
  const t = xn([it.target, it.raw].join(' ')); const o = s.opg && !s.opg.gone ? s.opg : null;
  if (E.age(s) < 18) return xfail('Слишком молоды', ['Своя группировка — с 18 лет.']);
  if (/отдел|независим|республик|автоном|суверен|сво[её] государ|отсоедин/.test(t)) return EXT.secede(s, it);
  const wantNew = /созда|основ|собра|сколот|сво[юя] (опг|банд|группир)/.test(t);
  if (!o && !wantNew) return xfail('Своей ОПГ пока нет', ['Сначала: «создаю свою ОПГ» (нужны деньги и влияние 20+).']);
  if (!o || wantNew) {
    if (o) return xfail('ОПГ уже есть', ['«' + o.name + '»: ' + o.members + ' чел., районов: ' + o.terr + '.']);
    const need = E.m(s, 5000000);
    if (s.st.money < need) return xfail('Мало денег, чтобы собрать своих', ['Нужно хотя бы ' + E.money(need) + ' на людей, оружие и «прикормку».']);
    if (s.st.infl < 20 && !(s.crime && s.crime.rank >= 2)) return xfail('Вас не воспринимают всерьёз', ['Нужно влияние 20+ (сейчас ' + Math.round(s.st.infl) + ') или ранг в банде повыше.']);
    const r = E.roll(s, E.clamp(Math.round(50 + s.st.infl / 3 + E.sk(s, 'str') / 6), 15, 90));
    if (!r.ok) return { ok: false, roll: r, title: 'Не собрали людей', lines: ['Люди не поверили, что вы — сила. Деньги ушли на «подготовку».'], fx: { money: -Math.round(need * 0.3), stress: 8 } };
    const name = EXT.opgName(s, it);
    s.opg = { name, members: 15, terr: 1, infl: 15, months: 0 };
    L.crimeInit(s); Object.assign(s.crime, { on: true, gang: name, boss: true }); s.crime.heat = (s.crime.heat || 0) + 10;
    return { ok: true, roll: r, title: 'Своя ОПГ: «' + name + '»', lines: ['15 человек, один район. Доход — каждый месяц.', 'Расширяйтесь: «набираю людей», «захватываю район», «прикармливаю полицию».'], fx: { money: -need, rep: -3, happy: 5 }, factAdd: `${E.monthStr(s.date)}: основал ОПГ «${name}».` };
  }
  if (/набира|набрать|люд|бойц|вербов|пополн/.test(t)) {
    const add = E.ri(10, 30), cost = Math.round(E.m(s, 40000) * add);
    if (s.st.money < cost) return xfail('Не хватает денег', ['Нужно ' + E.money(cost) + '.']);
    o.members += add; s.crime.heat = (s.crime.heat || 0) + 3;
    return { ok: true, title: 'Пополнение в «' + o.name + '»', lines: ['+' + add + ' человек (всего ' + o.members + ')'], fx: { money: -cost } };
  }
  if (/полиц|прикорм|мент|крыш|прокур|судь/.test(t)) {
    const cost = Math.round(E.m(s, 1500000) * (1 + o.terr * 0.3));
    if (s.st.money < cost) return xfail('Не хватает денег', ['Нужно ' + E.money(cost) + '.']);
    o.infl = E.clamp(o.infl + 10, 0, 100); s.crime.heat = Math.max(0, (s.crime.heat || 0) - 20);
    return { ok: true, title: 'Прикормили силовиков', lines: ['Влияние ОПГ +10, розыск −20'], fx: { money: -cost } };
  }
  if (/территор|район|захват|расшир|рынок|точк|город|подмят/.test(t)) {
    const r = E.roll(s, E.clamp(Math.round(40 + o.members / 8 + o.infl / 4 - o.terr * 3), 10, 85));
    s.crime.heat = (s.crime.heat || 0) + (r.ok ? 8 : 15);
    if (!r.ok) { const lost = E.ri(3, 10); o.members = Math.max(5, o.members - lost); return { ok: false, roll: r, title: 'Получили отпор', lines: ['Местные не сдались. Потери: ' + lost + ' чел.'], fx: { stress: 10, health: -3 } }; }
    o.terr++; o.infl = E.clamp(o.infl + 6, 0, 100);
    return { ok: true, roll: r, title: 'Новый район под «' + o.name + '»', lines: ['Районов: ' + o.terr + '. Доход ОПГ вырастет.'], fx: { happy: 4 } };
  }
  return { ok: true, title: 'ОПГ «' + o.name + '»', lines: ['Людей: ' + o.members, 'Районов: ' + o.terr, 'Влияние ОПГ: ' + Math.round(o.infl) + '/100', 'Для отделения региона нужно: влияние ОПГ 70+, 250+ человек, 6+ районов, ваше влияние 60+ и много денег.'], apCost: 0 };
};
// Отделение региона: новая страна на карте, вы — её глава. Родина, конечно, будет против.
EXT.secede = (s, it) => {
  const o = s.opg && !s.opg.gone ? s.opg : null;
  if (s.mp && s.mp.role === 'client') return xfail('В мультиплеере это решает хост', ['Отделение региона меняет общий мир.']);
  const need = E.m(s, 500000000);
  const miss = [];
  if (!o) miss.push('своя ОПГ («создаю свою ОПГ»)');
  else { if (o.infl < 70) miss.push('влияние ОПГ 70+ (сейчас ' + Math.round(o.infl) + ')'); if (o.members < 250) miss.push('250+ человек (сейчас ' + o.members + ')'); if (o.terr < 6) miss.push('6+ районов (сейчас ' + o.terr + ')'); }
  if (s.st.infl < 60) miss.push('ваше влияние 60+ (сейчас ' + Math.round(s.st.infl) + ')');
  if (s.st.money < need) miss.push('деньги: ' + E.money(need));
  if (miss.length) return xfail('Для отделения региона не хватает', miss);
  const r = E.roll(s, E.clamp(Math.round(35 + (o.infl - 70) + (o.members - 250) / 25 + (s.st.infl - 60) / 2), 10, 80));
  if (!r.ok) { o.members = Math.round(o.members * 0.6); o.infl -= 20; s.crime.heat = 100; return { ok: false, roll: r, title: 'Мятеж подавлен', lines: ['Силовики сработали на опережение. Половина людей арестована.'], fx: { money: -Math.round(need * 0.4), rep: -15, stress: 25, health: -8 } }; }
  const W = s.world, home = W.home, c0 = E.city(s), start = c0.prov !== undefined ? c0.prov : M().provinces.findIndex((p, i) => W.own[i] === home);
  // берём город игрока и соседние провинции страны
  const want = Math.min(60, 4 + o.terr * 3), got = [start], seen = new Set(got);
  for (let i = 0; i < got.length && got.length < want; i++) for (const n of M().provinces[got[i]].nb) if (!seen.has(n) && W.own[n] === home) { seen.add(n); got.push(n); if (got.length >= want) break; }
  const name = 'Республика ' + (E.cityName(s) || o.name);
  const nc = WD.newCountry(s, { n: name, col: '#' + Math.floor(xr(0.25, 0.85) * 0xffffff).toString(16).padStart(6, '0'), pw: Math.max(3, Math.round(o.members / 40)), cap: start, st: { gov: 'Самопровозглашённая республика', lead: s.ch.name + ' ' + s.ch.surname, stab: 40 } });
  got.forEach(p => { W.own[p] = nc; });
  WD.splitStats(s, home, nc, got);
  W.cs[nc].rebelOf = home;
  WD.declare(s, home, nc, { total: false, civil: true });
  WD.news(s, `${name}: ${s.ch.name} ${s.ch.surname} объявил независимость! ${W.cs[home].n} не признаёт отделение.`, [home, nc], 2, 'civil');
  W.home = nc; o.gone = false; o.state = nc;
  E.takeOffice(s, { id: 'president', n: 'Глава ' + name.replace('Республика', 'Республики') });
  return { ok: true, roll: r, title: 'Независимость!', lines: [name + ' — ' + got.length + ' провинций.', 'Вы — глава новой страны. Бывшая родина объявила вам войну.', 'Теперь вам доступны армия, указы, война и мир.'], fx: { money: -need, rep: 15, happy: 20, stress: 20 }, map: true, war: true, factAdd: `${E.monthStr(s.date)}: провозгласил независимость — ${name}.` };
};

// ---------- бизнес-войны ----------
E.A.bizwar = (s, it) => {
  if (!s.biz.length) return xfail('Нет своего бизнеса', ['Сначала откройте дело.']);
  const t = xn([it.target, it.raw].join(' '));
  const b = s.biz.find(x => t.includes(xn(x.n).slice(0, 5))) || s.biz[0], rv = EXT.rivals(s, b);
  const rival = rv.find(r => t.includes(xn(r.n).slice(0, 4))) || rv.slice().sort((a, b2) => b2.str - a.str)[0];
  const pay = (v, lines) => { const c = Math.round(E.m(s, v)); if (s.st.money < c) return xfail('Не хватает денег', ['Нужно ' + E.money(c) + '.']); s.st.money -= c; lines.push('Потрачено: ' + E.money(c)); return null; };
  const lines = [];
  if (/охран|защит|крыш|безопасн/.test(t)) { const e = pay(300000, lines); if (e) return e; b.guard = Math.min(75, (b.guard || 0) + 25); return { ok: true, title: 'Охрана для «' + b.n + '»', lines: lines.concat(['Защита ' + b.guard + '% (содержание ' + E.money(E.m(s, b.guard * 4000)) + '/мес)']) }; }
  if (/куп|поглот|выкуп/.test(t)) {
    if (rival.str > 35) return xfail('Конкурент ещё силён', ['«' + rival.n + '» не продаётся, пока его сила выше 35 (сейчас ' + Math.round(rival.str) + '). Ослабьте его.']);
    const e = pay(B.ind(s, b.ind).start * 0.8, lines); if (e) return e;
    rv.splice(rv.indexOf(rival), 1); b.pr = (b.pr || 0) + 0.15; b.level = Math.min(10, b.level + 1);
    return { ok: true, title: 'Поглотили «' + rival.n + '»', lines: lines.concat(['+1 уровень, доля рынка выросла']), fx: { rep: 3 } };
  }
  const K = [
    [/цен|демпинг|дешевл|скидк|акци/, 'Ценовая война', 0, 50, 8, 0.12, 0, 0, 'Клиенты потянулись к вам, но маржа просела'],
    [/пиар|компромат|слух|очерн|грязн/, 'Чёрный пиар', 300000, 55, 14, 0.05, 0, 2, 'Про «X» пишут гадости'],
    [/переман|сотрудник|кадр|специалист/, 'Переманили людей', 150000, 55, 7, 0, 0, 0, 'Лучшие люди «X» перешли к вам'],
    [/проверк|налогов|санэпид|натрав|пожарн|жалоб/, 'Наслали проверку', 200000, 45, 16, 0, 0, 3, 'К «X» нагрянула проверка'],
    [/спортик|браток|братв|громил|наехат|разгром|бандит|бойц/, 'Наехали спортики', 400000, 50, 26, 0, 15, 5, '«Гости» разнесли офис «X»'],
  ];
  const k = K.find(x => x[0].test(t)) || K[0];
  if (k[2]) { const e = pay(k[2], lines); if (e) return e; }
  const r = E.roll(s, E.clamp(Math.round(k[3] + s.st.infl / 4 + E.sk(s, 'biz') / 8 - (rival.str - 50) / 3), 10, 90));
  rival.angry = (rival.angry || 0) + 1;
  if (!r.ok) { if (k[6]) { L.crimeInit(s); s.crime.heat = (s.crime.heat || 0) + k[6] * 2; } return { ok: false, roll: r, title: k[1] + ': не вышло', lines: lines.concat(['«' + rival.n + '» отбился и затаил злобу.']), fx: { rep: -k[7], stress: 6 } }; }
  rival.str = E.clamp(rival.str - k[4], 5, 95); if (k[5]) b.pr = (b.pr || 0) + k[5];
  if (k[1] === 'Переманили людей') { const I = B.ind(s, b.ind); for (let i = 0; i < 2; i++) b.staff.push(Object.assign(B.person(s, I.roles[i % I.roles.length]), { sk: E.ri(70, 92), mor: 75 })); lines.push('+2 сильных сотрудника'); }
  if (k[1] === 'Ценовая война') b.price = Math.max(0.7, b.price - 0.05);
  if (k[6]) { L.crimeInit(s); s.crime.heat = (s.crime.heat || 0) + k[6]; }
  return { ok: true, roll: r, title: k[1] + ': «' + rival.n + '»', lines: lines.concat([k[8].replace('X', rival.n), 'Сила конкурента: ' + Math.round(rival.str) + '/100']), fx: { stress: 4 } };
};

// ===================== HR-отдел =====================
EXT.hrHire = (s, b) => {
  if (b.hr) return { ok: false, title: 'HR уже есть' };
  const sal = Math.round(B.mkt(s, 'Менеджер проектов') * 0.8);
  b.staff.push({ n: B.person(s, 'Менеджер').n, role: 'HR-менеджер', sk: E.ri(55, 85), sal, mor: 75, m: 0, hr: true });
  b.hr = { role: B.ind(s, b.ind).roles[0], minSk: 50, maxPct: 110, auto: true, pool: [] };
  return { ok: true, title: 'Нанят HR-менеджер', lines: ['Зарплата: ' + E.money(sal) + '/мес', 'Каждую неделю ищет людей по вашим фильтрам'] };
};
EXT.hrFire = (s, b) => { b.staff = b.staff.filter(p => !p.hr); b.hr = null; return { ok: true, title: 'HR-отдел закрыт' }; };
EXT.hrWeek = (s, b, rep) => {
  const h = b.hr, hrp = b.staff.find(p => p.hr), q = hrp ? hrp.sk : 50;
  h.pool = (h.pool || []).filter(p => (s.turn - (p.t || 0)) < 6);
  const n = 1 + Math.round(q / 40);
  for (let k = 0; k < n; k++) {
    const p = B.person(s, h.role), mkt = B.mkt(s, h.role);
    p.sk = E.clamp(Math.round(h.minSk + Math.random() * (100 - h.minSk) * (0.5 + q / 200)), 1, 99);
    p.sal = Math.round(mkt * (0.78 + p.sk / 160) / (E.ww2(s) ? 1 : 500)) * (E.ww2(s) ? 1 : 500);
    if (p.sal <= mkt * h.maxPct / 100) { p.t = s.turn; h.pool.push(p); }
  }
  h.pool.sort((a, c) => c.sk - a.sk); h.pool = h.pool.slice(0, 8);
  const work = b.staff.filter(p => !p.hr).length;
  if (h.auto && work < B.need(b) && h.pool.length) {
    const p = h.pool.shift(); const r = B.hire(s, b.id, p);
    if (r && r.ok !== false) (rep.life = rep.life || []).push(`HR «${b.n}» нанял: ${p.n} — ${p.role}, навык ${p.sk}, ${E.money(p.sal)}/мес`);
  }
};

// ===================== понимание фраз без нейросети =====================
const _pl = E.parseLocal;
E.parseLocal = text => {
  const t = xn(text), it = _pl(text);
  const set = type => Object.assign(it, { type });
  if (/взятк|дать на лапу|занести|подмаз|подкуп|откат/.test(t) && !/ограб/.test(t)) return set('bribe');
  if (/опг|группировк|сво[юя] банд|независим|отделить регион|республик/.test(t)) return set('opg');
  if (/конкурент|демпинг|переман|наслать проверк|спортик|братк|чёрн.*пиар|черн.*пиар|поглот/.test(t)) return set('bizwar');
  if (/благотвор|пожертв|фонд помощ|приют/.test(t)) return set('charity');
  if (EXT.lux({ era: E.cur && E.cur.era }).some(x => x.kw.test(t)) && /куп|завест|нанят|закат|устро/.test(t)) return set('lux');
  return it;
};

// ===================== подсказки для толкователя =====================
window.addEventListener('DOMContentLoaded', () => { if (typeof AI !== 'undefined') AI.SYS_INTERPRET = AI.SYS_INTERPRET.replace('other — всё остальное.', `bribe — дать взятку, занести, подкупить кого-то (чтобы взяли на работу без опыта/возраста, поступить в вуз, отсрочка от армии, закрыть дело, лицензия, проверки, чиновники, выборы). target — за что, amount — сумма
lux — купить роскошь: яхту, самолёт, особняк, остров, суперкар, часы, картины, футбольный клуб, своё СМИ, нанять охрану/повара/врача, закатить вечеринку
charity — благотворительность, пожертвовать деньги (amount — сумма)
opg — своя ОПГ/группировка: создать, набрать людей, захватить район, прикормить полицию, отделить регион/объявить независимость
bizwar — война с конкурентами в бизнесе: демпинг, чёрный пиар, переманить сотрудников, наслать проверку, нанять спортиков, поставить охрану, поглотить конкурента
other — всё остальное.`); });

// ===================== окна бизнеса: конкуренты и HR =====================
EXT.warHtml = (s, b) => {
  const rv = EXT.rivals(s, b), sh = EXT.share(b);
  const acts = [['price', 'Ценовая война', 'демпинг: −5% к цене, клиенты уходят к вам', 0], ['pr', 'Чёрный пиар', 'статьи и посты против конкурента', 300000], ['poach', 'Переманить людей', '+2 сильных сотрудника', 150000], ['inspect', 'Наслать проверку', 'налоговая и санэпид к конкуренту', 200000], ['thugs', 'Нанять спортиков', 'жёстко, но розыск растёт', 400000]];
  return `<div class="bgrid2"><div class="card"><h4>Конкуренты в городе</h4>
    <div class="kv"><span>Ваша доля рынка</span><b class="${sh >= 1 ? 'pos' : 'neg'}">${sh >= 1 ? '+' : ''}${Math.round((sh - 1) * 100)}% к выручке</b></div>
    <table class="tbl"><tr><th>Компания</th><th>Сила</th><th>Злость</th><th></th></tr>${rv.map((r, i) => `<tr><td><b>«${UI.esc(r.n)}»</b></td><td>${UI.bar(r.str, r.str > 65 ? 'bad' : r.str < 35 ? 'good' : '')} ${Math.round(r.str)}</td><td>${r.angry ? '🔥'.repeat(Math.min(3, r.angry)) : '—'}</td><td>${r.str <= 35 ? `<button class="btn small primary" data-wbuy="${i}">Поглотить</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="4">Конкурентов не осталось — рынок ваш!</td></tr>'}</table>
    <p class="small">Ослабленные конкуренты отдают вам клиентов. Обиженные — мстят: проверками, слухами, «гостями». Охрана защищает.</p></div>
    <div class="card"><h4>Удар по конкуренту</h4><label>Цель<select id="wTarget">${rv.map((r, i) => `<option value="${i}">«${UI.esc(r.n)}» — сила ${Math.round(r.str)}</option>`).join('')}</select></label>
    <div class="wacts">${acts.map(a => `<button class="btn ${a[0] === 'thugs' ? 'danger' : ''}" data-war="${a[0]}"><b>${a[1]}</b><small>${a[2]}${a[3] ? ' · ' + E.short(E.m(s, a[3])) + ' ₽' : ''}</small></button>`).join('')}</div>
    <h5>Защита</h5><div class="kv"><span>Охрана</span><b>${b.guard || 0}%</b></div><button class="btn wide" data-war="guard">${UI.ic('shield')} Усилить охрану (+25%) — ${E.short(E.m(s, 300000))} ₽ и ${E.short(E.m(s, ((b.guard || 0) + 25) * 4000))} ₽/мес</button>
    <p class="small">Каждый удар — одно действие недели.</p></div></div>`;
};
EXT.hrHtml = (s, b) => {
  const h = b.hr, I = B.ind(s, b.ind);
  if (!h) return `<div class="card"><h4>HR-отдел</h4><p>HR-менеджер сам ищет людей по вашим фильтрам каждую неделю и может нанимать их без вас.</p><button class="btn primary" id="hrHire">${UI.ic('user')} Нанять HR-менеджера — ${E.money(Math.round(B.mkt(s, 'Менеджер проектов') * 0.8))}/мес</button></div>`;
  const hp = b.staff.find(p => p.hr) || { n: '—', sk: 0 };
  return `<div class="bgrid2"><div class="card"><h4>Фильтры поиска</h4>
    <div class="kv"><span>HR-менеджер</span><b>${UI.esc(hp.n)} · навык ${hp.sk}</b></div>
    <label>Кого ищем<select id="hrRole">${I.roles.map(r => `<option ${r === h.role ? 'selected' : ''}>${UI.esc(r)}</option>`).join('')}</select></label>
    <label>Навык не ниже: <b id="hrSkV">${h.minSk}</b><input type="range" id="hrSk" min="20" max="90" step="5" value="${h.minSk}"></label>
    <label>Зарплата не выше: <b id="hrPctV">${h.maxPct}%</b> от рынка<input type="range" id="hrPct" min="70" max="160" step="5" value="${h.maxPct}"></label>
    <label class="chk"><input type="checkbox" id="hrAuto" ${h.auto ? 'checked' : ''}> Нанимать самому, пока есть свободные места (${b.staff.filter(p => !p.hr).length}/${B.need(b)})</label>
    <button class="btn danger small" id="hrFire">Закрыть HR-отдел</button></div>
    <div class="card"><h4>Найденные кандидаты</h4>${(h.pool || []).map((p, i) => `<div class="cand"><div><b>${UI.esc(p.n)}</b><small>${UI.esc(p.role)} · навык ${p.sk}</small></div><b>${E.money(p.sal)}</b><button class="btn small primary" data-hrh="${i}">Нанять</button></div>`).join('') || '<p class="small">Пока никого — HR ищет. Новые кандидаты каждую неделю.</p>'}
    <p class="small">Чем сильнее HR-менеджер, тем больше и лучше кандидатов.</p></div></div>`;
};
EXT.bindBiz = (s, b, re) => {
  const q = id => document.getElementById(id);
  if (q('hrHire')) q('hrHire').onclick = () => U.res(EXT.hrHire(s, b), () => re('hr'));
  if (q('hrFire')) q('hrFire').onclick = () => U.res(EXT.hrFire(s, b), () => re('hr'));
  if (q('hrRole')) q('hrRole').onchange = e => { b.hr.role = e.target.value; b.hr.pool = []; UI.save(); re('hr'); };
  if (q('hrSk')) q('hrSk').oninput = e => { b.hr.minSk = +e.target.value; q('hrSkV').textContent = e.target.value; UI.save(); };
  if (q('hrPct')) q('hrPct').oninput = e => { b.hr.maxPct = +e.target.value; q('hrPctV').textContent = e.target.value + '%'; UI.save(); };
  if (q('hrAuto')) q('hrAuto').onchange = e => { b.hr.auto = e.target.checked; UI.save(); };
  document.querySelectorAll('#modal [data-hrh]').forEach(x => x.onclick = () => { const p = b.hr.pool.splice(+x.dataset.hrh, 1)[0]; U.res(B.hire(s, b.id, p), () => re('hr')); });
  const word = { price: 'демпинг', pr: 'чёрный пиар', poach: 'переманить сотрудников', inspect: 'наслать проверку', thugs: 'нанять спортиков', guard: 'поставить охрану' };
  document.querySelectorAll('#modal [data-war]').forEach(x => x.onclick = () => {
    if (s.ap <= 0) { UI.toast('На этой неделе сил больше нет', 'bad'); return; }
    const rv = EXT.rivals(s, b), tgt = rv[+(q('wTarget') || { value: 0 }).value] || rv[0];
    const raw = word[x.dataset.war] + (tgt ? ' «' + tgt.n + '»' : '') + ' — ' + b.n;
    UI.closeModal(); UI.doIntent({ type: 'bizwar', target: raw, raw }, 'Бизнес-война: ' + raw);
  });
  document.querySelectorAll('#modal [data-wbuy]').forEach(x => x.onclick = () => { const r = EXT.rivals(s, b)[+x.dataset.wbuy]; const raw = 'поглотить конкурента «' + r.n + '» — ' + b.n; UI.closeModal(); UI.doIntent({ type: 'bizwar', target: raw, raw }, 'Поглотить «' + r.n + '»'); });
};
