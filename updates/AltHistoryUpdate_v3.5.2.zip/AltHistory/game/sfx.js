// «Судьба» — звуки интерфейса. Ничего не скачивается: каждый звук собирается на лету (Web Audio),
// как маленький деревянный перкуссионный инструмент — мягкая атака, тёплый тембр, короткое затухание.
'use strict';
const SFX = { KEY: 'sudba_sfx', vol: 60, ctx: null, out: null, last: {} };
try { const v = localStorage.getItem(SFX.KEY); if (v !== null) SFX.vol = +v; } catch (e) { }
SFX.setVol = v => { SFX.vol = Math.max(0, Math.min(100, v)); try { localStorage.setItem(SFX.KEY, SFX.vol); } catch (e) { } if (SFX.out) SFX.out.gain.value = SFX.gain(); };
SFX.gain = () => Math.pow(SFX.vol / 100, 1.6) * 0.55;
SFX.init = () => {
  if (SFX.ctx) { if (SFX.ctx.state === 'suspended') SFX.ctx.resume(); return true; }
  const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return false;
  const c = SFX.ctx = new AC();
  // мастер: мягкий срез верхов + чуть-чуть «комнаты» (короткая реверберация), чтобы звук не был сухим и цифровым
  const out = SFX.out = c.createGain(); out.gain.value = SFX.gain();
  const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 5200; lp.Q.value = 0.5;
  const comp = c.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 3;
  const dry = c.createGain(); dry.gain.value = 1;
  const wet = c.createGain(); wet.gain.value = 0.16;
  const rev = c.createConvolver();
  const len = Math.floor(c.sampleRate * 0.55), ir = c.createBuffer(2, len, c.sampleRate);
  for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2); }
  rev.buffer = ir;
  SFX.bus = c.createGain();
  SFX.bus.connect(dry); SFX.bus.connect(rev); rev.connect(wet);
  dry.connect(lp); wet.connect(lp); lp.connect(comp); comp.connect(out); out.connect(c.destination);
  return true;
};
// Деревянная нота: основной тон + обертон ×3,9 (как у маримбы), быстрое затухание
SFX.note = (f, t, len, vol, opt) => {
  const c = SFX.ctx, o = opt || {};
  const g = c.createGain(); g.connect(SFX.bus);
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + (o.att || 0.004)); g.gain.exponentialRampToValueAtTime(0.0001, t + len);
  const parts = o.bell ? [[1, 1], [2.0, 0.18], [3.01, 0.08]] : [[1, 1], [3.93, 0.22], [9.2, 0.05]];
  for (const [m, a] of parts) {
    const os = c.createOscillator(), og = c.createGain();
    os.type = 'sine'; os.frequency.setValueAtTime(f * m, t);
    og.gain.setValueAtTime(a, t); og.gain.exponentialRampToValueAtTime(0.0001, t + len / (m > 1 ? m * 0.55 : 1));
    os.connect(og); og.connect(g); os.start(t); os.stop(t + len + 0.05);
  }
};
// Шорох (бумага, ткань): шум через полосовой фильтр с движением частоты
SFX.rustle = (t, len, vol, f1, f2) => {
  const c = SFX.ctx, n = Math.floor(c.sampleRate * len), b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (0.6 + 0.4 * Math.random());
  const s = c.createBufferSource(); s.buffer = b;
  const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 0.9; bp.frequency.setValueAtTime(f1, t); bp.frequency.exponentialRampToValueAtTime(f2, t + len);
  const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + len * 0.3); g.gain.exponentialRampToValueAtTime(0.0001, t + len);
  s.connect(bp); bp.connect(g); g.connect(SFX.bus); s.start(t); s.stop(t + len);
};
// Мягкий щелчок: короткий «тук» по дереву
SFX.tick = (t, f, vol) => {
  const c = SFX.ctx, o = c.createOscillator(), g = c.createGain();
  o.type = 'triangle'; o.frequency.setValueAtTime(f, t); o.frequency.exponentialRampToValueAtTime(f * 0.6, t + 0.04);
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.002); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
  o.connect(g); g.connect(SFX.bus); o.start(t); o.stop(t + 0.07);
};
SFX.N = { C4: 261.6, D4: 293.7, E4: 329.6, F4: 349.2, G4: 392, A4: 440, B4: 493.9, C5: 523.3, D5: 587.3, E5: 659.3, G5: 784, A5: 880, C6: 1046.5, A3: 220, F3: 174.6, D3: 146.8 };
SFX.play = (name, force) => {
  if (!SFX.vol || !SFX.init()) return;
  const now = performance.now();
  if (!force && SFX.last[name] && now - SFX.last[name] < (name === 'click' ? 45 : 140)) return; // не строчить при быстрых кликах
  SFX.last[name] = now;
  const t = SFX.ctx.currentTime + 0.005, N = SFX.N;
  const p = {
    click: () => SFX.tick(t, 1350 + Math.random() * 120, 0.22),
    tab: () => { SFX.tick(t, 1100, 0.16); SFX.note(N.E5, t, 0.18, 0.05); },
    open: () => { SFX.rustle(t, 0.16, 0.05, 900, 2600); SFX.note(N.C5, t + 0.01, 0.35, 0.09); SFX.note(N.G5, t + 0.07, 0.4, 0.07); },
    close: () => { SFX.rustle(t, 0.12, 0.035, 2200, 800); SFX.note(N.G4, t, 0.25, 0.06); },
    week: () => { SFX.rustle(t, 0.32, 0.09, 600, 3200); SFX.note(N.D4, t + 0.05, 0.5, 0.07); SFX.note(N.A4, t + 0.12, 0.55, 0.06); },
    good: () => { SFX.note(N.C5, t, 0.5, 0.08, { bell: 1 }); SFX.note(N.E5, t + 0.08, 0.55, 0.07, { bell: 1 }); SFX.note(N.G5, t + 0.16, 0.8, 0.07, { bell: 1 }); },
    great: () => { [N.C5, N.E5, N.G5, N.C6].forEach((f, i) => SFX.note(f, t + i * 0.07, 0.9, 0.07, { bell: 1 })); },
    bad: () => { SFX.note(N.A3, t, 0.45, 0.09); SFX.note(N.F3, t + 0.13, 0.6, 0.08); },
    event: () => { SFX.note(N.A4, t, 0.9, 0.06, { bell: 1 }); SFX.note(N.E5, t + 0.11, 1.1, 0.05, { bell: 1 }); },
    coin: () => { SFX.note(N.E5, t, 0.2, 0.06, { bell: 1 }); SFX.note(N.A5, t + 0.06, 0.4, 0.06, { bell: 1 }); },
    type: () => SFX.tick(t, 1900 + Math.random() * 300, 0.08),
    send: () => { SFX.rustle(t, 0.12, 0.05, 1500, 3500); SFX.tick(t + 0.02, 1500, 0.12); },
  }[name];
  if (p) try { p(); } catch (e) { }
};
// Подключение к интерфейсу: клики по кнопкам, вкладки, ввод
SFX.bind = () => {
  if (SFX._bound) return; SFX._bound = true;
  document.addEventListener('pointerdown', e => {
    const b = e.target.closest && e.target.closest('button, .eopt, [data-dock], .mc, .rlist li, .chips button, select, input[type=checkbox]');
    if (!b || b.disabled) return;
    if (b.closest('.mtabs, .tabs, .seg')) SFX.play('tab'); else SFX.play('click');
  }, true);
  document.addEventListener('keydown', e => { if (e.target && /^(INPUT|TEXTAREA)$/.test(e.target.tagName) && e.target.type !== 'range' && e.key.length === 1 && Math.random() < 0.6) SFX.play('type'); }, true);
};
SFX.bind();
