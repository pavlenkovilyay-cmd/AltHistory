// «Судьба» — сетевая «шина» мультиплеера. Никакого прямого соединения между ПК (оно часто не пробивается через
// роутеры и провайдеров): все сообщения идут через открытые публичные серверы-ретрансляторы сразу по нескольким
// путям — MQTT-брокеры и Nostr-ретрансляторы (и, если задан, свой сервер). Дошло хоть по одному — хватит.
// Сообщения шифруются ключом из кода комнаты (AES-GCM), большие — режутся на куски.
'use strict';
const BUS = { tr: [], uid: '', topic: '', key: null, done: new Map(), parts: new Map(), onMsg: null, kind: 20777 };
BUS.DEF = {
  mqtt: ['wss://broker.emqx.io:8084/mqtt', 'wss://broker.hivemq.com:8884/mqtt', 'wss://test.mosquitto.org:8081/mqtt', 'wss://mqtt.eclipseprojects.io:443/mqtt', 'wss://public.mqtthq.com:8084/mqtt'],
  nostr: ['relay.damus.io', 'nos.lol', 'relay.nostr.band', 'relay.primal.net', 'nostr.mom', 'relay.snort.social', 'offchain.pub', 'nostr.oxtr.dev', 'relay.nostr.net', 'nostr-pub.wellorder.net', 'nostr.data.haus', 'relay.mostro.network', 'yabu.me', 'nostr.vulpem.com', 'relay.fountain.fm', 'nostr.einundzwanzig.space'].map(u => 'wss://' + u),
  own: [],
};
BUS.cfg = () => {
  const c = JSON.parse(JSON.stringify(BUS.DEF));
  if (window.SUDBA_NET && Array.isArray(SUDBA_NET.own)) c.own = SUDBA_NET.own.slice();
  try { const o = JSON.parse(localStorage.getItem('sudba_bus') || 'null'); if (o) Object.assign(c, o); } catch (e) { }
  try { const own = localStorage.getItem('sudba_own'); if (own) c.own = c.own.concat(own.split(/[\s,]+/).filter(Boolean)); } catch (e) { }
  return c;
};
const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
const unb64 = s => { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
const hex = u8 => Array.from(u8, x => x.toString(16).padStart(2, '0')).join('');
const sha = async t => new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)));
BUS.rid = () => hex(crypto.getRandomValues(new Uint8Array(8)));

BUS.start = async (code, uid) => {
  BUS.stop();
  BUS.uid = uid; BUS.gen = (BUS.gen || 0) + 1;
  BUS.topic = hex(await sha('sudba-room-v2:' + code)).slice(0, 40);
  BUS.key = await crypto.subtle.importKey('raw', await sha('sudba-key-v2:' + code), 'AES-GCM', false, ['encrypt', 'decrypt']);
  const c = BUS.cfg();
  c.mqtt.forEach(u => BUS.addMqtt(u));
  c.nostr.forEach(u => BUS.addNostr(u));
  c.own.forEach(u => BUS.addOwn(u));
};
BUS.stop = () => { for (const t of BUS.tr) { try { t.close(); } catch (e) { } } BUS.tr = []; BUS.parts.clear(); };
BUS.stat = () => { const r = {}; for (const k of ['mqtt', 'nostr', 'own']) { const l = BUS.tr.filter(t => t.kind === k); r[k] = [l.filter(t => t.on).length, l.length]; } return r; };
BUS.alive = () => BUS.tr.some(t => t.on);

// ---------- отправка / приём ----------
BUS.CH = 12000;
BUS.send = async obj => {
  if (!BUS.key) return;
  const i = BUS.rid();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, BUS.key, new TextEncoder().encode(JSON.stringify(obj))));
  const full = b64(iv) + '.' + b64(ct);
  const n = Math.max(1, Math.ceil(full.length / BUS.CH));
  const pieces = []; for (let k = 0; k < n; k++) pieces.push(JSON.stringify({ v: 2, i, n, k, p: full.slice(k * BUS.CH, (k + 1) * BUS.CH) }));
  BUS.done.set(i, Date.now()); // своё не принимаем
  const ts = BUS.tr.filter(t => t.on);
  let nostrUsed = 0;
  // частые сообщения (3D-дом: позиции ~10 раз/с) — через MQTT/свой релей; Nostr только если больше ничего нет, и на 1–2 релея
  const fast = obj && obj.t === 'h3', quick = fast && ts.some(t => t.kind !== 'nostr');
  for (const t of ts) {
    if (t.kind === 'nostr' && (quick || nostrUsed++ >= (fast ? 2 : 6) || n > 40)) continue; // Nostr — для небольших сообщений и не на все сразу
    for (const p of pieces) t.pub(p);
  }
};
BUS.recv = async str => {
  let m; try { m = JSON.parse(str); } catch (e) { return; }
  if (!m || m.v !== 2 || !m.i || BUS.done.has(m.i)) return;
  let e = BUS.parts.get(m.i); if (!e) { e = { n: m.n, got: new Array(m.n), c: 0, t: Date.now() }; BUS.parts.set(m.i, e); }
  if (e.got[m.k] !== undefined) return;
  e.got[m.k] = m.p; e.c++;
  if (e.c < e.n) return;
  BUS.parts.delete(m.i); BUS.done.set(m.i, Date.now());
  try {
    const [iv, ct] = e.got.join('').split('.');
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(iv) }, BUS.key, unb64(ct));
    const obj = JSON.parse(new TextDecoder().decode(pt));
    if (BUS.onMsg) BUS.onMsg(obj);
  } catch (err) { /* чужая комната или битое сообщение */ }
};
setInterval(() => { const now = Date.now(); for (const [k, t] of BUS.done) if (now - t > 300000) BUS.done.delete(k); for (const [k, e] of BUS.parts) if (now - e.t > 90000) BUS.parts.delete(k); }, 30000);

// ---------- MQTT ----------
BUS.addMqtt = url => {
  const t = { kind: 'mqtt', url, on: false, cli: null };
  try {
    const cli = t.cli = BUSLIB.mqtt.connect(url, { clientId: 'sudba_' + BUS.rid(), clean: true, keepalive: 30, reconnectPeriod: 5000, connectTimeout: 9000, protocolVersion: 4 });
    const tp = 'sudba/v2/' + BUS.topic;
    cli.on('connect', () => { t.on = true; cli.subscribe(tp, { qos: 0 }); BUS.changed(); });
    cli.on('close', () => { if (t.on) { t.on = false; BUS.changed(); } });
    cli.on('offline', () => { t.on = false; });
    cli.on('error', () => { });
    cli.on('message', (topic, payload) => BUS.recv(payload.toString()));
    t.pub = s => { try { cli.publish(tp, s, { qos: 0 }); } catch (e) { } };
    t.close = () => { try { cli.end(true); } catch (e) { } };
  } catch (e) { t.pub = () => { }; t.close = () => { }; }
  BUS.tr.push(t);
};

// ---------- Nostr ----------
BUS.nkey = null;
BUS.nostrSign = async content => {
  const S = BUSLIB.schnorr;
  if (!BUS.nkey) { const sk = crypto.getRandomValues(new Uint8Array(32)); BUS.nkey = { sk, pk: hex(S.getPublicKey(sk)) }; }
  const ev = { pubkey: BUS.nkey.pk, created_at: Math.floor(Date.now() / 1000), kind: BUS.kind, tags: [['t', BUS.topic]], content };
  const id = await sha(JSON.stringify([0, ev.pubkey, ev.created_at, ev.kind, ev.tags, ev.content]));
  ev.id = hex(id); ev.sig = hex(await S.signAsync(id, BUS.nkey.sk));
  return ev;
};
BUS.addNostr = url => {
  const t = { kind: 'nostr', url, on: false, ws: null, dead: false, tries: 0 };
  const open = () => {
    if (t.dead) return;
    let ws; try { ws = t.ws = new WebSocket(url); } catch (e) { return; }
    const sub = 's' + BUS.rid();
    const to = setTimeout(() => { try { ws.close(); } catch (e) { } }, 9000);
    ws.onopen = () => { clearTimeout(to); t.on = true; t.tries = 0; ws.send(JSON.stringify(['REQ', sub, { kinds: [BUS.kind], '#t': [BUS.topic], since: Math.floor(Date.now() / 1000) - 30 }])); BUS.changed(); };
    ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch (x) { return; } if (m[0] === 'EVENT' && m[2] && typeof m[2].content === 'string') BUS.recv(m[2].content); };
    ws.onclose = () => { clearTimeout(to); const was = t.on; t.on = false; if (was) BUS.changed(); if (!t.dead) setTimeout(open, Math.min(60000, 4000 * Math.pow(1.6, t.tries++))); };
    ws.onerror = () => { };
  };
  t.pub = async s => { if (!t.on) return; try { t.ws.send(JSON.stringify(['EVENT', await BUS.nostrSign(s)])); } catch (e) { } };
  t.close = () => { t.dead = true; try { t.ws && t.ws.close(); } catch (e) { } };
  open();
  BUS.tr.push(t);
};

// ---------- свой сервер (необязательно): простой WebSocket-ретранслятор из папки server ----------
BUS.addOwn = url => {
  const t = { kind: 'own', url, on: false, ws: null, dead: false, tries: 0 };
  const open = () => {
    if (t.dead) return;
    let ws; try { ws = t.ws = new WebSocket(url.replace(/\/$/, '') + '/?room=' + BUS.topic); } catch (e) { return; }
    ws.onopen = () => { t.on = true; t.tries = 0; BUS.changed(); };
    ws.onmessage = e => BUS.recv(String(e.data));
    ws.onclose = () => { const was = t.on; t.on = false; if (was) BUS.changed(); if (!t.dead) setTimeout(open, Math.min(30000, 3000 * Math.pow(1.5, t.tries++))); };
    ws.onerror = () => { };
  };
  t.pub = s => { if (t.on) try { t.ws.send(s); } catch (e) { } };
  t.close = () => { t.dead = true; try { t.ws && t.ws.close(); } catch (e) { } };
  open();
  BUS.tr.push(t);
};
BUS.changed = () => { if (BUS.onChange) BUS.onChange(); };

// ---------- «комната» поверх шины: участники по сердцебиению ----------
BUS.room = (code, uid) => {
  const room = { actions: {}, joinCb: () => { }, leaveCb: () => { }, peers: new Map(), hb: null };
  BUS.onMsg = m => {
    if (!m || m.f === uid) return;
    if (m.to && m.to !== uid) { room.seen(m.f); return; }
    const isNew = room.seen(m.f);
    if (m.t === '_hi' && !isNew) room.joinCb(m.f); // кто-то (пере)зашёл — представиться ему заново
    if (m.t !== '_hb' && m.t !== '_hi' && room.actions[m.t]) room.actions[m.t](m.d, m.f);
  };
  room.seen = pid => { const isNew = !room.peers.has(pid); room.peers.set(pid, Date.now()); if (isNew) room.joinCb(pid); return isNew; };
  room.makeAction = name => [(data, to) => BUS.send({ t: name, f: uid, to: to || undefined, d: data }), fn => { room.actions[name] = fn; }];
  room.onPeerJoin = f => { room.joinCb = f; };
  room.onPeerLeave = f => { room.leaveCb = f; };
  room.leave = () => { clearInterval(room.hb); const g = BUS.gen; BUS.send({ t: '_bye', f: uid }).finally(() => setTimeout(() => { if (BUS.gen === g) BUS.stop(); }, 600)); BUS.onMsg = null; BUS.onChange = null; };
  room.actions._bye = (d, pid) => { if (room.peers.delete(pid)) room.leaveCb(pid); };
  room.hb = setInterval(() => {
    BUS.send({ t: '_hb', f: uid });
    const now = Date.now();
    for (const [pid, t] of room.peers) if (now - t > 40000) { room.peers.delete(pid); room.leaveCb(pid); }
  }, 8000);
  BUS.onChange = () => { if (BUS.alive() && !room.first) { room.first = true; BUS.send({ t: '_hi', f: uid }); setTimeout(() => BUS.send({ t: '_hi', f: uid }), 2500); } if (typeof NET !== 'undefined') NET.refresh(); };
  BUS.start(code, uid);
  return room;
};
