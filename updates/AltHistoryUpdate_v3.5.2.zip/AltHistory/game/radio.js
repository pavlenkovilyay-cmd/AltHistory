// «Судьба» — радио. Плейлист из папки game/radio. Чтобы добавить трек: положите mp3 в game/radio и допишите строку ниже.
'use strict';
const RADIO = {
  list: [
    { f: 'radio/01.mp3', a: 'SHAMAN', t: 'Я русский' },
    { f: 'radio/02.mp3', a: 'Молодой Егор', t: 'Бегу от Аллаха' },
    { f: 'radio/03.mp3', a: 'Don Karton', t: 'Like Me' },
    { f: 'radio/04.mp3', a: 'WENARO feat. LXNER', t: 'Лёд' },
    { f: 'radio/05.mp3', a: 'Медовий Полин', t: 'Льоха ти сепаратіст' },
    { f: 'radio/06.mp3', a: 'Hava Nagila', t: 'Gachi Remix (Right Version)' },
    { f: 'radio/07.mp3', a: 'SHAMAN', t: 'Gachi Remix (Right Version)' },
    { f: 'radio/08.mp3', a: 'Ремикс', t: 'Remix' },
    { f: 'radio/09.mp3', a: 'Александр Пистолетов', t: 'Я российский новый пират' },
  ],
  KEY: 'sudba_radio', audio: null, st: { on: false, vol: 50, i: 0, t: 0, shuffle: false, open: false },
};
RADIO.save = () => { try { localStorage.setItem(RADIO.KEY, JSON.stringify(RADIO.st)); } catch (e) { } };
RADIO.init = () => {
  if (RADIO.audio) return;
  try { Object.assign(RADIO.st, JSON.parse(localStorage.getItem(RADIO.KEY) || '{}')); } catch (e) { }
  RADIO.st.i = Math.min(RADIO.st.i || 0, RADIO.list.length - 1); RADIO.st.open = false;
  const a = RADIO.audio = new Audio();
  a.preload = 'auto'; a.volume = Math.pow(RADIO.st.vol / 100, 1.7);
  a.addEventListener('ended', () => RADIO.next());
  a.addEventListener('timeupdate', () => { RADIO.st.t = a.currentTime; if (RADIO.panel && RADIO.st.open) RADIO.pos(); });
  a.addEventListener('error', () => { if (RADIO.st.on) setTimeout(RADIO.next, 800); });
  setInterval(RADIO.save, 5000);
  const panel = RADIO.panel = document.createElement('div');
  panel.className = 'radio hidden'; document.body.appendChild(panel);
  document.addEventListener('mousedown', e => { if (RADIO.st.open && !panel.contains(e.target) && !e.target.closest('#radioBtn')) RADIO.toggle(false); });
  RADIO.load(RADIO.st.i, RADIO.st.t);
  if (RADIO.st.on) RADIO.play();
};
RADIO.load = (i, t) => { const a = RADIO.audio; RADIO.st.i = (i + RADIO.list.length) % RADIO.list.length; a.src = RADIO.list[RADIO.st.i].f; if (t) a.addEventListener('loadedmetadata', () => { try { a.currentTime = t; } catch (e) { } }, { once: true }); };
RADIO.play = () => { RADIO.st.on = true; RADIO.audio.play().catch(() => { RADIO.st.on = false; RADIO.sync(); }); RADIO.sync(); RADIO.save(); };
RADIO.pause = () => { RADIO.st.on = false; RADIO.audio.pause(); RADIO.sync(); RADIO.save(); };
RADIO.next = () => { RADIO.load(RADIO.st.shuffle && RADIO.list.length > 1 ? (RADIO.st.i + 1 + Math.floor(Math.random() * (RADIO.list.length - 1))) : RADIO.st.i + 1); if (RADIO.st.on) RADIO.audio.play().catch(() => { }); RADIO.sync(); RADIO.save(); };
RADIO.prev = () => { if (RADIO.audio.currentTime > 4) RADIO.audio.currentTime = 0; else { RADIO.load(RADIO.st.i - 1); if (RADIO.st.on) RADIO.audio.play().catch(() => { }); } RADIO.sync(); RADIO.save(); };
RADIO.setVol = v => { RADIO.st.vol = Math.max(0, Math.min(100, v)); RADIO.audio.volume = Math.pow(RADIO.st.vol / 100, 1.7); RADIO.save(); };
RADIO.toggle = open => { RADIO.init(); RADIO.st.open = open === undefined ? !RADIO.st.open : open; RADIO.render(); };
RADIO.fmt = s => !isFinite(s) ? '0:00' : Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
RADIO.pos = () => { const a = RADIO.audio, p = RADIO.panel.querySelector('.rpos'); if (!p) return; p.querySelector('i').style.width = (a.duration ? a.currentTime / a.duration * 100 : 0) + '%'; RADIO.panel.querySelector('.rtime').textContent = RADIO.fmt(a.currentTime) + ' / ' + RADIO.fmt(a.duration); };
RADIO.render = () => {
  const p = RADIO.panel, s = RADIO.st, tr = RADIO.list[s.i];
  p.classList.toggle('hidden', !s.open);
  const btn = document.getElementById('radioBtn'); if (btn) btn.classList.toggle('on', s.on);
  if (!s.open) return;
  p.innerHTML = `<div class="rh">${UI.ic('radio')}<b>Радио AltHistory</b><button class="rx" data-r="close">${UI.ic('x')}</button></div>
    <div class="rnow"><div class="rdisc ${s.on ? 'spin' : ''}"><i></i></div><div><b>${UI.esc(tr.t)}</b><small>${UI.esc(tr.a)}</small></div></div>
    <div class="rpos" data-r="seek"><i></i></div><div class="rtime"></div>
    <div class="rctl"><button data-r="shuffle" class="${s.shuffle ? 'on' : ''}" title="Случайный порядок">⤮</button><button data-r="prev" title="Назад">⏮</button><button data-r="play" class="rp" title="${s.on ? 'Пауза' : 'Играть'}">${s.on ? '⏸' : '▶'}</button><button data-r="next" title="Дальше">⏭</button><button data-r="mute" title="Без звука">${s.vol ? '🔊' : '🔇'}</button></div>
    <label class="rvol"><span>Музыка</span><input type="range" min="0" max="100" value="${s.vol}" data-r="vol"><b>${s.vol}%</b></label>
    <label class="rvol sfx"><span>Звуки</span><input type="range" min="0" max="100" value="${typeof SFX !== 'undefined' ? SFX.vol : 0}" data-r="sfx"><b>${typeof SFX !== 'undefined' ? SFX.vol : 0}%</b></label>
    <ol class="rlist">${RADIO.list.map((x, i) => `<li class="${i === s.i ? 'cur' : ''}" data-i="${i}"><span>${i === s.i && s.on ? '♪' : i + 1}</span><b>${UI.esc(x.t)}</b><small>${UI.esc(x.a)}</small></li>`).join('')}</ol>`;
  RADIO.pos();
  p.querySelectorAll('[data-r]').forEach(el => {
    const k = el.dataset.r;
    if (k === 'vol') { el.oninput = () => { RADIO.setVol(+el.value); p.querySelector('.rvol b').textContent = el.value + '%'; }; return; }
    if (k === 'sfx') { el.oninput = () => { SFX.setVol(+el.value); p.querySelector('.rvol.sfx b').textContent = el.value + '%'; }; el.onchange = () => SFX.play('good', true); return; }
    if (k === 'seek') { el.onclick = e => { const r = el.getBoundingClientRect(), a = RADIO.audio; if (a.duration) a.currentTime = (e.clientX - r.left) / r.width * a.duration; }; return; }
    el.onclick = () => ({ close: () => RADIO.toggle(false), play: () => s.on ? RADIO.pause() : RADIO.play(), next: RADIO.next, prev: RADIO.prev, shuffle: () => { s.shuffle = !s.shuffle; RADIO.save(); RADIO.render(); }, mute: () => { if (s.vol) { s.lastVol = s.vol; RADIO.setVol(0); } else RADIO.setVol(s.lastVol || 50); RADIO.render(); } })[k]();
  });
  p.querySelectorAll('.rlist li').forEach(li => li.onclick = () => { RADIO.load(+li.dataset.i); RADIO.play(); });
};
RADIO.sync = () => { if (RADIO.st.open) RADIO.render(); else { const b = document.getElementById('radioBtn'); if (b) b.classList.toggle('on', RADIO.st.on); } };
