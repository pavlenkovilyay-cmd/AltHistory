// «Судьба» — управление государством, когда вы пришли к власти.
// Законы и политический капитал (как в HOI4), форма правления, бюджет и налоги, инфляция (она двигает цены в игре),
// министры (в т.ч. живые игроки), партии и выборы, ресурсы и торговля, дипломатия с нейросетью-лидером
// каждой страны, блоки, кризисы. Всё, что меняет общий мир, в мультиплеере считается у хоста.
'use strict';
const GOV = {};
(() => {
  const W_ = s => s.world;
  const cl = E.clamp;
  // ---------- формы правления ----------
  GOV.FORMS = {
    presidential: { n: 'Президентская республика', dem: 1, pc: 1, stab: 0, elect: 72, d: 'Сильный президент, выборы раз в 6 лет. Проиграете — потеряете власть.' },
    parliamentary: { n: 'Парламентская республика', dem: 1, pc: 0.8, stab: 4, elect: 48, d: 'Решения через парламент: капитала меньше, стабильность выше, выборы раз в 4 года.' },
    monarchy: { n: 'Конституционная монархия', dem: 1, pc: 0.9, stab: 6, elect: 60, d: 'Вы — монарх, правительство выбирают. Народ спокоен, но парламент может отобрать власть.' },
    absolute: { n: 'Абсолютная монархия', dem: 0, pc: 1.3, stab: -2, d: 'Всё решаете вы. Выборов нет, но Запад вас не любит, а недовольство копится.' },
    dictatorship: { n: 'Диктатура', dem: 0, pc: 1.5, stab: -4, d: 'Максимум власти, никаких выборов. При низкой популярности — риск переворота.' },
    junta: { n: 'Военная хунта', dem: 0, pc: 1.3, stab: -3, mil: 1.25, d: 'Армия у власти: дивизии сильнее, экономика хуже.' },
    socialist: { n: 'Социалистическое государство', dem: 0, pc: 1.3, stab: 0, d: 'Одна партия и плановая экономика. Стабильно, но рост медленнее.' },
  };
  GOV.formOf = gov => /Монарх/.test(gov || '') ? 'monarchy' : /Парламент/.test(gov || '') ? 'parliamentary' : /Республика|Конституц|Доминион/.test(gov || '') ? 'presidential' : /социал|Советск|Народн|коммун/i.test(gov || '') ? 'socialist' : /хунт|Военн/i.test(gov || '') ? 'junta' : /монарх/i.test(gov || '') ? 'absolute' : 'dictatorship';
  // ---------- законы ----------
  // fx — сдвиги «целей» страны: gr (рост %/год), infl (инфляция), stab, appr (популярность), mp (людской резерв ×), trade (×), pc (капитал/мес), crime (розыск преступников в стране)
  GOV.LAWS = {
    econ: { n: 'Экономика', o: {
      planned: { n: 'Плановая', fx: { gr: -1.2, infl: -2, stab: 3, appr: -2, pc: 0.3 }, d: 'Государство решает, что производить. Цены держат, рост слабый.' },
      state: { n: 'Госкапитализм', fx: { gr: -0.3, infl: -0.5, stab: 2, pc: 0.2 }, d: 'Крупные компании — у государства.' },
      mixed: { n: 'Смешанная', fx: {}, d: 'Баланс рынка и государства.' },
      market: { n: 'Рыночная', fx: { gr: 0.6, infl: 0.5, stab: -1, appr: -1 }, d: 'Больше свободы бизнесу — рост выше, неравенство тоже.' },
      free: { n: 'Свободный рынок', fx: { gr: 1.1, infl: 1, stab: -3, appr: -3 }, d: 'Минимум государства. Богатые богатеют быстрее.' } } },
    conscr: { n: 'Призыв', o: {
      volunteer: { n: 'Только добровольцы', fx: { mp: 0.4, appr: 3, gr: 0.2 }, d: 'Маленький резерв, народ доволен.' },
      contract: { n: 'Контрактная армия', fx: { mp: 0.7, appr: 1 }, d: 'Профессионалы за деньги.' },
      limited: { n: 'Ограниченный призыв', fx: { mp: 1 }, d: 'Срочная служба год.' },
      universal: { n: 'Всеобщая воинская обязанность', fx: { mp: 1.6, appr: -4, gr: -0.3 }, d: 'Служат все мужчины. Резерв большой.' },
      total: { n: 'Тотальная мобилизация', fx: { mp: 2.6, appr: -12, gr: -1.5, stab: -5 }, d: 'Все под ружьё. Только на войне.' } } },
    press: { n: 'СМИ', o: {
      free: { n: 'Свобода слова', fx: { appr: -2, stab: -1, pc: -0.3, west: 10 }, d: 'Вас критикуют, но и доверяют больше.' },
      partial: { n: 'Частично свободные', fx: {}, d: 'Крупные каналы — лояльны, интернет — свободен.' },
      state: { n: 'Государственные СМИ', fx: { appr: 3, pc: 0.3, west: -10 }, d: 'Телевизор говорит то, что нужно.' },
      censor: { n: 'Жёсткая цензура', fx: { appr: 5, stab: 2, pc: 0.6, gr: -0.3, west: -25 }, d: 'Недовольных не слышно. Пока.' } } },
    trade: { n: 'Торговля', o: {
      free: { n: 'Свободная торговля', fx: { gr: 0.6, trade: 1.3, infl: -0.5 }, d: 'Импорт дешевле, своё производство страдает.' },
      export: { n: 'Экспортная', fx: { gr: 0.3, trade: 1.15 }, d: 'Поддержка экспортёров.' },
      limited: { n: 'Протекционизм', fx: { trade: 0.85, infl: 0.5, appr: 1 }, d: 'Пошлины защищают своих.' },
      closed: { n: 'Автаркия', fx: { trade: 0.4, gr: -1, infl: 1.5, stab: 1 }, d: 'Живём своим. Санкции не страшны, но всё дорожает.' } } },
    social: { n: 'Соцполитика', o: {
      minimal: { n: 'Минимальная', fx: { appr: -5, gr: 0.4 }, d: 'Каждый сам за себя.' },
      basic: { n: 'Базовая', fx: {}, d: 'Пенсии и бесплатная медицина.' },
      welfare: { n: 'Социальное государство', fx: { appr: 6, gr: -0.3, stab: 2 }, d: 'Щедрые пособия. Дорого.' } } },
    police: { n: 'Правопорядок', o: {
      soft: { n: 'Мягкий', fx: { appr: 2, stab: -2, crime: -1 }, d: 'Полиция не лезет. Преступникам вольготно.' },
      normal: { n: 'Обычный', fx: {}, d: 'Как у всех.' },
      strict: { n: 'Строгий', fx: { stab: 3, appr: -1, crime: 1 }, d: 'Больше патрулей и сроков.' },
      state: { n: 'Полицейское государство', fx: { stab: 6, appr: -6, crime: 2, pc: 0.4, west: -15 }, d: 'Слежка и обыски. Бандитам — конец, свободам тоже.' } } },
    migr: { n: 'Миграция', o: {
      open: { n: 'Открытая', fx: { gr: 0.5, appr: -2 }, d: 'Рабочие руки дешёвые.' },
      quota: { n: 'По квотам', fx: {}, d: 'Сколько нужно экономике.' },
      closed: { n: 'Закрытая', fx: { gr: -0.4, appr: 2 }, d: 'Только свои.' } } },
  };
  GOV.DEFLAW = { econ: 'mixed', conscr: 'limited', press: 'partial', trade: 'export', social: 'basic', police: 'normal', migr: 'quota' };
  GOV.LAWCOST = 40; // политический капитал за смену закона
  // ---------- министерства ----------
  GOV.MIN = {
    econ: { n: 'Экономики', d: 'рост ВВП' }, fin: { n: 'Финансов', d: 'инфляция и долг' }, def: { n: 'Обороны', d: 'дивизии и резерв' },
    fore: { n: 'Иностранных дел', d: 'шансы на переговорах' }, inter: { n: 'Внутренних дел', d: 'стабильность, преступность' }, soc: { n: 'Соцполитики', d: 'популярность' },
  };
  GOV.TRAITS = [['Технократ', 'econ'], ['Банкир', 'fin'], ['Генерал', 'def'], ['Дипломат', 'fore'], ['Силовик', 'inter'], ['Популист', 'soc'], ['Реформатор', 'econ'], ['Казначей', 'fin'], ['Стратег', 'def'], ['Переговорщик', 'fore'], ['Чекист', 'inter'], ['Любимец народа', 'soc']];
  const FN = ['Алексей', 'Сергей', 'Игорь', 'Дмитрий', 'Андрей', 'Олег', 'Виктор', 'Михаил', 'Николай', 'Павел', 'Елена', 'Ольга', 'Татьяна', 'Ирина', 'Марина'];
  const LN = ['Соболев', 'Кравцов', 'Белов', 'Шувалов', 'Громов', 'Лаврентьев', 'Орлов', 'Зайцев', 'Медведев', 'Рогов', 'Карпов', 'Ветров', 'Ганин', 'Пестов', 'Тихонов', 'Кудрин'];
  GOV.cand = (s, slot, k) => {
    const r = L.rng(L.hash('min', slot, k, Math.floor((s.turn || 0) / 8)));
    const f = FN[Math.floor(r() * FN.length)], l = LN[Math.floor(r() * LN.length)], fem = FN.indexOf(f) >= 10;
    const tr = GOV.TRAITS.filter(t => t[1] === slot), t = r() < 0.6 && tr.length ? tr[Math.floor(r() * tr.length)] : GOV.TRAITS[Math.floor(r() * GOV.TRAITS.length)];
    return { n: f + ' ' + l + (fem ? 'а' : ''), comp: 1 + Math.floor(r() * 5), loy: Math.round(30 + r() * 70), cor: Math.round(r() * 80), trait: t[0], tk: t[1] };
  };
  // эффект министра: 0..1
  GOV.minK = (G, slot) => { const m = G.min[slot]; if (!m) return 0; return (m.comp / 5) * (m.tk === slot ? 1.2 : 0.8); };
  // ---------- партии ----------
  GOV.PARTIES = s => E.ww2(s) ? [['ВКП(б)', '#c0392b', 'left']] : [['Партия власти', '#3b6ea8', 'gov'], ['Коммунисты', '#c0392b', 'left'], ['Либералы', '#e0a800', 'lib'], ['Националисты', '#6d4c41', 'nat'], ['Социал-демократы', '#d35400', 'soc'], ['Зелёные', '#2e8b57', 'green']];
  // ---------- ресурсы ----------
  GOV.RES = {
    energy: { n: 'Энергия', ic: 'bolt', r: { oil: 3, gas: 3, coal: 2, uran: 2, hydro: 1.5, geo: 1 } },
    metal: { n: 'Металлы', ic: 'factory', r: { iron: 3, copp: 2, alum: 2, nick: 2, chrom: 2, tin: 1, zinc: 1, cob: 1, tung: 1, lith: 2, rare: 2, plat: 1, mang: 1, silv: 1 } },
    food: { n: 'Продовольствие', ic: 'heart', r: { grain: 2, cattle: 1, fish: 1, rice: 2, maize: 2, soy: 2, potato: 1, sunf: 1, beet: 1, fruit: 1, milk: 1, veg: 1, sugar: 1, sheep: 1, banana: 1, citrus: 1, date: 1, olive: 1, deer: 0.5 } },
    raw: { n: 'Сырьё', ic: 'box', r: { wood: 1, cott: 2, rubb: 2, palm: 1, flax: 1, jute: 1, silk: 1, fur: 1, cork: 1, phos: 2, pot: 2, salt: 1, sand: 1 } },
    lux: { n: 'Ценности', ic: 'star', r: { gold: 3, diam: 3, gems: 2, coff: 1, tea: 1, wine: 1, tob: 1, coco: 1, spice: 1, tour: 2, amber: 1 } },
  };
  GOV.res = (s, c) => {
    const W = W_(s), P = M().provinces, out = {}; for (const k in GOV.RES) out[k] = 0;
    for (let i = 0; i < P.length; i++) if (W.own[i] === c) for (const r of (P[i].r || [])) for (const k in GOV.RES) if (GOV.RES[k].r[r]) out[k] += GOV.RES[k].r[r];
    // потребность — по экономике и населению
    const C = W.cs[c], need = { energy: Math.sqrt(C.st.gdp) * 2.2, metal: Math.sqrt(C.st.gdp) * 1.4, food: Math.sqrt(C.st.pop) * 9, raw: Math.sqrt(C.st.gdp) * 1.2, lux: 0 };
    const G = (W.gov || {})[c]; const deals = G ? G.deals || [] : [];
    const res = {};
    for (const k in GOV.RES) { const imp = deals.filter(d => d.res === k && d.dir === 'in').reduce((a, d) => a + d.amt, 0), exp = deals.filter(d => d.res === k && d.dir === 'out').reduce((a, d) => a + d.amt, 0); res[k] = { prod: Math.round(out[k]), need: Math.round(need[k]), imp, exp, bal: Math.round(out[k] + imp - exp - need[k]) }; }
    return res;
  };
  // ---------- состояние правительства страны ----------
  GOV.get = (s, c) => { const W = W_(s); W.gov = W.gov || {}; return W.gov[c] || null; };
  GOV.init = (s, c, who) => {
    const W = W_(s); W.gov = W.gov || {};
    if (W.gov[c]) { if (who) Object.assign(W.gov[c], who); return W.gov[c]; }
    const C = W.cs[c], st = C.st;
    const form = GOV.formOf(st.gov);
    const G = W.gov[c] = {
      form, pc: 60, appr: cl(Math.round(st.stab * 0.8 + 10), 20, 80), laws: Object.assign({}, GOV.DEFLAW, E.ww2(s) ? { econ: 'planned', press: 'censor', conscr: 'universal' } : {}),
      bud: { tax: E.ww2(s) ? 25 : 22, army: Math.round(Math.max(1, st.milp) * 10) / 10, social: 7, health: 4, edu: 4, infra: 3, science: 1, police: 2, print: 0 },
      min: {}, deals: [], pacts: {}, dip: {}, crisis: [], hist: [], log: [],
      gr0: st.gr, infl0: C.inflBase !== undefined ? C.inflBase : st.infl, mp: Math.round(Math.sqrt(st.pop) * 12), mil: 25, bal: 0, last: {},
      elect: GOV.FORMS[form].dem ? new Date(Date.parse(s.date) + GOV.FORMS[form].elect * 30.4 * 864e5).toISOString() : null,
      parties: GOV.PARTIES(s).map(([n, col, ide], i) => ({ n, col, ide, pop: i === 0 ? 45 : Math.round(55 / Math.max(1, GOV.PARTIES(s).length - 1)) })),
    };
    for (const k in GOV.MIN) G.min[k] = GOV.cand(s, k, 0);
    if (who) Object.assign(G, who);
    return G;
  };
  // ---------- месяц для страны (в мультиплеере — у хоста) ----------
  GOV.lawFx = G => { const f = { gr: 0, infl: 0, stab: 0, appr: 0, mp: 1, trade: 1, pc: 0, crime: 0, west: 0 }; for (const cat in G.laws) { const o = GOV.LAWS[cat].o[G.laws[cat]]; if (!o) continue; for (const k in o.fx) { if (k === 'mp' || k === 'trade') f[k] *= o.fx[k]; else f[k] += o.fx[k]; } } return f; };
  GOV.budget = (s, c) => {
    const G = GOV.get(s, c), C = W_(s).cs[c], b = G.bud;
    const eff = 0.75 + C.st.stab / 400 + GOV.minK(G, 'fin') * 0.08 - (G.laws.police === 'soft' ? 0.04 : 0); // собираемость налогов
    const res = GOV.res(s, c), tm = GOV.lawFx(G).trade;
    const exportInc = Math.min(6, Object.values(res).reduce((a, r) => a + Math.sqrt(Math.max(0, r.bal)) * 0.12, 0)) * tm;
    const importCost = Object.values(res).reduce((a, r) => a + Math.sqrt(Math.max(0, -r.bal)) * 0.18, 0) / tm;
    const dealInc = (G.deals || []).reduce((a, d) => a + (d.dir === 'out' ? d.amt * 0.02 : -d.amt * 0.02), 0);
    const corr = Object.values(G.min).reduce((a, m) => a + (m && !m.uid ? m.cor : 0), 0) / 600 * 0.5;
    const rev = b.tax * eff + exportInc + dealInc;
    const debtCost = C.st.debt * (E.ww2(s) ? 0.03 : 0.06) / 1;
    const spend = b.army + b.social + b.health + b.edu + b.infra + b.science + b.police + debtCost * 0.12 + importCost + corr;
    return { rev: +rev.toFixed(1), spend: +spend.toFixed(1), bal: +(rev - spend).toFixed(1), eff, exportInc: +exportInc.toFixed(2), importCost: +importCost.toFixed(2), corr: +corr.toFixed(2), debtCost: +(debtCost * 0.12).toFixed(2) };
  };
  GOV.month = (s, c) => {
    const W = W_(s), C = W.cs[c], G = GOV.get(s, c); if (!G || C.dead) return;
    const st = C.st, f = GOV.lawFx(G), b = G.bud, F = GOV.FORMS[G.form] || GOV.FORMS.presidential;
    const bu = GOV.budget(s, c);
    // бюджет → долг и инфляция
    let printInfl = 0;
    if (bu.bal < 0) { if (b.print) printInfl = -bu.bal * 1.6; else st.debt = cl(st.debt - bu.bal / 12 * 10, 0, 400); }
    else st.debt = cl(st.debt - bu.bal / 12 * 6, 0, 400);
    // цели роста и инфляции
    const res = GOV.res(s, c);
    const short = k => Math.max(0, -res[k].bal) / Math.max(1, res[k].need);
    const gr = G.gr0 + f.gr + (b.infra - 3) * 0.25 + (b.science - 1) * 0.35 + (b.edu - 4) * 0.12 - (b.tax - 20) * 0.08 - Math.max(0, st.debt - 80) * 0.02 + GOV.minK(G, 'econ') * 0.8 - short('energy') * 2.5 - short('metal') * 1.2 + (F.mil ? -0.6 : 0);
    st.gr += (gr - st.gr) * 0.25;
    const infl = Math.max(-2, G.infl0 + f.infl + Math.max(0, -bu.bal - 3) * 0.5 + printInfl - GOV.minK(G, 'fin') * 1.5 + short('food') * 6 + short('energy') * 3);
    C.inflBase = infl;
    st.milp = Math.max(0.3, b.army);
    st.stab = cl(st.stab + (F.stab + f.stab) * 0.05 + (b.police - 2) * 0.15 + GOV.minK(G, 'inter') * 0.3 - short('food') * 4, 0, 100);
    // популярность
    const target = 30 + st.stab * 0.35 + Math.min(8, st.gr * 1.5) - Math.max(0, st.infl - 6) * 0.6 - st.unemp * 0.5 + (b.social - 7) * 1.2 + (b.health - 4) * 1 - (b.tax - 20) * 0.6 + f.appr + GOV.minK(G, 'soc') * 5 - (WD.enemies(s, c).length ? 4 + (C.wear || 0) * 0.15 : 0) - short('food') * 15;
    G.appr = cl(G.appr + (cl(target, 3, 95) - G.appr) * 0.2 + E.rnd(-1.5, 1.5), 0, 100);
    G.pc = Math.min(300, G.pc + 8 * F.pc + f.pc * 10 + (G.appr - 50) * 0.05);
    G.mp = Math.round((G.mp || 0) + st.pop * 1000 * 0.0006 * f.mp * (1 + GOV.minK(G, 'def') * 0.3)); // тыс. человек в резерве (в месяц)
    G.mil = Math.round(((G.mil || 0) + b.army * Math.sqrt(st.gdp) * 0.1 * (F.mil || 1)) * 10) / 10; // военное производство (очки)
    G.bal = bu.bal; G.last = bu;
    // партии
    const gov0 = G.parties[0]; if (gov0) { gov0.pop = cl(gov0.pop + (G.appr - 45 - gov0.pop * 0.3) * 0.05, 3, 90); const rest = 100 - gov0.pop, others = G.parties.slice(1), sum = others.reduce((a, p) => a + p.pop, 0) || 1; for (const p of others) { p.pop = Math.max(1, p.pop / sum * rest + E.rnd(-0.6, 0.6)); if (p.ide === 'left' && st.infl > 10) p.pop += 0.4; if (p.ide === 'nat' && WD.enemies(s, c).length) p.pop += 0.3; if (p.ide === 'lib' && G.laws.press === 'censor') p.pop -= 0.3; } const t = G.parties.reduce((a, p) => a + p.pop, 0); for (const p of G.parties) p.pop = Math.round(p.pop / t * 1000) / 10; }
    // сделки
    G.deals = (G.deals || []).filter(d => !d.until || s.date < d.until);
    // отношения с Западом от законов
    if (f.west) for (const x of W.cs) if (!x.dead && (x.st.bloc || []).some(bl => bl === 'НАТО' || bl === 'ЕС') && W.home === c) x.rel = cl(x.rel + f.west * 0.02, -100, 100);
    // союзники вступают в войну
    for (const ci in G.pacts) { const p = G.pacts[ci]; if (p.t !== 'alliance') continue; const a = +ci; if (W.cs[a].dead) continue; for (const en of WD.enemies(s, c)) if (en !== a && !WD.atWar(s, a, en) && Math.random() < 0.35) { WD.declare(s, a, en, {}); WD.news(s, `${W.cs[a].n} вступила в войну на стороне союзника — ${C.n} — против ${W.cs[en].n}.`, [a, en, c], 1, 'war'); } }
    // кризисы
    GOV.crises(s, c);
    G.hist.push(Math.round(G.appr)); if (G.hist.length > 36) G.hist.shift();
  };
  // ---------- кризисы ----------
  GOV.CRISES = [
    { id: 'protest', n: 'Массовые протесты', when: (s, G, C) => G.appr < 32, d: 'На площадях десятки тысяч людей. Требуют отставки правительства.',
      o: [{ n: 'Пойти на уступки (соцвыплаты)', fx: (s, G, C) => { G.appr += 8; C.st.debt += 3; G.pc -= 20; } }, { n: 'Разогнать силой', fx: (s, G, C) => { C.st.stab -= 6; G.appr -= 6; G.pc += 10; for (const x of s.world.cs) if ((x.st.bloc || []).includes('ЕС')) x.rel -= 10; } }, { n: 'Отправить правительство в отставку', fx: (s, G) => { for (const k in G.min) if (!G.min[k] || !G.min[k].uid) G.min[k] = GOV.cand(s, k, E.ri(1, 99)); G.appr += 5; G.pc -= 30; } }] },
    { id: 'bank', n: 'Банковский кризис', when: (s, G, C) => C.st.debt > 90 || G.bal < -6, d: 'Крупные банки на грани краха, люди снимают вклады.',
      o: [{ n: 'Спасти банки за счёт бюджета', fx: (s, G, C) => { C.st.debt += 12; G.appr -= 3; } }, { n: 'Дать обанкротиться', fx: (s, G, C) => { C.shock -= 5; C.st.unemp += 2; G.appr -= 8; } }, { n: 'Напечатать деньги', fx: (s, G, C) => { C.inflBase += 8; C.st.infl += 8; } }] },
    { id: 'hyper', n: 'Инфляция выходит из-под контроля', when: (s, G, C) => C.st.infl > 25, d: 'Цены растут каждую неделю. Зарплат не хватает.',
      o: [{ n: 'Поднять ставку и урезать бюджет', fx: (s, G, C) => { C.st.infl -= 8; C.shock -= 2; G.appr -= 6; G.bud.social = Math.max(3, G.bud.social - 1); } }, { n: 'Заморозить цены', fx: (s, G, C) => { C.st.infl -= 4; C.st.gr -= 1; G.appr += 2; } }, { n: 'Ничего не делать', fx: () => { } }] },
    { id: 'scandal', n: 'Коррупционный скандал', when: (s, G) => Object.values(G.min).some(m => m && !m.uid && m.cor > 60), d: 'Журналисты нашли виллы и счета одного из министров.',
      o: [{ n: 'Уволить и посадить', fx: (s, G) => { const k = Object.keys(G.min).find(k => G.min[k] && !G.min[k].uid && G.min[k].cor > 60); if (k) G.min[k] = GOV.cand(s, k, E.ri(1, 99)); G.appr += 5; } }, { n: 'Замять', fx: (s, G) => { G.pc += 10; G.appr -= 7; } }] },
    { id: 'coup', n: 'Генералы недовольны', when: (s, G) => !GOV.FORMS[G.form].dem && G.appr < 22 || (G.min.def && !G.min.def.uid && G.min.def.loy < 35 && G.appr < 35), d: 'Разведка докладывает: в армии зреет заговор.',
      o: [{ n: 'Чистка в армии', fx: (s, G, C) => { G.min.def = GOV.cand(s, 'def', E.ri(1, 99)); G.min.def.loy = 90; C.st.stab -= 4; G.pc -= 20; } }, { n: 'Повысить военным зарплаты', fx: (s, G, C) => { G.bud.army += 0.8; G.pc += 5; } }, { n: 'Игнорировать (риск!)', fx: (s, G, C) => { G.coupRisk = (G.coupRisk || 0) + 1; } }] },
    { id: 'energy', n: 'Энергетический кризис', when: (s, G) => GOV.res(s, G.c).energy.bal < -10, d: 'Не хватает топлива: отключения света, очереди на заправках.',
      o: [{ n: 'Закупить за любые деньги', fx: (s, G, C) => { C.st.debt += 4; G.appr += 2; } }, { n: 'Ввести лимиты', fx: (s, G, C) => { C.st.gr -= 0.8; G.appr -= 4; } }] },
    { id: 'strike', n: 'Забастовка', when: (s, G) => G.bud.social < 5 || G.bud.tax > 30, d: 'Шахтёры и транспортники остановили работу.',
      o: [{ n: 'Поднять зарплаты бюджетникам', fx: (s, G) => { G.bud.social += 0.8; G.appr += 4; } }, { n: 'Объявить забастовку незаконной', fx: (s, G, C) => { C.st.stab -= 3; G.appr -= 5; G.pc += 5; } }] },
  ];
  GOV.crises = (s, c) => {
    const G = GOV.get(s, c), C = W_(s).cs[c]; G.c = c;
    // неразрешённые кризисы сами решаются худшим вариантом
    for (const k of (G.crisis || []).slice()) { if (s.date >= k.until) { const def = GOV.CRISES.find(x => x.id === k.id); if (def) def.o[def.o.length - 1].fx(s, G, C); G.appr -= 3; G.crisis.splice(G.crisis.indexOf(k), 1); G.log.unshift({ d: s.date, t: def ? def.n + ': правительство тянуло, вышло хуже' : '' }); } }
    if ((G.crisis || []).length >= 2 || Math.random() > 0.25) return;
    const cand = GOV.CRISES.filter(k => !G.crisis.some(x => x.id === k.id) && !((G.cool || {})[k.id] && s.date < G.cool[k.id]) && (() => { try { return k.when(s, G, C); } catch (e) { return false; } })());
    if (!cand.length) return;
    const k = E.pick(cand);
    G.crisis.push({ id: k.id, since: s.date, until: new Date(Date.parse(s.date) + 35 * 864e5).toISOString() });
    WD.news(s, `${C.n}: ${k.n.toLowerCase()}. ${k.d}`, [c], 1, 'crisis');
    if (G.coupRisk && Math.random() < 0.25 * G.coupRisk) { G.coupFall = 1; }
  };
  GOV.solve = (s, c, id, k) => {
    const G = GOV.get(s, c), C = W_(s).cs[c], i = G.crisis.findIndex(x => x.id === id); if (i < 0) return null;
    const def = GOV.CRISES.find(x => x.id === id), o = def.o[k]; if (!o) return null;
    o.fx(s, G, C); G.crisis.splice(i, 1); G.cool = G.cool || {}; G.cool[id] = new Date(Date.parse(s.date) + 120 * 864e5).toISOString();
    G.log.unshift({ d: s.date, t: def.n + ': ' + o.n.toLowerCase() }); G.log = G.log.slice(0, 40);
    G.appr = cl(G.appr, 0, 100); C.st.stab = cl(C.st.stab, 0, 100);
    return { ok: true, title: def.n + ': ' + o.n, lines: ['Популярность: ' + Math.round(G.appr) + '%', 'Стабильность: ' + Math.round(C.st.stab) + '%'] };
  };

  // ---------- операции (всё, что меняет мир) ----------
  // В мультиплеере клиент выполняет операцию у себя (чтобы сразу видеть результат) и отправляет хосту — хост применяет к общему миру.
  GOV.OPS = {
    init: (s, a) => GOV.init(s, a.c, { uid: a.uid, who: a.who }),
    law: (s, a) => { const G = GOV.get(s, a.c); if (!G || G.pc < GOV.LAWCOST) return; G.laws[a.cat] = a.v; G.pc -= GOV.LAWCOST; G.log.unshift({ d: s.date, t: 'Закон: ' + GOV.LAWS[a.cat].n + ' — ' + GOV.LAWS[a.cat].o[a.v].n }); const o = GOV.LAWS[a.cat].o[a.v]; G.appr = cl(G.appr + (o.fx.appr || 0) * 0.5, 0, 100); WD.news(s, `${W_(s).cs[a.c].n}: новый закон — ${GOV.LAWS[a.cat].n.toLowerCase()}: «${o.n}».`, [a.c], 0, 'law'); },
    bud: (s, a) => { const G = GOV.get(s, a.c); if (!G) return; Object.assign(G.bud, a.b); },
    form: (s, a) => { const G = GOV.get(s, a.c), C = W_(s).cs[a.c]; if (!G || G.pc < 120) return; const was = GOV.FORMS[G.form], F = GOV.FORMS[a.v]; G.pc -= 120; G.form = a.v; C.st.gov = F.n; C.st.stab -= 10; G.appr += F.dem && !was.dem ? 8 : !F.dem && was.dem ? -10 : 0; G.elect = F.dem ? new Date(Date.parse(s.date) + F.elect * 30.4 * 864e5).toISOString() : null; if (!F.dem && was.dem) for (const x of W_(s).cs) if ((x.st.bloc || []).some(b => b === 'НАТО' || b === 'ЕС')) x.rel -= 25; WD.news(s, `${C.n}: смена формы правления — теперь это ${F.n.toLowerCase()}.`, [a.c], 2, 'gov'); },
    min: (s, a) => { const G = GOV.get(s, a.c); if (!G || G.pc < 10) return; G.pc -= 10; G.min[a.slot] = a.m; G.log.unshift({ d: s.date, t: 'Назначен министр ' + GOV.MIN[a.slot].n.toLowerCase() + ': ' + a.m.n }); },
    crisis: (s, a) => GOV.solve(s, a.c, a.id, a.k),
    pact: (s, a) => { const G = GOV.get(s, a.c), W = W_(s); if (!G) return; if (a.v) G.pacts[a.ci] = { t: a.v, since: s.date }; else delete G.pacts[a.ci]; if (a.rel) W.cs[a.ci].rel = cl(W.cs[a.ci].rel + a.rel, -100, 100); if (a.news) WD.news(s, a.news, [a.c, a.ci], 1, 'dip'); },
    deal: (s, a) => { const G = GOV.get(s, a.c); if (!G) return; G.deals.push(a.d); if (a.news) WD.news(s, a.news, [a.c, a.d.ci], 0, 'dip'); },
    undeal: (s, a) => { const G = GOV.get(s, a.c); if (G) G.deals.splice(a.i, 1); },
    rel: (s, a) => { const W = W_(s); W.cs[a.ci].rel = cl(W.cs[a.ci].rel + a.d, -100, 100); if (a.shock) { W.cs[a.ci].shock -= a.shock; } if (a.news) WD.news(s, a.news, [a.c, a.ci], 1, 'dip'); },
    bloc: (s, a) => { const C = W_(s).cs[a.c]; C.st.bloc = C.st.bloc || []; if (a.join) { if (!C.st.bloc.includes(a.b)) C.st.bloc.push(a.b); } else C.st.bloc = C.st.bloc.filter(x => x !== a.b); for (const x of W_(s).cs) if (!x.dead && x !== C) { if ((x.st.bloc || []).includes(a.b)) x.rel = cl(x.rel + (a.join ? 20 : -20), -100, 100); } if (a.news) WD.news(s, a.news, [a.c], 2, 'bloc'); },
    land: (s, a) => { const W = W_(s); for (const p of a.provs) if (W.own[p] === a.from) { WD.moveStats(s, a.from, a.c, 1 / Math.max(2, E.countryProvs(s, a.from).length), 0.7); W.own[p] = a.c; if (W.core) W.core[p] = a.c; } if (a.news) WD.news(s, a.news, [a.c, a.from], 2, 'annex'); },
    loan: (s, a) => { const C = W_(s).cs[a.c]; C.st.debt += a.pct; const G = GOV.get(s, a.c); if (G) G.bud.extra = (G.bud.extra || 0); C.shock += 0.6; if (a.news) WD.news(s, a.news, [a.c, a.ci], 0, 'dip'); },
    war: (s, a) => { if (!WD.atWar(s, a.c, a.ci)) { WD.declare(s, a.c, a.ci, {}); WD.news(s, `${W_(s).cs[a.c].n} объявила войну: ${W_(s).cs[a.ci].n}.`, [a.c, a.ci], 2, 'war'); } },
    peace: (s, a) => { const w = s.world.wars.find(x => (x.a === a.c && x.b === a.ci) || (x.b === a.c && x.a === a.ci)); if (w) WD.endWar(s, w, `${W_(s).cs[a.c].n} и ${W_(s).cs[a.ci].n} заключили мир.`, 2); },
    policy: (s, a) => { const W = W_(s), h = W.home; W.home = a.c; try { WD.policy(s, a.text, a.ok, a.crit); } finally { W.home = h; } },
    stat: (s, a) => { const C = W_(s).cs[a.c]; for (const k in a.d) C.st[k] = (C.st[k] || 0) + a.d[k]; const G = GOV.get(s, a.c); if (G && a.g) for (const k in a.g) G[k] = (G[k] || 0) + a.g[k]; },
    cityBoost: (s, a) => { const W = W_(s); W.cityBoost = W.cityBoost || {}; W.cityBoost[a.city] = a.until; },
    taxBreak: (s, a) => { const W = W_(s); W.taxBreak = W.taxBreak || {}; W.taxBreak[a.c] = a.until; },
  };
  GOV.op = (name, a) => {
    const s = UI.s; let r;
    try { r = GOV.OPS[name](s, a); } catch (e) { console.warn('gov op', name, e); }
    if (typeof NET !== 'undefined' && NET.on() && NET.role === 'client' && NET.A.gov) NET.A.gov({ k: 'op', name, a });
    return r;
  };
  GOV.onNet = (d, pid) => {
    if (!d) return;
    if (d.k === 'op' && NET.role === 'host' && UI.s && GOV.OPS[d.name]) { try { GOV.OPS[d.name](UI.s, d.a); } catch (e) { console.warn('gov net op', e); } if (/war|peace|land|bloc|form/.test(d.name) && window.MAP && MAP.svg) { MAP.paint(UI.s); UI.legend(); } return; }
    if (d.k === 'fx' && (d.to === NET.uid || d.to === '*') && !(d.from && d.from.uid === NET.uid) && typeof DEC !== 'undefined') DEC.recv(d);
    if (d.k === 'army' && NET.role === 'host' && typeof ARMY !== 'undefined') ARMY.onNet(d);
  };

  // ---------- кто правит ----------
  GOV.my = s => E.isLeader(s) ? GOV.get(s, s.world.home) : null;
  GOV.ensure = s => { if (!E.isLeader(s)) return null; const G = GOV.get(s, s.world.home); if (G && (G.uid === (typeof NET !== 'undefined' ? NET.uid : 'solo'))) return G; GOV.op('init', { c: s.world.home, uid: typeof NET !== 'undefined' ? NET.uid : 'solo', who: s.ch.name + ' ' + s.ch.surname }); return GOV.get(s, s.world.home); };

  // ---------- личный месяц правителя: зарплата, выборы, свержение ----------
  GOV.personal = (s, r) => {
    if (!E.isLeader(s)) return;
    const G = GOV.ensure(s); if (!G) return;
    const F = GOV.FORMS[G.form];
    if (F.dem && G.elect && s.date >= G.elect) {
      const ch = cl(Math.round(G.appr * 1.15 - 8 + (G.parties[0] ? G.parties[0].pop * 0.3 : 0) + (G.laws.press === 'state' ? 6 : G.laws.press === 'censor' ? 12 : 0)), 3, 97);
      const win = Math.random() * 100 < ch;
      G.elect = new Date(Date.parse(s.date) + F.elect * 30.4 * 864e5).toISOString();
      if (win) { (r.notes = r.notes || []).push(`Выборы: вы переизбраны! (шанс был ~${ch}%)`); E.fact(s, `${E.monthStr(s.date)}: переизбран(а) главой государства.`); s.st.rep = Math.min(100, s.st.rep + 5); }
      else { (r.notes = r.notes || []).push(`Выборы проиграны (шанс был ~${ch}%). Власть переходит к оппозиции.`); E.fact(s, `${E.monthStr(s.date)}: проиграл(а) выборы и ушёл(ла) из власти.`); s.pol = null; G.uid = null; WD.news(s, `${s.world.cs[s.world.home].n}: на выборах победила оппозиция. ${s.ch.name} ${s.ch.surname} покидает пост.`, [s.world.home], 2, 'elect'); return; }
    }
    if (G.coupFall || (!F.dem && G.appr < 12 && Math.random() < 0.08)) {
      G.coupFall = 0; s.pol = null; G.uid = null;
      (r.notes = r.notes || []).push('Военный переворот! Вас отстранили от власти.');
      E.fact(s, `${E.monthStr(s.date)}: свергнут(а) в результате переворота.`);
      WD.news(s, `${s.world.cs[s.world.home].n}: военный переворот, ${s.ch.name} ${s.ch.surname} отстранён(а).`, [s.world.home], 2, 'coup');
      s.st.rep = Math.max(0, s.st.rep - 20);
    }
  };

  // ---------- переговоры: шанс согласия ----------
  GOV.PROPS = {
    trade: { n: 'Торговое соглашение', base: 35, d: 'Обе экономики растут, отношения теплеют' },
    nap: { n: 'Пакт о ненападении', base: 30, d: 'Обещание не воевать друг с другом' },
    alliance: { n: 'Военный союз', base: 0, d: 'Союзник вступит в ваши войны' },
    loan: { n: 'Попросить кредит', base: 15, d: 'Деньги в бюджет, долг растёт' },
    sell: { n: 'Продать ресурсы', base: 30, d: 'Экспорт излишков: доход в бюджет' },
    buy: { n: 'Закупить ресурсы', base: 40, d: 'Закрыть дефицит энергии, металлов или еды' },
    land: { n: 'Потребовать территорию', base: -60, d: 'Отдать пограничную провинцию — или война' },
    peace: { n: 'Мир', base: 10, d: 'Закончить войну' },
    sanction: { n: 'Ввести санкции', base: 999, d: 'Удар по их экономике, отношения рухнут' },
    joinbloc: { n: 'Вступить в их блок', base: 5, d: 'Блок защищает своих' },
    insult: { n: 'Резкое заявление', base: 999, d: 'Поднять рейтинг дома за счёт отношений' },
  };
  GOV.chance = (s, ci, kind) => {
    const W = W_(s), c = W.home, C = W.cs[ci], G = GOV.get(s, c) || { min: {} }, P = GOV.PROPS[kind]; if (!P || !C) return 0;
    if (P.base >= 999) return 100;
    const pw = E.power(s, c) / Math.max(1, E.power(s, ci));
    const sameBloc = (W.cs[c].st.bloc || []).some(b => (C.st.bloc || []).includes(b));
    const rivalBloc = ((W.cs[c].st.bloc || []).includes('ОДКБ') && (C.st.bloc || []).some(b => b === 'НАТО' || b === 'ЕС')) || ((C.st.bloc || []).includes('ОДКБ') && (W.cs[c].st.bloc || []).some(b => b === 'НАТО' || b === 'ЕС'));
    let p = P.base + C.rel * 0.45 + (sameBloc ? 15 : 0) - (rivalBloc ? 25 : 0) + GOV.minK(G, 'fore') * 12 + (E.sk(s, 'cha') - 40) * 0.2;
    if (kind === 'land') p += Math.min(35, (pw - 1) * 10) + (WD.atWar(s, c, ci) ? 25 : 0) - (C.rel > 40 ? 10 : 0);
    if (kind === 'alliance') p += (C.rel > 50 ? 20 : -20) + (pw > 1.5 ? 10 : 0);
    if (kind === 'peace') { const w = W.wars.find(x => (x.a === c && x.b === ci) || (x.b === c && x.a === ci)); if (w) { const sc = w.a === c ? w.score : -w.score; p += sc * 3 + (C.wear || 0) * 0.4; } }
    if (kind === 'loan') p += (C.st.gdp > W.cs[c].st.gdp ? 10 : -10) - Math.max(0, W.cs[c].st.debt - 60) * 0.5;
    if (kind === 'sell' || kind === 'buy') { const res = GOV.res(s, ci); p += kind === 'sell' ? (Object.values(res).some(r => r.bal < 0) ? 20 : -10) : (Object.values(res).some(r => r.bal > 0) ? 15 : -15); }
    if (kind === 'joinbloc') p += sameBloc ? 100 : (C.st.bloc || []).length ? (rivalBloc ? -30 : 10) : -100;
    if (WD.atWar(s, c, ci) && kind !== 'peace' && kind !== 'land') p -= 60;
    return Math.round(cl(p, 1, 95));
  };
  GOV.apply = (s, ci, kind, ok, extra) => {
    const W = W_(s), c = W.home, C = W.cs[ci], H = W.cs[c], G = GOV.ensure(s), lines = [];
    if (!ok) { GOV.op('rel', { c, ci, d: kind === 'land' ? -15 : -3 }); return { ok: false, title: C.n + ' отказывает: ' + GOV.PROPS[kind].n.toLowerCase(), lines: ['Отношения: ' + UI.rel(C.rel)] }; }
    const until = m => new Date(Date.parse(s.date) + m * 30.4 * 864e5).toISOString();
    if (kind === 'trade') { GOV.op('pact', { c, ci, v: 'trade', rel: 10, news: `${H.n} и ${C.n} подписали торговое соглашение.` }); GOV.op('stat', { c, d: { gr: 0.25 } }); lines.push('Рост экономики +0,25%/год, отношения +10'); }
    if (kind === 'nap') { GOV.op('pact', { c, ci, v: 'nap', rel: 8, news: `${H.n} и ${C.n} подписали пакт о ненападении.` }); lines.push('Они не нападут на вас'); }
    if (kind === 'alliance') { GOV.op('pact', { c, ci, v: 'alliance', rel: 20, news: `${H.n} и ${C.n} заключили военный союз.` }); lines.push('Союзник может вступить в ваши войны'); }
    if (kind === 'loan') { const pct = Math.round(Math.min(8, C.st.gdp / H.st.gdp * 5) * 10) / 10 || 1; GOV.op('loan', { c, ci, pct, news: `${C.n} выдала кредит: ${H.n}.` }); GOV.op('stat', { c, d: {}, g: { pc: 5 } }); lines.push('Кредит: +' + pct + '% ВВП в бюджет (госдолг вырос)'); }
    if (kind === 'sell' || kind === 'buy') { const res = GOV.res(s, c), key = extra && extra.res || Object.keys(res).sort((a, b) => kind === 'sell' ? res[b].bal - res[a].bal : res[a].bal - res[b].bal)[0]; const amt = Math.max(5, Math.round(Math.abs(res[key].bal) * 0.6)); GOV.op('deal', { c, d: { ci, cn: C.n, res: key, dir: kind === 'sell' ? 'out' : 'in', amt, until: until(24) }, news: `${H.n} и ${C.n}: соглашение о поставках (${GOV.RES[key].n.toLowerCase()}).` }); GOV.op('rel', { c, ci, d: 4 }); lines.push((kind === 'sell' ? 'Экспорт: ' : 'Импорт: ') + GOV.RES[key].n.toLowerCase() + ' ' + amt + ' ед. на 2 года'); }
    if (kind === 'land') { const prov = M().provinces.map((p, i) => i).filter(i => W.own[i] === ci && M().provinces[i].nb.some(n => W.own[n] === c) && C.cap !== i).slice(0, 1 + (extra && extra.big ? 2 : 0)); if (!prov.length) return { ok: false, title: 'Нечего требовать', lines: ['Нет общей границы.'] }; GOV.op('land', { c, from: ci, provs: prov, news: `${C.n} уступила ${H.n} ${prov.length > 1 ? 'несколько провинций' : 'провинцию ' + M().provinces[prov[0]].n} без войны.` }); GOV.op('rel', { c, ci, d: -30 }); lines.push('Получено: ' + prov.map(i => M().provinces[i].n).join(', ')); if (window.MAP && MAP.svg) MAP.paint(s); }
    if (kind === 'peace') { GOV.op('peace', { c, ci }); GOV.op('rel', { c, ci, d: 20 }); lines.push('Война окончена. Занятые провинции остаются за теми, кто их держит.'); }
    if (kind === 'sanction') { GOV.op('rel', { c, ci, d: -35, shock: 1.5, news: `${H.n} ввела санкции против ${C.n}.` }); lines.push('Их экономика получила удар, отношения рухнули'); }
    if (kind === 'joinbloc') { const b = (C.st.bloc || [])[0]; if (b) { GOV.op('bloc', { c, b, join: true, news: `${H.n} вступила в ${b}.` }); lines.push('Вы теперь в блоке ' + b); } }
    if (kind === 'insult') { GOV.op('rel', { c, ci, d: -20 }); GOV.op('stat', { c, d: {}, g: { appr: 3 } }); lines.push('Дома аплодируют: популярность +3. Отношения −20'); }
    return { ok: true, title: GOV.PROPS[kind].n + ': ' + C.n, lines };
  };
  // ---------- нейросеть-лидер другой страны ----------
  GOV.leader = (s, ci) => { const C = W_(s).cs[ci]; return C.st.lead || (C.n === 'США' ? 'президент США' : 'лидер страны «' + C.n + '»'); };
  GOV.talk = async (s, ci, text, kind) => {
    const W = W_(s), c = W.home, C = W.cs[ci], H = W.cs[c], G = GOV.ensure(s);
    if (!C || !G) return { reply: '', ok: null, res: null, p: 0 };
    G.dip[ci] = G.dip[ci] || [];
    const log = G.dip[ci]; log.push({ me: 1, t: text + (kind ? ' [Предложение: ' + GOV.PROPS[kind].n + ']' : ''), d: s.date });
    const p = kind ? GOV.chance(s, ci, kind) : null;
    const pw = (E.power(s, ci) / Math.max(1, E.power(s, c))).toFixed(2);
    let reply = '', dec = 'none';
    if (typeof AI !== 'undefined' && AI.state === 'ok') {
      const sys = `Ты — ${GOV.leader(s, ci)}, глава государства «${C.n}» (${C.st.gov || 'государство'}${(C.st.bloc || []).length ? ', блоки: ' + C.st.bloc.join(', ') : ''}). Ты ведёшь переговоры с главой страны «${H.n}» — это игрок. Говори как настоящий политик своей страны: коротко (1–3 предложения), по-русски, с характером, без смайликов. Учитывай интересы своей страны. Факты: ваши отношения — ${UI.rel(C.rel)} (${Math.round(C.rel)} из 100); твоя армия относительно их: ×${pw}; ${WD.atWar(s, c, ci) ? 'вы ВОЮЕТЕ друг с другом' : 'войны между вами нет'}; ваш ВВП ${UI.gdp(s, C.st.gdp)}, их ${UI.gdp(s, H.st.gdp)}.`;
      const hist = log.slice(-8, -1).map(m => ({ role: m.me ? 'user' : 'assistant', content: m.t }));
      const ask = text + (kind ? `\n\n[Игрок предлагает: ${GOV.PROPS[kind].n} — ${GOV.PROPS[kind].d}. По расчётам советников, твоя страна склонна согласиться с вероятностью ~${p}%. Реши: accept — согласиться, reject — отказать, think — взять паузу. Решение должно быть разумным для твоей страны.]` : '\n\n[Конкретного предложения нет — просто ответь. decision: none]');
      const schema = { type: 'object', properties: { reply: { type: 'string' }, decision: { type: 'string', enum: ['accept', 'reject', 'think', 'none'] } }, required: ['reply', 'decision'] };
      try {
        const raw = await AI.chat([{ role: 'system', content: sys }].concat(hist, [{ role: 'user', content: ask }]), { body: { temperature: 0.8, max_tokens: 220, id_slot: 1, response_format: { type: 'json_schema', json_schema: { name: 'diplo', schema } } } });
        const j = JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1)); reply = AI.clean ? AI.clean(j.reply || '') : j.reply || ''; dec = j.decision || 'none';
      } catch (e) { console.warn('diplo', e); }
    }
    if (!reply) { const ok = kind ? Math.random() * 100 < p : null; dec = kind ? (ok ? 'accept' : 'reject') : 'none'; reply = GOV.canned(s, ci, kind, dec); }
    // итог решает и нейросеть, и расчёт: совсем невыгодное она не подпишет, даже если «согласилась»
    let ok = null;
    if (kind && dec !== 'none') { const q = dec === 'accept' ? Math.min(95, p * 1.35 + 10) : dec === 'think' ? p * 0.5 : p * 0.25; ok = Math.random() * 100 < q; if (dec === 'accept' && !ok) reply += ' …Впрочем, мои советники против. Не сейчас.'; if (dec !== 'accept' && ok) reply += ' Хотя… ладно. Договорились.'; }
    log.push({ me: 0, t: reply, d: s.date }); if (log.length > 30) log.splice(0, log.length - 30);
    const res = kind && ok !== null ? GOV.apply(s, ci, kind, ok) : null;
    return { reply, ok, res, p };
  };
  GOV.canned = (s, ci, kind, dec) => {
    const C = W_(s).cs[ci];
    if (!kind) return C.rel > 30 ? 'Рады слышать вас. Наши народы — друзья, двери открыты.' : C.rel > -20 ? 'Мы слушаем. Говорите по делу.' : 'Нам не о чем говорить, пока ваша страна ведёт себя так.';
    if (dec === 'accept') return E.pick(['Это разумно. Мы согласны.', 'Хорошо. Пусть министры готовят документы.', 'Принимаем. Надеюсь, вы сдержите слово.']);
    return E.pick(['Нет. Это не в интересах нашего народа.', 'Мы не готовы к этому. Возможно, позже.', 'Вы просите слишком многого.']);
  };
  GOV.cost = (s, pct) => pct; // доли ВВП
  GOV.fmtPct = v => (Math.round(v * 10) / 10).toString().replace('.', ',') + '%';

  // ---------- подключение к миру ----------
  const _month = WD.month;
  WD.month = s => { _month(s); const W = W_(s); if (W.gov) for (const c in W.gov) { const G = W.gov[c]; if (G && G.uid) { try { GOV.month(s, +c); } catch (e) { console.warn('gov month', e); } } } };
  const _me = E.monthEnd;
  E.monthEnd = s => { const r = _me(s); try { GOV.personal(s, r); } catch (e) { console.warn('gov personal', e); } return r; };
  // старые кнопки и чат: война/мир/указы работают у клиента через хоста
  for (const k of ['war', 'peace', 'policy']) {
    const f = E.A[k];
    E.A[k] = (s, it) => {
      const cli = s.mp && s.mp.role === 'client';
      if (!cli) { const before = s.world.wars.slice(), r = f(s, it); return r; }
      // клиент: считаем у себя, а мир меняет хост
      const W = s.world, snapWars = W.wars.slice();
      const r = f(s, it);
      if (k === 'war') { const nw = W.wars.find(w => !snapWars.includes(w)); if (nw) GOV.op('war', { c: nw.a, ci: nw.b }); }
      if (k === 'peace') { const gone = snapWars.find(w => !W.wars.includes(w)); if (gone) GOV.op('peace', { c: gone.a, ci: gone.b }); }
      if (k === 'policy' && r && r.title) GOV.op('policy', { c: W.home, text: [it.target, it.raw].join(' '), ok: r.ok, crit: r.roll && r.roll.crit });
      return r;
    };
  }
  // снимаем запрет «это решает хост» для этих действий
  const _act = E.act;
  E.act = (s, it) => { if (s.mp && s.mp.role === 'client' && ['war', 'peace', 'policy', 'army'].includes(it.type)) { const mp = s.mp; s.mp = Object.assign({}, mp, { role: 'host' }); try { const r = _act(s, it); return r; } finally { s.mp = mp; } } return _act(s, it); };
  // законы через чат: «ввожу всеобщую воинскую обязанность», «отменяю цензуру»
  const _pol = E.A.policy;
  E.A.policy = (s, it) => {
    const t = E.norm([it.target, it.raw].join(' '));
    if (E.isLeader(s)) {
      const G = GOV.ensure(s);
      for (const cat in GOV.LAWS) for (const v in GOV.LAWS[cat].o) { const o = GOV.LAWS[cat].o[v], w = E.norm(o.n).split(' ').filter(x => x.length > 4); if (w.length && w.every(x => t.includes(x.slice(0, 5)))) { if (G.laws[cat] === v) return { ok: false, impossible: true, title: 'Этот закон уже действует', lines: [o.n], apCost: 0 }; if (G.pc < GOV.LAWCOST) return { ok: false, impossible: true, title: 'Мало политического капитала', lines: ['Нужно ' + GOV.LAWCOST + ', есть ' + Math.round(G.pc) + '. Он копится каждый месяц.'], apCost: 0 }; GOV.op('law', { c: s.world.home, cat, v }); return { ok: true, title: 'Закон принят: ' + o.n, lines: [GOV.LAWS[cat].n + ': ' + o.d, 'Политический капитал: ' + Math.round(G.pc)] }; } }
    }
    return _pol(s, it);
  };
  const _pl = E.parseLocal;
  E.parseLocal = text => { const it = _pl(text); if (E.cur && E.isLeader(E.cur) && it.type !== 'policy') { const t = E.norm(text); for (const cat in GOV.LAWS) for (const v in GOV.LAWS[cat].o) { const w = E.norm(GOV.LAWS[cat].o[v].n).split(' ').filter(x => x.length > 4); if (w.length && w.every(x => t.includes(x.slice(0, 5)))) return Object.assign(it, { type: 'policy', target: text }); } } return it; };
  // кто-то пришёл к власти (выборы, переворот, отделение) — заводим правительство
  const _take = E.takeOffice;
  E.takeOffice = (s, p) => { _take(s, p); if (p && p.id === 'president') setTimeout(() => { try { GOV.ensure(s); } catch (e) { } }, 0); };
  // контекст для рассказчика
  document.addEventListener('DOMContentLoaded', () => {
    if (typeof AI === 'undefined') return;
    const _br = AI.brief;
    AI.brief = s => { const b = _br(s), G = GOV.my(s); if (!G) return b; return b + `; глава государства: ${GOV.FORMS[G.form].n.toLowerCase()}, популярность ${Math.round(G.appr)}%, инфляция ${GOV.fmtPct(s.world.cs[s.world.home].st.infl)}, бюджет ${G.bal >= 0 ? 'профицит' : 'дефицит'} ${GOV.fmtPct(Math.abs(G.bal || 0))} ВВП${G.crisis.length ? ', кризисы: ' + G.crisis.map(k => (GOV.CRISES.find(x => x.id === k.id) || {}).n).join(', ') : ''}`; };
  });
})();
