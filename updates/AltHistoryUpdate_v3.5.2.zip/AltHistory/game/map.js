// «Судьба» — светлая карта мира в духе хойки: провинции, границы по владельцам, столицы, города, достопримечательности.
'use strict';
const MAP = { z: 1, vb: null, svg: null, sel: -1, flash: {} };
window.MAP = MAP; // другие модули проверяют window.MAP
const NS = 'http://www.w3.org/2000/svg';

const ICONS = {
  castle: 'M1 9V3.5h1.6v1.4h1.2V3.5h2.4v1.4h1.2V3.5H9V9H6V7a1 1 0 0 0-2 0v2z',
  palace: 'M1 9V6.3h8V9zM2.2 6.3a2.8 2.8 0 0 1 5.6 0zM4.7 1.2h.6v2.4h-.6z',
  lake: 'M1 4.3q1-1 2 0t2 0 2 0 2 0v1.2q-1-1-2 0t-2 0-2 0-2 0zM1 6.8q1-1 2 0t2 0 2 0 2 0V8q-1-1-2 0t-2 0-2 0-2 0z',
  mount: 'M.5 9 4 2.6l1.6 2.8 1-1.6L9.5 9z',
  statue: 'M4.2 9V5.2h1.6V9zM5 1.4a1.2 1.2 0 1 1 0 2.4 1.2 1.2 0 0 1 0-2.4zM2.8 9V8h4.4v1zM5.6 4.4 7.6 2l.5.4-1.8 2.6z',
  church: 'M4.6.8h.8v1.2h1v.8h-1V4L8 6v3H2V6l2.6-2V2.8h-1V2h1z',
  tower: 'M4 9 4.6 2h.8L6 9zM3 9h4v-.8H3zM4.3 5h1.4v.6H4.3z',
  ruin: 'M1 9V8h8v1zM2 8V3h1.2v5zM4.4 8V4.5h1.2V8zM6.8 8V2.5H8V8zM1.5 3h2.2v-.8H1.5z',
  gate: 'M1 9V2.5h8V9H6.6V6a1.6 1.6 0 0 0-3.2 0v3z',
  star: 'M5 .8l1.2 2.7 2.9.3-2.2 2 .7 2.9L5 7.2 2.4 8.7l.7-2.9-2.2-2 2.9-.3z',
  pyramid: 'M5 1.5 9.5 9h-9z',
  wall: 'M.5 9V5h1V4h1v1h1V4h1v1h1V4h1v1h1V4h1v1h1v4z',
};

MAP.el = (tag, attrs, parent) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); if (parent) parent.appendChild(e); return e; };

MAP.seaBitmap = m => {
  if (MAP._seaUrl) { MAP.seaImg.setAttribute('href', MAP._seaUrl); return; }
  try {
    const K = 1, c = document.createElement('canvas'); c.width = m.W * K; c.height = m.H * K;
    const x = c.getContext('2d'); x.scale(K, K);
    const g = x.createLinearGradient(0, 0, 0, m.H); g.addColorStop(0, '#a9c8d8'); g.addColorStop(.45, '#bcd7e4'); g.addColorStop(1, '#aecbda');
    x.fillStyle = g; x.fillRect(0, 0, m.W, m.H);
    const coast = new Path2D(m.coast); x.lineJoin = 'round'; x.lineCap = 'round';
    for (const [w, col, o] of [[34, '#c9e0ea', .55], [18, '#d6e9f0', .7], [8, '#e4f1f5', .85]]) { x.globalAlpha = o; x.strokeStyle = col; x.lineWidth = w; x.stroke(coast); }
    c.toBlob(b => { MAP._seaUrl = URL.createObjectURL(b); if (MAP.seaImg) MAP.seaImg.setAttribute('href', MAP._seaUrl); }, 'image/png');
  } catch (e) { console.warn('sea', e); }
};
MAP.init = (host, s) => {
  const m = M();
  host.innerHTML = '';
  const svg = MAP.el('svg', { class: 'map', xmlns: NS });
  MAP.svg = svg; MAP.host = host;
  const defs = MAP.el('defs', {}, svg);
  defs.innerHTML = `
    <pattern id="waves" width="36" height="18" patternUnits="userSpaceOnUse"><path d="M0 9q4.5-4 9 0t9 0 9 0 9 0" fill="none" stroke="#b9d3de" stroke-width=".7"/></pattern>
    <pattern id="hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="6" height="6" fill="rgba(200,60,50,.10)"/><line x1="0" y1="0" x2="0" y2="6" stroke="rgba(190,40,30,.45)" stroke-width="2.2"/></pattern>
    <filter id="soft" x="-5%" y="-5%" width="110%" height="110%"><feGaussianBlur stdDeviation="2.5"/></filter>
    <linearGradient id="seaG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a9c8d8"/><stop offset=".45" stop-color="#bcd7e4"/><stop offset="1" stop-color="#aecbda"/></linearGradient>
    <radialGradient id="vign" cx="50%" cy="50%" r="75%"><stop offset="60%" stop-color="#cfe3ec" stop-opacity="0"/><stop offset="100%" stop-color="#a9c6d3" stop-opacity=".55"/></radialGradient>
    ${Object.keys(ICONS).map(k => `<symbol id="ic-${k}" viewBox="0 0 10 10"><path d="${ICONS[k]}"/></symbol>`).join('')}`;
  MAP.el('rect', { x: -2000, y: -1000, width: m.W + 4000, height: m.H + 2000, fill: '#b9d4e1' }, svg);
  // море и мелководье у берегов рисуем ОДИН раз в картинку: векторные широкие обводки берега очень дорогие
  MAP.seaImg = MAP.el('image', { x: 0, y: 0, width: m.W, height: m.H, preserveAspectRatio: 'none', 'pointer-events': 'none' }, svg);
  MAP.seaBitmap(m);
  MAP.el('rect', { x: -2000, y: -1000, width: m.W + 4000, height: m.H + 2000, fill: 'url(#waves)', opacity: .5 }, svg);
  // сетка меридианов
  const grid = MAP.el('g', { class: 'grid' }, svg);
  for (let x = 0; x <= m.W; x += m.W / 24) MAP.el('line', { x1: x, y1: 0, x2: x, y2: m.H }, grid);
  for (let y = 0; y <= m.H; y += m.H / 10) MAP.el('line', { x1: 0, y1: y, x2: m.W, y2: y }, grid);

  MAP.gProv = MAP.el('g', { class: 'provs' }, svg);
  MAP.paths = m.provinces.map((p, i) => { const e = MAP.el('path', { d: p.d, 'data-i': i }, MAP.gProv); return e; });
  MAP.pHover = MAP.el('path', { class: 'hoverprov' }, svg);
  MAP.gWar = MAP.el('g', { class: 'warzone' }, svg);
  MAP.pEdgeIn = MAP.el('path', { class: 'edge-in' }, svg);
  MAP.pEdgeOut = MAP.el('path', { class: 'edge-out' }, svg);
  MAP.pFront2 = MAP.el('path', { class: 'front2' }, svg);
  MAP.pFront = MAP.el('path', { class: 'front' }, svg);
  MAP.el('path', { d: m.coast, class: 'coast' }, svg);
  MAP.pSel = MAP.el('path', { class: 'selprov' }, svg);
  MAP.gCountry = MAP.el('g', { class: 'clabels' }, svg);
  MAP.gLand = MAP.el('g', { class: 'lands' }, svg);
  MAP.gCity = MAP.el('g', { class: 'cities' }, svg);
  MAP.gHome = MAP.el('g', { class: 'home' }, svg);
  MAP.el('rect', { x: -2000, y: -1000, width: m.W + 4000, height: m.H + 2000, fill: 'url(#vign)', 'pointer-events': 'none', class: 'vign' }, svg);

  // достопримечательности
  const old = E.ww2(s);
  const NEW_LM = new Set(['Бурдж-Халифа', 'Сиднейская опера', 'Мамаев курган']);
  for (const l of m.landmarks) {
    if (old && NEW_LM.has(l.n)) continue;
    const g0 = MAP.el('g', { class: 'lm', transform: `translate(${l.x},${l.y})` }, MAP.gLand);
    const g = MAP.el('g', { class: 'sc' }, g0);
    MAP.el('circle', { r: 7, class: 'lmbg' }, g);
    MAP.el('use', { href: '#ic-' + (ICONS[l.t] ? l.t : 'star'), x: -4.5, y: -4.6, width: 9, height: 9, class: 'lmic' }, g);
    const t = MAP.el('text', { class: 'lmt', y: 17 }, g); t.textContent = l.n;
    g0.addEventListener('mouseenter', () => MAP.tipShow(l.n, 'Достопримечательность'));
    g0.addEventListener('mouseleave', MAP.tipHide);
  }
  // города
  MAP.cityEls = m.cities.filter(c => !(old && c.h2)).map(c => {
    const cap = old ? c.cap2 : c.cap, n = old && c.n2 || c.n;
    const g0 = MAP.el('g', { class: 'city' + (cap ? ' cap' : '') + (c.p >= 2e6 ? ' big' : ''), transform: `translate(${c.x},${c.y})` }, MAP.gCity);
    const g = MAP.el('g', { class: 'sc' }, g0);
    if (cap) MAP.el('use', { href: '#ic-star', x: -5, y: -5, width: 10, height: 10, class: 'capic' }, g); else MAP.el('circle', { r: 2.6, class: 'dot' }, g);
    const t = MAP.el('text', { class: 'ct', x: cap ? 7 : 5, y: 4 }, g); t.textContent = n;
    return g;
  });
  MAP.mover = document.createElement('div'); MAP.mover.className = 'mapmove'; MAP.mover.appendChild(svg); host.appendChild(MAP.mover);
  MAP.tip = document.createElement('div'); MAP.tip.className = 'maptip'; host.appendChild(MAP.tip);

  MAP.bind(s);
  MAP.paint(s);
  MAP.focusOn(E.city(s).x, E.city(s).y, 760);
};

// ---------- окраска и границы ----------
MAP.paint = (s, changed) => {
  const m = M(), own = s.world.own, cs = s.world.cs, home = s.world.home;
  MAP.paths.forEach((e, i) => { const c = cs[own[i]]; e.style.fill = c.col; e.classList.toggle('mine', own[i] === home); });
  let din = '', dout = '', dfront = '', dfront2 = '';
  const enemies = new Set(WD.enemies(s, home));
  const pair = new Set(s.world.wars.map(w => w.a + ':' + w.b).concat(s.world.wars.map(w => w.b + ':' + w.a)));
  for (const e of m.edges) {
    const a = own[e.a], b = own[e.b];
    if (a === b) din += e.d;
    else { dout += e.d; if ((a === home && enemies.has(b)) || (b === home && enemies.has(a))) dfront += e.d; else if (pair.has(a + ':' + b)) dfront2 += e.d; }
  }
  MAP.pEdgeIn.setAttribute('d', din); MAP.pEdgeOut.setAttribute('d', dout); MAP.pFront.setAttribute('d', dfront); MAP.pFront2.setAttribute('d', dfront2);
  // зона войны — штриховка вражеских провинций
  MAP.gWar.innerHTML = '';
  if (enemies.size) { let d = ''; own.forEach((o, i) => { if (enemies.has(o)) d += m.provinces[i].d; }); MAP.el('path', { d, fill: 'url(#hatch)' }, MAP.gWar); }
  if (changed) for (const i of changed) { const e = MAP.paths[i]; e.classList.remove('flash'); void e.getBBox(); e.classList.add('flash'); }
  MAP.labels(s);
  MAP.home(s);
};

// подписи стран: по самому большому связному куску территории
// ширина подписи в «буквах-em» (жирный Georgia) — чтобы буквы никогда не налезали друг на друга
MAP.emW = txt => { const c = MAP._mc || (MAP._mc = document.createElement('canvas').getContext('2d')); c.font = 'bold 100px Georgia, "Times New Roman", serif'; return c.measureText(txt).width / 100; };
MAP.labels = s => {
  const m = M(), own = s.world.own;
  MAP.gCountry.innerHTML = '';
  const seen = new Uint8Array(own.length);
  const best = {};
  for (let i = 0; i < own.length; i++) {
    if (seen[i]) continue;
    const o = own[i], comp = [], st = [i]; seen[i] = 1;
    while (st.length) { const k = st.pop(); comp.push(k); for (const n of m.provinces[k].nb) if (!seen[n] && own[n] === o) { seen[n] = 1; st.push(n); } }
    const area = comp.reduce((a, k) => a + m.provinces[k].a, 0);
    (best[o] = best[o] || []).push({ area, comp, cap: comp.includes(s.world.cs[o] && s.world.cs[o].cap) });
  }
  // подписываем метрополию (кусок со столицей) и другие крупные куски (колонии, анклавы) — до 3 на страну
  const jobs = [];
  for (const o in best) {
    const list = best[o].sort((a, b) => b.area - a.area), top = list[0].area;
    list.filter((c, i) => (c.cap && c.area >= 60) || (c.area >= 120 && (i === 0 || c.area >= top * 0.3))).slice(0, 3).forEach(c => jobs.push([o, c]));
  }
  let uid = 0;
  for (const [o, { area, comp }] of jobs) {
    const name = s.world.cs[o].n;
    const txt = name.length > 22 && area < 2500 ? (s.world.cs[o].iso || name.slice(0, 10)) : name.toUpperCase();
    const L = MAP.labelPath(comp, txt.length);
    if (!L) continue;
    const id = 'clp' + (uid++);
    MAP.el('path', { id, d: L.d, fill: 'none', stroke: 'none' }, MAP.gCountry);
    const t = MAP.el('text', { 'data-fs': L.fs.toFixed(1), 'data-len': L.len.toFixed(1), 'data-n': txt.length, class: 'cl' + (L.fs < 9 ? ' clsm' : '') + (+o === s.world.home ? ' homec' : '') }, MAP.gCountry);
    const tp = MAP.el('textPath', { href: '#' + id, startOffset: '50%', textLength: L.len.toFixed(1), lengthAdjust: 'spacing' }, t);
    t._em = MAP.emW(txt);
    t._P = L.P; t._plen = L.plen; t._pri = area * (+o === s.world.home ? 4 : 1);
    tp.textContent = txt;
  }
  MAP.sizeLabels();
};
// Подпись как в HOI4: вдоль главной оси страны, по изогнутой «хребтовой» линии, растянута на всю длину,
// а высота букв — по толщине страны. Так подписи не налезают друг на друга.
MAP.labelPath = (comp, n) => {
  const m = M(); let W = 0, sx = 0, sy = 0;
  for (const k of comp) { const p = m.provinces[k]; W += p.a; sx += p.x * p.a; sy += p.y * p.a; }
  const cx = sx / W, cy = sy / W;
  let xx = 0, yy = 0, xy = 0;
  for (const k of comp) { const p = m.provinces[k], dx = p.x - cx, dy = p.y - cy; xx += p.a * dx * dx; yy += p.a * dy * dy; xy += p.a * dx * dy; }
  let ang = 0.5 * Math.atan2(2 * xy, xx - yy);
  const elong = Math.sqrt(Math.max(xx, yy) / Math.max(1e-6, Math.min(xx, yy)));
  if (elong < 1.25) ang *= Math.max(0, (elong - 1) / 0.25); // круглые страны — почти горизонтально
  ang = E.clamp(ang, -0.5, 0.5); // не круче ~30°, чтобы читалось
  const ux = Math.cos(ang), uy = Math.sin(ang), nx = -uy, ny = ux;
  const pts = comp.map(k => { const p = m.provinces[k], dx = p.x - cx, dy = p.y - cy; return { u: dx * ux + dy * uy, v: dx * nx + dy * ny, a: p.a, r: Math.sqrt(p.a) * 0.55 }; });
  pts.sort((a, b) => a.u - b.u);
  const q = f => { let acc = 0; for (const p of pts) { acc += p.a; if (acc >= W * f) return p.u; } return pts[pts.length - 1].u; };
  const avgR = Math.sqrt(W / pts.length) * 0.5;
  let u0 = q(0.03) - avgR * 0.6, u1 = q(0.97) + avgR * 0.6;
  if (pts.length < 3) { u0 = pts[0].u - avgR * 1.4; u1 = pts[pts.length - 1].u + avgR * 1.4; }
  const span = Math.max(u1 - u0, avgR * 2);
  // «хребет»: медиана v в полосах вдоль оси → парабола
  const B = Math.max(3, Math.min(9, Math.round(pts.length / 4))), bins = [];
  for (let i = 0; i < B; i++) bins.push([]);
  for (const p of pts) { const i = Math.min(B - 1, Math.max(0, Math.floor((p.u - u0) / span * B))); bins[i].push(p); }
  const mid = [], thick = [];
  bins.forEach((bp, i) => {
    if (!bp.length) return;
    const vs = bp.map(p => p.v).sort((a, b) => a - b);
    const lo = Math.min(...bp.map(p => p.v - p.r)), hi = Math.max(...bp.map(p => p.v + p.r));
    mid.push({ u: u0 + (i + 0.5) / B * span, v: (lo + hi) / 2, w: bp.reduce((a, p) => a + p.a, 0) });
    thick.push(hi - lo);
  });
  // взвешенный МНК для v = A u² + Bu + C
  let S = [0, 0, 0, 0, 0], T = [0, 0, 0];
  for (const p of mid) { const w = Math.sqrt(p.w), u = p.u; let up = 1; for (let k = 0; k < 5; k++) { S[k] += w * up; up *= u; } T[0] += w * p.v; T[1] += w * p.v * u; T[2] += w * p.v * u * u; }
  const solve = () => {
    const M3 = [[S[0], S[1], S[2]], [S[1], S[2], S[3]], [S[2], S[3], S[4]]];
    const det = M => M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0]) + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]);
    const D0 = det(M3); if (Math.abs(D0) < 1e-9 || mid.length < 3) return null;
    const rep = (c) => M3.map((r, i) => r.map((x, j) => j === c ? T[i] : x));
    return [det(rep(0)) / D0, det(rep(1)) / D0, det(rep(2)) / D0]; // C, B, A
  };
  let C = 0, Bc = 0, A = 0;
  const sol = solve();
  if (sol) { [C, Bc, A] = sol; } else if (mid.length) { C = mid.reduce((a, p) => a + p.v * p.w, 0) / mid.reduce((a, p) => a + p.w, 0); }
  thick.sort((a, b) => a - b);
  const th = thick.length ? thick[Math.floor(thick.length * 0.5)] : avgR * 2;
  // длина надписи и ограничение изгиба
  const len = span * 0.86, um = (u0 + u1) / 2, h = len / 2;
  const sag = A * h * h, maxSag = Math.min(len * 0.08, th * 0.3);
  if (Math.abs(sag) > maxSag) A *= maxSag / Math.abs(sag);
  const slope = 2 * A * um + Bc, maxSlope = 0.15; // наклон относительно оси тоже ограничиваем
  const Bfix = Math.abs(slope) > maxSlope ? Bc - (slope - Math.sign(slope) * maxSlope) : Bc;
  const vAt = u => A * u * u + Bfix * u + C;
  // буквы не толще страны и не шире, чем помещается по длине (иначе налезают друг на друга)
  const fs = E.clamp(Math.min(th * 0.6, len / (Math.max(3, n) * 0.8)), 3, 60);
  // точки пути — слева направо
  const P = [];
  for (let i = 0; i <= 16; i++) { const u = um - h + len * i / 16, v = vAt(u); P.push([cx + u * ux + v * nx, cy + u * uy + v * ny]); }
  if (P[0][0] > P[P.length - 1][0]) P.reverse();
  // путь чуть длиннее надписи, чтобы textLength уложился целиком
  const d = 'M' + P.map(p => p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('L');
  let plen = 0; for (let i = 1; i < P.length; i++) plen += Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]);
  return { d, fs, len: plen * 0.97, P, plen };
};
// подписи стран растут вместе с картой, но не больше ~34 px на экране
MAP.sizeLabels = () => {
  if (!MAP.gCountry) return;
  const K = MAP.labelK || 1, cap = 34 * K / (MAP.z || 1);
  const z = MAP.z || 1, items = [];
  for (const t of MAP.gCountry.children) {
    if (t.tagName !== 'text') continue;
    // настройка «размер подписей» увеличивает их, но не настолько, чтобы буквы вылезали за страну
    const fs0 = +t.dataset.fs, fs = fs0 * Math.min(K, 1.12), fit = t._em ? +t.dataset.len / (t._em * 1.06) : 1e9, f = Math.min(fs * Math.min(1, cap / fs), fit);
    t.setAttribute('font-size', f.toFixed(2));
    // разрядка: буквы растянуты по стране, но не дальше ~2 букв друг от друга
    const len = Math.max(Math.min(+t.dataset.len, +t.dataset.n * f * 1.7), t._em ? t._em * f * 1.02 : 0);
    t.firstChild.setAttribute('textLength', len.toFixed(1));
    const vis = f * z >= 5.5;
    t.style.display = vis ? '' : 'none';
    if (vis && t._P) items.push({ t, f, len });
  }
  // подписи не должны наезжать друг на друга: крупные страны важнее, мелкую, которая мешает, прячем
  const segs = it => {
    const P = it.t._P, L = it.t._plen || 1, a = (L - it.len) / 2 / L, b = 1 - a, n = P.length - 1, out = [];
    for (let i = 0; i <= n; i++) { const q = i / n; if (q >= a - 0.5 / n && q <= b + 0.5 / n) out.push(P[i]); }
    return out.length > 1 ? out : P;
  };
  const dseg = (p, a, b) => { const dx = b[0] - a[0], dy = b[1] - a[1], l = dx * dx + dy * dy || 1, t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l)); return Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy); };
  const near = (A, B, lim) => { for (const p of A.pts) for (let i = 1; i < B.pts.length; i++) if (dseg(p, B.pts[i - 1], B.pts[i]) < lim) return true; for (const p of B.pts) for (let i = 1; i < A.pts.length; i++) if (dseg(p, A.pts[i - 1], A.pts[i]) < lim) return true; return false; };
  for (const it of items) {
    it.pts = segs(it); it.r = it.f * 0.62;
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9; for (const [x, y] of it.pts) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
    it.b = [x0 - it.r, y0 - it.r, x1 + it.r, y1 + it.r];
    // для коротких подписей точек мало — добавим середины
    if (it.pts.length < 4) { const q = []; for (let i = 0; i < it.pts.length; i++) { q.push(it.pts[i]); if (i + 1 < it.pts.length) q.push([(it.pts[i][0] + it.pts[i + 1][0]) / 2, (it.pts[i][1] + it.pts[i + 1][1]) / 2]); } it.pts = q; }
  }
  items.sort((a, b) => b.t._pri - a.t._pri);
  const kept = [];
  for (const it of items) {
    const hit = kept.some(k => k.b[0] < it.b[2] && it.b[0] < k.b[2] && k.b[1] < it.b[3] && it.b[1] < k.b[3] && near(k, it, (k.r + it.r) * 0.85));
    if (hit) it.t.style.display = 'none'; else kept.push(it);
  }
};

MAP.home = s => {
  MAP.gHome.innerHTML = '';
  const c = E.city(s);
  const g0 = MAP.el('g', { transform: `translate(${c.x},${c.y})`, class: 'pin' }, MAP.gHome);
  const g = MAP.el('g', { class: 'sc' }, g0);
  MAP.el('path', { d: 'M0 0c-4-6-9-9.5-9-15a9 9 0 0 1 18 0c0 5.5-5 9-9 15z', class: 'pinbody' }, g);
  MAP.el('circle', { cy: -15, r: 3.6, fill: '#fff' }, g);
  const nm = E.cityName(s);
  if (!M().cities.some(x => (E.ww2(s) ? x.cap2 && (x.n2 || x.n) : x.cap && x.n) === nm)) { const t = MAP.el('text', { y: -28, class: 'pint' }, g); t.textContent = nm; }
  // другие игроки комнаты
  if (typeof NET !== 'undefined' && NET.on()) {
    const same = {};
    for (const p of Object.values(NET.players)) {
      if (p.city === undefined || !p.name) continue;
      const c2 = M().start[p.city] || M().start[0], k = same[p.city] = (same[p.city] || 0) + 1;
      const q0 = MAP.el('g', { transform: `translate(${c2.x + (k + (p.city === s.ch.city ? 1 : 0) - 1) * 7},${c2.y})`, class: 'pin mpin' }, MAP.gHome);
      const q = MAP.el('g', { class: 'sc' }, q0);
      MAP.el('path', { d: 'M0 0c-4-6-9-9.5-9-15a9 9 0 0 1 18 0c0 5.5-5 9-9 15z', class: 'pinbody' }, q);
      MAP.el('circle', { cy: -15, r: 3.6, fill: '#fff' }, q);
      const t = MAP.el('text', { y: -28, class: 'pint' }, q); t.textContent = p.name.split(' ')[0];
    }
  }
};

// ---------- зум и панорама ----------
// Во время перетаскивания и зума карта не перерисовывается: уже нарисованная картинка просто сдвигается/масштабируется
// видеокартой (CSS transform). Настоящая перерисовка — один раз, когда движение остановилось. Так 60 FPS даже на 9000 провинций.
MAP.hostRect = () => MAP.host.getBoundingClientRect();
MAP.apply = live => {
  const v = MAP.vb;
  if (live && MAP.vb0) {
    const v0 = MAP.vb0, W = MAP.host.clientWidth, H = MAP.host.clientHeight;
    const k = v0.w / v.w, tx = (v0.x - v.x) * W / v.w, ty = (v0.y - v.y) * H / v.h;
    MAP.mover.style.transform = `translate(${tx.toFixed(2)}px,${ty.toFixed(2)}px) scale(${k.toFixed(5)})`;
    clearTimeout(MAP._ct);
    // пока тянем мышью — не перерисовываем карту (это дорого), только сдвигаем готовую картинку;
    // перерисуем, когда отпустили, или если утащили очень далеко
    const far = Math.abs(tx) > W * 0.45 || Math.abs(ty) > H * 0.45 || k > 2.2 || k < 0.6;
    if (MAP._down && !far) return;
    MAP._ct = setTimeout(() => MAP.apply(), MAP._down ? 0 : 220);
    return;
  }
  clearTimeout(MAP._ct);
  MAP.mover.style.transform = '';
  MAP.svg.setAttribute('viewBox', `${v.x} ${v.y} ${v.w} ${v.h}`);
  MAP.vb0 = { x: v.x, y: v.y, w: v.w, h: v.h };
  MAP.z = MAP.host.clientWidth / v.w; // пикселей на единицу карты
  MAP.svg.style.setProperty('--k', (1 / MAP.z).toFixed(4));
  const z = MAP.z;
  MAP.svg.classList.toggle('z1', z > 0.55); MAP.svg.classList.toggle('z2', z > 1.7); MAP.svg.classList.toggle('z3', z > 3);
  if (Math.abs((MAP._lz || 0) - z) > 0.01) { MAP._lz = z; MAP.sizeLabels(); }
};
MAP.clampVb = () => {
  const m = M(), v = MAP.vb;
  v.w = E.clamp(v.w, 120, m.W * 1.1);
  v.h = v.w * (MAP.host.clientHeight / Math.max(1, MAP.host.clientWidth));
  v.x = E.clamp(v.x, -v.w * 0.4, m.W - v.w * 0.6); v.y = E.clamp(v.y, -v.h * 0.4, m.H - v.h * 0.6);
};
MAP.focusOn = (x, y, w) => {
  MAP.vb = { x: x - w / 2, y: 0, w, h: 0 }; MAP.clampVb(); MAP.vb.y = y - MAP.vb.h / 2; MAP.vb.x = x - MAP.vb.w / 2; MAP.clampVb(); MAP.apply();
};
MAP.zoomAt = (px, py, f) => {
  const r = MAP.hostRect(), v = MAP.vb;
  const mx = v.x + (px - r.left) / r.width * v.w, my = v.y + (py - r.top) / r.height * v.h;
  v.w /= f; MAP.clampVb(); v.x = mx - (px - r.left) / r.width * v.w; v.y = my - (py - r.top) / r.height * v.h; MAP.clampVb(); MAP.apply(true);
};

MAP.bind = s => {
  const svg = MAP.svg;
  let drag = null, moved = 0;
  svg.addEventListener('wheel', e => { e.preventDefault(); MAP.zoomAt(e.clientX, e.clientY, Math.exp(-e.deltaY * 0.0016)); }, { passive: false });
  svg.addEventListener('pointerdown', e => { MAP._down = true; drag = { x: e.clientX, y: e.clientY, vx: MAP.vb.x, vy: MAP.vb.y, t: e.target }; moved = 0; svg.setPointerCapture(e.pointerId); svg.classList.add('grab'); });
  svg.addEventListener('pointermove', e => {
    if (drag) {
      const r = MAP.hostRect(); const dx = e.clientX - drag.x, dy = e.clientY - drag.y; moved = Math.max(moved, Math.abs(dx) + Math.abs(dy));
      MAP.vb.x = drag.vx - dx / r.width * MAP.vb.w; MAP.vb.y = drag.vy - dy / r.height * MAP.vb.h; MAP.clampVb(); MAP.apply(true);
    }
    const tgt = e.target; const i = tgt && tgt.dataset ? tgt.dataset.i : undefined;
    if (i !== undefined && !drag) MAP.hover(+i, e); else if (!drag && !(tgt.closest && tgt.closest('.lm'))) MAP.tipHide();
    const hr = MAP.host.getBoundingClientRect(), z = parseFloat(document.body.style.zoom) || 1;
    MAP.tip.style.left = ((e.clientX - hr.left) / z + 14) + 'px';
    MAP.tip.style.top = ((e.clientY - hr.top) / z + 14) + 'px';
  });
  svg.addEventListener('pointerup', e => {
    svg.classList.remove('grab');
    if (drag && moved < 5) {
      const t = drag.t || e.target, dv = t.closest && t.closest('.dv'); let i = t.dataset && t.dataset.i;
      if (typeof ARMY !== 'undefined') {
        if (dv && ARMY.click(+dv.dataset.p)) { drag = null; MAP._down = false; return; }
        if (dv) i = dv.dataset.p;
        if (i !== undefined && ARMY.sel && ARMY.target(+i)) { drag = null; MAP._down = false; return; }
      }
      if (i !== undefined) MAP.select(+i); else MAP.select(-1);
    }
    drag = null; MAP._down = false;
    if (moved >= 5) { clearTimeout(MAP._ct); MAP._ct = setTimeout(() => MAP.apply(), 30); }
  });
  svg.addEventListener('pointercancel', () => { drag = null; MAP._down = false; MAP.apply(); });
  svg.addEventListener('pointerleave', () => MAP.tipHide());
  window.addEventListener('resize', () => { if (MAP.vb) { MAP.clampVb(); MAP.apply(); } });
};

MAP.hover = (i, e) => {
  if (MAP._hi === i && MAP.tip.style.display === 'block') return;
  MAP._hi = i; MAP.pHover.setAttribute('d', M().provinces[i].d);
  const s = UI.s, p = M().provinces[i], o = s.world.own[i];
  const core = (s.world.core || s.world.own)[i];
  let sub = E.countryName(o);
  if (core !== o && s.world.cs[core]) sub += ' · оккупирована (была: ' + s.world.cs[core].n + ')';
  MAP.tipShow((s.world.cs[o].cap === i ? '★ ' : '') + p.n, sub);
};
MAP.tipShow = (a, b) => { MAP.tip.innerHTML = `<b>${a}</b><span>${b}</span>`; MAP.tip.style.display = 'block'; };
MAP.tipHide = () => { if (MAP.tip) MAP.tip.style.display = 'none'; if (MAP.pHover && MAP._hi !== -1) { MAP._hi = -1; MAP.pHover.setAttribute('d', ''); } };

MAP.select = i => {
  MAP.sel = i;
  if (i < 0) { MAP.pSel.setAttribute('d', ''); U.provPanels(-1); return; }
  MAP.pSel.setAttribute('d', M().provinces[i].d);
  U.provPanels(i);
};

MAP.zoomBtn = f => { const r = MAP.hostRect(); MAP.zoomAt(r.left + r.width / 2, r.top + r.height / 2, f); };
