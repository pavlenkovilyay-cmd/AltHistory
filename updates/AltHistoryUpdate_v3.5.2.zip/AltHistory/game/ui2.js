// «Судьба» v3 — окна: вакансии (HH), жильё (ЦИАН), дом с мебелью, транспорт, бизнес, криминал, газета, люди,
// панели провинции/региона/страны, масштаб интерфейса, «неделя/месяц/квартал».
'use strict';
const U = {};
U.big = html => { const m = UI.modal(html); m.firstElementChild.classList.add('wide'); return m; };
U.res = (r, after) => { if (!r) return; UI.appendMsg({ k: 'out', title: r.title, ok: r.ok, crit: r.crit, impossible: r.ok === false && !r.roll, roll: r.roll ? { roll: r.roll.roll, chance: r.roll.chance } : null, lines: (r.lines || []).concat(r.fx ? E.apply(UI.s, r.fx) : []) }); if (r.ok) E.logAdd(UI.s, 'act', r.title, { ok: r.ok, title: r.title }); UI.renderAll(); UI.save(); if (r.map) MAP.paint(UI.s); if (after) after(); else UI.toast(UI.esc(r.title), r.ok ? '' : 'bad'); };
U.tabs = (id, tabs, cur) => `<div class="mtabs" id="${id}">${tabs.map(t => `<button data-t="${t[0]}" class="${t[0] === cur ? 'on' : ''}">${t[1]}</button>`).join('')}</div>`;
U.head = (icon, title, sub, links) => `<div class="mhead">${UI.ic(icon)}<div><h3>${title}</h3>${sub ? `<small>${sub}</small>` : ''}</div>${(links || []).map(l => `<button class="btn small hlink" onclick="${l[1]}">${l[2] ? UI.ic(l[2]) : ''}${l[0]}</button>`).join('')}<button class="close" onclick="UI.closeModal()">${UI.ic('x')}</button></div>`;
U.cityOpts = (s, sel) => M().start.map((c, i) => (E.ww2(s) && c.no36) || s.world.own[c.prov] !== s.world.home ? '' : `<option value="${i}" ${i === sel ? 'selected' : ''}>${E.startName(s, c)}</option>`).join('');

// ============================================================================
//  ВАКАНСИИ
// ============================================================================
U.hh = (city, q) => {
  const s = UI.s; L.hhInit(s);
  city = city === undefined ? s.ch.city : city; q = q || {};
  const ww = E.ww2(s);
  let vs = L.vacancies(s, city);
  if (q.text) vs = vs.filter(v => E.norm(v.title + ' ' + v.comp).includes(E.norm(q.text)));
  if (q.min) vs = vs.filter(v => v.salTo >= q.min);
  if (q.noexp) vs = vs.filter(v => v.exp === 0);
  if (q.fit) vs = vs.filter(v => !L.match(s, v).length);
  vs.sort((a, b) => b.sal - a.sal);
  const R = s.hh.resume, exp = L.expYears(s);
  const apps = s.hh.apps.slice().reverse();
  const st = { sent: ['отправлен', ''], invite: ['приглашение!', 'pos'], reject: ['отказ', 'neg'], offer: ['вы приняты', 'pos'] };
  U.big(`${U.head('brief', ww ? 'Отдел кадров · «Требуются»' : 'Поиск работы', ww ? 'Доска объявлений и личный листок по учёту кадров' : 'Вакансии вашего города, резюме и отклики', [['Тёмная сторона', 'U.crime()', 'bolt']])}
  <div class="hh">
    <div class="hhl">
      <div class="card resume">
        <h4>${ww ? 'Личный листок' : 'Моё резюме'}</h4>
        <div class="rhead">${UI.avatar(s.ch, 52)}<div><b>${UI.esc(s.ch.name)} ${UI.esc(s.ch.surname)}</b><small>${E.years(E.age(s))} · ${UI.esc(E.cityName(s))}</small></div></div>
        <label>Желаемая должность<input id="rTitle" maxlength="40" value="${UI.esc(R.title)}" placeholder="${ww ? 'Токарь, счетовод…' : 'Менеджер, водитель…'}"></label>
        <label>Желаемая зарплата, ₽<input id="rSal" type="number" min="0" value="${R.salary || ''}" placeholder="не указана"></label>
        <label>О себе<textarea id="rAbout" rows="3" maxlength="300" placeholder="Ответственный, быстро учусь, есть права…">${UI.esc(R.about)}</textarea></label>
        <div class="kv"><span>Образование</span><b>${D.EDU[s.ch.edu]}</b></div>
        <div class="kv"><span>Опыт</span><b>${exp ? E.years(exp) : 'без опыта'}</b></div>
        <div class="kv"><span>Сильные стороны</span><b>${Object.keys(D.SKILLS).sort((a, b) => E.sk(s, b) - E.sk(s, a)).slice(0, 2).map(k => D.SKILLS[k].toLowerCase()).join(', ')}</b></div>
        ${(s.hh.career || []).length ? `<div class="career">${s.hh.career.slice().reverse().slice(0, 4).map(c => `<div><b>${UI.esc(c.title)}</b><small>${UI.esc(c.org || '')} · ${Math.max(1, Math.round(c.weeks / 4.3))} мес.</small></div>`).join('')}</div>` : ''}
        <button class="btn primary wide" id="rSave">Сохранить ${ww ? 'листок' : 'резюме'}</button>
        <p class="small">Хорошее резюме и разумная зарплата повышают шанс приглашения.</p>
      </div>
      <div class="card"><h4>Отклики</h4>${apps.length ? apps.map(a => `<div class="app"><div><b>${UI.esc(a.v.title)}</b><small>${UI.esc(a.v.comp)} · ${E.money(a.v.sal)}</small></div><span class="${st[a.st][1]}">${st[a.st][0]}</span>${a.st === 'invite' ? `<button class="btn small primary" data-iv="${a.v.id}">Собеседование</button>` : ''}</div>`).join('') : '<p class="small">Пока нет. Откликайтесь на вакансии справа — ответы придут на следующей неделе.</p>'}</div>
    </div>
    <div class="hhr">
      <div class="filters">
        <select id="hCity">${U.cityOpts(s, city)}</select>
        <input id="hText" placeholder="Профессия или компания" value="${UI.esc(q.text || '')}">
        <input id="hMin" type="number" placeholder="Зарплата от" value="${q.min || ''}">
        <label class="chk"><input type="checkbox" id="hNoexp" ${q.noexp ? 'checked' : ''}> без опыта</label>
        <label class="chk"><input type="checkbox" id="hFit" ${q.fit ? 'checked' : ''}> подхожу</label>
      </div>
      <div class="vlist">${vs.map(v => { const iss = L.match(s, v), done = s.hh.apps.some(a => a.v.id === v.id); return `<div class="vac ${v.hot ? 'hot' : ''}">
        <div class="vt"><b>${UI.esc(v.title)}</b>${v.hot ? '<em>срочно</em>' : ''}</div>
        <div class="vs">${E.money(v.sal)} — ${E.money(v.salTo)}</div>
        <div class="vc">${UI.esc(v.comp)} · ${UI.esc(v.cityN)} · ${v.sched}</div>
        <div class="vr">${v.exp ? 'Опыт от ' + E.years(v.exp) : 'Без опыта'}${v.req.edu ? ' · ' + D.EDU[v.req.edu] : ''}</div>
        <div class="vp">${v.perks.map(p => `<span>${UI.esc(p)}</span>`).join('')}</div>
        ${iss.length ? `<div class="vi neg">Не подходите: ${iss.join('; ')}</div>` : ''}
        <button class="btn small ${done ? '' : 'primary'}" ${done ? 'disabled' : `data-ap="${v.id}"`}>${done ? 'Отклик отправлен' : 'Откликнуться'}</button>
      </div>`; }).join('') || '<p class="note">Ничего не найдено.</p>'}</div>
    </div>
  </div>`);
  const rd = () => ({ text: $('#hText').value.trim(), min: +$('#hMin').value || 0, noexp: $('#hNoexp').checked, fit: $('#hFit').checked });
  $('#hCity').onchange = e => U.hh(+e.target.value, rd());
  for (const id of ['#hNoexp', '#hFit']) $(id).onchange = () => U.hh(+$('#hCity').value, rd());
  for (const id of ['#hText', '#hMin']) $(id).onkeydown = e => { if (e.key === 'Enter') U.hh(+$('#hCity').value, rd()); };
  $('#rSave').onclick = () => { R.title = $('#rTitle').value.trim(); R.salary = +$('#rSal').value || 0; R.about = $('#rAbout').value.trim(); UI.save(); UI.toast('Сохранено'); };
  $$('#modal [data-ap]').forEach(b => b.onclick = () => { const r = L.apply(s, b.dataset.ap); UI.save(); UI.toast(r.title, r.ok ? '' : 'bad'); U.hh(+$('#hCity').value, rd()); });
  $$('#modal [data-iv]').forEach(b => b.onclick = () => { const r = L.interview(s, b.dataset.iv); UI.closeModal(); UI.appendMsg({ k: 'me', t: 'Иду на собеседование' }); U.res(r); });
};

// ============================================================================
//  ЖИЛЬЁ (ЦИАН)
// ============================================================================
U.thumb = (kind, cls, ph) => {
  const pal = { poor: ['#b7b2a2', '#8d8778', '#d8d2c0'], mid: ['#e2c9a2', '#b98e5a', '#f4ead6'], rich: ['#e8e3da', '#5e6d7a', '#fffaf0'] }[cls];
  if (kind === 'house') {
    const roof = cls === 'rich' ? '#6b4a3a' : cls === 'mid' ? '#9a5a40' : '#6f6a5c';
    return `<svg viewBox="0 0 120 80" class="thumb"><rect width="120" height="80" fill="${['#cfe3ec', '#d9e8d2', '#e6dcc8', '#dfe6ee'][ph]}"/><rect y="62" width="120" height="18" fill="#9fbf86"/>${cls === 'rich' ? '<rect x="14" y="30" width="92" height="36" fill="#f4efe6"/><polygon points="8,32 60,10 112,32" fill="' + roof + '"/><rect x="24" y="40" width="16" height="12" fill="#9cc5dc"/><rect x="52" y="40" width="16" height="26" fill="#6b4a3a"/><rect x="80" y="40" width="16" height="12" fill="#9cc5dc"/><rect x="0" y="66" width="30" height="6" fill="#8ec8e4"/>' : cls === 'mid' ? '<rect x="26" y="34" width="68" height="32" fill="#d9b48a"/><polygon points="20,36 60,14 100,36" fill="' + roof + '"/><rect x="36" y="42" width="14" height="12" fill="#9cc5dc"/><rect x="66" y="44" width="12" height="22" fill="#6b4a3a"/>' : '<rect x="34" y="38" width="52" height="28" fill="#8b7a5c" transform="rotate(-3 60 52)"/><polygon points="28,40 60,20 92,40" fill="' + roof + '" transform="rotate(-4 60 30)"/><rect x="44" y="46" width="12" height="10" fill="#7d8d92"/><path d="M70 44h8v22h-8z" fill="#4e4234"/>'}</svg>`;
  }
  if (kind === 'room') return `<svg viewBox="0 0 120 80" class="thumb"><rect width="120" height="80" fill="#cbc4b0"/><rect x="0" y="58" width="120" height="22" fill="#8f7b5e"/><rect x="40" y="14" width="34" height="26" fill="#a9c2cc" stroke="#7d6c52" stroke-width="3"/><rect x="10" y="44" width="40" height="18" fill="#7f8c6a"/><rect x="82" y="30" width="22" height="32" fill="#6d5b44"/></svg>`;
  const floors = cls === 'rich' ? 14 : cls === 'mid' ? 9 : 5, h = cls === 'rich' ? 70 : 48 + (cls === 'mid' ? 10 : 0);
  let win = ''; for (let y = 0; y < floors; y++) for (let x = 0; x < 5; x++) win += `<rect x="${34 + x * 11}" y="${78 - h + 4 + y * (h - 6) / floors}" width="6" height="${Math.max(2, (h - 6) / floors - 2)}" fill="${(x + y + ph) % 4 ? pal[2] : '#ffe29a'}"/>`;
  return `<svg viewBox="0 0 120 80" class="thumb"><rect width="120" height="80" fill="${['#cfe3ec', '#dfe6ee', '#e6e2d6', '#d6e4ea'][ph]}"/><rect x="28" y="${78 - h}" width="64" height="${h}" fill="${pal[0]}"/>${win}<rect y="76" width="120" height="4" fill="#8a8a7a"/></svg>`;
};
U.cian = (city, q) => {
  const s = UI.s; city = city === undefined ? s.ch.city : city; q = q || { deal: 'rent', kind: '', cls: '' };
  const ww = E.ww2(s);
  let ls = L.listings(s, city);
  if (q.deal === 'rent') ls = ls.filter(l => l.deal !== 'sale');
  if (q.deal === 'sale') ls = ls.filter(l => l.deal === 'sale' || l.deal === 'both');
  if (q.kind) ls = ls.filter(l => l.kind === q.kind);
  if (q.cls) ls = ls.filter(l => l.cls === q.cls);
  const mk = L.market(s, city), h = s.home;
  const clsN = { poor: 'бедное', mid: 'среднее', rich: 'богатое' };
  U.big(`${U.head('home', ww ? 'Жилищный отдел и частные объявления' : 'Поиск жилья', ww ? 'Комнаты, ордера на квартиры, частные дома' : 'Аренда помесячно и покупка — во всех городах', [['Моя недвижимость', 'RENT.ui()', 'coin'], ['Мой дом', 'U.home()', 'box']])}
  <div class="cian">
    <div class="filters">
      <select id="cCity2">${U.cityOpts(s, city)}</select>
      <div class="seg small" id="cDeal">${[['rent', ww ? 'Аренда/ордер' : 'Аренда'], ['sale', 'Покупка'], ['', 'Все']].map(d => `<button data-v="${d[0]}" class="${q.deal === d[0] ? 'on' : ''}">${d[1]}</button>`).join('')}</div>
      <div class="seg small" id="cKind">${[['', 'Любое'], ['flat', 'Квартира'], ['house', 'Дом'], ['room', 'Комната']].map(d => `<button data-v="${d[0]}" class="${q.kind === d[0] ? 'on' : ''}">${d[1]}</button>`).join('')}</div>
      <div class="seg small" id="cCls">${[['', 'Любой класс'], ['poor', 'Бедное'], ['mid', 'Среднее'], ['rich', 'Богатое']].map(d => `<button data-v="${d[0]}" class="${q.cls === d[0] ? 'on' : ''}">${d[1]}</button>`).join('')}</div>
    </div>
    <div class="mkt"><span>${UI.esc(E.startName(s, L.cityStart(city)))}: ${ww ? 'кооперативный метр' : 'метр на вторичке'} ≈ <b>${E.money(mk.m2)}</b></span>${ww ? `<span>Квартплата ≈ <b>${E.money(mk.rm2)}</b> за м²</span>` : `<span>Однушка в аренду ≈ <b>${E.money(mk.r1)}</b>/мес</span>`}<span>Сейчас вы: <b>${UI.esc(E.homeName(s))}</b>${h.area ? ', ' + h.area + ' м²' : ''}${h.owned ? ' (своё)' : E.homeRent(s) ? ' · ' + E.money(E.homeRent(s)) + '/мес' : ''}</span></div>
    <div class="llist">${ls.map(l => `<div class="lst cls-${l.cls}">
      ${U.thumb(l.kind, l.cls, l.photo)}
      <div class="li"><b>${UI.esc(l.n)}${l.kind !== 'room' ? ', ' + l.rooms + '-комн.' : ''}</b><span class="tag ${l.cls}">${l.kind === 'room' ? 'комната' : clsN[l.cls]}</span>
        <small>${l.area} м²${l.floor ? ' · ' + l.floor + ' этаж' : ''} · ${UI.esc(l.dist)} · ${UI.esc(l.addr)}</small>
        <small class="ld">${UI.esc(l.d)}</small></div>
      <div class="lp">${l.deal !== 'sale' ? `<div><b>${E.money(l.rent)}</b><small>${l.deal === 'order' ? 'квартплата по ордеру' : 'в месяц'}</small></div>` : ''}${l.deal === 'sale' || l.deal === 'both' ? `<div><b>${E.money(l.price)}</b><small>${E.money(Math.round(l.price / l.area))} за м²</small></div>` : ''}
        <div class="lb">${l.deal === 'order' ? `<button class="btn small primary" data-take="${l.id}|order">Получить ордер</button>` : ''}${l.deal === 'rent' || l.deal === 'both' ? `<button class="btn small primary" data-take="${l.id}|rent">Снять</button>` : ''}${l.deal === 'sale' || l.deal === 'both' ? `<button class="btn small" data-take="${l.id}|sale">Купить</button>${ww ? '' : `<button class="btn small" data-take="${l.id}|mort">Ипотека</button>`}<button class="btn small inv" data-invest="${l.id}" title="Купить и сдавать жильцам, не переезжая">Купить под сдачу</button>` : ''}</div></div>
    </div>`).join('') || '<p class="note">Подходящих объявлений нет — попробуйте другой фильтр или город.</p>'}</div>
    <div class="mine"><h4>Моя недвижимость</h4>
      <div class="kv"><span>Живу</span><b>${UI.esc(E.homeName(s))}${h.addr ? ' · ' + UI.esc(h.addr) : ''}</b></div>
      ${s.props.length ? `<div class="kv"><span>Ещё объектов: ${s.props.length}, сдаётся ${s.props.filter(p => p.rentOut).length}</span><button class="btn small primary" onclick="RENT.ui()">Управлять и сдавать</button></div>` : ''}
      ${h.type !== 'parents' ? '<button class="btn small" id="cParents">Переехать к родителям</button>' : ''}
      <p class="small">Новые объявления — каждые 4 недели. Своё жильё при переезде остаётся вам — его можно сдавать. «Купить под сдачу» — квартира для дохода без переезда.</p></div>
  </div>`);
  const go = () => U.cian(+$('#cCity2').value, q);
  $('#cCity2').onchange = go;
  for (const [id, key] of [['#cDeal', 'deal'], ['#cKind', 'kind'], ['#cCls', 'cls']]) $$(id + ' button').forEach(b => b.onclick = () => { q[key] = b.dataset.v; go(); });
  $$('#modal [data-take]').forEach(b => b.onclick = () => {
    const [id, mode] = b.dataset.take.split('|');
    const r = L.take(s, id, mode === 'mort' ? 'sale' : mode, mode === 'mort');
    UI.closeModal(); UI.appendMsg({ k: 'me', t: mode === 'rent' ? 'Снимаю жильё' : mode === 'order' ? 'Получаю ордер на квартиру' : 'Покупаю жильё' });
    U.res(r); if (r.ok) MAP.home(s);
  });
  $$('#modal [data-sell]').forEach(b => b.onclick = () => { const r = L.sellProp(s, +b.dataset.sell); U.res(r, () => U.cian(city, q)); });
  $$('#modal [data-invest]').forEach(b => b.onclick = () => { UI.appendMsg({ k: 'me', t: 'Покупаю квартиру под сдачу' }); const r = RENT.invest(s, b.dataset.invest, false); U.res(r, () => { if (r.ok) RENT.ui(); }); });
  if ($('#cParents')) $('#cParents').onclick = () => { const r = L.toParents(s); UI.closeModal(); U.res(r); };
};

// ============================================================================
//  ДОМ: рисунок и мебель, транспорт
// ============================================================================
U.scene = s => {
  const h = s.home, ww = E.ww2(s), cls = h.cls || (h.type === 'parents' ? 'mid' : 'poor');
  const has = id => (h.furn || []).find(f => f.id === id);
  const tier = id => { const f = has(id); return f ? f.tier || 'std' : null; };
  const col = (id, a, b, c) => ({ eco: a, std: b, pre: c }[tier(id)] || b);
  const house = h.type === 'house';
  const wall = house ? { poor: '#a88b62', mid: '#d8c3a0', rich: '#efe6d6' }[cls] : { poor: '#a9b39a', mid: '#e5d6bd', rich: '#f2ede4' }[cls];
  const floor = { poor: '#7d6a50', mid: '#b48a5c', rich: '#8a5a3c' }[cls];
  let g = `<svg viewBox="0 0 860 360" class="scene"><defs><pattern id="pq" width="24" height="12" patternUnits="userSpaceOnUse"><path d="M0 12 12 0M12 12 24 0" stroke="rgba(0,0,0,.12)"/></pattern><pattern id="logs" width="40" height="22" patternUnits="userSpaceOnUse"><rect width="40" height="22" fill="${wall}"/><path d="M0 21h40" stroke="rgba(60,40,20,.35)" stroke-width="2"/></pattern></defs>`;
  g += `<rect width="860" height="270" fill="${house && cls === 'poor' ? 'url(#logs)' : wall}"/><rect y="270" width="860" height="90" fill="${floor}"/>${cls === 'rich' ? '<rect y="270" width="860" height="90" fill="url(#pq)"/><rect y="40" width="860" height="6" fill="#fff" opacity=".6"/>' : ''}`;
  g += `<rect x="300" width="6" height="270" fill="rgba(0,0,0,.12)"/><rect x="620" width="6" height="270" fill="rgba(0,0,0,.12)"/><rect x="620" y="150" width="240" height="120" fill="${cls === 'rich' ? '#e8e2d8' : cls === 'mid' ? '#d6cdb8' : '#9aa290'}"/>`;
  if (cls === 'poor') g += `<path d="M120 20 l12 30 l-8 20 l10 26" stroke="rgba(60,50,40,.45)" fill="none" stroke-width="2"/><ellipse cx="520" cy="60" rx="40" ry="22" fill="rgba(90,80,40,.18)"/><path d="M690 70 l-6 22 l8 14" stroke="rgba(60,50,40,.4)" fill="none" stroke-width="2"/>`;
  // окно
  const wx = 330, ww_ = cls === 'rich' ? 220 : 130;
  g += `<rect x="${wx}" y="40" width="${ww_}" height="${cls === 'rich' ? 190 : 120}" fill="#bcdcea" stroke="${cls === 'poor' ? '#e8e1d0' : '#fff'}" stroke-width="8"/><path d="M${wx + ww_ / 2} 40v${cls === 'rich' ? 190 : 120}" stroke="#fff" stroke-width="5"/>`;
  if (has('curtain')) g += `<path d="M${wx - 18} 30 q12 90 0 ${cls === 'rich' ? 210 : 140} h26 q-10-80 0-${cls === 'rich' ? 210 : 140}z" fill="${col('curtain', '#c9b98f', '#b5483b', '#5d3a6b')}"/><path d="M${wx + ww_ + 18} 30 q-12 90 0 ${cls === 'rich' ? 210 : 140} h-26 q10-80 0-${cls === 'rich' ? 210 : 140}z" fill="${col('curtain', '#c9b98f', '#b5483b', '#5d3a6b')}"/>`;
  if (has('ac')) g += `<rect x="460" y="12" width="110" height="26" rx="6" fill="#f7f7f5" stroke="#cfcfcf"/><path d="M470 30h90" stroke="#bbb"/>`;
  // спальня
  if (has('wardrobe')) g += `<rect x="20" y="60" width="90" height="210" fill="${col('wardrobe', '#b9a27f', '#8b5e3c', '#3d2b22')}"/><path d="M65 60v210" stroke="rgba(0,0,0,.3)"/><circle cx="58" cy="165" r="3" fill="#d9c08a"/><circle cx="72" cy="165" r="3" fill="#d9c08a"/>`;
  if (has('art')) g += `<rect x="140" y="60" width="70" height="50" fill="${col('art', '#d9cfae', '#6f9fb8', '#8a4f2d')}" stroke="${col('art', '#8b7350', '#c9a24a', '#d4af37')}" stroke-width="6"/><path d="M146 100 l18-20 l14 12 l12-16 l14 24z" fill="rgba(255,255,255,.5)"/>`;
  if (has('bed')) g += `<rect x="20" y="240" width="200" height="60" rx="6" fill="${col('bed', '#9b8a6a', '#6f8fb0', '#5a3d6b')}"/><rect x="20" y="232" width="200" height="22" rx="8" fill="#fbf7ee"/><rect x="${has('wardrobe') ? 120 : 20}" y="190" width="${has('wardrobe') ? 18 : 18}" height="110" fill="${col('bed', '#8b7350', '#5c4330', '#2e1f18')}"/><rect x="30" y="226" width="44" height="16" rx="6" fill="#fff"/>`;
  if (has('desk')) g += `<rect x="190" y="200" width="100" height="10" fill="#8b5e3c"/><rect x="196" y="210" width="8" height="60" fill="#6b4a30"/><rect x="276" y="210" width="8" height="60" fill="#6b4a30"/>`;
  if (has('pc')) g += ww ? `<rect x="210" y="178" width="56" height="22" rx="3" fill="#2e2e2e"/><rect x="216" y="170" width="44" height="10" fill="#efe6cf"/>` : `<rect x="214" y="150" width="56" height="40" rx="3" fill="#222"/><rect x="218" y="154" width="48" height="30" fill="#5fa9d8"/><rect x="238" y="190" width="8" height="10" fill="#333"/>`;
  if (has('lamp')) g += `<path d="M262 120 l18 0 l8 26 h-34z" fill="${col('lamp', '#e7d8a8', '#f1c96a', '#e9b44c')}"/><rect x="269" y="146" width="4" height="124" fill="#555"/><ellipse cx="271" cy="272" rx="16" ry="4" fill="#555"/>`;
  if (has('carpet')) g += `<ellipse cx="460" cy="320" rx="150" ry="28" fill="${col('carpet', '#b98f6a', '#a63d3d', '#2f4d6e')}"/><ellipse cx="460" cy="320" rx="120" ry="20" fill="none" stroke="#e8d8a8" stroke-width="3" stroke-dasharray="6 4"/>`;
  // гостиная
  if (has('shelf')) g += `<rect x="314" y="${cls === 'rich' ? 240 : 170}" width="0" height="0"/><rect x="566" y="80" width="46" height="190" fill="#8b5e3c"/>${[0, 1, 2, 3].map(k => `<rect x="570" y="${92 + k * 44}" width="38" height="4" fill="#5a3d28"/>${[0, 1, 2, 3, 4].map(z => `<rect x="${572 + z * 7}" y="${70 + k * 44}" width="5" height="22" fill="${['#b5483b', '#2f6f7e', '#b8892f', '#4f8a4b', '#7a5fa0'][(k + z) % 5]}"/>`).join('')}`).join('')}`;
  if (has('sofa')) g += `<rect x="340" y="250" width="200" height="50" rx="10" fill="${col('sofa', '#8a8a7a', '#4f7a8a', '#6b2f2f')}"/><rect x="340" y="226" width="200" height="34" rx="12" fill="${col('sofa', '#9a9a8a', '#5f8a9a', '#7b3f3f')}"/><rect x="330" y="236" width="22" height="64" rx="8" fill="${col('sofa', '#7a7a6a', '#3f6a7a', '#5b1f1f')}"/><rect x="528" y="236" width="22" height="64" rx="8" fill="${col('sofa', '#7a7a6a', '#3f6a7a', '#5b1f1f')}"/>`;
  const tvx = cls === 'rich' ? 380 : 360;
  if (has('tv')) g += ww ? `<rect x="480" y="200" width="70" height="50" rx="6" fill="#6b4a30"/><circle cx="500" cy="225" r="14" fill="#c9b27a"/><rect x="520" y="212" width="22" height="26" fill="#e9dcb4"/>` : (has('sofa') ? '' : '') + `<rect x="${tvx}" y="${has('sofa') ? 130 : 160}" width="${col('tv', 90, 120, 170)}" height="${col('tv', 56, 72, 100)}" rx="4" fill="#1e1e22"/><rect x="${tvx + 5}" y="${(has('sofa') ? 130 : 160) + 5}" width="${col('tv', 80, 110, 160)}" height="${col('tv', 46, 62, 90)}" fill="#3b6f9a"/>`;
  if (has('console')) g += ww ? `<rect x="250" y="140" width="0" height="0"/><rect x="230" y="${has('desk') ? 130 : 230}" width="40" height="18" fill="#7a4b2a"/><circle cx="250" cy="${has('desk') ? 128 : 228}" r="12" fill="#222" opacity=".85"/><path d="M250 ${has('desk') ? 128 : 228} l20 -24" stroke="#b8892f" stroke-width="3"/>` : `<rect x="${tvx + 20}" y="${has('sofa') ? 206 : 236}" width="44" height="10" rx="3" fill="#111"/>`;
  if (has('theater')) g += `<rect x="${tvx - 22}" y="150" width="16" height="70" rx="3" fill="#222"/><rect x="${tvx + 186}" y="150" width="16" height="70" rx="3" fill="#222"/>`;
  if (has('plant')) g += `<rect x="314" y="244" width="22" height="26" fill="#b5764a"/><circle cx="325" cy="232" r="18" fill="#4f8a4b"/><circle cx="315" cy="222" r="10" fill="#5f9a5b"/>`;
  if (has('aqua')) g += `<rect x="520" y="${has('tv') && !ww ? 110 : 150}" width="40" height="0"/><rect x="250" y="${has('desk') ? 0 : 0}" width="0" height="0"/><rect x="${has('shelf') ? 500 : 560}" y="170" width="54" height="36" fill="#9fd3e6" stroke="#555" stroke-width="2" opacity=".9"/><circle cx="${has('shelf') ? 515 : 575}" cy="190" r="3" fill="#e8762b"/>`;
  if (has('piano')) g += `<rect x="440" y="196" width="0" height="0"/><rect x="${cls === 'rich' ? 470 : 470}" y="150" width="0" height="0"/><rect x="232" y="220" width="0" height="0"/><rect x="560" y="200" width="56" height="70" fill="#1b1410"/><rect x="560" y="226" width="56" height="8" fill="#f4f0e6"/>`;
  if (has('speaker')) g += ww ? `<rect x="250" y="40" width="30" height="40" rx="3" fill="#6b4a30"/><circle cx="265" cy="56" r="10" fill="#efe6cf"/><path d="M265 80 v30" stroke="#333"/><circle cx="265" cy="114" r="4" fill="#b8892f"/>` : `<rect x="576" y="64" width="20" height="16" rx="6" fill="#333"/>`;
  // кухня
  if (has('fridge')) g += `<rect x="790" y="${ww ? 180 : 110}" width="60" height="${ww ? 90 : 160}" rx="6" fill="${ww ? '#8b6a46' : col('fridge', '#e8e8e8', '#f4f4f2', '#b9bcc0')}" stroke="#bbb"/><path d="M790 ${ww ? 210 : 170}h60" stroke="#aaa"/><rect x="840" y="${ww ? 190 : 130}" width="4" height="22" fill="#999"/>`;
  if (has('stove')) g += ww ? `<rect x="700" y="236" width="34" height="34" fill="#7a7a72"/><circle cx="717" cy="236" r="12" fill="#3a3a3a"/>` : `<rect x="700" y="200" width="70" height="70" fill="${col('stove', '#ddd', '#efefef', '#2a2a2a')}" stroke="#bbb"/><circle cx="716" cy="208" r="6" fill="#444"/><circle cx="752" cy="208" r="6" fill="#444"/><rect x="708" y="226" width="54" height="34" fill="#333" opacity=".75"/>`;
  if (has('micro')) g += ww ? `<rect x="640" y="240" width="30" height="30" fill="#5d6d6a"/><path d="M646 238 v-8 h18 v8" stroke="#333" fill="none" stroke-width="2"/>` : `<rect x="636" y="120" width="54" height="30" rx="3" fill="#f2f2f2" stroke="#bbb"/><rect x="640" y="124" width="34" height="22" fill="#333"/>`;
  if (has('kettle')) g += ww ? `<path d="M740 150 l8 -24 h20 l8 24z" fill="#c9a24a"/><rect x="744" y="150" width="28" height="6" fill="#8b6a2a"/>` : `<path d="M708 192 q8-22 22 0z" fill="#d84" /><rect x="706" y="190" width="26" height="4" fill="#933"/>`;
  if (has('wash')) g += `<rect x="636" y="${ww ? 250 : 210}" width="58" height="${ww ? 20 : 60}" rx="${ww ? 8 : 4}" fill="${ww ? '#9a8f80' : '#f4f4f4'}" stroke="#bbb"/>${ww ? '' : '<circle cx="665" cy="242" r="18" fill="#9cc5dc" stroke="#888" stroke-width="3"/>'}`;
  if (has('dish')) g += ww ? `<rect x="640" y="150" width="70" height="60" fill="#8b5e3c"/><rect x="646" y="156" width="58" height="24" fill="#c9e2ea" opacity=".7"/>` : `<rect x="636" y="${has('wash') ? 156 : 210}" width="58" height="${has('wash') ? 0 : 60}" fill="#eee"/>${has('wash') ? '' : '<rect x="640" y="214" width="50" height="6" fill="#bbb"/>'}`;
  if (has('table')) g += `<rect x="650" y="292" width="120" height="8" fill="${col('table', '#b9a27f', '#8b5e3c', '#3d2b22')}"/><rect x="660" y="300" width="6" height="40" fill="#6b4a30"/><rect x="754" y="300" width="6" height="40" fill="#6b4a30"/><rect x="630" y="296" width="14" height="44" fill="#7a5a3a"/><rect x="776" y="296" width="14" height="44" fill="#7a5a3a"/>`;
  if (has('vac')) g += ww ? `<rect x="40" y="300" width="0" height="0"/><rect x="236" y="280" width="40" height="30" fill="#1f1f1f"/><circle cx="256" cy="300" r="6" fill="#d4af37"/>` : `<ellipse cx="590" cy="334" rx="20" ry="7" fill="#2b2b2b"/>`;
  if (has('buffet')) g += `<rect x="636" y="150" width="70" height="120" fill="#6b4a30"/><rect x="642" y="156" width="58" height="40" fill="#c9e2ea" opacity=".7"/>`;
  // сломанное
  for (const f of h.furn || []) if (f.broken) { const it = L.FURN(s).find(x => x.id === f.id); if (it) g += ''; }
  // дом снаружи
  if (house) g += `<g transform="translate(700,14)">${U.thumb('house', cls, 0).replace('<svg viewBox="0 0 120 80" class="thumb">', '<svg width="140" height="94" viewBox="0 0 120 80">')}</g>`;
  if (h.type === 'parents') g += `<text x="14" y="352" font-family="Georgia" font-size="14" fill="#5b5348" text-anchor="start">квартира родителей</text>`;
  if (h.type === 'street') g = `<svg viewBox="0 0 860 360" class="scene"><rect width="860" height="360" fill="#9aa5ab"/><rect y="280" width="860" height="80" fill="#6d6d66"/><rect x="380" y="230" width="120" height="50" fill="#a0896a"/><text x="430" y="200" text-anchor="middle" font-family="Georgia" font-size="22" fill="#fff">Жилья нет</text>`;
  return g + '</svg>';
};
U.home = (tab) => {
  const s = UI.s, h = s.home; tab = tab || 'furn';
  const F = L.FURN(s);
  const broken = (h.furn || []).filter(f => f.broken);
  U.big(`${U.head('home', 'Мой дом', `${UI.esc(E.homeName(s))}${h.area ? ' · ' + h.area + ' м²' : ''}${h.rooms ? ' · ' + h.rooms + '-комн.' : ''} · уют ${Math.round(E.comfort(s))}`, [['Найти другое жильё', 'U.cian()', 'home']])}
    <div class="homev">${U.scene(s)}${broken.length ? `<div class="brk">${UI.ic('bolt')} Сломано: ${broken.map(f => (F.find(x => x.id === f.id) || {}).n).join(', ')}</div>` : ''}</div>
    ${U.tabs('hTabs', [['furn', 'Мебель и техника'], ['car', 'Транспорт'], ['fam', 'Семья дома']], tab)}
    <div class="hbody">${tab === 'furn' ? `<div class="furn">${F.map(it => { const f = (h.furn || []).find(x => x.id === it.id); return `<div class="fi ${f ? 'own' : ''}"><b>${it.n}</b>${f ? `<small class="${f.broken ? 'neg' : 'pos'}">${f.broken ? 'сломано' : 'есть · ' + D.TIER[f.tier || 'std'].n.toLowerCase()}</small>` : '<small>нет</small>'}<div class="tiers">${Object.keys(D.TIER).map(t => `<button class="btn small" data-buy="${it.id}|${t}">${D.TIER[t].n} · ${E.short(L.furnPrice(s, it, t))} ₽</button>`).join('')}</div></div>`; }).join('')}</div>`
      : tab === 'car' ? `<div class="cars"><div class="kv"><span>Сейчас</span><b>${s.car ? UI.esc(s.car.n) + ' · содержание ' + E.money(E.carUp(s)) + '/мес' : 'общественный транспорт · ' + E.money(E.transit(s)) + '/мес'}</b></div>${s.car ? '<button class="btn small" id="sellCar">Продать машину</button>' : ''}
        <div class="carl">${L.CARS(s).map(c => `<div class="fi"><b>${c.n}</b><small>${E.money(L.carPrice(s, c))} · содержание ~${E.money(Math.round(c.up * E.cpi(s) * Math.sqrt(E.city(s).cost)))}/мес${c.need ? ' · по разнарядке (реп. ' + c.need + '+)' : ''}</small><button class="btn small primary" data-car="${c.id}">Купить</button></div>`).join('')}</div>
        <p class="small">Без машины вы платите за проездной и тратите больше времени в дороге (стресс). Машина — плюс к счастью, но содержание дорогое.</p></div>`
      : `<div class="fam">${(() => { const sp = s.rel.find(r => r.role === 'супруг(а)'); const kids = s.kids || []; return (sp ? `<div class="kv"><span>${s.ch.sex === 'f' ? 'Муж' : 'Жена'}: ${UI.esc(sp.name)}</span>${UI.bar(sp.att, sp.att > 60 ? 'good' : sp.att < 30 ? 'bad' : '')}</div>` : '<p class="note">Вы живёте без пары.</p>') + kids.map(k => `<div class="kv"><span>${k.sex === 'm' ? 'Сын' : 'Дочь'} ${UI.esc(k.name)}, ${E.years(Math.max(0, L.kidAge(s, k)))}</span>${UI.bar(k.att || 70, (k.att || 70) > 60 ? 'good' : '')}</div>`).join('') + (E.missingWife(s) && sp ? `<p class="small neg">${UI.esc(sp.name)} давно намекает: дома не хватает — ${E.missingWife(s).n.toLowerCase()}.</p>` : '') + `<p class="small">Расходы на детей: ${E.money(L.kidCost(s))}/мес${L.spouseIncome(s) ? ' · зарплата супруга(и): ' + E.money(L.spouseIncome(s)) : ''}</p>`; })()}</div>`}</div>`);
  $$('#hTabs button').forEach(b => b.onclick = () => U.home(b.dataset.t));
  $$('#modal [data-buy]').forEach(b => b.onclick = () => { const [id, t] = b.dataset.buy.split('|'); const r = L.buyFurn(s, id, t); U.res(r, () => U.home('furn')); });
  $$('#modal [data-car]').forEach(b => b.onclick = () => { const r = L.buyCar(s, b.dataset.car); U.res(r, () => U.home('car')); });
  if ($('#sellCar')) $('#sellCar').onclick = () => U.res(L.sellCar(s), () => U.home('car'));
};

// ============================================================================
//  БИЗНЕС
// ============================================================================
U.biz = (id, tab) => {
  const s = UI.s;
  const b = id ? B.get(s, id) : s.biz[0];
  if (!b) return U.bizNew();
  tab = tab || 'main';
  const I = B.ind(s, b.ind), need = B.need(b), prod = B.prod(s, b);
  const c = b.cost || {};
  const spark = b.hist.length > 1 ? UI.spark(b.hist) : '<div class="spark empty">статистика появится через месяц</div>';
  let body = '';
  if (tab === 'main') body = `<div class="bgrid">
      <div class="card"><h4>Итоги прошлого месяца</h4>
        <div class="kv"><span>Выручка</span><b>${E.money(b.lastRev || 0)}</b></div>
        ${c.contracts ? `<div class="kv"><span>в т.ч. контракты</span><b>${E.money(c.contracts)}</b></div>` : ''}
        <div class="kv"><span>Зарплаты</span><b class="neg">−${E.money(c.sal || 0)}</b></div>
        <div class="kv"><span>Сырьё и товар</span><b class="neg">−${E.money(c.mat || 0)}</b></div>
        <div class="kv"><span>Аренда помещений</span><b class="neg">−${E.money(c.rent || 0)}</b></div>
        <div class="kv"><span>Реклама</span><b class="neg">−${E.money(c.mkt || 0)}</b></div>
        <div class="kv"><span>Коммуналка, бухгалтерия, связь</span><b class="neg">−${E.money(c.over || 0)}</b></div>
        ${c.inc ? `<div class="kv"><span>Неприятность: ${c.incT}</span><b class="neg">−${E.money(c.inc)}</b></div>` : ''}
        <div class="kv"><span>Налоги</span><b class="neg">−${E.money(c.tax || 0)}</b></div>
        <div class="kv tot"><span>Прибыль</span><b class="${b.lastProfit >= 0 ? 'pos' : 'neg'}">${E.money(b.lastProfit)}</b></div>${spark}</div>
      <div class="card"><h4>Состояние</h4>
        <div class="kv"><span>Уровень здания</span><b>${b.level} / 10</b></div>
        <div class="kv"><span>Объектов (точек)</span><b>${b.branches}</b></div>
        <div class="kv"><span>Сотрудники</span><b class="${b.staff.length < need ? 'neg' : ''}">${b.staff.length} / ${need}</b></div>
        <div class="kv"><span>Загрузка (работает на)</span><b>${Math.round(prod * 100)}%</b></div>
        <div class="kv" title="Сколько людей знают вас и возвращаются. Растёт от рекламы, качества и навыка «Бизнес»."><span>Клиентская база</span><b>${Math.round((b.base == null ? 0.4 : b.base) * 100)}%</b></div>
        <div class="kv"><span>Спрос</span><b>${b.lastDemand ? Math.round(b.lastDemand * 100) + '%' : '—'}</b></div>
        <div class="kv"><span>Репутация бизнеса</span><b>${Math.round(b.health)}</b></div>${UI.bar(b.health, b.health > 60 ? 'good' : b.health < 30 ? 'bad' : '')}
        <div class="kv"><span>Стоимость бизнеса</span><b>${E.money(b.value)}</b></div>
        <div class="kv"><span>Помещения</span><b>${b.owned ? 'в собственности' : 'в аренде'}</b></div></div>
      <div class="card"><h4>Управление</h4>
        <label>Цены: <b id="pv">${Math.round(b.price * 100)}%</b> от рынка<input type="range" id="bPrice" min="70" max="150" value="${Math.round(b.price * 100)}"></label>
        <small>Дороже — больше с каждого клиента, но меньше спрос.</small>
        <label>Реклама в месяц, ₽<input type="number" id="bMkt" min="0" value="${b.mkt}"></label>
        <button class="btn small" id="bSave">Применить</button>
        <h4>Развитие</h4>
        <button class="btn wide" id="bUp" ${b.level >= 10 ? 'disabled' : ''}>${UI.ic('up')} Расширить здание до ур. ${b.level + 1} — ${E.short(B.upCost(s, b))} ₽</button>
        <button class="btn wide" id="bBr">${UI.ic('plus')} Открыть новую точку — ${E.short(B.branchCost(s, b))} ₽</button>
        ${b.owned ? '' : `<button class="btn wide" id="bOwn">${UI.ic('home')} Выкупить помещения</button>`}
        <button class="btn wide danger" id="bSell">Продать бизнес (~${E.short(b.value * (0.75 + b.health / 300))} ₽)</button></div>
    </div>`;
  if (tab === 'staff') {
    const cands = B.candidates(s, b);
    body = `<div class="bgrid2"><div class="card"><h4>Сотрудники (${b.staff.length} / ${need})</h4><table class="tbl"><tr><th>Имя</th><th>Должность</th><th>Навык</th><th>Зарплата</th><th>Мораль</th><th></th></tr>
      ${b.staff.map((p, i) => `<tr><td>${UI.esc(p.n)}</td><td>${UI.esc(p.role)}</td><td>${p.sk}</td><td>${E.money(p.sal)} <span class="mini"><button data-sal="${i}|0.9">−</button><button data-sal="${i}|1.1">+</button></span><br><small>рынок ${E.short(B.mkt(s, p.role))}</small></td><td>${UI.bar(p.mor, p.mor > 60 ? 'good' : p.mor < 30 ? 'bad' : '')}</td><td><button class="btn small danger" data-fire="${i}">Уволить</button></td></tr>`).join('') || '<tr><td colspan="6">Никого нет — бизнес работает только на вас.</td></tr>'}</table></div>
      <div class="card"><h4>Кандидаты</h4>${cands.map((p, i) => `<div class="cand"><div><b>${UI.esc(p.n)}</b><small>${UI.esc(p.role)} · навык ${p.sk}</small></div><b>${E.money(p.sal)}</b><button class="btn small primary" data-hire="${i}">Нанять</button></div>`).join('')}<p class="small">Новые кандидаты — каждую неделю. Платите ниже рынка — люди уходят.</p></div></div>`;
    U._cands = cands;
  }
  if (tab === 'assets') body = `<div class="card"><h4>Покупка объектов и улучшений</h4><div class="assets">${D.ASSETS[E.EV(s)].filter(a => !a.factory || I.factory).map(a => { const own = (b.assets || []).includes(a.id); const lock = a.need && b.level < a.need; return `<div class="fi ${own ? 'own' : ''}"><b>${a.n}</b><small>${a.boost ? '+' + Math.round(a.boost * 100) + '% мощности ' : ''}${a.prod ? '+' + Math.round(a.prod * 100) + '% эффективности ' : ''}${a.br ? '+' + a.br + ' к репутации' : ''}${lock ? ' · нужен ур. ' + a.need : ''}</small><button class="btn small ${own ? '' : 'primary'}" ${own && !a.br || lock ? 'disabled' : `data-asset="${a.id}"`}>${own && !a.br ? 'Куплено' : E.short(B.assetCost(s, b, a)) + ' ₽'}</button></div>`; }).join('')}</div></div>`;
  if (tab === 'prod') {
    const offers = B.offers(s, b);
    body = `<div class="bgrid2"><div class="card"><h4>Производственная линия</h4>
      <div class="kv"><span>Сейчас выпускаем</span><b>${UI.esc(b.product || '—')}${b.line === 'military' ? ' (военная продукция)' : ''}</b></div>
      <h5>Потребительские товары</h5><div class="chips">${D.PRODUCTS.consumer.map(p => `<button data-line="consumer|${p}" class="${b.product === p ? 'on' : ''}">${p}</button>`).join('')}</div>
      ${E.ww2(s) ? '' : `<h5>Военная продукция ${b.lic.mil ? '<span class="pos">лицензия есть</span>' : '<span class="neg">нужна лицензия</span>'}</h5><div class="chips">${D.PRODUCTS.military.map(p => `<button data-line="military|${p.n}" class="${b.product === p.n ? 'on' : ''}" ${!b.lic.mil || b.level < p.lvl ? 'disabled' : ''}>${p.n}${b.level < p.lvl ? ' (ур. ' + p.lvl + ')' : ''}</button>`).join('')}</div>
      ${b.lic.mil ? '' : (b.lic.milWait ? `<p class="note">Заявка на лицензию рассматривается (ещё ~${Math.max(1, b.lic.milWait - s.turn)} нед.)</p>` : `<button class="btn wide" id="licA">Подать заявку на лицензию — ${E.short(B.licCost(s, 'mil'))} ₽ (6 недель)</button><button class="btn wide danger" id="licB">«Ускорить» через знакомых — ${E.short(B.licCost(s, 'mil') * 2)} ₽ (2 недели, риск)</button>`)}`}
      </div>
      <div class="card"><h4>Контракты</h4>${b.contracts.map(c => `<div class="kv"><span>${UI.esc(c.n)}: ${UI.esc(c.product)}</span><b>${E.money(c.monthly)}/мес · ещё ${c.left} мес.</b></div>`).join('') || '<p class="small">Активных контрактов нет.</p>'}
      ${b.line === 'military' ? `<h5>Запросы от государств</h5><table class="tbl"><tr><th>Страна</th><th>В месяц</th><th>Срок</th><th></th></tr>${offers.map(o => `<tr><td>${UI.esc(o.n)}${o.gov ? ' <small>(госзаказ)</small>' : ''}${o.war ? ' <span class="neg">воюет</span>' : ''}${o.legal ? '' : ' <span class="neg">серая сделка</span>'}</td><td>${E.money(o.monthly)}</td><td>${o.months} мес.</td><td><button class="btn small primary" data-sign="${o.ci}">Подписать</button></td></tr>`).join('')}</table><p class="small">Продажа воюющим странам портит отношения с их врагами. Серые сделки привлекают внимание полиции.</p>` : '<p class="small">Переключите линию на военную продукцию, чтобы получать запросы от стран.</p>'}</div></div>`;
  }
  if (tab === 'lic') body = `<div class="card"><h4>Банковская лицензия</h4>${b.lic.fin ? '<p class="pos">Лицензия есть — банк работает в полную силу.</p>' : b.lic.finWait ? `<p class="note">Заявка рассматривается (~${Math.max(1, b.lic.finWait - s.turn)} нед.)</p>` : `<p class="small">Без лицензии банк почти ничего не зарабатывает.</p><button class="btn wide" id="licF">Подать заявку — ${E.short(B.licCost(s, 'fin'))} ₽</button><button class="btn wide danger" id="licF2">«Ускорить» — ${E.short(B.licCost(s, 'fin') * 2)} ₽</button>`}</div>`;
  if (tab === 'war' && typeof EXT !== 'undefined') body = EXT.warHtml(s, b);
  if (tab === 'hr' && typeof EXT !== 'undefined') body = EXT.hrHtml(s, b);
  const tabs = [['main', 'Обзор'], ['staff', 'Сотрудники'], ['hr', 'HR-отдел'], ['war', 'Конкуренты'], ['assets', 'Объекты']].concat(I.factory ? [['prod', 'Производство и контракты']] : []).concat(I.lic === 'fin' ? [['lic', 'Лицензия']] : []);
  U.big(`${U.head('factory', UI.esc(b.n), UI.esc(I.n) + ' · ' + b.months + ' мес. · ' + (b.lastProfit >= 0 ? 'прибыль ' : 'убыток ') + E.money(b.lastProfit) + '/мес')}
    <div class="bsel">${s.biz.map(x => `<button data-b="${x.id}" class="${x.id === b.id ? 'on' : ''}">${UI.esc(x.n)}</button>`).join('')}<button data-new="1">${UI.ic('plus')} Новый бизнес</button></div>
    ${U.tabs('bTabs', tabs, tab)}<div class="bbody">${body}</div>`);
  const re = t => U.biz(b.id, t || tab);
  $$('#modal [data-b]').forEach(x => x.onclick = () => U.biz(x.dataset.b, 'main'));
  if ($('#modal [data-new]')) $('#modal [data-new]').onclick = () => U.bizNew();
  $$('#bTabs button').forEach(x => x.onclick = () => U.biz(b.id, x.dataset.t));
  if ($('#bPrice')) $('#bPrice').oninput = e => $('#pv').textContent = e.target.value + '%';
  if ($('#bSave')) $('#bSave').onclick = () => { b.price = +$('#bPrice').value / 100; b.mkt = Math.max(0, +$('#bMkt').value || 0); UI.save(); UI.toast('Применено'); };
  if ($('#bUp')) $('#bUp').onclick = () => U.res(B.upgrade(s, b.id), () => re());
  if ($('#bBr')) $('#bBr').onclick = () => U.res(B.branch(s, b.id), () => re());
  if ($('#bOwn')) $('#bOwn').onclick = () => U.res(B.buyOwn(s, b.id), () => re());
  if ($('#bSell')) $('#bSell').onclick = () => { if (confirm('Продать «' + b.n + '»?')) { UI.closeModal(); U.res(B.sell(s, b.id)); } };
  $$('#modal [data-sal]').forEach(x => x.onclick = () => { const [i, k] = x.dataset.sal.split('|'); B.setSal(s, b.id, +i, +k); UI.save(); re(); });
  $$('#modal [data-fire]').forEach(x => x.onclick = () => U.res(B.fire(s, b.id, +x.dataset.fire), () => re()));
  $$('#modal [data-hire]').forEach(x => x.onclick = () => U.res(B.hire(s, b.id, U._cands[+x.dataset.hire]), () => re()));
  $$('#modal [data-asset]').forEach(x => x.onclick = () => U.res(B.buyAsset(s, b.id, x.dataset.asset), () => re()));
  $$('#modal [data-line]').forEach(x => x.onclick = () => { const [l, p] = x.dataset.line.split('|'); const r = B.setLine(s, b.id, l, p); if (r) UI.toast(r.title, r.ok ? '' : 'bad'); UI.save(); re(); });
  if ($('#licF')) $('#licF').onclick = () => U.res(B.license(s, b.id, 'fin', false), () => re());
  if ($('#licF2')) $('#licF2').onclick = () => U.res(B.license(s, b.id, 'fin', true), () => re());
  if ($('#licA')) $('#licA').onclick = () => U.res(B.license(s, b.id, 'mil', false), () => re());
  if ($('#licB')) $('#licB').onclick = () => U.res(B.license(s, b.id, 'mil', true), () => re());
  $$('#modal [data-sign]').forEach(x => x.onclick = () => U.res(B.sign(s, b.id, +x.dataset.sign), () => re()));
  if (typeof EXT !== 'undefined') EXT.bindBiz(s, b, re);
};
U.bizNew = () => {
  const s = UI.s;
  U.big(`${U.head('factory', E.ww2(s) ? 'Открыть артель' : 'Открыть бизнес', E.ww2(s) ? 'Частное предпринимательство запрещено — разрешены артели' : 'Выберите отрасль. Производство и военный сектор — дорогие, но очень прибыльные.')}
    ${s.biz.length ? `<div class="bsel">${s.biz.map(x => `<button data-b="${x.id}">${UI.esc(x.n)}</button>`).join('')}</div>` : ''}
    <label class="nm">Название<input id="bName" maxlength="40" placeholder="Своё название (необязательно)"></label>
    <p class="bwarn">Бизнес — это не быстро: первые 6–12 месяцев клиентов мало (клиентская база растёт от рекламы и качества), часто выходит в минус. Держите запас денег на зарплаты и аренду. Если вы ещё и работаете по найму — на бизнес остаётся меньше сил.</p>
    <div class="inds">${B.IND(s).map(I => { const cost = B.money(s, I.start); const lack = I.req && Object.keys(I.req).find(k => E.sk(s, k) < I.req[k]); return `<div class="fi ind ${I.illegal ? 'ill' : ''}"><b>${I.n}</b><small>Старт: ${E.money(cost)} · выручка ~${E.short(B.money(s, I.rev))}/мес · ${I.staff} чел. на уровень${I.factory ? ' · завод' : ''}${I.lic ? ' · нужна лицензия на продажу' : ''}</small><small>Например: ${UI.esc(I.ex)}</small>${lack ? `<small class="neg">${D.SKILLS[lack]}: нужно ${I.req[lack]}</small>` : ''}<button class="btn small primary" data-ind="${I.id}" ${lack || s.st.money < cost ? 'disabled' : ''}>${s.st.money < cost ? 'Не хватает денег' : 'Открыть'}</button></div>`; }).join('')}</div>`);
  $$('#modal [data-b]').forEach(x => x.onclick = () => U.biz(x.dataset.b));
  $$('#modal [data-ind]').forEach(x => x.onclick = () => { if (UI.s.ap <= 0) { UI.toast('На этой неделе сил больше нет', 'bad'); return; } UI.s.ap--; const r = B.create(s, x.dataset.ind, $('#bName').value.trim()); UI.appendMsg({ k: 'me', t: 'Открываю бизнес' }); U.res(r, () => { if (r.ok !== false && s.biz.length) U.biz(s.biz[s.biz.length - 1].id); }); });
};

// ============================================================================
//  КРИМИНАЛ
// ============================================================================
U.crime = () => {
  const s = UI.s, C = L.crimeInit(s), w = L.wanted(s);
  const rng = (v, k) => { const e = Math.max(0.12, 0.45 - C.cred / 220) * k; return [Math.round(v * (1 - e)), Math.round(v * (1 + e))]; };
  const need = [15, 32, 52, 72, 90, 100][C.rank];
  const prob = C.heat >= 70 ? 'очень проблемный' : C.heat >= 45 ? 'проблемный' : C.heat >= 20 ? 'на заметке' : 'не на радаре';
  U.big(`${U.head('bolt', 'Тёмная сторона', C.on ? (C.gang ? 'Банда «' + UI.esc(C.gang) + '» · ' + D.CRIME_RANKS[C.rank] : 'Одиночка') : 'Вы пока чисты', [['Честная работа', 'U.hh()', 'brief']])}
  <div class="crime">
    <div class="cgrid">
      <div class="cbox"><h5>Положение</h5>
        <div class="kv"><span>Банда</span><b>${C.gang ? UI.esc(C.gang) : 'нет'}</b></div>
        <div class="kv"><span>Ранг</span><b>${D.CRIME_RANKS[C.rank]}</b></div>
        <div class="kv"><span>Авторитет до повышения</span><b>${Math.round(C.cred)} / ${need}</b></div>${UI.bar(C.cred / need * 100, 'good')}
        <div class="kv"><span>Дел провёрнуто</span><b>${C.acts}</b></div></div>
      <div class="cbox"><h5>Полиция</h5>
        <div class="kv"><span>Розыск</span><b class="stars">${'★'.repeat(w)}${'☆'.repeat(5 - w)}</b></div>
        <div class="kv"><span>Насколько вы проблемный</span><b class="${C.heat >= 45 ? 'neg' : ''}">${prob} (${Math.round(C.heat)})</b></div>${UI.bar(C.heat, C.heat > 45 ? 'bad' : '')}
        <div class="kv"><span>Подкупность ${E.ww2(s) ? 'милиции' : 'полиции'}</span><b>${C.corr}%</b></div>
        <div class="kv"><span>Прикормлено</span><b>${Math.round(C.bribe)}%</b></div></div>
      <div class="cbox"><h5>Деньги</h5>
        <div class="kv"><span>Доход за месяц</span><b class="pos">${E.money(C.income)}</b></div>
        <div class="kv"><span>Всего заработано</span><b>${E.money(C.total)}</b></div>
        <div class="kv"><span>Шанс облавы в месяц</span><b>${Math.round(w * 5 * E.dif(s).bad * (1 - C.bribe / 150))}%</b></div></div>
    </div>
    <h4>Конкуренты <small>(цифры примерные — точных данных нет)</small></h4>
    <table class="tbl"><tr><th>Банда</th><th>Лидер</th><th>Людей</th><th>Доход в месяц</th><th>Территория</th><th>Агрессия</th><th>Связи в полиции</th></tr>
      ${C.comp.map(g => { const sz = rng(g.size, 1), inc = rng(g.inc, 1.3); return `<tr class="${g.n === C.gang ? 'mine' : ''}"><td>${UI.esc(g.n)}${g.n === C.gang ? ' <small>(ваши)</small>' : ''}</td><td>${UI.esc(g.leader)}</td><td>${g.n === C.gang ? g.size : '~' + sz[0] + '–' + sz[1]}</td><td>${g.n === C.gang ? E.money(g.inc) : '~' + E.short(inc[0]) + '–' + E.short(inc[1])}</td><td>${g.terr}%</td><td>${g.aggr > 65 ? 'высокая' : g.aggr > 40 ? 'средняя' : 'низкая'}</td><td>${g.cops > 55 ? 'крепкие' : g.cops > 30 ? 'есть' : 'слабые'}</td></tr>`; }).join('')}</table>
    <h4>Что можно сделать</h4><div class="chips">${['Вступаю в банду', 'Иду на мелкую кражу', 'Ограбление', 'Крышуем ларьки на рынке', 'Контрабанда', 'Мошенническая схема', 'Наезд на конкурентов', 'Дать взятку полиции', 'Залечь на дно', 'Завязать с криминалом'].map(t => `<button data-fill="${t}">${t}</button>`).join('')}</div>
    <h4>История</h4><ul class="news">${C.hist.slice().reverse().slice(0, 12).map(h => `<li>${UI.esc(h)}</li>`).join('') || '<li><small>Пока пусто.</small></li>'}</ul>
    <p class="small">Это игра: всё вымышлено. Криминал быстро даёт деньги, но копит розыск — облава заканчивается сроком.</p>
  </div>`);
  $$('#modal [data-fill]').forEach(b => b.onclick = () => { UI.closeModal(); UI.fill(b.dataset.fill); });
};

// ============================================================================
//  ГАЗЕТА
// ============================================================================
U.paper = (idx) => {
  const s = UI.s, ps = s.papers || [];
  s.unread = 0; UI.top();
  if (!ps.length) { UI.modal(`${U.head('book', 'Газета')}<p class="note" style="padding:16px">Свежий номер выйдет на следующей неделе.</p>`); return; }
  idx = idx === undefined ? ps.length - 1 : idx;
  const p = ps[idx];
  const lastCity = ps.map((x, i) => [x, i]).filter(x => x[0].kind === 'city').pop(), lastWorld = ps.map((x, i) => [x, i]).filter(x => x[0].kind === 'world').pop();
  U.big(`<div class="paper">
    <div class="ptop"><div class="pbtns">${lastCity ? `<button class="${p.kind === 'city' ? 'on' : ''}" data-p="${lastCity[1]}">Городская газета</button>` : ''}${lastWorld ? `<button class="${p.kind === 'world' ? 'on' : ''}" data-p="${lastWorld[1]}">Мировое обозрение (месяц)</button>` : ''}</div><button class="close" onclick="UI.closeModal()">${UI.ic('x')}</button></div>
    <div class="pmast"><h2>${UI.esc(p.name)}</h2><div class="pmeta"><span>№ ${p.no}</span><span>${E.dateStr(p.d)}</span><span>${p.kind === 'world' ? 'Выходит раз в месяц' : 'Еженедельная газета'}</span></div></div>
    <div class="pcols">${p.arts.map((a, i) => `<article class="${a.big ? 'lead' : ''} ${a.small ? 'sm' : ''}"><h5>${UI.esc(a.h)}</h5><p>${UI.esc(a.t)}</p></article>`).join('')}</div>
    <div class="parch"><small>Архив:</small>${ps.map((x, i) => `<button data-p="${i}" class="${i === idx ? 'on' : ''}">${x.kind === 'world' ? '🌍' : '📰'} ${E.dateStr(x.d).replace(/ \d{4}$/, '')}</button>`).reverse().slice(0, 16).join('')}</div>
  </div>`);
  $$('#modal [data-p]').forEach(b => b.onclick = () => U.paper(+b.dataset.p));
};

// ============================================================================
//  ЛЮДИ
// ============================================================================
U.people = () => {
  const s = UI.s; L.npcSync(s);
  const sp = s.rel.find(r => r.role === 'супруг(а)' || r.role === 'партнёр');
  const look = n => ({ sex: n.sex, look: L.hash(n.name) % 9999 });
  U.big(`${U.head('user', 'Близкие люди', 'Друзья, семья и соседи — они живут своей жизнью и помнят, что вы для них сделали')}
  <div class="people">${(s.npcs || []).map(n => `<div class="npc ${n.alive ? '' : 'dead'}">
      <div class="nh">${UI.avatar(look(n), 64)}<div><b>${UI.esc(n.name)}</b><small>${UI.esc(n.role)} · ${E.years(n.age)}${n.alive ? '' : ' · †'}</small><small>${UI.esc(n.d || '')}</small></div></div>
      <div class="kv"><span>Характер</span><b>${UI.esc(n.trait)}</b></div>
      <div class="kv"><span>Чем занят</span><b>${UI.esc(n.job || '—')}</b></div>
      <div class="kv"><span>Семья</span><b>${n.married ? 'в браке' : 'один'}${n.kids ? ', детей: ' + n.kids : ''}</b></div>
      <div class="kv"><span>Отношение к вам</span><b>${Math.round(n.att)}</b></div>${UI.bar(n.att, n.att > 65 ? 'good' : n.att < 30 ? 'bad' : '')}
      <div class="nhist">${n.hist.slice().reverse().slice(0, 6).map(h => `<span>${UI.esc(h)}</span>`).join('')}</div>
      ${n.alive ? `<div class="nbtn"><button class="btn small" data-fill="Звоню ${UI.esc(n.name)}, болтаем обо всём">Позвонить</button><button class="btn small" data-fill="Встречаюсь с ${UI.esc(n.name)}, гуляем и вспоминаем старое">Встретиться</button><button class="btn small" data-gift="${n.id}">Помочь деньгами</button><button class="btn small" data-fill="Прошу ${UI.esc(n.name)} помочь мне: ">Попросить о помощи</button></div>` : ''}
    </div>`).join('')}
    <div class="npc fam"><h4>Семья</h4>
      ${s.rel.filter(r => ['мать', 'отец'].includes(r.role)).map(r => `<div class="kv"><span>${UI.esc(r.name)} <small>${r.role}</small></span>${UI.bar(r.att)}</div>`).join('')}
      ${sp ? `<div class="kv"><span>${UI.esc(sp.name)} <small>${sp.role}</small></span>${UI.bar(sp.att, 'good')}</div>` : '<p class="small">Пары нет. Можно познакомиться: «иду на свидание», «знакомлюсь в парке».</p>'}
      ${(s.kids || []).map(k => `<div class="kv"><span>${UI.esc(k.name)} <small>${k.sex === 'm' ? 'сын' : 'дочь'}, ${E.years(Math.max(0, L.kidAge(s, k)))}</small></span>${UI.bar(k.att || 70, 'good')}</div>`).join('')}
    </div></div>`);
  $$('#modal [data-fill]').forEach(b => b.onclick = () => { UI.closeModal(); UI.fill(b.dataset.fill); });
  $$('#modal [data-gift]').forEach(b => b.onclick = () => {
    const n = L.npc(s, b.dataset.gift); const sum = Math.round(E.m(s, 10000));
    if (s.st.money < sum) { UI.toast('Не хватает денег', 'bad'); return; }
    s.st.money -= sum; n.att = E.clamp(n.att + 8, 0, 100); n.hist.push('вы помогли деньгами (' + E.monthStr(s.date) + ')'); L.npcSync(s);
    UI.appendMsg({ k: 'out', ok: true, title: 'Помогли ' + L.gen(n.name).replace(/и$|ы$/, 'е').replace(/а$/, 'у'), lines: ['−' + E.money(sum), n.name + ': отношение +8'] });
    UI.save(); UI.renderAll(); U.people();
  });
};
// событие с другом
U.npcEvent = e => new Promise(res => {
  const s = UI.s, ev = L.npcEvent(s, e), n = L.npc(s, e.npc);
  UI.modal(`<div class="ev"><div class="evpic ev-friend">${UI.avatar({ sex: n.sex, look: L.hash(n.name) % 9999 }, 84)}</div><h3>${UI.esc(ev.t)}</h3><p>${UI.esc(ev.x)}</p><div class="eopts">${ev.opts.map((o, i) => `<button class="eopt" data-i="${i}"><b>${UI.esc(o.n)}</b>${o.roll ? `<span class="roll">${UI.ic('dice')} шанс ${E.chance(s, 100 - o.roll.diff, o.roll.sk)}%</span>` : ''}<small>${o.att ? (o.att > 0 ? n.name + ' оценит' : n.name + ' обидится') : ''}</small></button>`).join('')}</div></div>`);
  if (typeof NET !== 'undefined') NET.autoPick();
  $$('#modal .eopt').forEach(b => b.onclick = () => {
    const r = L.npcResolve(s, e, +b.dataset.i); UI.closeModal(); if (r.roll && typeof SFX !== 'undefined') SFX.play(r.ok ? 'good' : 'bad', true);
    const lg = s.log[s.log.length - 1]; if (lg && lg.kind === 'event') { lg.x = ev.t + '. ' + ev.x; }
    UI.appendMsg({ k: 'out', title: ev.t + ': ' + ev.opts[+b.dataset.i].n.toLowerCase(), x: ev.x, ok: r.ok, lines: r.lines, roll: r.roll ? { roll: r.roll.roll, chance: r.roll.chance } : null });
    UI.renderAll(); res();
  });
});

// ============================================================================
//  ПРОВИНЦИЯ · РЕГИОН · СТРАНА (три панели на карте)
// ============================================================================
U.h = (i, k) => (L.hash(i, k) % 10000) / 10000;
U.CLIM = (lat, coast) => { const a = Math.abs(lat); return a > 66 ? 'арктический' : a > 58 ? 'субарктический' : a > 44 ? (coast ? 'умеренный морской' : 'умеренно-континентальный') : a > 32 ? (coast ? 'средиземноморский/субтропический' : 'засушливый континентальный') : a > 23 ? 'субтропический' : 'тропический'; };
U.provStats = (i) => {
  const s = UI.s, m = M(), W = s.world, p = m.provinces[i], o = W.own[i], C = W.cs[o];
  const key = i + ':' + W.month + ':' + o;
  if (U._pc && U._pc.key === key) return U._pc.v;
  // доля провинции в населении и ВВП владельца
  let sw = 0, sg = 0;
  const ww = E.ww2(s);
  W.own.forEach((x, j) => { if (x !== o) return; const q = m.provinces[j]; const pm = m.countries[q.c].st.pop * (q.w || 0); const urb = Math.min(1, (q.u || 0) / Math.max(1, pm * 1e6)); sw += pm; sg += pm * (0.55 + urb * (ww ? 0.8 : 1.2) + (q.cap ? 0.4 : 0)); });
  const pm = m.countries[p.c].st.pop * (p.w || 0);
  const urb = Math.min(0.97, (p.u || 0) / Math.max(1, pm * 1e6));
  const pop = C.st.pop * pm / Math.max(sw, 1e-9);
  const gdp = C.st.gdp * pm * (0.55 + urb * (ww ? 0.8 : 1.2) + (p.cap ? 0.4 : 0)) / Math.max(sg, 1e-9);
  const pc = gdp * 1e9 / Math.max(1, pop * 1e6);
  const giniBase = { ZA: 0.63, BR: 0.52, US: 0.41, RU: 0.36, CN: 0.38, DE: 0.31, SE: 0.29, IN: 0.35, MX: 0.45, NO: 0.27, FI: 0.27, JP: 0.33, GB: 0.35, FR: 0.31, TR: 0.42, NG: 0.35, KZ: 0.29, UA: 0.26, BY: 0.25 }[C.iso] || (ww ? 0.42 : 0.37);
  const gini = E.clamp(giniBase + (p.cap ? 0.04 : 0) + (urb - 0.5) * 0.05 + (U.h(i, 'g') - 0.5) * 0.04, 0.22, 0.7);
  const top10 = 0.12 + gini * 0.62;
  const pcNoRich = pc * (1 - top10) / 0.9;
  const hd = pc > 0 ? 1 - Math.exp(-pc / (ww ? 3500 : 14000)) : 0;
  const wage = pc * (ww ? 0.5 : 0.42) / 12;
  const lat = p.lat || 50;
  const coast = !!p.sea;
  const unemp = E.clamp(C.st.unemp * (0.7 + (1 - urb) * 0.6 + (U.h(i, 'u') - 0.5) * 0.4), 0.3, 60);
  const life = E.clamp((ww ? 38 : 55) + hd * (ww ? 26 : 28) + (U.h(i, 'l') - 0.5) * 4, 30, 86);
  const resList = (p.r || []).map(r => (window.RESN || {})[r] || r);
  const sectors = (() => { const ag = E.clamp((1 - urb) * (ww ? 70 : 32) + (p.r || []).filter(x => ['grain', 'cattle', 'rice', 'maize', 'soy', 'sunf', 'beet', 'potato', 'fruit', 'cott', 'coff', 'tea', 'sheep'].includes(x)).length * 4, 2, 80); const ind = E.clamp((ww ? 22 : 24) + (p.r || []).filter(x => ['oil', 'gas', 'coal', 'iron', 'nick', 'copp', 'gold', 'alum', 'diam'].includes(x)).length * 6, 8, 65); return [Math.round(ag), Math.round(ind), Math.max(5, 100 - Math.round(ag) - Math.round(ind))]; })();
  const lms = m.landmarks.filter(l => Math.hypot(l.x - p.x, l.y - p.y) < Math.sqrt(p.a) * 0.8);
  const v = { p, o, C, pop, gdp, pc, pcNoRich, gini, top10, wage, urb, unemp, life, hd, lat, coast, resList, sectors, lms,
    dens: pop * 1e6 / Math.max(1, p.km || 1), poverty: E.clamp(gini * 60 - hd * 30 + unemp * 0.6, 1, 75),
    edu: E.clamp((ww ? 3 : 18) + urb * (ww ? 12 : 22) + hd * (ww ? 6 : 14) + (p.cap ? 8 : 0), 1, 60),
    crime: E.clamp(20 + gini * 60 + unemp * 1.5 - hd * 15 + (U.h(i, 'c') - 0.5) * 15, 3, 95),
    infra: E.clamp(hd * 80 + urb * 20 - (Math.abs(lat) > 62 ? 25 : 0), 4, 99), net: ww ? 0 : E.clamp(hd * 85 + urb * 15, 10, 99),
    birth: E.clamp((ww ? 30 : 9) + (1 - hd) * (ww ? 15 : 22) + (U.h(i, 'b') - 0.5) * 3, 6, 48),
    tJan: Math.round(28 - Math.abs(lat) * 0.85 - (coast ? -4 : 6) * (Math.abs(lat) > 35 ? 1 : 0.3) + (lat < 0 ? 18 : 0)), tJul: Math.round(34 - Math.abs(lat) * 0.32 + (coast ? -2 : 1) - (lat < 0 ? 12 : 0)),
  };
  U._pc = { key, v };
  return v;
};
U.politics = (i, v) => {
  const s = UI.s, W = s.world, C = v.C, home = W.home;
  const ww = E.ww2(s), P = D.PARTIES[E.EV(s)];
  const one = /диктатур|Коммунист|хунта|Империя|теократ|Марионеточ|Шахск|режим/i.test(C.st.gov || '');
  const war = WD.enemies(s, v.o).length > 0, occ = (W.core || W.own)[i] !== v.o;
  const h = k => U.h(i, k);
  let sup = {
    gov: 30 + C.st.stab * 0.4 - v.unemp * 0.6 + (v.p.cap ? 4 : 0) + (h('a') - 0.5) * 12,
    left: 8 + v.gini * 30 + v.unemp * 0.8 + (1 - v.hd) * 10 + (h('b') - 0.5) * 8,
    nat: 6 + (war ? 10 : 0) + (1 - v.urb) * 8 + (h('c') - 0.5) * 8,
    lib: 3 + v.urb * 14 + v.hd * 10 + v.edu * 0.2 + (h('d') - 0.5) * 6,
    green: 1 + v.hd * 7 + v.urb * 4 + (h('e') - 0.5) * 3,
    reg: 1 + (h('f') > 0.82 ? 14 * h('g') : 2) + (occ ? 12 : 0),
  };
  for (const k in sup) sup[k] = Math.max(0.5, sup[k]);
  const tot = Object.values(sup).reduce((a, b) => a + b, 0);
  for (const k in sup) sup[k] = sup[k] / tot * 100;
  const axis = { econ: E.clamp(50 - (sup.left - sup.lib) * 0.9 + (h('x') - 0.5) * 10, 3, 97), auth: E.clamp(50 + (sup.gov + sup.nat - sup.lib - sup.green) * 0.5, 3, 97), trad: E.clamp(40 + (1 - v.urb) * 35 + sup.nat * 0.4 - v.edu * 0.4, 3, 97), center: E.clamp(80 - sup.reg * 2.5 - (occ ? 30 : 0), 3, 97) };
  const mov = [];
  if (v.unemp > 9) mov.push('Профсоюзное движение');
  if (war) mov.push(ww ? 'Движение помощи фронту' : 'Антивоенные настроения');
  if (sup.reg > 12) mov.push('Движение за автономию');
  if (!ww && v.hd > 0.7 && v.urb > 0.5) mov.push('Экоактивисты');
  if (C.st.stab < 35) mov.push('Протестные митинги');
  if (ww && C.id === '643') mov.push('Стахановское движение');
  if (ww && v.urb < 0.3) mov.push(C.id === '643' ? 'Скрытое недовольство коллективизацией' : 'Крестьянские союзы');
  if (!ww && v.urb > 0.6) mov.push('Волонтёрское движение');
  if (h('r') > 0.7) mov.push('Религиозное возрождение');
  if (!mov.length) mov.push('Спокойно, крупных движений нет');
  const res = v.p.r || [];
  const path = occ ? 'Оккупированная территория' : war && WD.enemies(s, v.o).some(e => M().provinces[i].nb.some(n => W.own[n] === e)) ? 'Прифронтовая зона' : v.p.cap ? 'Столичный регион — центр власти и денег' : res.some(r => ['oil', 'gas', 'coal', 'gold', 'diam', 'nick', 'iron', 'copp'].includes(r)) ? 'Сырьевой регион: живёт добычей' : v.urb > 0.6 && v.edu > (ww ? 8 : 28) ? (ww ? 'Промышленный центр' : 'Научно-технологический хаб') : res.includes('tour') ? 'Курортный регион' : v.urb < 0.25 ? (v.hd < 0.4 ? 'Депрессивная глубинка: молодёжь уезжает' : 'Аграрная провинция') : 'Индустриальный регион';
  const trust = E.clamp(C.st.stab * 0.8 + (h('t') - 0.5) * 20 - (occ ? 40 : 0), 2, 95);
  const protest = E.clamp(100 - C.st.stab - (one ? 25 : 0) + v.unemp + (h('p') - 0.5) * 15, 1, 90);
  const migr = Math.round((v.hd - 0.45) * 20 + (v.p.cap ? 6 : 0) + (occ ? -15 : 0) + (h('m') - 0.5) * 6);
  return { sup, P, one, axis, mov, path, trust, protest, migr, occ };
};
U.provPanels = i => {
  const s = UI.s, el = $('#pstack');
  if (i < 0) { el.classList.add('hidden'); return; }
  const v = U.provStats(i), pol = U.politics(i, v), C = v.C, ww = E.ww2(s);
  const usd = x => '$' + Math.round(x).toLocaleString('ru-RU');
  const rub = x => E.ww2(s) ? '' : ' (~' + E.short(x * 90) + ' ₽)';
  const kv = (k, val, cls) => `<div class="kv"><span>${k}</span><b class="${cls || ''}">${val}</b></div>`;
  const ax = (a, b, val) => `<div class="axis"><small>${a}</small><i><i style="left:${val}%"></i></i><small>${b}</small></div>`;
  el.innerHTML = `
  <div class="pcard pc1"><button class="close" onclick="MAP.select(-1)">${UI.ic('x')}</button><div class="flagbar" style="background:${C.col}"></div>
    <h3>${C.cap === i ? '★ ' : ''}${UI.esc(v.p.n)}</h3><small>Провинция · ${UI.esc(C.n)}${pol.occ ? ' · <span class="neg">оккупирована</span>' : ''}</small>
    <div class="pgrid">
      ${kv('Население', UI.pop(v.pop))}${kv('Плотность', Math.round(v.dens) + ' чел/км²')}
      ${kv('Площадь', Math.round(v.p.km || 0).toLocaleString('ru-RU') + ' км²')}${kv('Горожане', Math.round(v.urb * 100) + '%')}
      ${kv('ВВП провинции', UI.gdp(s, v.gdp))}${kv('ВВП на душу', usd(v.pc))}
      ${kv('…без 10% богатых', usd(v.pcNoRich))}${kv('Доля 10% богатых', Math.round(v.top10 * 100) + '% доходов')}
      ${kv('Средняя зарплата', usd(v.wage) + '/мес' + rub(v.wage))}${kv('Безработица', UI.num(v.unemp) + '%')}
      ${kv('Бедность', Math.round(v.poverty) + '%')}${kv('Неравенство (Джини)', UI.num(v.gini, 2))}
      ${kv('Продолж. жизни', Math.round(v.life) + ' лет')}${kv('Рождаемость', UI.num(v.birth) + '‰')}
      ${kv('С высшим образованием', Math.round(v.edu) + '%')}${kv('Преступность', Math.round(v.crime) + '/100')}
      ${kv('Инфраструктура', Math.round(v.infra) + '/100')}${ww ? kv('Электрификация', Math.round(v.infra * 0.7) + '%') : kv('Интернет', Math.round(v.net) + '%')}
      ${kv('Климат', U.CLIM(v.lat, v.coast))}${kv('Январь / июль', (v.tJan > 0 ? '+' : '') + v.tJan + '° / +' + v.tJul + '°')}
    </div>
    <div class="sect"><small>Экономика:</small><span class="bar3"><i style="width:${v.sectors[0]}%;background:#9fbf86" title="сельское хозяйство"></i><i style="width:${v.sectors[1]}%;background:#c9a27a" title="промышленность"></i><i style="width:${v.sectors[2]}%;background:#8fb8e3" title="услуги"></i></span><small>аграрн. ${v.sectors[0]}% · пром. ${v.sectors[1]}% · услуги ${v.sectors[2]}%</small></div>
    <div class="res"><small>Природные ресурсы:</small>${v.resList.map(r => `<span>${UI.esc(r)}</span>`).join('')}</div>
    ${(v.p.ct || []).length ? `<div class="res"><small>Города:</small>${v.p.ct.map(c => `<span>${UI.esc(c[0])} · ${c[1] >= 1e6 ? UI.num(c[1] / 1e6) + ' млн' : Math.round(c[1] / 1000) + ' тыс.'}</span>`).join('')}</div>` : ''}
    ${v.lms.length ? `<div class="res"><small>Достопримечательности:</small>${v.lms.map(l => `<span>${UI.esc(l.n)}</span>`).join('')}</div>` : ''}
  </div>
  <div class="pcard pc2"><h4>Регион: общество и политика</h4>
    ${pol.one ? `<p class="small">${UI.esc(C.st.gov)}: открытой политической конкуренции нет. Ниже — скрытые симпатии жителей по опросам и донесениям.</p>` : ''}
    <div class="parties">${pol.P.map(p => `<div class="pp"><span>${UI.esc(p.n)}</span><i><i style="width:${pol.sup[p.id]}%;background:${p.c}"></i></i><b>${Math.round(pol.sup[p.id])}%</b></div>`).join('')}</div>
    <h5>Взгляды</h5>${ax('левые', 'правые', pol.axis.econ)}${ax('свобода', 'порядок', pol.axis.auth)}${ax('прогресс', 'традиции', pol.axis.trad)}${ax('регионализм', 'за центр', pol.axis.center)}
    <div class="pgrid">${kv('Путь развития', UI.esc(pol.path))}${kv('Индекс развития', UI.num(v.hd, 2))}${kv('Доверие властям', Math.round(pol.trust) + '%')}${kv('Протестность', Math.round(pol.protest) + '%')}${kv('Миграция', (pol.migr >= 0 ? 'приток +' : 'отток ') + Math.abs(pol.migr) + '‰ в год', pol.migr >= 0 ? 'pos' : 'neg')}</div>
    <div class="res"><small>Движения:</small>${pol.mov.map(m => `<span>${UI.esc(m)}</span>`).join('')}</div>
  </div>
  <div class="pcard pc3"><div class="ch"><i style="background:${C.col}"></i><b>${UI.esc(C.n)}</b></div><small>${UI.esc(C.st.gov || '')}${C.st.lead ? ' · ' + UI.esc(C.st.lead) : ''}</small>
    <div class="pgrid">${kv('ВВП', UI.gdp(s, C.st.gdp) + ' ' + UI.chg(C.h.gdp, 12))}${kv('Население', UI.pop(C.st.pop))}${kv('Стабильность', Math.round(C.st.stab) + '%')}${kv('Инфляция', UI.num(C.st.infl) + '%')}${kv('Армия', Math.round(C.st.army).toLocaleString('ru-RU') + ' тыс.')}${kv('Мощь', Math.round(E.power(s, v.o)))}</div>
    <button class="btn small wide" id="pcMore">${UI.ic('globe')} Вся статистика страны</button>
  </div>`;
  el.classList.remove('hidden');
  $('#pcMore').onclick = () => UI.country(v.o);
};

// ============================================================================
//  МАСШТАБ, ПАНЕЛЬ КНОПОК, МНОГО НЕДЕЛЬ
// ============================================================================
U.ZOOM_KEY = 'sudba_zoom2';
U.zoom = () => { let z = 0.95; try { z = +localStorage.getItem(U.ZOOM_KEY) || 0.95; } catch (e) { } return z; };
U.applyZoom = z => { z = z || U.zoom(); document.documentElement.style.setProperty('--uiz', z); document.body.style.zoom = z; if (window.MAP && MAP.vb) { MAP.clampVb(); MAP.apply(); } };
// ---------- настройки интерфейса: масштаб, ширина панелей, шрифт чата, подписи карты ----------
U.UI_KEY = 'sudba_ui';
U.UIDEF = { lw: 0, cw: 0, chatFs: 0, labels: 100 }; // 0 = авто
U.ui = () => { let o = {}; try { o = JSON.parse(localStorage.getItem(U.UI_KEY) || '{}'); } catch (e) { } return Object.assign({}, U.UIDEF, o); };
U.setUi = (k, v) => { const o = U.ui(); o[k] = v; try { localStorage.setItem(U.UI_KEY, JSON.stringify(o)); } catch (e) { } U.applyUI(); };
U.applyUI = () => {
  const o = U.ui(), b = document.body, r = document.documentElement.style;
  b.classList.toggle('lay', !!(o.lw || o.cw)); b.classList.toggle('chatfs', !!o.chatFs);
  r.setProperty('--lw', (o.lw || 300) + 'px'); r.setProperty('--cw', (o.cw || 410) + 'px'); r.setProperty('--chatfs', (o.chatFs || 14.5) + 'px');
  if (window.MAP) { MAP.labelK = (o.labels || 100) / 100; if (MAP.gCountry) MAP.sizeLabels(); }
  U.applyZoom();
};
U.settings = () => {
  const o = U.ui(), z = Math.round(U.zoom() * 100);
  const row = (id, label, min, max, step, val, unit, auto) => `<div class="setrow"><span>${label}</span><input type="range" id="${id}" min="${min}" max="${max}" step="${step}" value="${val || (auto || min)}"><b id="${id}V">${val ? val + unit : 'авто'}</b>${auto ? `<button class="btn small" data-auto="${id}">Авто</button>` : ''}</div>`;
  UI.modal(`<div class="menu settings"><h3>Настройки интерфейса</h3>
    <div class="setrow"><span>Масштаб всего</span><input type="range" id="sZ" min="70" max="150" step="5" value="${z}"><b id="sZV">${z}%</b></div>
    <div class="zoomsel"><span>Быстро:</span>${[80, 90, 95, 100, 110, 125].map(v => `<button class="${v === z ? 'on' : ''}" data-z="${v}">${v}%</button>`).join('')}</div>
    ${row('sLW', 'Левая панель', 220, 440, 10, o.lw, ' px', 300)}
    ${row('sCW', 'Нейрочат (ширина)', 300, 640, 10, o.cw, ' px', 410)}
    ${row('sFS', 'Текст в чате', 12, 20, 0.5, o.chatFs, ' px', 14.5)}
    <div class="setrow"><span>Названия стран на карте</span><input type="range" id="sLB" min="50" max="160" step="10" value="${o.labels}"><b id="sLBV">${o.labels}%</b></div>
    <p class="small">Горячие клавиши: Ctrl + «+» / Ctrl + «−» — масштаб, Ctrl + 0 — сбросить. Всё запоминается.</p>
    <div class="row2"><button class="btn" id="sReset">Сбросить всё</button><button class="btn primary" id="sOk">Готово</button></div></div>`);
  const bind = (id, k, unit, fmt) => { const el = $('#' + id); el.oninput = () => { $('#' + id + 'V').textContent = (fmt ? fmt(+el.value) : el.value) + unit; U.setUi(k, +el.value); }; };
  $('#sZ').oninput = () => { $('#sZV').textContent = $('#sZ').value + '%'; U.setZoom(+$('#sZ').value / 100); };
  $$('#modal [data-z]').forEach(b => b.onclick = () => { U.setZoom(+b.dataset.z / 100); U.settings(); });
  bind('sLW', 'lw', ' px'); bind('sCW', 'cw', ' px'); bind('sFS', 'chatFs', ' px'); bind('sLB', 'labels', '%');
  $$('#modal [data-auto]').forEach(b => b.onclick = () => { U.setUi({ sLW: 'lw', sCW: 'cw', sFS: 'chatFs' }[b.dataset.auto], 0); U.settings(); });
  $('#sReset').onclick = () => { try { localStorage.removeItem(U.UI_KEY); } catch (e) { } U.setZoom(0.95); U.applyUI(); U.settings(); };
  $('#sOk').onclick = UI.closeModal;
};
document.addEventListener('keydown', e => {
  if (!e.ctrlKey || e.altKey) return;
  const k = e.key, z = U.zoom();
  if (k === '=' || k === '+') { U.setZoom(Math.min(1.5, Math.round((z + 0.05) * 20) / 20)); e.preventDefault(); }
  else if (k === '-' || k === '_') { U.setZoom(Math.max(0.7, Math.round((z - 0.05) * 20) / 20)); e.preventDefault(); }
  else if (k === '0') { U.setZoom(0.95); e.preventDefault(); }
});
setTimeout(() => { try { U.applyUI(); } catch (e) { } }, 0);
U.setZoom = z => { try { localStorage.setItem(U.ZOOM_KEY, z); } catch (e) { } U.applyZoom(z); };
U.dock = () => {
  const s = UI.s; if (!s) return '';
  const crime = s.crime && (s.crime.on || s.crime.heat > 0);
  const items = [['hh', 'brief', E.ww2(s) ? 'Отдел кадров' : 'Работа'], ['cian', 'home', 'Жильё'], ['home', 'box', 'Мой дом'], ['biz', 'factory', s.biz.length ? 'Бизнес' : 'Открыть дело'], ['people', 'user', 'Близкие'], ['paper', 'book', 'Газета', s.unread], ['room', 'globe', 'Мультиплеер', typeof NET !== 'undefined' && NET.on() ? NET.list().length : 0]].concat([['crime', 'bolt', 'Криминал', crime && L.wanted(s) ? '★' + L.wanted(s) : 0]]);
  return items.map(x => `<button data-dock="${x[0]}" title="${x[2]}">${UI.ic(x[1])}<span>${x[2]}</span>${x[3] ? `<em>${x[3]}</em>` : ''}</button>`).join('');
};
U.bindDock = () => { $$('[data-dock]').forEach(b => b.onclick = () => ({ room: () => U.room(), hh: () => U.hh(), cian: () => U.cian(), home: () => U.home(), biz: () => U.biz(), people: () => U.people(), paper: () => U.paper(), crime: () => U.crime() })[b.dataset.dock]()); };
U.advance = async n => {
  if (UI.busy) return;
  UI._multi = n;
  for (let k = 0; k < n; k++) {
    await UI.nextWeek(k < n - 1);
    if (UI.s.over) break;
  }
  UI._multi = 0;
};

// ============================================================================
//  МУЛЬТИПЛЕЕР — окно комнаты
// ============================================================================
U.room = () => {
  const s = UI.s; U.roomOpen = true;
  const box = h => { const m = $('#modal'); if (m.classList.contains('hidden') || !m.querySelector('.room')) UI.modal(h); else m.firstElementChild.innerHTML = h; m.firstElementChild.classList.add('wide', 'roomw'); };
  const head = `<div class="mhead">${UI.ic('globe')}<div><h3>Мультиплеер</h3><small>Друзья играют в одном мире. Каждый считает свою нейросеть у себя, хост — общий мир.</small></div><button class="close" id="rmX">${UI.ic('x')}</button></div>`;
  let body;
  if (!NET.on()) {
    body = `<div class="room rgrid">
      <div class="card"><h4>Создать комнату</h4><p class="small">Вы станете хостом: ваш мир (страны, войны, экономика) станет общим. Друзьям нужен только код.</p>
        <button class="btn primary big" id="rmHost">${UI.ic('plus')} Создать комнату</button></div>
      <div class="card"><h4>Войти по коду</h4><p class="small">Вы начнёте новую жизнь в мире друга. Текущая жизнь заменится — если она нужна, сначала сохраните её в файл (меню ☰).</p>
        <div class="rjoin"><input id="rmCode" placeholder="ABC-123" autocomplete="off" spellcheck="false"><button class="btn" id="rmPaste" title="Вставить из буфера">Вставить</button><button class="btn primary" id="rmJoin">Войти</button></div></div>
      <p class="small rnote">Сервер не нужен: игроки находят друг друга через открытые «доски объявлений» в интернете и дальше соединяются напрямую. Нужен только интернет.</p></div>`;
  } else {
    const all = NET.list(), host = NET.role === 'host';
    const st = NET.status === 'search' ? (host ? 'Ждём игроков…' : 'Ищу комнату… (обычно 5–20 секунд)') : NET.status === 'hostlost' ? 'Хост не в сети' : 'Соединено';
    body = `<div class="room">
      <div class="rtop"><div><small>Код комнаты</small><b class="rcode">${NET.code}</b></div><button class="btn" id="rmCopy">${UI.ic('save')} Скопировать</button>
        <div class="rst ${NET.status}"><i></i>${st}</div><small class="rrel">связь: ${NET.netText()}</small><span class="sp"></span>${host ? `<button class="btn" id="rmForce" title="Не ждать отметки «Готов»">Неделя для всех</button>` : ''}<button class="btn danger" id="rmLeave">Выйти из комнаты</button></div>
      <div class="rgrid2">
        <div class="card"><h4>Игроки (${all.length})</h4>
          ${all.map(p => `<div class="rpl">${UI.avatar({ sex: p.sex || 'm', look: p.look || 1 }, 34)}<div><b>${UI.esc(p.name || '…')}${p.self ? ' (вы)' : ''}${p.host ? ' <em>хост</em>' : ''}</b><small>${UI.esc(p.pos || '')}${p.cityN ? ' · ' + UI.esc(p.cityN) : ''}${p.age ? ' · ' + E.years(p.age) : ''}</small></div>
            <span class="rrd ${p.ready ? 'on' : ''}">${p.ready ? 'готов' : 'думает'}</span>${!p.self ? `<button class="btn small primary" data-ia="${p.uid}">${UI.ic('hand')} Взаимодействие</button><button class="btn small" data-pay="${p.uid}">${UI.ic('coin')} Перевести</button>` : ''}</div>`).join('')}
          ${all.length < 2 ? `<p class="small">Пока вы один. Отправьте друзьям код <b>${NET.code}</b> — пусть в игре нажмут «Мультиплеер» → «Войти по коду».</p>` : ''}
          <div id="rmPay" class="hidden rpay"><input id="rmSum" type="number" min="1" placeholder="Сумма, ₽"><input id="rmNote" maxlength="80" placeholder="Комментарий"><button class="btn primary" id="rmPayGo">Отправить</button></div></div>
        <div class="card rchat"><h4>Чат комнаты</h4><div class="rmsgs" id="rmMsgs">${NET.chat.slice(-40).map(m => m.sys ? `<p class="rs">${UI.esc(m.t)}</p>` : `<p><b>${UI.esc(m.who)}:</b> ${UI.esc(m.t)}</p>`).join('') || '<p class="rs">Сообщений пока нет.</p>'}</div>
          <div class="rjoin"><input id="rmSay" maxlength="300" placeholder="Написать всем…"><button class="btn primary" id="rmSend">${UI.ic('send')}</button></div></div>
      </div>
      <p class="small rnote">Скорость времени и «+месяц» — у хоста в верхней панели. «Готов» — если готовы все, неделя наступает сразу. Войны, мир и указы в мультиплеере решает хост.</p></div>`;
  }
  box(head + body);
  $('#rmX').onclick = () => { U.roomOpen = false; UI.closeModal(); };
  if (!NET.on()) {
    $('#rmHost').onclick = () => { NET.host(); U.room(); };
    $('#rmJoin').onclick = () => { const c = NET.pick($('#rmCode').value); if (c.length < 6) { UI.toast('Код — 6 символов, например ABC-123', 'bad'); return; } if (UI.s && !confirm('Текущая жизнь заменится новой в мире друга. Продолжить?')) return; U.joinFlow(c); };
    U.codeInput('#rmCode', '#rmPaste');
  } else {
    $('#rmCopy').onclick = () => { try { navigator.clipboard.writeText(NET.code); UI.toast('Код скопирован'); } catch (e) { } };
    $('#rmLeave').onclick = () => { if (!confirm('Выйти из комнаты? Жизнь сохранится, вернуться можно по коду.')) return; if (UI.s && UI.s.mp) { UI.s.mp = null; UI.save(); } NET.leave(); U.room(); };
    if ($('#rmForce')) $('#rmForce').onclick = () => { NET.checkAll(true); };
    $$('#modal [data-ia]').forEach(b => b.onclick = () => { U.roomOpen = false; IA.open(b.dataset.ia); });
    let payTo = null;
    $$('#modal [data-pay]').forEach(b => b.onclick = () => { payTo = b.dataset.pay; $('#rmPay').classList.remove('hidden'); $('#rmSum').focus(); });
    $('#rmPayGo').onclick = () => { const r = NET.send(payTo, $('#rmSum').value, $('#rmNote').value); UI.toast(UI.esc(r.title), r.ok ? '' : 'bad'); if (r.ok) $('#rmPay').classList.add('hidden'); };
    const say = () => { NET.say($('#rmSay').value); $('#rmSay').value = ''; };
    $('#rmSend').onclick = say; $('#rmSay').onkeydown = e => { if (e.key === 'Enter') say(); };
    const mm = $('#rmMsgs'); if (mm) mm.scrollTop = 1e9;
  }
};
// Поле кода: вставка текстом целиком («Код: ABC-123» тоже подойдёт), кнопка «Вставить»
U.codeInput = (sel, btn) => {
  const el = $(sel); if (!el) return;
  el.addEventListener('paste', e => { const t = (e.clipboardData || window.clipboardData).getData('text'); if (t) { e.preventDefault(); el.value = NET.fmt(t); } });
  el.oninput = () => { const v = NET.fmt(el.value); if (v !== el.value) el.value = v; };
  if ($(btn)) $(btn).onclick = async () => { try { const t = await navigator.clipboard.readText(); el.value = NET.fmt(t); el.focus(); } catch (e) { UI.toast('Не получилось прочитать буфер — нажмите Ctrl+V в поле', 'bad'); } };
};
// Вход по коду с титульного экрана или из игры: найти комнату → создать героя в эпохе хоста → войти
U.joinFlow = code => {
  if (!NET.join(code)) return;
  UI.modal(`<div class="menu room"><h3>Ищу комнату ${NET.fmt(code)}…</h3><div class="rspin"></div><p class="small" id="rjSt">Связываюсь с другими игроками через интернет. Обычно 5–20 секунд.</p><button class="btn wide" id="rjCancel">Отмена</button></div>`);
  $('#rjCancel').onclick = () => { NET.leave(); UI.closeModal(); };
  const t = setInterval(() => { const el = $('#rjSt'); if (!el) { clearInterval(t); return; } const sec = Math.round((Date.now() - NET.t0) / 1000); const [ok] = NET.relayStat(); el.textContent = (sec > 20 ? `Пока не нашёл (${sec} с). Проверьте код и что хост сейчас в игре. ` : 'Связываюсь с другими игроками… ') + `Каналы связи: ${NET.netText()}.`; if (sec > 12 && !ok) el.textContent = `Нет связи ни с одним сервером (${NET.netText()}). Проверьте интернет; если не поможет — VPN.`; }, 1000);
  NET.onWelcomeCb = d => { clearInterval(t); NET.onWelcomeCb = null; UI.closeModal(); UI.toast('Комната найдена! Создайте героя.'); UI.cr = Object.assign(UI.cr || {}, { era: d.era }); UI.create(); };
};
// близкие в досье — по клику открываются карточки людей
document.addEventListener('click', e => { const li = e.target.closest && e.target.closest('.rels li'); if (li && UI.s) U.people(); });
