// «Судьба» — свободные затеи через чат: свой YouTube/TikTok/Telegram-канал, стримы, музыка, книга, стартап,
// партия, фонд, спортивная карьера, изобретение — и громкие планы вроде переворота. Всё без отдельных окон:
// игрок пишет в чат, игра считает, рассказчик ведёт диалог и спрашивает, сколько вложить.
// Итоги каждого месяца — в отчёте о доходах и расходах.
'use strict';
const PROJ = {};
(() => {
const pr = (s, v) => Math.round(E.m(s, v) / (E.ww2(s) ? 1 : 1000)) * (E.ww2(s) ? 1 : 1000);
const fmtN = n => n >= 1e6 ? (n / 1e6).toFixed(1).replace('.0', '') + ' млн' : n >= 1e4 ? Math.round(n / 1000) + ' тыс.' : String(Math.round(n));

// ---------- виды затей ----------
// plat — площадки для медиа: rate — ₽ в месяц с подписчика (реклама/донаты), vir — вирусность
PROJ.PLAT = {
  youtube: { n: 'YouTube', re: /ютуб|youtube|ютьюб/, rate: 0.55, vir: 1, unit: 'подписчиков', era: 'm' },
  tiktok: { n: 'TikTok', re: /тикток|tiktok|тик-ток|тик ток/, rate: 0.12, vir: 3, unit: 'подписчиков', era: 'm' },
  telegram: { n: 'Telegram', re: /телеграм|telegram|тг-канал|тг канал|телега/, rate: 0.4, vir: 0.7, unit: 'подписчиков', era: 'm' },
  twitch: { n: 'Twitch', re: /твич|twitch|стрим/, rate: 0.8, vir: 0.8, unit: 'зрителей', era: 'm' },
  vk: { n: 'ВКонтакте', re: /(^|[^а-яё])вк([^а-яё]|$)|вконтакт|паблик|(^|[^a-z])vk([^a-z]|$)/, rate: 0.3, vir: 1, unit: 'подписчиков', era: 'm' },
  insta: { n: 'Instagram', re: /(^|[^а-яё])инст(а|е|у|ой)?([^а-яё]|$)|instagram|инстаграм/, rate: 0.35, vir: 1.4, unit: 'подписчиков', era: 'm' },
  podcast: { n: 'Подкаст', re: /подкаст|podcast/, rate: 0.5, vir: 0.6, unit: 'слушателей', era: 'm' },
  blog: { n: 'Блог', re: /блог/, rate: 0.3, vir: 0.8, unit: 'читателей', era: 'm' },
  paper: { n: 'Стенгазета и самиздат', re: /газет|листовк|самиздат|стенгазет/, rate: 0.002, vir: 0.6, unit: 'читателей', era: 'w' },
};
PROJ.KIND = [
  { id: 'coup', n: 'Захват власти', re: /свер[гж]|переворот|революц|захват\w* власт|хунт|путч|мятеж|скинуть (власть|президент|правительств)|стать (президентом|диктатор)|узурп/ },
  { id: 'music', n: 'Музыкальная карьера', re: /рэп|реп |музык|песн|трек|альбом|групп[уа] (собрать|создать)|певц|певиц|концерт|диджей|dj|битмейк/ },
  { id: 'book', n: 'Книга', re: /книг|роман|написать (повесть|рассказ)|мемуар|писател/ },
  { id: 'startup', n: 'Стартап', re: /стартап|приложени|игру (сделать|разработать)|сделать игру|своя игра|сервис|нейросет|маркетплейс|платформ|крипто(валют|проект)|токен|nft/ },
  { id: 'party', n: 'Своя партия', re: /парти[юяи]|политическ\w* движени|своё движение/ },
  { id: 'fund', n: 'Фонд', re: /фонд|некоммерч|нко|волонт[её]рск\w* (движени|организац)/ },
  { id: 'sport', n: 'Спортивная карьера', re: /мма|бокс|боец|бои без|футболист|хоккеист|спортивн\w* карьер|профессиональн\w* спорт|чемпион|олимпи/ },
  { id: 'invent', n: 'Изобретение', re: /изобрет|патент|конструир|собрать (робот|дрон|машину времени)|прототип/ },
  { id: 'media', n: 'Канал', re: /канал|блог|ютуб|youtube|тикток|tiktok|телеграм|telegram|стрим|твич|twitch|подкаст|паблик|инст|блогер|видео|ролик|контент|подписчик|газет|самиздат/ },
];
PROJ.detect = t => {
  t = E.norm(t || '');
  const k = PROJ.KIND.find(x => x.re.test(t));
  return k ? k.id : 'other';
};
PROJ.platOf = (s, t) => {
  t = E.norm(t || '');
  for (const id in PROJ.PLAT) if (PROJ.PLAT[id].re.test(t)) return id;
  return E.ww2(s) ? 'paper' : 'youtube';
};
PROJ.opOf = t => {
  t = E.norm(t || '');
  if (/закры|удал|бросить|забросить|прекрат|распуст|отказ/.test(t)) return 'close';
  if (/нанят|нанима|монтаж|редактор|команд|менеджер|продюсер|тренер|сценарист/.test(t)) return 'hire';
  if (/реклам|продвиж|раскрут|таргет|накрут|посев|пиар/.test(t)) return 'ads';
  if (/вложи|вкладыв|инвест|потрат|закуп|купить (камер|оборудован|свет|микрофон)|оборудован|техник|бюджет|деньги в/.test(t)) return 'invest';
  if (/коллаб|совместн|фит|с блогером/.test(t)) return 'collab';
  if (/продать|продаю|выкуп/.test(t)) return 'sell';
  if (/инвестор|раунд|привлечь деньги|венчур/.test(t)) return 'raise';
  if (/концерт|тур|выступ/.test(t)) return 'gig';
  if (/бой|поединок|турнир|матч|соревнован/.test(t)) return 'fight';
  if (/день x|день х|штурм|начать переворот|выступить|поднять (восстание|мятеж)|час x|час х|захватить (кремль|власть)|действовать/.test(t)) return 'strike';
  if (/союзник|людей|сторонник|вербов|собрать|найти генерал|завербовать|агитир/.test(t)) return 'people';
  if (/пропаганд|агитац|митинг|листовк/.test(t)) return 'propaganda';
  if (/как дела|статистик|сколько подпис|что с канал|отчёт|прогресс|состояни|что нужно|что надо|требован/.test(t)) return 'status';
  if (/снять|снимаю|выпуст|опубликов|пост|ролик|видео|трек|записать|написать|глав[уы]|выложи|стрим|эфир|тренир|работать над|разрабатыв|кодить|прокач/.test(t)) return 'work';
  return '';
};
PROJ.find = (s, kind, t) => {
  const ps = (s.proj || []).filter(p => !p.closed);
  t = E.norm(t || '');
  return ps.find(p => t && E.norm(p.n).length > 2 && t.includes(E.norm(p.n).slice(0, 6))) || ps.find(p => p.kind === kind && (kind !== 'media' || !t || p.plat === PROJ.platOf(s, t) || !Object.values(PROJ.PLAT).some(x => x.re.test(t)))) || null;
};
PROJ.title = (s, p) => p.kind === 'media' ? `${PROJ.PLAT[p.plat].n}-канал «${p.n}»` : p.kind === 'music' ? `музыкальный проект «${p.n}»` : p.kind === 'book' ? `книга «${p.n}»` : p.kind === 'startup' ? `стартап «${p.n}»` : p.kind === 'party' ? `партия «${p.n}»` : p.kind === 'fund' ? `фонд «${p.n}»` : p.kind === 'sport' ? `спортивная карьера` : p.kind === 'invent' ? `изобретение «${p.n}»` : p.kind === 'coup' ? 'заговор' : `затея «${p.n}»`;
// название из фразы: «канал про машины “Гараж”» → Гараж
PROJ.name = (s, kind, t, it) => {
  const q = (t.match(/[«"“']([^»"”']{2,30})[»"”']/) || [])[1];
  if (q) return q.trim();
  if (it && it.org && it.org.length > 1) return it.org.slice(0, 30);
  const about = (E.norm(t).match(/(?:про|о|об|по) ([а-яёa-z0-9 -]{3,24})/) || [])[1];
  const base = { media: 'Канал ' + (s.ch.name || ''), music: s.ch.name + ' ' + s.ch.surname, book: 'Без названия', startup: 'Проект', party: 'Новая сила', fund: 'Помощь рядом', sport: s.ch.surname, invent: 'Прототип', coup: 'Рассвет', other: 'Затея' }[kind];
  if (about && kind === 'book') return 'О ' + about.trim();
  return about && kind === 'media' ? about.trim().replace(/^./, c => c.toUpperCase()) : base;
};

// ---------- создание ----------
PROJ.create = (s, kind, it) => {
  const t = it.raw || it.target || '';
  const p = { id: 'p' + Date.now().toString(36), kind, n: PROJ.name(s, kind, t, it), since: s.date, prog: 0, q: 0.5, subs: 0, inv: 0, staff: 0, posts: 0, idle: 0, inc: 0, hist: [], about: AI_about(t) };
  if (kind === 'media') { p.plat = PROJ.platOf(s, t); if (E.ww2(s)) p.plat = 'paper'; }
  if (kind === 'coup') { Object.assign(p, { sup: 0, ppl: 0, heat: 0, prop: 0 }); }
  if (kind === 'sport') { p.rank = 0; p.wins = 0; p.loss = 0; }
  if (kind === 'party') { p.members = 10; p.rating = 0.2; }
  (s.proj = s.proj || []).push(p);
  E.fact(s, `${E.monthStr(s.date)}: начал${s.ch.sex === 'f' ? 'а' : ''} ${PROJ.title(s, p)}.`);
  return p;
};
const AI_about = t => ((E.norm(t).match(/(?:про|о|об) ([а-яёa-z0-9 ,-]{3,40})/) || [])[1] || '').trim();

// ---------- требования для громких планов ----------
PROJ.need = (s, p) => {
  if (p.kind !== 'coup') return [];
  const o = s.opg && !s.opg.gone ? s.opg : null;
  const army = s.job && s.job.army ? s.job.level || 0 : 0;
  const ppl = p.ppl + (o ? o.members : 0) + army * 40 + (s.pol ? 60 : 0);
  return [
    { n: 'Деньги на подкуп', ok: p.sup >= 60, v: `поддержка силовиков ${Math.round(p.sup)}/60 (вкладывайте в подкуп: ~${E.short(pr(s, 50000000))} ₽ за 10 пунктов)` },
    { n: 'Люди', ok: ppl >= 300, v: `${ppl}/300 верных людей (вербуйте сторонников, своя ОПГ и армия помогают)` },
    { n: 'Влияние', ok: s.st.infl >= 55, v: `${Math.round(s.st.infl)}/55` },
    { n: 'Репутация', ok: s.st.rep >= 50, v: `${Math.round(s.st.rep)}/50` },
    { n: 'Пропаганда', ok: p.prop >= 40, v: `${Math.round(p.prop)}/40 (свой канал с подписчиками сильно помогает)` },
  ];
};
PROJ.needTxt = (s, p) => PROJ.need(s, p).map(x => (x.ok ? '✓ ' : '✗ ') + x.n + ': ' + x.v);

// ---------- действие из чата ----------
E.ACTIONS.push('project');
E.A.project = (s, it) => {
  const t = [it.target, it.raw].filter(Boolean).join(' ');
  let kind = PROJ.detect(t);
  let p = PROJ.find(s, kind, t);
  if (!p && kind === 'other') { const ps = (s.proj || []).filter(x => !x.closed); if (ps.length === 1 && PROJ.opOf(t)) p = ps[0]; }
  let op = PROJ.opOf(it.raw || t);
  const fresh = /завож|завести|завед|созда|откры|начина|начн|запуска|хочу (свой|сво[юе]|завести|стать|написать|сделать)|стану|решил/.test(E.norm(it.raw || t)) && !op;
  const OPK = { propaganda: 'coup', people: 'coup', strike: 'coup', gig: 'music', fight: 'sport', raise: 'startup' };
  if (!p && OPK[op]) p = (s.proj || []).find(x => !x.closed && x.kind === OPK[op]) || null;
  if (!p && !fresh) { const ps = (s.proj || []).filter(x => !x.closed && (x.kind === kind || kind === 'other' || kind === 'media' && x.kind === 'music')); if (ps.length) p = ps[ps.length - 1]; }
  if (p && fresh && p.kind === kind && kind === 'media' && Object.values(PROJ.PLAT).some(x => x.re.test(E.norm(t))) && p.plat !== PROJ.platOf(s, t)) p = null;
  const amount = Math.max(0, it.amount || 0);
  if (!p) {
    if (op === 'close' || op === 'sell') return { ok: false, impossible: true, title: 'Такой затеи у вас нет', lines: ['Сначала начните её — напишите, например, «завожу ютуб-канал про машины».'], apCost: 0 };
    if (E.age(s) < 12) return { ok: false, impossible: true, title: 'Рановато', lines: ['Подрастите немного.'], apCost: 0 };
    if (kind === 'coup' && s.mp && s.mp.role === 'client') return { ok: false, impossible: true, title: 'В мультиплеере это решает хост', lines: ['Смена власти меняет общий мир.'], apCost: 0 };
    p = PROJ.create(s, kind === 'other' ? 'other' : kind, it);
    return PROJ.start(s, p, amount);
  }
  if (amount > 0 && !op) op = p.kind === 'media' || p.kind === 'music' ? 'invest' : 'invest';
  return (PROJ.OPS[op] || PROJ.OPS.work)(s, p, amount, it);
};
// первый шаг: что есть и что дальше
PROJ.start = (s, p, amount) => {
  const lines = [], plat = p.plat ? PROJ.PLAT[p.plat] : null;
  let ask = '';
  if (p.kind === 'media') {
    lines.push(`Создан ${PROJ.title(s, p)}${p.about ? ' (тема: ' + p.about + ')' : ''}. Подписчиков пока 0.`, 'Снимаете на телефон: качество контента 0.5 из 3.');
    if (plat && p.plat === 'youtube' && !E.ww2(s) && new Date(s.date) >= new Date('2024-08-01')) lines.push('YouTube в России замедлен — рост медленнее, часть аудитории смотрит через VPN.');
    ask = `Вложишь в технику (камера, свет, микрофон ~${E.short(pr(s, 150000))} ₽) или в рекламу — или пока снимаешь на телефон?`;
  } else if (p.kind === 'coup') {
    p.heat += 5;
    lines.push('Вы задумали захватить власть. Это самая опасная затея в игре: провал — тюрьма на годы.', ...PROJ.needTxt(s, p));
    ask = 'С чего начнёшь: вложишь деньги в подкуп силовиков, будешь вербовать людей или займёшься пропагандой?';
  } else if (p.kind === 'startup') {
    lines.push(`Стартап «${p.n}» — пока идея в заметках. Чтобы выйти на рынок, нужна разработка (прогресс 0/100).`, 'Можно кодить самому (интеллект) или вложить деньги в команду.');
    ask = `Сколько вложишь в разработку? Минимальная команда — около ${E.short(pr(s, 400000))} ₽ в месяц.`;
  } else if (p.kind === 'music') {
    lines.push(`Музыкальный проект «${p.n}» создан. Слушателей пока 0.`, 'Нужны треки: записывайте их (харизма), а студия и сведение сильно поднимают качество.');
    ask = `Вложишь в студию и сведение (~${E.short(pr(s, 100000))} ₽ за трек) или пишешь дома на ноутбуке?`;
  } else if (p.kind === 'book') {
    lines.push(`Книга «${p.n}»: написано 0%. Пишите главы — это неделя за неделей.`); ask = 'Будешь писать сам или наймёшь редактора?';
  } else if (p.kind === 'party') {
    lines.push(`Партия «${p.n}»: 10 членов, рейтинг 0,2%. Нужна регистрация, офисы и агитация.`); ask = `Сколько вложишь в регистрацию и агитацию? На старт нужно хотя бы ~${E.short(pr(s, 3000000))} ₽.`;
  } else if (p.kind === 'fund') {
    lines.push(`Фонд «${p.n}» зарегистрирован. Каждый вложенный рубль идёт на помощь и растит репутацию и влияние.`); ask = 'Сколько внесёшь в фонд для начала?';
  } else if (p.kind === 'sport') {
    lines.push('Вы решили стать профессиональным спортсменом. Ранг 0: нужны тренировки (сила), тренер и первые бои.'); ask = `Наймёшь тренера (~${E.short(pr(s, 60000))} ₽/мес) или тренируешься сам?`;
  } else if (p.kind === 'invent') {
    lines.push(`Изобретение «${p.n}»: прогресс 0/100. Нужны детали, мастерская и голова (интеллект, ремесло).`); ask = 'Сколько вложишь в материалы и мастерскую?';
  } else {
    lines.push(`Затея «${p.n}» начата. Прогресс 0/100: вкладывайте силы и деньги, по ходу станет ясно, выгорит ли.`); ask = 'Сколько готов вложить на старте?';
  }
  if (amount > 0) { const r = PROJ.OPS.invest(s, p, amount); return Object.assign(r, { title: 'Начато: ' + PROJ.title(s, p), lines: lines.concat(r.lines), ask: '' }); }
  return { ok: true, title: 'Начато: ' + PROJ.title(s, p), lines, ask, apCost: 1, fx: { happy: 4 } };
};
const money = (s, amount, lines) => { if (amount <= 0) return 0; if (s.st.money < amount) { lines.push('Столько денег нет: на руках ' + E.money(s.st.money) + '.'); return -1; } s.st.money -= amount; return amount; };

PROJ.OPS = {
  status: (s, p) => {
    const lines = [PROJ.title(s, p).replace(/^./, c => c.toUpperCase()) + ' · с ' + E.monthStr(p.since)];
    if (p.kind === 'media' || p.kind === 'music') lines.push(`${PROJ.PLAT[p.plat] ? PROJ.PLAT[p.plat].unit.replace(/^./, c => c.toUpperCase()) : 'Слушателей'}: ${fmtN(p.subs)}`, `Качество контента: ${p.q.toFixed(1)} из 3`, `Доход в прошлом месяце: ${E.money(p.inc || 0)}`, p.staff ? 'В команде: ' + p.staff + ' чел.' : 'Работаете один');
    else if (p.kind === 'coup') lines.push(...PROJ.needTxt(s, p), `Внимание спецслужб: ${Math.round(p.heat)}/100`);
    else if (p.kind === 'sport') lines.push(`Ранг: ${p.rank}/10, побед ${p.wins}, поражений ${p.loss}`);
    else if (p.kind === 'party') lines.push(`Членов: ${fmtN(p.members)}, рейтинг: ${p.rating.toFixed(1)}%`);
    else lines.push(`Прогресс: ${Math.round(p.prog)}/100`, p.launched ? `Пользователей/читателей: ${fmtN(p.subs)}, доход ${E.money(p.inc || 0)}/мес` : 'Ещё не запущено');
    lines.push('Всего вложено: ' + E.money(p.inv));
    return { ok: true, title: 'Как дела: ' + PROJ.title(s, p), lines, apCost: 0, ask: PROJ.hint(s, p) };
  },
  invest: (s, p, amount) => {
    const lines = [];
    if (!amount) return { ok: false, impossible: true, title: 'Сколько вложить?', lines: ['Назовите сумму, например «вкладываю 200к в канал».'], apCost: 0, ask: PROJ.hint(s, p) };
    const got = money(s, amount, lines); if (got < 0) return { ok: false, impossible: true, title: 'Не хватает денег', lines, apCost: 0 };
    p.inv += got;
    const k = got / pr(s, 100000);
    if (p.kind === 'media' || p.kind === 'music') {
      const dq = Math.min(3 - p.q, Math.log10(1 + k * 2) * 0.9 / Math.max(1, p.q));
      p.q = Math.min(3, p.q + dq);
      lines.push(`Вложено ${E.money(got)}: техника, свет, монтаж. Качество контента ${p.q.toFixed(1)}/3.`);
    } else if (p.kind === 'coup') {
      const d = got / pr(s, 50000000) * 10; p.sup = Math.min(100, p.sup + d); p.heat = Math.min(100, p.heat + d * 0.6);
      lines.push(`${E.money(got)} ушло нужным людям в погонах. Поддержка силовиков +${d.toFixed(1)} (сейчас ${Math.round(p.sup)}).`, 'Чем больше людей знает, тем выше риск утечки.');
      PROJ.leak(s, p, lines);
    } else if (p.kind === 'party') {
      const d = Math.sqrt(k) * 0.4; p.rating = Math.min(45, p.rating + d); p.members += Math.round(k * 60);
      lines.push(`Офисы, агитация, регистрация: рейтинг ${p.rating.toFixed(1)}%, членов ${fmtN(p.members)}.`);
    } else if (p.kind === 'fund') {
      const r = Math.min(8, Math.sqrt(k) * 1.2), inf = Math.min(6, Math.sqrt(k) * 0.8);
      s.st.infl = Math.min(100, (s.st.infl || 0) + inf);
      lines.push(`Фонд помог сотням людей. Репутация и влияние растут.`); return { ok: true, title: 'Фонд «' + p.n + '»: +' + E.money(got), lines, fx: { rep: Math.round(r), happy: 4 }, apCost: 1 };
    } else if (p.kind === 'sport') {
      p.q = Math.min(3, p.q + Math.log10(1 + k) * 0.4); lines.push(`Сборы, экипировка, спарринги: подготовка ${p.q.toFixed(1)}/3.`);
    } else {
      const d = Math.min(100 - p.prog, Math.sqrt(k) * 9 * (0.7 + (E.sk(s, 'int') + E.sk(s, 'biz')) / 250)); p.prog += d;
      lines.push(`Вложено ${E.money(got)}. Прогресс +${Math.round(d)} → ${Math.round(p.prog)}/100.`);
      if (p.prog >= 100 && !p.launched) lines.push(...PROJ.launch(s, p));
    }
    return { ok: true, title: 'Вложено в ' + PROJ.title(s, p), lines, apCost: 1, ask: PROJ.hint(s, p) };
  },
  ads: (s, p, amount) => {
    const lines = [];
    if (p.kind !== 'media' && p.kind !== 'music' && !p.launched) return PROJ.OPS.invest(s, p, amount);
    if (!amount) amount = pr(s, 50000);
    const got = money(s, amount, lines); if (got < 0) return { ok: false, impossible: true, title: 'Не хватает денег', lines, apCost: 0 };
    p.inv += got;
    const cps = E.m(s, E.ww2(s) ? 2 : 25) / (p.q * 0.6 + 0.4) / (PROJ.PLAT[p.plat] ? PROJ.PLAT[p.plat].vir : 1) ** 0.5; // цена подписчика
    const add = Math.round(got / cps * E.rnd(0.6, 1.3));
    p.subs += add;
    lines.push(`Реклама за ${E.money(got)}: +${fmtN(add)} ${p.plat ? PROJ.PLAT[p.plat].unit : 'пользователей'} (всего ${fmtN(p.subs)}).`, 'Купленная аудитория удерживается хуже — нужен хороший контент.');
    p.bought = (p.bought || 0) + add;
    return { ok: true, title: 'Продвижение: ' + PROJ.title(s, p), lines, apCost: 1 };
  },
  hire: (s, p, amount) => {
    const role = { media: 'монтажёр и сценарист', music: 'звукорежиссёр', book: 'редактор', startup: 'разработчик', party: 'политтехнолог', fund: 'координатор', sport: 'тренер', invent: 'инженер', coup: 'вербовщик', other: 'помощник' }[p.kind] || 'помощник';
    p.staff++;
    return { ok: true, title: 'Нанят ' + role, lines: [`${role.replace(/^./, c => c.toUpperCase())} в команде «${p.n}». Зарплата ~${E.money(PROJ.staffCost(s, p))}/мес (в расходах).`, p.kind === 'media' ? 'Ролики будут выходить и без вас — 4 в месяц.' : 'Дело пойдёт быстрее.'], apCost: 1 };
  },
  work: (s, p) => {
    const lines = [];
    if (p.kind === 'coup') return PROJ.OPS.people(s, p);
    const sk = { media: 'cha', music: 'cha', book: 'int', startup: 'int', party: 'cha', fund: 'cha', sport: 'str', invent: 'craft', other: 'biz' }[p.kind] || 'cha';
    const r = E.roll(s, E.chance(s, 55, sk, 0));
    p.posts++; p.idle = 0;
    if (p.kind === 'media' || p.kind === 'music') {
      const pl = PROJ.PLAT[p.plat] || { vir: 1, unit: 'слушателей' };
      const viral = r.crit && Math.random() < 0.5;
      const views = Math.round((50 + p.subs * 0.3) * p.q * pl.vir * (r.ok ? E.rnd(0.8, 2.2) : E.rnd(0.2, 0.6)) * (viral ? E.rnd(8, 30) : 1));
      const add = Math.round(views * (r.ok ? 0.06 : 0.02) * (0.7 + p.q / 3));
      p.subs += add; p.views = (p.views || 0) + views;
      lines.push(`${p.kind === 'music' ? 'Новый трек' : 'Новый ролик'}: ${fmtN(views)} просмотров, +${fmtN(add)} ${pl.unit}.`);
      if (viral) lines.push('Залетело в рекомендации! Ролик разлетелся по сети.');
      if (p.subs > 1000 && Math.random() < 0.15) lines.push('В комментариях спорят, кто-то уже делает мемы.');
      return { ok: r.ok, roll: r, title: (viral ? 'Вирусный ' : '') + (p.kind === 'music' ? 'трек' : 'выпуск') + ' в «' + p.n + '»', lines, apCost: 1, fx: { happy: r.ok ? 4 : -2, cha: r.ok ? 1 : 0 } };
    }
    if (p.kind === 'sport') return PROJ.OPS.fight(s, p, 0, null, true);
    if (p.kind === 'party') { const d = r.ok ? E.rnd(0.1, 0.5) : 0.02; p.rating = Math.min(45, p.rating + d); p.members += r.ok ? E.ri(20, 200) : 5; lines.push(`Встречи с избирателями, листовки, эфиры: рейтинг ${p.rating.toFixed(1)}%.`); return { ok: r.ok, roll: r, title: 'Агитация партии «' + p.n + '»', lines, apCost: 1, fx: { infl: r.ok ? 1 : 0 } }; }
    const d = r.ok ? E.rnd(6, 14) * (r.crit ? 1.6 : 1) : E.rnd(1, 4);
    if (!p.launched) { p.prog = Math.min(100, p.prog + d); lines.push(`Работа над «${p.n}»: прогресс ${Math.round(p.prog)}/100.`); if (p.prog >= 100) lines.push(...PROJ.launch(s, p)); }
    else { p.q = Math.min(3, p.q + (r.ok ? 0.1 : 0.02)); lines.push(`Доработки и обновления: качество ${p.q.toFixed(1)}/3.`); }
    return { ok: r.ok, roll: r, title: 'Работа над: ' + PROJ.title(s, p), lines, apCost: 1, fx: { stress: 3, [sk]: r.ok ? 1 : 0 } };
  },
  collab: (s, p) => {
    if (p.kind !== 'media' && p.kind !== 'music') return PROJ.OPS.work(s, p);
    const r = E.roll(s, E.chance(s, 40 + Math.min(30, Math.log10(1 + p.subs) * 6), 'cha', 0));
    const add = r.ok ? Math.round((p.subs * 0.25 + 500) * E.rnd(0.5, 2)) : 0;
    p.subs += add;
    return { ok: r.ok, roll: r, title: r.ok ? 'Коллаборация удалась' : 'Звёзды не ответили', lines: r.ok ? [`Совместный выпуск: +${fmtN(add)} ${PROJ.PLAT[p.plat] ? PROJ.PLAT[p.plat].unit : 'слушателей'}.`] : ['Крупные блогеры вежливо промолчали. Подрастите — потом позовут сами.'], apCost: 1 };
  },
  gig: (s, p) => {
    if (p.kind !== 'music') return PROJ.OPS.work(s, p);
    if (p.subs < 3000) return { ok: false, impossible: true, title: 'Слишком рано для концертов', lines: ['Нужно хотя бы 3 тыс. слушателей — сейчас ' + fmtN(p.subs) + '.'], apCost: 0 };
    const r = E.roll(s, E.chance(s, 60, 'cha', 0));
    const fans = Math.round(p.subs * E.rnd(0.005, 0.02) * (r.ok ? 1 : 0.4)), cash = Math.round(fans * E.m(s, E.ww2(s) ? 2 : 1200) * 0.6);
    s.st.money += cash; p.subs += Math.round(fans * 0.5);
    return { ok: r.ok, roll: r, title: r.ok ? 'Концерт: аншлаг!' : 'Концерт: полупустой зал', lines: [`Пришло ${fmtN(fans)} человек, вам после площадки: +${E.money(cash)}.`], apCost: 1, fx: { happy: r.ok ? 10 : -4, rep: r.ok ? 2 : 0 } };
  },
  fight: (s, p, amount, it, train) => {
    if (p.kind !== 'sport') return PROJ.OPS.work(s, p);
    if (train || p.rank === 0 && p.wins + p.loss === 0 && Math.random() < 0.5) {
      const r = E.roll(s, E.chance(s, 60, 'str', 0)); p.q = Math.min(3, p.q + (r.ok ? 0.12 : 0.03));
      return { ok: r.ok, roll: r, title: 'Тренировка', lines: [`Подготовка ${p.q.toFixed(1)}/3. ${p.rank < 1 ? 'Пора и на первый бой.' : ''}`], apCost: 1, fx: { str: r.ok ? 1 : 0, health: r.ok ? 1 : -2, stress: -2 } };
    }
    const r = E.roll(s, E.chance(s, 38 + p.q * 12 - p.rank * 3, 'str', 0));
    const prize = Math.round(E.m(s, E.ww2(s) ? 30000 : 40000) * Math.pow(1.7, p.rank) * (r.ok ? 1 : 0.3));
    s.st.money += prize;
    if (r.ok) { p.wins++; if (p.wins % 2 === 0) p.rank = Math.min(10, p.rank + 1); p.subs += Math.round(200 * Math.pow(1.8, p.rank)); } else p.loss++;
    const inj = !r.ok && Math.random() < 0.35;
    return { ok: r.ok, roll: r, title: r.ok ? 'Победа!' : 'Поражение', lines: [`Гонорар: +${E.money(prize)}`, `Ранг ${p.rank}/10, ${p.wins}–${p.loss}`].concat(inj ? ['Травма — нужно восстановиться.'] : []), apCost: 1, fx: { health: inj ? -E.ri(10, 25) : -3, happy: r.ok ? 8 : -6, rep: r.ok ? 2 : 0 } };
  },
  raise: (s, p) => {
    if (p.kind !== 'startup' && p.kind !== 'invent' && p.kind !== 'other') return PROJ.OPS.work(s, p);
    const val = Math.max(p.inv * 1.5, (p.inc || 0) * 36, p.prog * pr(s, 50000));
    const r = E.roll(s, E.chance(s, 25 + p.prog * 0.3 + (p.launched ? 15 : 0), 'cha', 0));
    if (!r.ok) return { ok: false, roll: r, title: 'Инвесторы не впечатлились', lines: ['«Покажите выручку — тогда поговорим».'], apCost: 1, fx: { stress: 5 } };
    const cash = Math.round(val * 0.2 / 1000) * 1000; s.st.money += cash; p.share = (p.share || 1) * 0.8; p.prog = Math.min(100, p.prog + 10);
    return { ok: true, roll: r, title: 'Привлечены инвестиции', lines: [`Инвестор дал ${E.money(cash)} за 20% доли. Ваша доля: ${Math.round(p.share * 100)}%.`, 'Оценка проекта: ' + E.money(Math.round(val))], apCost: 1, fx: { happy: 8 } };
  },
  sell: (s, p) => {
    const val = Math.round(Math.max(p.inv * 0.4, (p.inc || 0) * 24, p.subs * (p.kind === 'media' ? E.m(s, 15) : E.m(s, 30))) * (p.share || 1) / 1000) * 1000;
    if (val < pr(s, 10000)) return { ok: false, impossible: true, title: 'Покупателей нет', lines: ['Пока это никому не интересно.'], apCost: 0 };
    s.st.money += val; p.closed = true;
    E.fact(s, `${E.monthStr(s.date)}: продал ${PROJ.title(s, p)} за ${E.money(val)}.`);
    return { ok: true, title: 'Продано: ' + PROJ.title(s, p), lines: ['Выручка: ' + E.money(val)], apCost: 1 };
  },
  close: (s, p) => { p.closed = true; return { ok: true, title: 'Закрыто: ' + PROJ.title(s, p), lines: ['Больше этим не занимаетесь.'], apCost: 0 }; },
  people: (s, p) => {
    if (p.kind !== 'coup') return PROJ.OPS.work(s, p);
    const r = E.roll(s, E.chance(s, 45, 'cha', s.st.infl / 5));
    const add = r.ok ? E.ri(10, 35) * (r.crit ? 2 : 1) : E.ri(0, 4);
    p.ppl += add; p.heat = Math.min(100, p.heat + E.rnd(3, 8));
    const lines = [`Тайные встречи: +${add} верных людей (всего ${p.ppl}).`];
    PROJ.leak(s, p, lines);
    return { ok: r.ok, roll: r, title: 'Вербовка сторонников', lines, apCost: 1, fx: { stress: 8 }, ask: PROJ.hint(s, p) };
  },
  propaganda: (s, p) => {
    if (p.kind !== 'coup') return PROJ.OPS.work(s, p);
    const media = (s.proj || []).filter(x => !x.closed && (x.kind === 'media' || x.kind === 'party')).reduce((a, x) => a + (x.subs || 0) + (x.members || 0) * 3, 0);
    const r = E.roll(s, E.chance(s, 50, 'cha', 0));
    const d = (r.ok ? E.rnd(4, 9) : 1) + Math.min(12, Math.log10(1 + media) * 2);
    p.prop = Math.min(100, p.prop + d); p.heat = Math.min(100, p.heat + E.rnd(2, 6));
    const lines = [`Листовки, анонимные каналы, слухи: пропаганда ${Math.round(p.prop)}/40.`].concat(media ? ['Ваши каналы и партия дали охват.'] : ['Свой канал с подписчиками дал бы больше охвата.']);
    PROJ.leak(s, p, lines);
    return { ok: r.ok, roll: r, title: 'Пропаганда', lines, apCost: 1, fx: { stress: 5 } };
  },
  strike: (s, p) => {
    if (p.kind !== 'coup') return PROJ.OPS.work(s, p);
    if (s.mp && s.mp.role === 'client') return { ok: false, impossible: true, title: 'В мультиплеере это решает хост', lines: [], apCost: 0 };
    const need = PROJ.need(s, p), miss = need.filter(x => !x.ok);
    if (miss.length > 1) return { ok: false, impossible: true, title: 'Слишком рано', lines: ['Генералы не пойдут за вами, пока не хватает:', ...miss.map(x => '✗ ' + x.n + ': ' + x.v)], apCost: 0 };
    const H = s.world.cs[s.world.home];
    const ch = E.clamp(Math.round(20 + (p.sup - 60) * 0.5 + (p.prop - 40) * 0.3 + (60 - H.st.stab) * 0.6 - miss.length * 15 + s.st.infl * 0.15), 5, 75);
    const r = E.roll(s, ch);
    if (!r.ok) {
      p.closed = true;
      const lines = ['Мятеж подавлен. Ваших людей арестовали ночью.'];
      if (E.ww2(s) && Math.random() < 0.6) { s.st.health = 0; s.over = true; s.overReason = 'расстрелян за заговор'; return { ok: false, roll: r, title: 'Заговор раскрыт', lines: lines.concat(['Приговор — высшая мера.']), apCost: 1, dead: true }; }
      s.st.money = Math.round(s.st.money * 0.2); L.crimeInit(s);
      lines.push(...L.jail(s, 4));
      return { ok: false, roll: r, title: 'Переворот провалился', lines, apCost: 1, fx: { rep: -30, infl: -30 } };
    }
    const old = H.st.gov;
    H.st.stab = Math.max(20, H.st.stab - 20); H.st.gov = E.ww2(s) ? 'Военная диктатура' : 'Переходное правительство'; H.st.lead = s.ch.name + ' ' + s.ch.surname;
    for (const c of s.world.cs) if (!c.dead && c !== H) c.rel = Math.max(-100, c.rel - 25);
    E.takeOffice(s, { id: 'president', n: 'Глава переходного правительства' });
    WD.news(s, `${H.n}: смена власти! К власти пришёл ${s.ch.name} ${s.ch.surname}. Прежнее руководство (${old}) отстранено, мир настороженно следит.`, [s.world.home], 2, 'coup');
    p.closed = true; p.won = true;
    E.fact(s, `${E.monthStr(s.date)}: захватил власть в стране.`);
    return { ok: true, roll: r, title: 'Власть ваша!', lines: ['Вы — глава страны. Теперь вам решать: указы, армия, войны и мир.', 'Стабильность низкая — придётся её поднимать, иначе выйдут на улицы.'], apCost: 1, map: true, fx: { happy: 25, rep: 10, infl: 30, stress: 20 } };
  },
};
PROJ.leak = (s, p, lines) => {
  if (p.kind !== 'coup') return;
  if (Math.random() < Math.max(0, p.heat - 35) / 250) {
    p.sup *= 0.6; p.ppl = Math.round(p.ppl * 0.6); p.heat = 20;
    lines.push('Утечка! Несколько ваших людей задержаны, остальные залегли на дно. Поддержка и люди −40%.');
    if (Math.random() < 0.35) { L.crimeInit(s); s.crime.heat = Math.min(100, (s.crime.heat || 0) + 40); lines.push('Вами интересуются спецслужбы.'); }
  }
};
PROJ.launch = (s, p) => {
  p.launched = true;
  const r = E.roll(s, E.chance(s, 50, p.kind === 'book' ? 'int' : 'biz', p.q * 5));
  p.q = r.crit ? 2.5 : r.ok ? 1.5 : 0.7;
  p.subs = Math.round((r.ok ? E.rnd(500, 5000) : E.rnd(50, 400)) * (p.kind === 'startup' ? 1 : 0.6));
  E.fact(s, `${E.monthStr(s.date)}: запустил ${PROJ.title(s, p)} — ${r.ok ? 'успешно' : 'вяло'}.`);
  return [r.crit ? 'Запуск — бомба! О вас пишут.' : r.ok ? 'Запуск прошёл хорошо: первые пользователи и деньги.' : 'Запуск вышел вялым. Можно дорабатывать или продвигать рекламой.', 'Доход пойдёт в ежемесячном отчёте.'];
};
PROJ.staffCost = (s, p) => pr(s, { media: 70000, music: 60000, book: 40000, startup: 180000, party: 120000, fund: 50000, sport: 60000, invent: 120000, coup: 200000, other: 60000 }[p.kind] || 60000);
PROJ.hint = (s, p) => {
  if (p.kind === 'coup') { const m = PROJ.need(s, p).filter(x => !x.ok); return m.length ? 'Чего не хватает: ' + m.map(x => x.n.toLowerCase()).join(', ') + '. С чего продолжишь?' : 'Всё готово. Назначаешь день X?'; }
  if (p.kind === 'media') return p.q < 1.2 ? 'Вложишь в технику или снимешь новый ролик?' : p.subs < 1000 ? 'Снимаешь новый выпуск или вкладываешь в рекламу?' : 'Какой следующий выпуск?';
  if (!p.launched && p.prog < 100 && p.kind !== 'party' && p.kind !== 'fund' && p.kind !== 'sport') return 'Продолжишь работать сам или вложишь ещё?';
  return '';
};

// ---------- месяц ----------
PROJ.month = (s, r) => {
  const notes = r.notes || (r.notes = []);
  for (const p of (s.proj || [])) {
    if (p.closed) continue;
    if (p.staff) r.exp.push([`Команда «${p.n}» (${p.staff} чел.)`, PROJ.staffCost(s, p) * p.staff]);
    const posts = p.posts + (p.staff && (p.kind === 'media' || p.kind === 'music') ? 4 : 0);
    if (p.kind === 'media' || p.kind === 'music') {
      const pl = PROJ.PLAT[p.plat] || { rate: 0.4, vir: 1, unit: 'слушателей', n: 'Музыка' };
      let slow = (p.plat === 'youtube' && !E.ww2(s) && new Date(s.date) >= new Date('2024-08-01')) ? 0.55 : 1;
      const viral = Math.random() < 0.02 * p.q * Math.min(3, posts);
      let add = (posts ? (p.q * p.q * 60 + E.sk(s, 'cha') * 3 + posts * 25 * p.q) * pl.vir * (1 + Math.sqrt(p.subs) / 120) : -p.subs * 0.03) * slow * E.rnd(0.6, 1.5);
      if (viral) add += (p.subs + 2000) * E.rnd(0.5, 3) * pl.vir;
      if (p.bought) { const lost = Math.round(p.bought * 0.15); p.subs -= lost; p.bought -= lost; }
      add = Math.round(add); p.subs = Math.max(0, p.subs + add);
      const ads = Math.round(p.subs * pl.rate * (0.5 + p.q / 3) * E.k(s) * E.cpi(s));
      let deal = 0;
      if (p.subs > 10000 && Math.random() < 0.25 + p.q * 0.08) deal = Math.round(p.subs * E.rnd(0.3, 1.2) * E.k(s) * E.cpi(s) * (p.plat === 'telegram' ? 1.5 : 1));
      p.inc = ads + deal;
      if (p.inc > 0) r.inc.push([`${pl.n} «${p.n}»: ${fmtN(p.subs)} ${pl.unit}${deal ? ', интеграция' : ''}`, p.inc]);
      notes.push(`${pl.n} «${p.n}»: ${add >= 0 ? '+' : ''}${fmtN(add)} ${pl.unit} за месяц${viral ? ' — ролик залетел!' : ''}${!posts ? ' (без новых выпусков аудитория уходит)' : ''}.`);
      if (p.subs > 50000) s.st.infl = Math.min(100, (s.st.infl || 0) + 0.3);
      if (p.subs > 100000 && !p.famous) { p.famous = 1; E.apply(s, { rep: 5 }); notes.push('Вас начали узнавать на улице.'); }
    } else if (p.kind === 'party') {
      p.rating = Math.max(0, p.rating + (posts ? 0.1 : -0.15) + E.rnd(-0.1, 0.1));
      if (p.rating > 5) s.flags.campaign = Math.min(25, (s.flags.campaign || 0) + Math.round(p.rating / 3));
      notes.push(`Партия «${p.n}»: рейтинг ${p.rating.toFixed(1)}%, членов ${fmtN(p.members)}.`);
    } else if (p.kind === 'coup') {
      p.heat = Math.max(0, p.heat - 4);
      if (Math.random() < Math.max(0, p.heat - 50) / 300) { p.closed = true; L.crimeInit(s); notes.push('ФСБ вышла на заговор. Вас задержали.'); r.coupJail = L.jail(s, 3); }
    } else if (p.launched) {
      const arpu = { startup: 60, book: 25, invent: 120, other: 40 }[p.kind] || 40;
      p.subs = Math.max(0, Math.round(p.subs * (1 + (p.q - 1) * 0.05 + (posts ? 0.04 : -0.03) + E.rnd(-0.03, 0.05))));
      p.inc = Math.round(p.subs * arpu * E.k(s) * E.cpi(s) * (p.share || 1) * (p.kind === 'book' ? Math.max(0.2, 1 - (p.hist.length) * 0.04) : 1));
      if (p.inc > 0) r.inc.push([`${PROJ.title(s, p).replace(/^./, c => c.toUpperCase())}: ${fmtN(p.subs)} ${p.kind === 'book' ? 'читателей' : 'пользователей'}`, p.inc]);
    }
    p.hist.push(Math.round(p.inc || 0)); if (p.hist.length > 24) p.hist.shift();
    p.posts = 0;
  }
};
PROJ.brief = s => (s.proj || []).filter(p => !p.closed).map(p => PROJ.title(s, p) + (p.subs ? ' (' + fmtN(p.subs) + ')' : p.prog && !p.launched ? ' (' + Math.round(p.prog) + '%)' : '')).join(', ');

// ---------- подключение к игре ----------
const _me = E.monthEnd;
E.monthEnd = s => {
  const r = _me(s);
  try {
    const n0 = r.inc.length, e0 = r.exp.length;
    PROJ.month(s, r);
    const dn = r.inc.slice(n0).reduce((a, x) => a + x[1], 0) - r.exp.slice(e0).reduce((a, x) => a + x[1], 0);
    s.st.money += dn; r.net = (r.net || 0) + dn;
  } catch (e) { console.warn('proj', e); }
  return r;
};
// влияние (fx.infl) и подсказка без нейросети
const _act = E.act;
E.act = (s, it) => {
  let infl = 0;
  if (it && it.type === 'project') {
    const fn = E.A.project; E.A.project = (s2, it2) => { const o = fn(s2, it2); if (o && o.fx && o.fx.infl) { infl = o.fx.infl; o.fx = Object.assign({}, o.fx); delete o.fx.infl; } return o; };
    try { var out = _act(s, it); } finally { E.A.project = fn; }
    if (infl) { const o = s.st.infl || 0; s.st.infl = E.clamp(o + infl, 0, 100); const d = Math.round(s.st.infl - o); if (d) out.lines = (out.lines || []).concat(['Влияние ' + (d > 0 ? '+' : '') + d]); }
    if (out.ask && !(typeof AI !== 'undefined' && AI.state === 'ok')) out.lines = (out.lines || []).concat(['Дальше: ' + out.ask]);
    if (s.over && !out.dead) out.dead = true;
    return out;
  }
  return _act(s, it);
};
// разбор без нейросети
PROJ.amount = t => { const m = E.norm(t).replace(/(\d)\s+(?=\d{3}\b)/g, '$1').match(/(\d+(?:[.,]\d+)?)\s*(млрд|миллиард|млн|миллион|лям|тыс|тысяч|косар|т\.?р|к(?![а-яё])|k(?![a-z]))?/); if (!m) return 0; const v = parseFloat(m[1].replace(',', '.')), u = m[2] || ''; return Math.round(v * (/млрд|миллиард/.test(u) ? 1e9 : /млн|миллион|лям/.test(u) ? 1e6 : /^(к|k|тыс|тысяч|т\.?р|косар)/.test(u) ? 1e3 : 1)); };
const _pl = E.parseLocal;
E.parseLocal = text => {
  const it = _pl(text), t = E.norm(text);
  const toP = () => Object.assign(it, { type: 'project', target: text, amount: PROJ.amount(text) || it.amount || 0 });
  const has = (E.cur && (E.cur.proj || []).some(p => !p.closed));
  if (PROJ.KIND.some(k => k.re.test(t)) && !/куп(лю|ить) (акци|крипт)|на вклад|депозит/.test(t)) return toP();
  if (has && (/канал|ролик|видео|подписчик|трек|книг|глав[уы]|стартап|партия|фонд|заговор|переворот|пропаганд|вербу|сторонник|день x|день х/.test(t) || (/вложи|вкладыва/.test(t) && !/вклад в банк|депозит|акци|крипт/.test(t)))) return toP();
  return it;
};
document.addEventListener('DOMContentLoaded', () => {
  if (typeof AI === 'undefined') return;
  AI.SYS_INTERPRET = AI.SYS_INTERPRET.replace('other — всё остальное.', `project — долгая личная затея или громкий план: завести/вести свой YouTube, TikTok, Telegram-канал, блог, стримы, подкаст, паблик; музыка, рэп, записать трек, концерт; написать книгу; стартап, приложение, своя игра, крипто-проект; своя партия; благотворительный фонд; спортивная карьера (бои, MMA); изобретение; а также свергнуть власть, переворот, революция, захватить власть. Сюда же — вложить деньги в уже начатую затею, снять ролик/пост/трек, нанять людей для неё, рекламу, вербовку сторонников (target — что за затея и что делает, amount — сумма).
other — всё остальное.`);
  AI.SCHEMA.properties.type.enum = E.ACTIONS.concat(['chat']);
  AI.SYS_NARRATE_BASE = AI.SYS_NARRATE;
  AI.SYS_NARRATE = s => AI.SYS_NARRATE_BASE(s).replace('Не задавай вопросов игроку и не давай советов.', 'Не задавай вопросов игроку и не давай советов — кроме случая, когда в задании есть пункт «Спроси игрока»: тогда закончи ответ этим вопросом своими словами.');
  const _br = AI.brief;
  AI.brief = s => { const b = _br(s), pj = PROJ.brief(s); return pj ? b + '; затеи: ' + pj : b; };
  const _nar = AI.narrate;
  AI.narrate = (s, text, out, onToken) => {
    if (out && out.ask) out = Object.assign({}, out, { lines: (out.lines || []).concat(['Спроси игрока: ' + out.ask]) });
    return _nar(s, text, out, onToken);
  };
});
})();
