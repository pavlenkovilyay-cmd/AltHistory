// «Судьба» — ещё больше взаимодействий с друзьями в мультиплеере.
// Работа: взять друга к себе в бизнес на должность и зарплату, вложиться в его бизнес, похлопотать о повышении, контракт между бизнесами.
// Жильё: сдать другу квартиру, продать машину, помочь с ремонтом, новоселье.
// Досуг: баня, рыбалка, бар, вечеринка, гонки на машинах, приставка, караоке, розыгрыш. Семья, власть, криминал, затеи.
'use strict';
(() => {
  const M = v => IA.M(v), $m = v => IA.money(v);
  const hasProp = s => (s.props || []).map((p, i) => [p, i]).filter(([p]) => !p.rentOut);
  const kids = s => (s.kids || []).filter(k => L.kidAge(s, k) >= 0);
  const NEW = [
    // ===== Работа и бизнес =====
    { id: 'hire', cat: 'Работа и бизнес', n: 'Взять к себе в бизнес', d: 'Друг получает работу в вашем бизнесе: вы выбираете должность и зарплату. Его навык «Бизнес» помогает делу.',
      fields: [
        { k: 'biz', label: 'Бизнес', type: 'select', opts: s => s.biz.map(b => [b.id, b.n]) },
        { k: 'role', label: 'Должность', type: 'select', opts: s => { const b = s.biz.find(x => x.id === (IA._f.hire || {}).biz) || s.biz[0]; if (!b) return []; const I = B.ind(s, b.ind); return [['Управляющий', 'Управляющий'], ['Заместитель директора', 'Заместитель директора']].concat(I.roles.map(r => [r, r])); } },
        { k: 'sal', label: 'Зарплата в месяц', type: 'money', def: 70000 }],
      need: (s, p, f) => !s.biz.length ? 'Нужен свой бизнес' : !f.sal ? 'Укажите зарплату' : null,
      data: (s, f) => { const b = s.biz.find(x => x.id === f.biz) || s.biz[0]; return { bizN: b.n, biz: b.id, type: b.type, mkt: B.mkt(s, f.role) }; },
      text: (s, f, d) => `зовёт к себе в бизнес «${d.bizN}» (${d.type.toLowerCase()}): ${f.role}, ${$m(f.sal)}/мес`,
      accept: s => s.pol ? 'Вы на государственной должности' : null,
      reply: s => ({ sk: Math.round(E.sk(s, 'biz')), job: s.job ? s.job.title : '' }),
      onAccept: (s, f, d, from) => {
        const old = s.job ? s.job.title : '';
        s.job = { id: 'friendbiz', title: f.role, org: '«' + d.bizN + '»', salary: f.sal, level: /Управляющ|Заместит/.test(f.role) ? 3 : 1, perf: 60, months: 0, weeks: 0, sk: 'biz', ladder: [f.role, 'Старший ' + f.role.toLowerCase(), 'Управляющий'], boss: from.uid, bossN: from.name };
        E.fact(s, `${E.monthStr(s.date)}: устроился к ${from.name} в «${d.bizN}» — ${f.role}, ${E.money(f.sal)}/мес.`);
        return { fx: { happy: 6 }, rel: 8, note: 'работаю у друга', lines: [(old ? 'Ушли с прежней работы (' + old + '). ' : '') + 'Новая работа: ' + f.role + ' в «' + d.bizN + '», ' + $m(f.sal) + '/мес'] };
      },
      done: (s, p, f, r, d, rp) => {
        const b = s.biz.find(x => x.id === d.biz); if (!b) return { fail: 'Бизнеса больше нет' };
        b.staff.push({ n: p.name, role: f.role, sk: E.clamp((rp && rp.sk) || 50, 30, 100) + 10, sal: f.sal, mor: 90, m: 0, friend: p.uid });
        return { rel: 8, note: 'взял на работу в «' + b.n + '»', lines: [p.name + ' теперь работает у вас: ' + f.role + ', ' + $m(f.sal) + '/мес (в расходах бизнеса).', f.sal < d.mkt * 0.8 ? 'Зарплата ниже рынка — друг может обидеться.' : 'Друг доволен зарплатой.'], pub: `${p.name} теперь работает у ${NET.me().name} в «${b.n}»` };
      }, fin: () => null },
    { id: 'invest', cat: 'Работа и бизнес', n: 'Вложиться в бизнес друга', d: 'Вы даёте деньги, друг — долю прибыли каждый месяц. Сколько процентов — договариваетесь.',
      fields: [{ k: 'sum', label: 'Сумма', type: 'money', def: 500000 }, { k: 'pct', label: 'За долю', type: 'select', opts: () => [[5, '5%'], [10, '10%'], [20, '20%'], [30, '30%'], [49, '49%']] }],
      need: (s, p, f) => s.st.money < (f.sum || 0) ? 'Не хватает денег' : null,
      text: (s, f) => `хочет вложить ${$m(f.sum)} в ваш бизнес за ${f.pct}% прибыли (каждый месяц)`,
      accept: s => !s.biz.length ? 'У вас нет бизнеса' : null,
      reply: s => { const b = s.biz.slice().sort((a, c) => c.lastProfit - a.lastProfit)[0]; return { bizN: b ? b.n : '' }; },
      onAccept: (s, f, d, from) => { const b = s.biz.slice().sort((a, c) => c.lastProfit - a.lastProfit)[0]; IA.links().push({ t: 'bizshare', uid: from.uid, n: from.name, biz: b.id, bizN: b.n, pct: f.pct }); return { fx: { money: f.sum }, rel: 6, note: 'инвестировал в «' + b.n + '»', lines: [from.name + ' вложил ' + $m(f.sum) + ' в «' + b.n + '». Ему — ' + f.pct + '% прибыли каждый месяц.'] }; },
      done: (s, p, f, r, d, rp) => { IA.links().push({ t: 'bizpart', uid: p.uid, n: p.name, bizN: (rp && rp.bizN) || 'бизнес друга', pct: f.pct }); return { fx: { money: -f.sum }, rel: 6, note: 'вложился в бизнес', lines: ['Ваша доля: ' + f.pct + '% в «' + ((rp && rp.bizN) || 'бизнес друга') + '». Прибыль — каждый месяц.'] }; }, fin: () => null },
    { id: 'promo', cat: 'Работа и бизнес', n: 'Похлопотать о повышении', d: 'Замолвить словечко начальству друга. Нужна репутация 40+ или своя власть.', ap: 1,
      need: s => s.st.rep < 40 && !s.pol ? 'Нужна репутация 40+' : null,
      text: () => 'предлагает замолвить за вас словечко начальству',
      accept: s => !s.job ? 'У вас нет работы' : null,
      roll: s => ({ chance: E.clamp(40 + Math.round(s.st.rep / 2) + (s.pol ? 20 : 0), 30, 90) }),
      done: (s, p, f, r) => ({ rel: r.ok ? 6 : 2, note: r.ok ? 'замолвил словечко' : 'пытался помочь с повышением' }),
      fin: (s, d, f, from, r) => { if (r.ok && s.job) s.job.perf = E.clamp(s.job.perf + 25, 0, 100); return { fx: r.ok ? { happy: 4 } : {}, rel: r.ok ? 6 : 1, note: r.ok ? 'помог с повышением' : null, lines: [r.ok ? 'Начальство вас заметило: оценка работы +25 — самое время просить повышение.' : 'Слово замолвили, но начальство не впечатлилось.'] }; } },
    { id: 'deal', cat: 'Работа и бизнес', n: 'Контракт между бизнесами', d: 'Ваши бизнесы работают друг с другом: клиенты и поставки. Оба бизнеса крепнут.',
      need: s => !s.biz.length ? 'Нужен свой бизнес' : null,
      text: () => 'предлагает контракт между вашими бизнесами',
      accept: s => !s.biz.length ? 'У вас нет бизнеса' : null,
      done: s => { const b = s.biz[0]; b.health = E.clamp(b.health + 8, 0, 100); b.base = Math.min(1, (b.base || 0.5) + 0.1); return { rel: 5, note: 'контракт между бизнесами', lines: ['«' + b.n + '»: состояние +8, клиентская база +10%'] }; },
      fin: s => { const b = s.biz[0]; b.health = E.clamp(b.health + 8, 0, 100); b.base = Math.min(1, (b.base || 0.5) + 0.1); return { rel: 5, note: 'контракт между бизнесами', lines: ['«' + b.n + '»: состояние +8, клиентская база +10%'] }; } },
    // ===== Жильё =====
    { id: 'rentflat', cat: 'Жильё', n: 'Сдать другу квартиру', d: 'Свободная квартира из «Моей недвижимости». Друг переезжает и платит каждый месяц.',
      fields: [{ k: 'pi', label: 'Квартира', type: 'select', opts: s => hasProp(s).map(([p, i]) => [i, p.n]) }, { k: 'sum', label: 'Аренда в месяц', type: 'money', def: 35000 }],
      need: (s, p, f) => !hasProp(s).length ? 'Нет свободной своей квартиры (купите «под сдачу» в поиске жилья)' : null,
      data: (s, f) => { const p = s.props[f.pi] || hasProp(s)[0][0]; return { home: Object.assign({}, p.home, { furn: [] }), n: p.n, city: p.home.city != null ? p.home.city : s.ch.city, cityN: E.startName(s, L.cityStart(p.home.city != null ? p.home.city : s.ch.city)) }; },
      text: (s, f, d) => `предлагает снять у него квартиру: ${d.n}, ${d.cityN} — ${$m(f.sum)}/мес`,
      accept: (s, f) => s.st.money < f.sum ? 'Не хватает на первый месяц' : null,
      onAccept: (s, f, d, from) => {
        const lines = []; L.leave(s, lines);
        if (d.city !== s.ch.city) { s.ch.city = d.city; s.ch.cityName = ''; if (s.job && !s.job.army && !s.job.boss) { lines.push('Работу в старом городе пришлось оставить'); s.job = null; } }
        s.home = Object.assign({}, d.home, { owned: false, rent: 0, value: 0, shared: from.uid, furn: s.home.furn || [] });
        IA.links().push({ t: 'rentout', uid: from.uid, n: from.name, pay: f.sum });
        return { rel: 6, note: 'снимаю квартиру у друга', lines: ['Вы переехали в квартиру ' + from.name + '. Аренда ' + $m(f.sum) + '/мес — автоматически.'].concat(lines) };
      },
      done: (s, p, f) => { const pr = s.props[f.pi] || hasProp(s)[0][0]; pr.rentOut = true; pr.tenant = { who: p.name, t: 'Друг', d: 'Свой человек', rent: f.sum, late: 0, dmg: 0.01, leave: 0, left: 999, mp: p.uid, since: s.date }; pr.rentIncome = f.sum; IA.links().push({ t: 'rentin', uid: p.uid, n: p.name, pay: f.sum }); return { rel: 6, note: 'сдал квартиру', lines: [p.name + ' снимает «' + pr.n + '» за ' + $m(f.sum) + '/мес'] }; }, fin: () => null },
    { id: 'car', cat: 'Жильё', n: 'Продать машину другу', d: 'Ваша машина уходит другу за назначенную цену.',
      fields: [{ k: 'sum', label: 'Цена', type: 'money', def: 300000 }],
      need: s => !s.car ? 'У вас нет машины' : null,
      data: s => ({ car: Object.assign({}, s.car) }),
      text: (s, f, d) => `предлагает купить его машину: ${d.car.n} за ${$m(f.sum)} (рыночная ~${$m(d.car.value * 0.7)})`,
      accept: (s, f) => s.st.money < f.sum ? 'Не хватает денег' : null,
      onAccept: (s, f, d) => { const lines = []; if (s.car) lines.push(...L.sellCar(s).lines); s.car = Object.assign({}, d.car, { d: s.date }); return { fx: { money: -f.sum, happy: 6 }, rel: 4, note: 'купил машину у друга', lines: ['Ключи у вас: ' + d.car.n].concat(lines) }; },
      done: (s, p, f) => { const n = s.car ? s.car.n : 'машину'; s.car = null; return { fx: { money: f.sum }, rel: 4, note: 'продал машину другу', lines: ['Продали ' + n + ' за ' + $m(f.sum)] }; }, fin: () => null },
    { id: 'repair', cat: 'Жильё', n: 'Помочь с ремонтом', d: 'Руки из нужного места (ремесло 30+): чините другу всё сломанное и делаете уютнее.', ap: 1,
      need: s => E.sk(s, 'craft') < 30 ? 'Нужно ремесло 30+' : null,
      text: () => 'предлагает помочь с ремонтом дома',
      done: () => ({ fx: { craft: 1, happy: 2 }, rel: 7, note: 'помог с ремонтом' }),
      fin: s => { const n = (s.home.furn || []).filter(f => f.broken).length; (s.home.furn || []).forEach(f => { f.broken = false; }); return { fx: { happy: 5 }, rel: 7, note: 'помог с ремонтом', lines: [n ? 'Починили: ' + n + ' вещ.' : 'Подкрасили, повесили полки — стало уютнее'] }; } },
    { id: 'housewarm', cat: 'Жильё', n: 'Позвать на новоселье', d: 'Праздник в вашем доме. Друг приходит с подарком.',
      need: s => !s.home.owned && s.home.type === 'parents' ? 'Нужно своё жильё' : null,
      text: s => `зовёт на новоселье: ${E.homeName(s).toLowerCase()}`,
      done: () => ({ fx: { happy: 6, money: M(8000) }, rel: 6, note: 'новоселье' }),
      fin: () => ({ fx: { happy: 5, money: -M(8000) }, rel: 6, note: 'был на новоселье', lines: ['Подарок на новоселье: ' + $m(M(8000))] }) },
    // ===== Общение и досуг =====
    { id: 'banya', cat: 'Общение', n: 'Сходить в баню', d: 'Пар, веники, разговоры по душам. Здоровье, минус стресс.', ap: 1, cost: () => M(3000),
      text: () => 'зовёт в баню — попариться и поговорить',
      done: () => ({ fx: { money: -M(3000), health: 3, stress: -10, happy: 4 }, rel: 8, note: 'парились в бане' }), fin: () => ({ fx: { money: -M(3000), health: 3, stress: -10, happy: 4 }, rel: 8, note: 'парились в бане' }) },
    { id: 'fishing', cat: 'Общение', n: 'На рыбалку или охоту', d: 'Выходные на природе. Кому-то повезёт с уловом.', ap: 1,
      text: () => 'зовёт на рыбалку на выходные',
      roll: () => ({ chance: 50 }),
      done: (s, p, f, r) => ({ fx: { happy: r.ok ? 8 : 4, stress: -8, health: 1 }, rel: 7, note: r.ok ? 'поймал больше на рыбалке' : 'рыбачили вместе', lines: [r.ok ? 'Ваш улов больше — щука на 4 кило! Будет что рассказать.' : 'Клевало у друга, вы больше разговаривали.'] }),
      fin: (s, d, f, from, r) => ({ fx: { happy: r.ok ? 4 : 8, stress: -8, health: 1 }, rel: 7, note: 'рыбачили вместе', lines: [r.ok ? from.name + ' поймал больше. Завидуете.' : 'Ваш улов лучше! Фото с рыбой — в семейный чат.'] }) },
    { id: 'bar', cat: 'Общение', n: 'Посидеть в баре', d: 'Пятничный вечер. Наутро может быть тяжело.', cost: () => M(4000),
      text: () => 'зовёт посидеть в баре',
      done: () => { const h = Math.random() < 0.4; return { fx: { money: -M(4000), happy: 6, stress: -6, health: h ? -3 : 0 }, rel: 6, note: 'сидели в баре', lines: h ? ['Утро было тяжёлым.'] : [] }; },
      fin: () => { const h = Math.random() < 0.4; return { fx: { money: -M(4000), happy: 6, stress: -6, health: h ? -3 : 0 }, rel: 6, note: 'сидели в баре', lines: h ? ['Утро было тяжёлым.'] : [] }; } },
    { id: 'party', cat: 'Общение', n: 'Закатить вечеринку вместе', d: 'Скидываетесь пополам. Репутация и куча новых знакомых. Бывает, приезжает полиция.', ap: 1,
      fields: [{ k: 'sum', label: 'Бюджет (пополам)', type: 'money', def: 60000 }],
      need: (s, p, f) => s.st.money < (f.sum || 0) / 2 ? 'Нужна ваша половина' : null,
      text: (s, f) => `предлагает закатить вечеринку вскладчину: с каждого ${$m(f.sum / 2)}`,
      accept: (s, f) => s.st.money < f.sum / 2 ? 'Не хватает денег' : null,
      roll: () => ({ chance: 80 }),
      done: (s, p, f, r) => ({ fx: { money: -Math.round(f.sum / 2), happy: r.ok ? 10 : 2, rep: r.ok ? Math.min(5, 1 + Math.round(f.sum / M(40000))) : -2, cha: 1 }, rel: 8, note: r.ok ? 'закатили вечеринку' : 'вечеринку разогнала полиция', lines: [r.ok ? 'Вечеринку обсуждает весь район.' : 'Соседи вызвали полицию — штраф и неловкость.'], pub: r.ok ? `${NET.me().name} и ${p.name} закатили вечеринку` : '' }),
      fin: (s, d, f, from, r) => ({ fx: { money: -Math.round(f.sum / 2), happy: r.ok ? 10 : 2, rep: r.ok ? Math.min(5, 1 + Math.round(f.sum / M(40000))) : -2, cha: 1 }, rel: 8, note: 'вечеринка', lines: [r.ok ? 'Отличная вечеринка!' : 'Приехала полиция. Ну хоть весело было.'] }) },
    { id: 'advice', cat: 'Общение', n: 'Попросить совета', d: 'Друг поумнее подскажет: интеллект или деловая хватка +1.',
      text: () => 'просит у вас совета',
      reply: s => ({ int: Math.round(E.sk(s, 'int')), biz: Math.round(E.sk(s, 'biz')) }),
      roll: (s, rp) => ({ chance: E.clamp(30 + Math.round(Math.max(rp.int || 0, rp.biz || 0) - Math.max(E.sk(s, 'int'), E.sk(s, 'biz'))) + 40, 15, 90) }),
      done: (s, p, f, r) => ({ fx: r.ok ? { int: 1, biz: 1 } : {}, rel: 4, note: 'советовался', lines: [r.ok ? 'Толковый совет — многое прояснилось.' : 'Совет так себе, но спасибо.'] }),
      fin: () => ({ fx: { happy: 2, cha: 1 }, rel: 4, note: 'дал совет' }) },
    // ===== Семья =====
    { id: 'babysit', cat: 'Семья', n: 'Посидеть с детьми друга', d: 'Даёте другу выдохнуть: у него минус стресс, у вас — опыт.', ap: 1,
      text: () => 'предлагает посидеть с вашими детьми',
      accept: s => !kids(s).length ? 'У вас нет детей' : null,
      done: () => ({ fx: { stress: 4, happy: 2 }, rel: 8, note: 'сидел с детьми друга' }),
      fin: () => ({ fx: { stress: -12, happy: 6 }, rel: 8, note: 'друг посидел с детьми', lines: ['Свободный вечер! Вы наконец выспались.'] }) },
    { id: 'godparent', cat: 'Семья', n: 'Позвать в крёстные', d: 'Друг станет крёстным ваших детей. Сильно сближает.',
      need: s => !kids(s).length ? 'Нужны дети' : null,
      text: () => 'зовёт вас стать крёстным его ребёнка',
      done: () => ({ fx: { happy: 6 }, rel: 15, note: 'крёстный моих детей' }),
      fin: () => ({ fx: { happy: 8, rep: 2 }, rel: 15, note: 'крёстный детей друга' }) },
    // ===== Развлечения =====
    { id: 'race', cat: 'Развлечения', n: 'Гонка на машинах на деньги', d: 'Нужны машины у обоих. Быстрее машина и смелее водитель — выше шанс. Бывают аварии.',
      fields: [{ k: 'sum', label: 'Ставка', type: 'money', def: 20000 }],
      need: (s, p, f) => !s.car ? 'Нужна машина' : s.st.money < (f.sum || 0) ? 'Не хватает на ставку' : null,
      text: (s, f) => `вызывает на гонку: ставка ${$m(f.sum)} (его машина — ${s.car ? s.car.n : '?'})`,
      accept: (s, f) => !s.car ? 'У вас нет машины' : s.st.money < f.sum ? 'Не хватает на ставку' : null,
      reply: s => ({ car: s.car ? s.car.value : 0 }),
      roll: (s, rp) => ({ chance: E.clamp(50 + Math.round(Math.log2(Math.max(1, s.car.value) / Math.max(1, rp.car || 1)) * 12), 15, 85) }),
      done: (s, p, f, r) => { const crash = Math.random() < 0.08; if (crash && s.car) s.car.value = Math.round(s.car.value * 0.7); return { fx: { money: r.ok ? f.sum : -f.sum, happy: r.ok ? 6 : -3, health: crash ? -8 : 0 }, rel: 2, note: r.ok ? 'выиграл гонку' : 'проиграл гонку', lines: crash ? ['Авария! Машина побита.'] : [] }; },
      fin: (s, d, f, from, r) => ({ fx: { money: r.ok ? -f.sum : f.sum, happy: r.ok ? -3 : 6 }, rel: 2, note: r.ok ? 'проиграл гонку' : 'выиграл гонку' }) },
    { id: 'console', cat: 'Развлечения', n: 'Поиграть в приставку', d: 'FIFA, Mortal Kombat — кто кого.',
      text: () => 'зовёт порубиться в приставку',
      roll: () => ({ chance: 50 }),
      done: (s, p, f, r) => ({ fx: { happy: r.ok ? 5 : 2, stress: -4 }, rel: 4, note: r.ok ? 'разгромил в приставку' : 'проиграл в приставку' }),
      fin: (s, d, f, from, r) => ({ fx: { happy: r.ok ? 2 : 5, stress: -4 }, rel: 4, note: 'играли в приставку' }) },
    { id: 'karaoke', cat: 'Развлечения', n: 'Караоке', d: 'Петь плохо, но громко. Харизма +1.', cost: () => M(3000),
      text: () => 'зовёт в караоке',
      done: () => ({ fx: { money: -M(3000), happy: 6, cha: 1 }, rel: 5, note: 'пели в караоке' }), fin: () => ({ fx: { money: -M(3000), happy: 6, cha: 1 }, rel: 5, note: 'пели в караоке' }) },
    { id: 'prank', cat: 'Развлечения', n: 'Разыграть друга', d: 'Смешно — если друг оценит. Может и обидеться.',
      text: () => 'что-то задумал… (розыгрыш)',
      roll: (s, rp) => ({ chance: E.clamp(55 + Math.round((E.sk(s, 'cha') - 40) / 3), 25, 85) }),
      done: (s, p, f, r) => ({ fx: { happy: r.ok ? 5 : -2 }, rel: r.ok ? 5 : -8, note: r.ok ? 'удачно разыграл' : 'неудачно разыграл', lines: [r.ok ? 'Друг смеялся до слёз. Видео разошлось по общему чату.' : 'Друг обиделся. Перегнули.'] }),
      fin: (s, d, f, from, r) => ({ fx: { happy: r.ok ? 3 : -4 }, rel: r.ok ? 5 : -8, note: r.ok ? 'разыграл меня' : 'глупо разыграл', lines: [r.ok ? from.name + ' вас разыграл — смешно вышло!' : from.name + ' вас разыграл. Не смешно.'] }) },
    // ===== Власть =====
    { id: 'appoint', cat: 'Власть', n: 'Назначить советником', d: 'Если вы на государственной должности — берёте друга в команду с хорошей зарплатой.',
      need: s => !s.pol ? 'Нужна государственная должность' : null,
      data: s => ({ pos: 'Советник (' + s.pol.n.toLowerCase() + ')', sal: M(E.isLeader(s) ? 400000 : 180000) }),
      text: (s, f, d) => `предлагает должность: ${d.pos}, ${$m(d.sal)}/мес`,
      onAccept: (s, f, d, from) => { s.job = { id: 'advisor', title: d.pos, org: 'Администрация', salary: d.sal, level: 3, perf: 60, months: 0, weeks: 0, sk: 'cha', ladder: [d.pos], boss: from.uid }; s.st.infl = Math.min(100, (s.st.infl || 0) + 8); return { fx: { rep: 4, happy: 6 }, rel: 8, note: 'советник у друга', lines: ['Новая работа: ' + d.pos + ', ' + $m(d.sal) + '/мес', 'Влияние +8'] }; },
      done: (s, p) => ({ rel: 8, note: 'назначил советником', pub: `${p.name} — новый советник ${NET.me().name}` }), fin: () => null },
    { id: 'debate', cat: 'Власть', n: 'Публичные дебаты', d: 'Спор на камеру: у кого выше харизма — тот и выиграл. Победителю репутация и влияние.',
      text: () => 'вызывает на публичные дебаты',
      reply: s => ({ cha: Math.round(E.sk(s, 'cha')) }),
      roll: (s, rp) => ({ chance: E.clamp(50 + Math.round((E.sk(s, 'cha') - (rp.cha || 30)) / 2), 15, 85) }),
      done: (s, p, f, r) => { if (r.ok) s.st.infl = Math.min(100, (s.st.infl || 0) + 2); return { fx: r.ok ? { rep: 3, happy: 4 } : { rep: -2 }, rel: -1, note: r.ok ? 'выиграл дебаты' : 'проиграл дебаты', pub: `Дебаты: ${r.ok ? NET.me().name : p.name} разгромил оппонента` }; },
      fin: (s, d, f, from, r) => { if (!r.ok) s.st.infl = Math.min(100, (s.st.infl || 0) + 2); return { fx: r.ok ? { rep: -2 } : { rep: 3, happy: 4 }, rel: -1, note: r.ok ? 'проиграл дебаты' : 'выиграл дебаты' }; } },
    // ===== Криминал =====
    { id: 'alibi', cat: 'Криминал', n: 'Обеспечить алиби', d: 'Вы клянётесь, что друг был с вами. Его розыск −20, но если вскроется — пострадаете оба.',
      text: () => 'готов подтвердить ваше алиби перед полицией',
      accept: s => !(s.crime && (s.crime.heat || 0) > 0) ? 'Вас никто не ищет' : null,
      roll: () => ({ chance: 75 }),
      done: (s, p, f, r) => ({ fx: r.ok ? {} : { rep: -5, stress: 10 }, rel: r.ok ? 10 : 3, note: r.ok ? 'обеспечил алиби' : 'алиби вскрылось', lines: [r.ok ? 'Следователь поверил.' : 'Алиби развалилось — вас тоже взяли на заметку.'] }),
      fin: (s, d, f, from, r) => { L.crimeInit(s); s.crime.heat = Math.max(0, (s.crime.heat || 0) + (r.ok ? -20 : 10)); return { rel: r.ok ? 10 : 3, note: r.ok ? 'друг обеспечил алиби' : 'алиби не сработало', lines: [r.ok ? 'Розыск −20' : 'Розыск +10'] }; } },
    { id: 'krysha', cat: 'Криминал', n: 'Дать крышу бизнесу', d: 'Своя ОПГ или банда защищает бизнес друга от наездов и проверок. Друг платит разово.',
      fields: [{ k: 'sum', label: 'Плата', type: 'money', def: 150000 }],
      need: s => !((s.opg && !s.opg.gone) || (s.crime && s.crime.on && s.crime.gang)) ? 'Нужна своя ОПГ или банда' : null,
      text: (s, f) => `предлагает «крышу» для вашего бизнеса за ${$m(f.sum)}: защита от наездов и проверок`,
      accept: (s, f) => !s.biz.length ? 'У вас нет бизнеса' : s.st.money < f.sum ? 'Не хватает денег' : null,
      onAccept: (s, f) => { for (const b of s.biz) b.guard = Math.max(b.guard || 0, 40); s.flags.noInspect = s.turn + 26; return { fx: { money: -f.sum }, rel: 4, note: 'под крышей друга', lines: ['Бизнес под защитой: охрана 40, проверки полгода обходят стороной.'] }; },
      done: (s, p, f) => { L.crimeInit(s); s.crime.heat = Math.min(100, (s.crime.heat || 0) + 5); return { fx: { money: f.sum }, rel: 4, note: 'крышую бизнес друга' }; }, fin: () => null },
    { id: 'launder', cat: 'Криминал', n: 'Отмыть деньги через бизнес друга', d: 'Грязные деньги проходят через его кассу. Ему 20%, вам — чистые и минус розыск.',
      fields: [{ k: 'sum', label: 'Сумма', type: 'money', def: 300000 }],
      need: (s, p, f) => !(s.crime && s.crime.on) ? 'Вы не на тёмной стороне' : s.st.money < (f.sum || 0) ? 'Не хватает денег' : null,
      text: (s, f) => `просит прогнать ${$m(f.sum)} через ваш бизнес (вам 20%)`,
      accept: s => !s.biz.length ? 'У вас нет бизнеса' : null,
      roll: () => ({ chance: 82 }),
      onAccept: () => null,
      done: (s, p, f, r) => { L.crimeInit(s); if (r.ok) s.crime.heat = Math.max(0, s.crime.heat - 15); else s.crime.heat = Math.min(100, s.crime.heat + 20); return { fx: { money: r.ok ? -Math.round(f.sum * 0.2) : -Math.round(f.sum * 0.5) }, rel: 4, note: r.ok ? 'отмыл деньги' : 'схема с деньгами вскрылась', lines: [r.ok ? 'Деньги чистые. Комиссия 20%, розыск −15.' : 'Финмониторинг заметил. Половина суммы заморожена, розыск +20.'] }; },
      fin: (s, d, f, from, r) => { if (r.ok) return { fx: { money: Math.round(f.sum * 0.2) }, rel: 4, note: 'помог с деньгами', lines: ['Ваша комиссия: ' + $m(f.sum * 0.2)] }; const b = s.biz[0]; if (b) b.health = E.clamp(b.health - 10, 0, 100); return { fx: { stress: 10 }, rel: -2, note: 'проверка из-за друга', lines: ['К вам пришёл финмониторинг. Бизнес −10.'] }; } },
    // ===== Затеи =====
    { id: 'collab', cat: 'Затеи', n: 'Снять совместный ролик', d: 'Позовите друга на свой канал. Чем он известнее и харизматичнее, тем больше новых подписчиков.', ap: 1,
      need: s => !(s.proj || []).some(p => !p.closed && (p.kind === 'media' || p.kind === 'music')) ? 'Нужен свой канал или музыка (напишите в чат «завожу ютуб-канал»)' : null,
      text: s => { const p = s.proj.find(x => !x.closed && (x.kind === 'media' || x.kind === 'music')); return `зовёт сняться у него: ${PROJ.title(s, p)}`; },
      reply: s => ({ cha: Math.round(E.sk(s, 'cha')), subs: (s.proj || []).filter(p => !p.closed).reduce((a, p) => a + (p.subs || 0), 0), rep: Math.round(s.st.rep) }),
      roll: s => ({ chance: 70 }),
      done: (s, p, f, r, d, rp) => { const pj = s.proj.find(x => !x.closed && (x.kind === 'media' || x.kind === 'music')); const add = Math.round(((rp && rp.subs) || 0) * 0.08 + ((rp && rp.cha) || 30) * 8 + ((rp && rp.rep) || 30) * 5) * (r.ok ? 1 : 0.3); pj.subs += add; pj.posts++; return { fx: { happy: 4 }, rel: 6, note: 'сняли совместный ролик', lines: [`Совместный выпуск с ${p.name}: +${add} в «${pj.n}»`] }; },
      fin: (s, d, f, from, r) => { const pj = (s.proj || []).find(x => !x.closed && (x.kind === 'media' || x.kind === 'music')); if (pj) pj.subs += r.ok ? 150 : 30; return { fx: { rep: 1, cha: 1, happy: 3 }, rel: 6, note: 'снимался у друга', lines: [pj ? 'Ваш канал тоже подрос.' : 'Вас заметили зрители друга.'] }; } },
    { id: 'pinvest', cat: 'Затеи', n: 'Вложиться в затею друга', d: 'Друг получает деньги на свою затею (канал, стартап, партию) — и ему приятно, что вы верите.',
      fields: [{ k: 'sum', label: 'Сумма', type: 'money', def: 100000 }],
      need: (s, p, f) => s.st.money < (f.sum || 0) ? 'Не хватает денег' : null,
      text: (s, f) => `хочет вложить ${$m(f.sum)} в вашу затею`,
      accept: s => !(s.proj || []).some(p => !p.closed) ? 'У вас нет затей (канал, стартап, партия…)' : null,
      onAccept: (s, f) => { const pj = s.proj.filter(p => !p.closed).slice(-1)[0]; s.st.money += f.sum; const r = PROJ.OPS.invest(s, pj, f.sum); return { rel: 8, note: 'друг вложился в затею', lines: r.lines }; },
      done: (s, p, f) => ({ fx: { money: -f.sum }, rel: 8, note: 'вложился в затею друга' }), fin: () => null },
  ];
  // категории: «Затеи» — перед «Подлянками»
  const hi = IA.CATS.indexOf('Подлянки');
  if (!IA.CATS.includes('Затеи')) IA.CATS.splice(hi >= 0 ? hi : IA.CATS.length, 0, 'Затеи');
  const firstHost = IA.DEFS.findIndex(d => d.hostile);
  IA.DEFS.splice(firstHost >= 0 ? firstHost : IA.DEFS.length, 0, ...NEW);
  for (const d of IA.DEFS) IA.DEF[d.id] = d;
  // старый «блат в бизнес» теперь ведёт в «Взять к себе в бизнес»
  IA.DEF.blat.d = 'На свою работу или в администрацию — с шансом. В свой бизнес удобнее через «Взять к себе в бизнес».';
})();
