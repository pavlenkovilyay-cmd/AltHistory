// AltHistory — большая политика:
//  • ультиматумы (глава государства → другим странам, и боты друг другу / вам);
//  • недовольство в странах: протесты, митинги, забастовки → революции, дворцовые перевороты, кровавые восстания;
//  • методы подавления (переговоры, полиция, аресты, армия, комендантский час, пропаганда, отставка правительства);
//  • боты-страны живут своей жизнью: торговля, санкции, помощь, союзы, пограничные инциденты, ультиматумы и войны.
'use strict';
const POL = {};
(() => {
  const cl = (v, a, b) => Math.max(a, Math.min(b, v));
  const W_ = s => s.world;
  const nrm = t => E.norm(t || '');
  const fail = (title, lines, extra) => Object.assign({ ok: false, impossible: true, title, lines: lines || [], apCost: 0 }, extra || {});
  const op = (name, a) => (typeof GOV !== 'undefined' && GOV.op) ? GOV.op(name, a) : GOV.OPS[name](UI.s, a);
  const isCli = s => s.mp && s.mp.role === 'client';
  const alive = (s, i) => { const c = W_(s).cs[i]; return c && !c.dead && E.countryProvs(s, i).length > 0; };
  const nm = (s, i) => W_(s).cs[i].n;
  const dem = c => typeof DEMOC === 'function' ? DEMOC(c.st.gov) : /Республика/.test(c.st.gov || '');

  // ======================= поиск стран и регионов в тексте =======================
  POL.REGIONS = [
    [/прибалт|балти/, ['Эстония', 'Латвия', 'Литва']],
    [/закавказ|кавказ/, ['Грузия', 'Армения', 'Азербайджан']],
    [/средн\S* ази|центральн\S* ази/, ['Казахстан', 'Узбекистан', 'Туркмения', 'Туркменистан', 'Киргизия', 'Кыргызстан', 'Таджикистан']],
    [/скандинав/, ['Норвегия', 'Швеция', 'Дания', 'Финляндия']],
    [/бенилюкс/, ['Бельгия', 'Нидерланды', 'Люксембург']],
    [/балкан/, ['Сербия', 'Югославия', 'Хорватия', 'Босния', 'Черногория', 'Албания', 'Болгария', 'Греция', 'Северная Македония', 'Македония']],
  ];
  const stem = n => { n = nrm(n).split(/[ (]/)[0]; return n.slice(0, Math.max(4, n.length - 2)); };
  POL.targets = (s, text) => {
    const W = W_(s), t = nrm(text), out = [];
    for (const [re, names] of POL.REGIONS) if (re.test(t)) for (const n of names) { const i = W.cs.findIndex(c => !c.dead && nrm(c.n).startsWith(nrm(n).slice(0, 5))); if (i >= 0 && i !== W.home && alive(s, i) && !out.includes(i)) out.push(i); }
    if (out.length) return out;
    W.cs.forEach((c, i) => { if (i === W.home || !alive(s, i)) return; const st = stem(c.n); if (st.length >= 4 && t.includes(st)) out.push(i); });
    if (!out.length) { const i = E.findCountry(s, t); if (i >= 0 && i !== W.home) out.push(i); }
    return out.slice(0, 5);
  };
  // ======================= ультиматумы =======================
  POL.DEMANDS = [
    { id: 'annex', re: /вступ|присоедин|войти в состав|войт(и|ёт) в|аннекс|стать частью|воссоедин|в состав/, n: 'войти в состав вашей страны', sev: 3 },
    { id: 'puppet', re: /вассал|марионет|протекторат|сател|подчин(иться|ение)|под (наш|мо)\S* контрол/, n: 'стать вашим сателлитом', sev: 2.4 },
    { id: 'land', re: /(отда|переда|верн|уступ|отко|забер)\S*.{0,30}(провинц|регион|территор|област|город|земл|край|полуостров|остров|границ)/, n: 'отдать приграничные земли', sev: 2 },
    { id: 'demil', re: /демилитар|распуст\S* арм|разоруж|отвести войск|убрать войск/, n: 'сократить армию', sev: 1.7 },
    { id: 'bloc', re: /вый(ти|дет)\S* из (нато|ес|союз|блок|альянс)|разорвать союз|порвать с (нато|сша|западом)/, n: 'выйти из военного блока', sev: 1.4 },
    { id: 'regime', re: /отставк|смен\S* (власт|правительств|президент)|уйти в отставку/, n: 'сменить правительство', sev: 2.2 },
    { id: 'tribute', re: /дань|контрибуц|выплат|заплат|компенсац|репарац|деньг/, n: 'выплатить компенсацию', sev: 1 },
  ];
  POL.demand = text => { const t = nrm(text); return POL.DEMANDS.find(d => d.re.test(t)) || POL.DEMANDS.find(d => d.id === 'land'); };
  // шанс, что страна примет требование
  POL.acceptP = (s, from, to, d) => {
    const W = W_(s), A = W.cs[from], T = W.cs[to];
    const ratio = Math.max(0.05, E.power(s, from)) / Math.max(0.05, E.power(s, to));
    const blocProt = (T.st.bloc || []).some(b => /НАТО|Союзники|Антанта/.test(b)) && !(A.st.bloc || []).some(b => (T.st.bloc || []).includes(b));
    const rel = to === W.home ? 0 : (from === W.home ? T.rel || 0 : POL.rel(s, from, to));
    const p = 0.06 + 0.22 * Math.log2(ratio) - 0.13 * (d.sev - 1) + rel / 350 - (blocProt ? 0.3 : 0) + (T.st.stab < 30 ? 0.08 : 0) - (dem(T) && d.sev >= 2 ? 0.08 : 0) + (WD.enemies(s, to).length ? 0.06 : 0);
    return cl(p, 0.02, 0.92);
  };
  // принятие: меняем мир (через GOV.op — в мультиплеере это уйдёт хосту)
  POL.applyDemand = (s, from, to, d) => {
    const W = W_(s), A = W.cs[from], T = W.cs[to];
    if (d.id === 'annex') { op('annex', { c: from, ci: to, news: `${T.n} приняла ультиматум и вошла в состав страны ${A.n}.` }); return [T.n + ' теперь часть вашей страны.']; }
    if (d.id === 'land') {
      const provs = POL.border(s, from, to, 2 + Math.round(Math.random() * 3));
      if (!provs.length) return ['Общей границы нет — земли передать нечего. Договорились о компенсации.'].concat(POL.applyDemand(s, from, to, POL.DEMANDS.find(x => x.id === 'tribute')));
      op('land', { c: from, from: to, provs, news: `${T.n} уступила ${A.n} ${provs.length} пригранич. провинц. под давлением ультиматума.` });
      return ['Получено провинций: ' + provs.length + ' (' + provs.slice(0, 3).map(i => M().provinces[i].n).join(', ') + (provs.length > 3 ? '…' : '') + ')'];
    }
    if (d.id === 'puppet') { op('puppet', { c: from, ci: to, news: `${T.n} стала сателлитом страны ${A.n}.` }); return [T.n + ' — теперь ваш сателлит: союзник в войнах и торговле.']; }
    if (d.id === 'demil') { op('stat', { c: to, d: { milp: -T.st.milp * 0.5 } }); op('rel', { c: from, ci: to, d: -10, news: `${T.n} согласилась сократить армию по требованию ${A.n}.` }); return ['Армия ' + T.n + ' сокращена вдвое.']; }
    if (d.id === 'bloc') { for (const b of (T.st.bloc || []).slice()) op('bloc', { c: to, b, join: false }); WD.news(s, `${T.n} вышла из военных блоков под давлением ${A.n}.`, [from, to], 1, 'dip'); return ['Блоки покинуты.']; }
    if (d.id === 'regime') { op('regime', { c: to, gov: T.st.gov, lead: '', stab: -10, news: `${T.n}: правительство ушло в отставку после ультиматума ${A.n}.` }); return ['Правительство ' + T.n + ' сменилось.']; }
    const sum = Math.max(0.5, Math.round(T.st.gdp * 0.02 * 10) / 10);
    op('stat', { c: to, d: { debt: 2 } }); op('stat', { c: from, d: { debt: -2 } });
    WD.news(s, `${T.n} выплатит компенсацию стране ${A.n}.`, [from, to], 1, 'dip');
    if (from === W.home && s.pol && s.pol.id === 'president') { const G = GOV.my && GOV.my(s); if (G) { G.appr = cl(G.appr + 4, 0, 100); G.pc = (G.pc || 0) + 20; } }
    return ['Компенсация: госдолг вашей страны −2% ВВП (~' + sum + ' млрд).'];
  };
  POL.border = (s, a, b, n) => {
    const W = W_(s), P = M().provinces, out = [];
    for (const e of M().edges) { const oa = W.own[e.a], ob = W.own[e.b]; if (oa === a && ob === b && !out.includes(e.b)) out.push(e.b); else if (ob === a && oa === b && !out.includes(e.a)) out.push(e.a); }
    const cap = W.cs[b].cap; return out.filter(i => i !== cap && P[i]).slice(0, n);
  };
  E.ACTIONS.push('ultimatum', 'unrest', 'revolt', 'suppress', 'rep');
  E.A.ultimatum = (s, it) => {
    const raw = [it.target, it.raw].join(' ');
    if (!E.isLeader(s)) return fail('Ультиматумы шлёт глава государства', ['Сейчас вы — ' + E.position(s).toLowerCase() + '.', 'Путь к власти: выборы, «дворцовый переворот», революция или своя партия.']);
    const ts = POL.targets(s, raw);
    if (!ts.length) return fail('Кому ультиматум?', ['Назовите страну или регион: «ультиматум Латвии: вступить в наш союз», «требую от Польши отдать приграничные земли».']);
    const d = POL.demand(raw), W = W_(s), lines = [];
    s.flags.ult = s.flags.ult || {};
    let okN = 0;
    for (const ci of ts) {
      const C = W.cs[ci];
      if (WD.atWar(s, W.home, ci) && d.id !== 'tribute') { lines.push(C.n + ': уже воюете — сначала мир или победа.'); continue; }
      const cd = s.flags.ult[ci]; if (cd && Date.parse(cd) > Date.parse(s.date)) { lines.push(C.n + ': ответ на прошлый ультиматум ещё в силе — повторить можно позже.'); continue; }
      s.flags.ult[ci] = new Date(Date.parse(s.date) + 8 * 7 * 864e5).toISOString();
      const p = POL.acceptP(s, W.home, ci, d), yes = Math.random() < p;
      lines.push(`${C.n}: шанс согласия был ~${Math.round(p * 100)}% — ${yes ? 'ПРИНЯЛА' : 'ОТКАЗАЛА'}.`);
      if (yes) { okN++; lines.push(...POL.applyDemand(s, W.home, ci, d)); }
      else {
        op('rel', { c: W.home, ci, d: -35, news: `${C.n} отвергла ультиматум страны ${nm(s, W.home)} (${d.n}).` });
        op('stat', { c: ci, d: { stab: 4 } });
        s.flags.cb = s.flags.cb || {}; s.flags.cb[ci] = new Date(Date.parse(s.date) + 26 * 7 * 864e5).toISOString();
        lines.push('Есть повод для войны (полгода): «объявляю войну ' + C.n + '».');
      }
    }
    if (d.sev >= 2) for (const c of W.cs) if (!c.dead && dem(c) && !ts.includes(W.cs.indexOf(c))) c.rel = cl((c.rel || 0) - 4, -100, 100);
    if (d.sev >= 2) lines.push('Демократии осуждают давление: отношения с ними −4.');
    return { ok: okN > 0, title: okN ? `Ультиматум принят${ts.length > 1 ? ' (' + okN + ' из ' + ts.length + ')' : ''}` : 'Ультиматум отвергнут', lines, apCost: 1, map: okN > 0, war: okN > 0 ? 0 : undefined, fx: okN ? { rep: 3 } : { stress: 4 } };
  };
  // ---------- новые операции мира (выполняются у хоста и у клиента одинаково) ----------
  const addOps = () => {
    if (typeof GOV === 'undefined' || !GOV.OPS) return;
    Object.assign(GOV.OPS, {
      annex: (s, a) => { if (!s.world.cs[a.ci].dead) WD.annex(s, a.ci, a.c, a.news); },
      puppet: (s, a) => { const T = s.world.cs[a.ci]; T.puppetOf = a.c; T.st.gov = T.st.gov && /сателлит/.test(T.st.gov) ? T.st.gov : (T.st.gov || 'Правительство') + ' (сателлит)'; if (a.news) WD.news(s, a.news, [a.c, a.ci], 2, 'annex'); },
      regime: (s, a) => { const T = s.world.cs[a.c]; if (a.gov) T.st.gov = a.gov; T.st.lead = a.lead || ''; T.st.stab = cl(T.st.stab + (a.stab || 0), 0, 100); if (a.unrest !== undefined) T.st.unrest = a.unrest; if (a.news) WD.news(s, a.news, [a.c], a.imp || 1, 'coup'); },
      stat: (st0 => (s, a) => { st0(s, a); const C = s.world.cs[a.c]; if (C) { if (C.st.unrest !== undefined) C.st.unrest = cl(C.st.unrest, 0, 100); C.st.stab = cl(C.st.stab, 0, 100); if (C.st.repr !== undefined) C.st.repr = Math.max(0, C.st.repr); } })(GOV.OPS.stat),
      rebels: (s, a) => { // кровавое восстание/отделение: провинции заранее выбраны тем, кто начал (одинаково у всех)
        const W = s.world; const nc = WD.newCountry(s, { id: a.id, n: a.n, col: a.col, pw: a.pw || 4, cap: a.provs[0], st: { gov: a.gov || 'Повстанцы', lead: a.lead || '', stab: 45 } });
        a.provs.forEach(p => { if (W.own[p] === a.c) W.own[p] = nc; });
        WD.splitStats(s, a.c, nc, a.provs); W.cs[nc].rebelOf = a.c; W.cs[nc].milp0 = W.cs[a.c].st.milp; W.cs[nc].st.milp = W.cs[a.c].st.milp;
        WD.declare(s, nc, a.c, { total: !a.limited, civil: true });
        if (a.news) WD.news(s, a.news, [a.c, nc], 2, 'civil');
        return nc;
      },
    });
  };
  // ======================= отношения ботов между собой =======================
  POL.key = (a, b) => a < b ? a + ':' + b : b + ':' + a;
  POL.rel = (s, a, b) => { const W = W_(s); if (a === W.home) return W.cs[b].rel || 0; if (b === W.home) return W.cs[a].rel || 0; const R = W.rel2 || {}; if (R[POL.key(a, b)] !== undefined) return R[POL.key(a, b)]; const A = W.cs[a], B = W.cs[b]; let v = 0; if ((A.st.bloc || []).some(x => (B.st.bloc || []).includes(x))) v += 40; if (dem(A) === dem(B)) v += 10; else v -= 10; if (A.rebelOf === b || B.rebelOf === a) v -= 70; if (A.puppetOf === b || B.puppetOf === a) v += 50; return v; };
  POL.addRel = (s, a, b, d) => { const W = W_(s); W.rel2 = W.rel2 || {}; W.rel2[POL.key(a, b)] = cl(POL.rel(s, a, b) + d, -100, 100); };
  POL.neigh = s => { const W = W_(s), N = new Map(); for (const e of M().edges) { const a = W.own[e.a], b = W.own[e.b]; if (a === b || a === undefined || b === undefined) continue; if (!N.has(a)) N.set(a, new Set()); if (!N.has(b)) N.set(b, new Set()); N.get(a).add(b); N.get(b).add(a); } return N; };
  POL.botsMonth = s => {
    const W = W_(s), N = POL.neigh(s), big = i => WD.big(s, i), list = E.alive(s);
    if (W.rel2) for (const k in W.rel2) { W.rel2[k] *= 0.97; if (Math.abs(W.rel2[k]) < 2) delete W.rel2[k]; }
    let news = 0;
    const say = (t, cs, imp, kind) => { if (news > 5 && imp < 2) return; news++; WD.news(s, t, cs, imp, kind); };
    const n = Math.min(list.length, 8 + Math.round(list.length / 25));
    for (let k = 0; k < n; k++) {
      const a = E.pick(list); if (a === undefined) break; const A = W.cs[a]; if (A.dead) continue;
      const nb = [...(N.get(a) || [])].filter(x => !W.cs[x].dead);
      const pool = nb.length && Math.random() < 0.7 ? nb : list.filter(x => x !== a && big(x));
      const b = E.pick(pool); if (b === undefined || b === a) continue; const B = W.cs[b];
      if (b === W.home || a === W.home) continue; // с нашей страной — отдельно (ниже)
      const r = POL.rel(s, a, b), pa = E.power(s, a), pb = E.power(s, b), war = WD.atWar(s, a, b);
      if (war) continue;
      const imp = (big(a) || big(b)) ? 0 : -1;
      const roll = Math.random();
      if (A.st.stab > 40 && B.st.stab > 40 && r > -10 && roll < 0.35) { // торговля
        POL.addRel(s, a, b, 6); A.shock += 0.25; B.shock += 0.25;
        if (imp >= 0 && Math.random() < 0.12) say(`${A.n} и ${B.n} подписали торговое соглашение.`, [a, b], 0, 'dip');
      } else if (dem(A) !== dem(B) && r < -25 && A.st.gdp > B.st.gdp * 2 && roll < 0.5) { // санкции
        POL.addRel(s, a, b, -10); B.shock -= 1; A.shock -= 0.15;
        if (imp >= 0) say(`${A.n} ввела санкции против страны ${B.n}.`, [a, b], 0, 'sanction');
      } else if (B.shock < -2 && A.st.gdp > B.st.gdp && r > -20 && roll < 0.6) { // помощь
        POL.addRel(s, a, b, 12); B.shock += 0.8; if (imp >= 0) say(`${A.n} выделила помощь стране ${B.n}.`, [a, b], 0, 'dip');
      } else if (r > 55 && !(W.pact2 || []).some(p => POL.key(p[0], p[1]) === POL.key(a, b)) && roll < 0.4) { // союз
        (W.pact2 = W.pact2 || []).push([a, b]); POL.addRel(s, a, b, 8);
        if (imp >= 0) say(`${A.n} и ${B.n} заключили военный союз.`, [a, b], 1, 'dip');
      } else if (nb.includes(b) && r < -25 && pa > pb * 2.5 && (A.st.milp > 2.5 || A.st.stab < 45 || (A.st.bloc || []).includes('Ось')) && roll < 0.25) { // ультиматум бота
        const d = Math.random() < 0.75 ? POL.DEMANDS.find(x => x.id === 'land') : POL.DEMANDS.find(x => x.id === 'puppet');
        const p = POL.acceptP(s, a, b, d);
        if (Math.random() < p) { POL.botApply(s, a, b, d); }
        else if (Math.random() < 0.5) { WD.declare(s, a, b, { limited: true }); say(`${B.n} отвергла ультиматум страны ${A.n} — началась война.`, [a, b], 1, 'war'); }
        else { POL.addRel(s, a, b, -20); if (imp >= 0) say(`${B.n} отвергла ультиматум страны ${A.n}: напряжение на границе.`, [a, b], 0, 'dip'); }
      } else if (nb.includes(b) && r < -10 && roll < 0.3) { // инцидент
        POL.addRel(s, a, b, -12); if (imp >= 0 && Math.random() < 0.5) say(`Пограничный инцидент между ${A.n} и ${B.n}.`, [a, b], 0, 'dip');
      } else if (r < -40 && roll < 0.25) { // разрядка
        POL.addRel(s, a, b, 15); if (imp >= 0 && Math.random() < 0.3) say(`${A.n} и ${B.n} начали переговоры о разрядке.`, [a, b], 0, 'dip');
      }
    }
    // боты и наша страна: ультиматумы соседей (если вы глава — решаете вы; иначе решает правительство)
    const H = W.home, nbH = [...(N.get(H) || [])].filter(x => !W.cs[x].dead && !WD.atWar(s, x, H));
    for (const a of nbH) {
      const A = W.cs[a]; if ((A.rel || 0) > -35 || Math.random() > 0.05) continue;
      if (E.power(s, a) < E.power(s, H) * 2) continue;
      const d = POL.DEMANDS.find(x => x.id === (Math.random() < 0.7 ? 'land' : 'tribute'));
      (W.ultQ = W.ultQ || []).push({ id: 'u' + W.month + '_' + a, from: a, to: H, d: d.id, at: s.date });
      WD.news(s, `${A.n} предъявила ультиматум стране ${W.cs[H].n}: ${d.n}.`, [a, H], 2, 'dip');
    }
  };
  POL.botApply = (s, a, b, d) => {
    const W = W_(s), A = W.cs[a], B = W.cs[b];
    if (d.id === 'land') { const provs = POL.border(s, a, b, 1 + Math.round(Math.random() * 2)); if (!provs.length) return; GOV.OPS.land(s, { c: a, from: b, provs, news: `${B.n} уступила ${A.n} ${provs.length} пров. под угрозой войны.` }); }
    else if (d.id === 'puppet') GOV.OPS.puppet(s, { c: a, ci: b, news: `${B.n} стала сателлитом страны ${A.n}.` });
    POL.addRel(s, a, b, -10);
  };
  // WD.big раньше на каждый вызов перебирал 25 тыс. границ — кэшируем соседей нашей страны (ход стал быстрее)
  WD.big = (s, ci) => { const W = s.world; if (ci === W.home) return true; if (W.cs[ci].st.gdp >= (W.era === 'ww2' ? 40 : 500)) return true; const k = s.turn + ':' + W.home + ':' + W.month + ':' + W.own.length; if (POL._bk !== k) { POL._bk = k; POL._bn = POL.neigh(s).get(W.home) || new Set(); } return POL._bn.has(ci); };
  // союзники вступают в войну за своих
  const hookDeclare = () => {
    const _d = WD.declare;
    WD.declare = (s, a, b, opt) => {
      const r = _d(s, a, b, opt);
      try {
        const W = W_(s);
        if (opt && opt.civil) return r;
        for (const p of (W.pact2 || [])) { const ally = p[0] === b ? p[1] : p[1] === b ? p[0] : -1; if (ally < 0 || ally === a || W.cs[ally].dead || WD.atWar(s, ally, a) || ally === W.home) continue; if (Math.random() < 0.55) { _d(s, ally, a, { limited: true }); WD.news(s, `${W.cs[ally].n} вступила в войну на стороне союзника — ${W.cs[b].n}.`, [ally, a, b], 1, 'war'); } }
      } catch (e) { console.warn('pact', e); }
      return r;
    };
  };

  // ======================= недовольство в странах =======================
  // c.st.unrest 0..100: копится от низкой стабильности, безработицы, инфляции, войны; гасится реформами и силой (c.st.repr — страх)
  POL.unrestTarget = (s, c) => cl(92 - c.st.stab * 1.05 + c.st.unemp * 0.7 + Math.max(0, c.st.infl - 8) * 0.35 + (c.wear || 0) * 0.25 - (c.st.repr || 0) * 0.35, 0, 100);
  POL.unrestMonth = s => {
    const W = W_(s);
    for (let i = 0; i < W.cs.length; i++) {
      const c = W.cs[i]; if (c.dead) continue; const st = c.st;
      if (st.unrest === undefined) st.unrest = cl(POL.unrestTarget(s, c) * 0.6, 0, 60);
      st.unrest = cl(st.unrest + (POL.unrestTarget(s, c) - st.unrest) * 0.12 + E.rnd(-2, 2), 0, 100);
      st.repr = Math.max(0, (st.repr || 0) * 0.9 - 0.5);
      if (st.unrest > 50) st.stab = cl(st.stab - (st.unrest - 50) / 25, 0, 100);
      const human = i === W.home && s.pol && s.pol.id === 'president';
      const gov = W.gov && W.gov[i];
      if (human || (gov && gov.uid)) continue; // страной правит игрок — решает он (окно в начале недели)
      const big = WD.big(s, i);
      if (st.unrest > 88 && Math.random() < 0.35) POL.botRevolution(s, i);
      else if (st.unrest > 72 && Math.random() < 0.5) POL.botSuppress(s, i);
      else if (st.unrest > 58 && Math.random() < 0.3 && (big || Math.random() < 0.2)) WD.news(s, `${c.n}: ${E.pick(['массовые митинги против властей', 'общенациональная забастовка', 'протестующие вышли на улицы столицы', 'шествия с требованием отставки правительства'])}.`, [i], i === W.home ? 1 : 0, 'protest');
    }
  };
  POL.botSuppress = (s, i) => {
    const W = W_(s), c = W.cs[i], st = c.st, big = WD.big(s, i), home = i === W.home;
    const m = dem(c) ? E.pick(['talks', 'talks', 'resign', 'police']) : E.pick(['police', 'arrest', 'arrest', 'army', 'curfew', 'talks']);
    const T = { talks: ['пошли на уступки протестующим', -18, 0, 0.6], resign: ['отправили правительство в отставку', -25, 0, -0.3], police: ['разогнали митинги полицией', -12, 8, 0], arrest: ['провели массовые аресты оппозиции', -20, 20, -0.2], army: ['применили армию против протестующих — есть погибшие', -32, 35, -1], curfew: ['ввели комендантский час', -10, 10, -0.5] }[m];
    if (m === 'army' && Math.random() < 0.35) { st.unrest = cl(st.unrest + 15, 0, 100); WD.news(s, `${c.n}: власти стреляли в толпу — это только разожгло восстание.`, [i], big || home ? 2 : 0, 'protest'); return; }
    st.unrest = cl(st.unrest + T[1], 0, 100); st.repr = (st.repr || 0) + T[2]; c.shock += T[3];
    if (m === 'resign') st.lead = '';
    if (m === 'army' || m === 'arrest') for (const x of W.cs) if (!x.dead && dem(x) && x !== c) POL.addRel(s, W.cs.indexOf(x), i, m === 'army' ? -15 : -6);
    if (big || home || Math.random() < 0.15) WD.news(s, `${c.n}: власти ${T[0]}.`, [i], home ? 1 : 0, 'protest');
  };
  POL.botRevolution = (s, i) => {
    const W = W_(s), c = W.cs[i], st = c.st, big = WD.big(s, i) || i === W.home;
    const k = Math.random(), provs = E.countryProvs(s, i).length;
    if (k < 0.45) { st.gov = dem(c) ? st.gov : E.pick(['Республика (переходное правительство)', 'Республика']); st.lead = ''; st.stab = cl(st.stab + 15, 0, 100); st.unrest = 25; st.repr = 0; c.shock -= 1; WD.news(s, `${c.n}: революция! Власть пала, к руководству пришло переходное правительство.`, [i], big ? 2 : 0, 'coup'); }
    else if (k < 0.75) { st.gov = 'Военная хунта'; st.lead = ''; st.stab = cl(st.stab + 10, 0, 100); st.unrest = 35; st.repr = 30; WD.news(s, `${c.n}: дворцовый переворот — генералы сместили руководство.`, [i], big ? 2 : 0, 'coup'); }
    else if (provs >= 4 && !WD.enemies(s, i).length) { st.unrest = 40; WD.civilWar(s, i, c.n + ' (революционеры)'); }
    else { st.unrest = 50; st.repr += 20; WD.news(s, `${c.n}: восстание подавлено, лидеры бежали.`, [i], big ? 1 : 0, 'protest'); }
  };
  // ======================= игрок: митинги, протесты, забастовки =======================
  POL.mov = s => s.mov || (s.mov = { sup: 0, heat: 0, rallies: 0, armed: 0, name: '' });
  POL.regime = s => { const H = W_(s).cs[W_(s).home]; return E.ww2(s) ? 'terror' : dem(H) ? 'dem' : 'auto'; };
  E.A.unrest = (s, it) => {
    const t = nrm([it.target, it.raw].join(' ')), W = W_(s), H = W.cs[W.home], mv = POL.mov(s), rg = POL.regime(s);
    if (E.age(s) < 16) return fail('Рано', ['Организовывать акции — с 16 лет.']);
    if (E.isLeader(s)) return fail('Вы и есть власть', ['Против себя митинг не соберёшь. Если на улицах неспокойно: «провожу переговоры с протестующими», «ввожу комендантский час».']);
    const strike = /забастов|стачк/.test(t), big = /массов|всеросс|общенац|миллион|крупн|больш|по всей стране|майдан/.test(t);
    const un = H.st.unrest || 0;
    const base = 45 + E.sk(s, 'cha') / 4 + Math.min(20, s.st.rep / 4) + un / 5 + Math.min(15, Math.log10(1 + mv.sup) * 3) - (big ? 15 : 0) - (rg === 'terror' ? 25 : rg === 'auto' ? 10 : 0);
    const r = E.roll(s, cl(Math.round(base), 8, 90));
    const riskArrest = (rg === 'terror' ? 0.45 : rg === 'auto' ? 0.18 : 0.04) + mv.heat / 300 + (big ? 0.06 : 0);
    mv.rallies++;
    if (!r.ok) {
      const caught = Math.random() < riskArrest;
      if (caught) {
        L.crimeInit(s); mv.heat = Math.max(0, mv.heat - 20);
        if (rg === 'terror' && Math.random() < 0.5) { const lines = ['НКВД пришёл ночью.']; lines.push(...L.jail(s, 3)); return { ok: false, roll: r, title: 'Арестован за «антисоветскую агитацию»', lines, apCost: 1 }; }
        return { ok: false, roll: r, title: 'Задержаны на акции', lines: ['Штраф и 10 суток.', 'Сторонники запомнили вашу смелость: +' + Math.round(mv.sup * 0.05 + 20) + ' человек.'], fx: { money: -Math.round(E.m(s, 30000)), stress: 12, rep: 2 }, after: mv.sup += Math.round(mv.sup * 0.05 + 20) };
      }
      return { ok: false, roll: r, title: 'Пришло мало людей', lines: ['Акция прошла незаметно. Поддержка: ' + mv.sup + ' чел.'], fx: { stress: 4 }, apCost: 1 };
    }
    const add = Math.round((r.crit ? 2 : 1) * (big ? E.ri(400, 3000) : E.ri(60, 500)) * (1 + un / 50) * (1 + s.st.rep / 60));
    mv.sup += add; mv.heat = cl(mv.heat + (big ? 15 : 7), 0, 100);
    const dU = (big ? 6 : 2.5) * (1 + mv.sup / 20000) * (strike ? 1.3 : 1);
    op('stat', { c: W.home, d: { unrest: Math.min(12, dU), stab: -Math.min(4, dU / 3) } });
    if (strike) op('stat', { c: W.home, d: { gr: -0.05 } });
    const repUp = big ? E.ri(4, 8) : E.ri(2, 4);
    if (big || mv.sup > 5000) WD.news(s, `${H.n}: ${s.ch.name} ${s.ch.surname} вывел на улицы ${E.short(add)} человек — ${strike ? 'забастовка' : 'митинг'} против властей.`, [W.home], 1, 'protest');
    return { ok: true, roll: r, crit: r.crit, title: strike ? 'Забастовка состоялась' : big ? 'Массовый митинг!' : 'Митинг прошёл', lines: [`Пришло: ~${E.short(add)} чел. Ваше движение: ${E.short(mv.sup)} сторонников.`, `Недовольство в стране: ${Math.round((H.st.unrest || 0))}/100`, rg === 'dem' ? 'Риск задержания низкий.' : 'Власти недовольны — внимание к вам растёт (' + Math.round(mv.heat) + '/100).'], fx: { rep: repUp, stress: 6, infl: big ? 3 : 1 }, apCost: 1 };
  };
  // ======================= революция / дворцовый переворот / кровавое восстание =======================
  E.A.revolt = (s, it) => {
    const t = nrm([it.target, it.raw].join(' ')), W = W_(s), H = W.cs[W.home], mv = POL.mov(s), un = H.st.unrest || 0, rg = POL.regime(s);
    if (E.isLeader(s)) return fail('Вы уже глава государства', ['Против собственной власти не восстают. Следите за недовольством: «Правительство» → «Улицы».']);
    if (E.age(s) < 18) return fail('Слишком молоды', []);
    const mode = it.mode || (/дворц|заговор|генерал|изнутри/.test(t) ? 'palace' : /кровав|вооруж|оруж|штурм|восстани|мятеж/.test(t) ? 'bloody' : 'revolution');
    const armyLvl = s.job && s.job.army ? s.job.level || 0 : 0;
    const o = s.opg && !s.opg.gone ? s.opg : null;
    if (mode === 'palace') {
      const elite = (s.pol && ['minister', 'governor'].includes(s.pol.id)) || armyLvl >= 4 || s.st.infl >= 70;
      if (!elite) return fail('Нужен доступ к верхушке', ['Дворцовый переворот делают изнутри. Нужно одно из:', '• должность министра или губернатора', '• воинское звание майор и выше', '• влияние 70+ (сейчас ' + Math.round(s.st.infl) + ')']);
      const ch = cl(Math.round(18 + s.st.infl / 4 + armyLvl * 5 + (60 - H.st.stab) * 0.4 + un * 0.2 + (s.pol && s.pol.id === 'minister' ? 10 : 0)), 5, 70);
      const r = E.roll(s, ch);
      if (!r.ok) {
        if (rg === 'terror' && Math.random() < 0.5) { s.over = true; s.overReason = 'расстрелян за заговор'; s.st.health = 0; return { ok: false, roll: r, title: 'Заговор раскрыт', lines: ['Приговор — высшая мера.'], dead: true, apCost: 1 }; }
        L.crimeInit(s); s.pol = null; const lines = ['Заговорщиков взяли под стражу.']; lines.push(...L.jail(s, 4));
        return { ok: false, roll: r, title: 'Дворцовый переворот провалился', lines, apCost: 1, fx: { rep: -20, infl: -30 } };
      }
      POL.takePower(s, 'Дворцовый переворот', `${H.n}: дворцовый переворот! ${s.ch.name} ${s.ch.surname} сместил прежнее руководство.`, { stab: -8, unrest: Math.max(20, un - 20) });
      return { ok: true, roll: r, crit: r.crit, title: 'Дворцовый переворот удался', lines: ['Шанс был ' + ch + '%.', 'Вы — глава государства. Генералы присягнули, народ ждёт перемен.'], apCost: 1, map: true, fx: { happy: 20, infl: 25, rep: 5, stress: 15 } };
    }
    if (mode === 'revolution') {
      const need = []; if (un < 60) need.push('недовольство в стране 60+ (сейчас ' + Math.round(un) + ') — оно растёт от кризисов, а ваши митинги его разгоняют'); if (mv.sup < 5000) need.push('движение 5 000+ сторонников (сейчас ' + E.short(mv.sup) + ') — «устраиваю митинг», «массовый митинг»'); if (s.st.rep < 35) need.push('репутация 35+ (сейчас ' + Math.round(s.st.rep) + ')');
      if (need.length) return fail('Для революции не хватает', need.concat(['Есть и другие пути: «дворцовый переворот» (изнутри власти) или «вооружённое восстание» (нужны бойцы).']));
      const ch = cl(Math.round(10 + (un - 60) * 1.1 + Math.log10(mv.sup) * 6 + s.st.rep / 5 - (H.st.repr || 0) / 3 - (rg === 'terror' ? 25 : rg === 'auto' ? 8 : 0)), 5, 80);
      const r = E.roll(s, ch);
      if (!r.ok) {
        mv.sup = Math.round(mv.sup * 0.4); mv.heat = 80; op('stat', { c: W.home, d: { unrest: -15, repr: 20 } });
        if (rg === 'terror') { const lines = ['Восстание раздавлено.']; lines.push(...L.jail(s, 5)); return { ok: false, roll: r, title: 'Революция подавлена', lines, apCost: 1 }; }
        return { ok: false, roll: r, title: 'Революция подавлена', lines: ['Площади зачистили. Движение потеряло 60% людей.', 'Шанс был ' + ch + '%.'], fx: { rep: -5, stress: 25, health: -5 }, apCost: 1 };
      }
      POL.takePower(s, 'Революция', `${H.n}: революция! Толпы заняли центр столицы, прежняя власть бежала. Лидер протестов ${s.ch.name} ${s.ch.surname} возглавил переходное правительство.`, { gov: 'Республика (переходное правительство)', stab: 5, unrest: 20 });
      mv.sup = Math.round(mv.sup * 1.5);
      return { ok: true, roll: r, crit: r.crit, title: 'Революция победила!', lines: ['Шанс был ' + ch + '%.', 'Вы — глава переходного правительства. Обещания придётся выполнять: недовольство вернётся, если экономика не наладится.'], apCost: 1, map: true, fx: { happy: 25, rep: 20, infl: 30, stress: 15 } };
    }
    // кровавое вооружённое восстание → гражданская война, вы — глава повстанцев
    const fighters = (o ? o.members : 0) + mv.armed + armyLvl * 60;
    const need = []; if (fighters < 150) need.push('150+ вооружённых бойцов (сейчас ' + fighters + '): своя ОПГ, «вооружаю сторонников» или армейское звание'); if (un < 45) need.push('недовольство 45+ (сейчас ' + Math.round(un) + ')'); if (E.countryProvs(s, W.home).length < 4) need.push('страна слишком мала для гражданской войны');
    if (need.length) return fail('Для вооружённого восстания не хватает', need);
    if (isCli(s) && !(typeof NET !== 'undefined' && NET.A && NET.A.gov)) return fail('В мультиплеере это решает хост', []);
    const ch = cl(Math.round(25 + fighters / 25 + (un - 45) * 0.6 - (H.st.repr || 0) / 4), 10, 80);
    const r = E.roll(s, ch);
    if (!r.ok) { if (o) o.members = Math.round(o.members * 0.5); mv.armed = Math.round(mv.armed * 0.3); L.crimeInit(s); s.crime.heat = 100; return { ok: false, roll: r, title: 'Восстание утоплено в крови', lines: ['Шанс был ' + ch + '%.', 'Половина бойцов погибла или арестована. Вас ищут.'], fx: { health: -15, stress: 30, rep: -10 }, apCost: 1 }; }
    const cap = H.cap >= 0 && W.own[H.cap] === W.home ? H.cap : -1, c0 = E.city(s), start = c0.prov !== undefined && W.own[c0.prov] === W.home ? c0.prov : E.countryProvs(s, W.home)[0];
    const want = Math.max(2, Math.min(Math.round(E.countryProvs(s, W.home).length * (0.2 + fighters / 4000)), 40)), got = [start], seen = new Set(got);
    for (let i = 0; i < got.length && got.length < want; i++) for (const n of M().provinces[got[i]].nb) if (!seen.has(n) && W.own[n] === W.home && n !== cap) { seen.add(n); got.push(n); if (got.length >= want) break; }
    const nmR = 'Революционная ' + (E.ww2(s) ? 'власть' : 'республика') + ' (' + s.ch.surname + ')';
    const old = W.home;
    const nc = op('rebels', { c: old, provs: got, n: nmR, col: '#b0302a', pw: Math.max(3, Math.round(fighters / 60)), gov: 'Революционный совет', lead: s.ch.name + ' ' + s.ch.surname, id: 'R' + Date.now().toString(36), news: `${H.n}: вооружённое восстание! Отряды ${s.ch.name} ${s.ch.surname} взяли ${got.length} провинций — гражданская война.` });
    if (typeof nc === 'number') { W.home = nc; E.takeOffice(s, { id: 'president', n: 'Командующий революционной армией' }); }
    return { ok: true, roll: r, title: 'Гражданская война началась', lines: ['Шанс был ' + ch + '%.', 'Под вашим контролем: ' + got.length + ' провинций. Прежняя власть воюет с вами.', 'Победите на карте — страна ваша. Проиграете — конец.'], apCost: 1, map: true, war: true, fx: { stress: 30, rep: 5 } };
  };
  POL.takePower = (s, how, news, o) => {
    const W = W_(s), H = W.cs[W.home];
    op('regime', { c: W.home, gov: o.gov || H.st.gov, lead: s.ch.name + ' ' + s.ch.surname, stab: o.stab || 0, unrest: o.unrest, news, imp: 2 });
    E.takeOffice(s, { id: 'president', n: how === 'Революция' ? 'Глава переходного правительства' : 'Глава государства' });
    E.fact(s, `${E.monthStr(s.date)}: пришёл к власти — ${how.toLowerCase()}.`);
  };
  // вооружить сторонников (для восстания)
  POL.arm = (s, t) => {
    const mv = POL.mov(s); if (mv.sup < 200) return fail('Некого вооружать', ['Сначала соберите движение: «устраиваю митинг».']);
    const n = Math.min(mv.sup, /много|все|массов/.test(t) ? 300 : 80), cost = Math.round(E.m(s, 60000) * n);
    if (s.st.money < cost) return fail('Не хватает денег', ['Оружие для ' + n + ' чел.: ' + E.money(cost) + '.']);
    mv.armed += n; mv.heat = cl(mv.heat + 20, 0, 100); L.crimeInit(s); s.crime.heat = cl((s.crime.heat || 0) + 15, 0, 100);
    return { ok: true, title: 'Сторонники вооружены', lines: ['+' + n + ' бойцов (всего ' + mv.armed + '). −' + E.money(cost), 'Спецслужбы насторожились.'], fx: { money: -cost, stress: 8 }, apCost: 1 };
  };
  // ======================= подавление (глава государства) =======================
  POL.METHODS = [
    { id: 'talks', re: /переговор|диалог|уступ|реформ|выслуша|компромисс|требовани/, n: 'Переговоры и уступки', d: 'Самый мягкий путь. Недовольство −15…−25, популярность растёт, но бюджет платит.', un: [-15, -25], rep: 3, appr: 5, debt: 1.5, dem: 0, back: 0 },
    { id: 'propaganda', re: /пропаганд|тв|телевид|сми|агитац|объясн/, n: 'Пропаганда в СМИ', d: 'Недовольство −6…−12. Дёшево, но слабо.', un: [-6, -12], rep: 0, appr: 1, pc: 15, dem: 0, back: 0.05 },
    { id: 'resign', re: /отставк|сменить правительств|уволить правительств|уволить министр/, n: 'Отправить правительство в отставку', d: 'Недовольство −20…−30, политический капитал −40.', un: [-20, -30], rep: 1, appr: 6, pc: 40, dem: 0, back: 0 },
    { id: 'police', re: /полиц|разогна|разгон|дубин|омон|нацгвард|водомет/, n: 'Разгон полицией', d: 'Недовольство −10…−18. Шанс 20%, что протест разгорится сильнее. Репутация −3.', un: [-10, -18], rep: -3, appr: -2, dem: -3, back: 0.2, repr: 8 },
    { id: 'curfew', re: /комендант|чрезвычайн|чп\b/, n: 'Комендантский час / ЧП', d: 'Недовольство −8…−14, экономика страдает.', un: [-8, -14], rep: -2, appr: -3, dem: -2, back: 0.08, shock: -0.6, repr: 10 },
    { id: 'arrest', re: /арест|задерж|сажа|посадить|лидер|зачинщик|репресс/, n: 'Аресты лидеров протеста', d: 'Недовольство −18…−26, страх растёт. Репутация −8, Запад недоволен.', un: [-18, -26], rep: -8, appr: -4, dem: -8, back: 0.12, repr: 20 },
    { id: 'army', re: /арми|войск|стрел|огонь|танк|расстрел|подав.*сил/, n: 'Ввести войска (кровавое подавление)', d: 'Недовольство −30…−45 — или (35%) восстание вспыхнет ещё сильнее. Репутация −20, санкции.', un: [-30, -45], rep: -20, appr: -10, dem: -25, back: 0.35, repr: 40, shock: -1 },
  ];
  POL.suppress = (s, mid) => {
    const W = W_(s), H = W.cs[W.home], M0 = POL.METHODS.find(m => m.id === mid) || POL.METHODS[0], G = GOV.my && GOV.my(s);
    if (M0.pc && G && (G.pc || 0) < M0.pc) return fail('Мало политического капитала', ['Нужно ' + M0.pc + ', есть ' + Math.round(G.pc || 0) + '.']);
    const before = Math.round(H.st.unrest || 0), lines = [];
    if (Math.random() < M0.back) {
      const up = M0.id === 'army' ? 25 : 10; op('stat', { c: W.home, d: { unrest: up, stab: -4 } });
      WD.news(s, `${H.n}: ${M0.id === 'army' ? 'кровь на улицах — протест перерос в восстание' : 'жёсткий разгон только разозлил людей'}.`, [W.home], 2, 'protest');
      lines.push('Обратный эффект! Недовольство ' + before + ' → ' + Math.round(H.st.unrest) + '.');
      if (G) G.appr = cl(G.appr + M0.appr * 1.5, 0, 100);
      return { ok: false, title: M0.n + ': не сработало', lines, fx: { rep: M0.rep, stress: 12 }, apCost: 1 };
    }
    const dU = -E.ri(-M0.un[0], -M0.un[1]);
    op('stat', { c: W.home, d: { unrest: dU, repr: M0.repr || 0, debt: M0.debt || 0, stab: M0.id === 'talks' || M0.id === 'resign' ? 4 : 1 } });
    if (M0.shock) H.shock += M0.shock;
    if (G) { G.appr = cl(G.appr + M0.appr, 0, 100); if (M0.pc) G.pc -= M0.pc; }
    if (M0.dem) for (const c of W.cs) if (!c.dead && c !== H && dem(c)) c.rel = cl((c.rel || 0) + M0.dem, -100, 100);
    if (M0.id === 'army') for (const c of W.cs) if (!c.dead && c !== H && dem(c) && c.st.gdp > 200) c.shock -= 0; // санкции — через отношения
    if (M0.id === 'army' || M0.id === 'arrest') WD.news(s, `${H.n}: ${M0.id === 'army' ? 'протесты подавлены силой, есть жертвы' : 'массовые аресты оппозиции'}. ${M0.id === 'army' ? 'Запад обсуждает санкции.' : ''}`, [W.home], 1, 'protest');
    lines.push('Недовольство: ' + before + ' → ' + Math.round(H.st.unrest) + '.');
    if (M0.dem) lines.push('Отношения с демократиями ' + M0.dem + '.');
    if (M0.repr) lines.push('Страх в обществе растёт: протестовать будут реже, но обида копится.');
    return { ok: true, title: M0.n, lines, fx: { rep: M0.rep, stress: M0.id === 'army' ? 15 : 5 }, apCost: 1 };
  };
  E.A.suppress = (s, it) => {
    if (!E.isLeader(s)) return fail('Подавлять протесты может только власть', ['Сейчас вы — ' + E.position(s).toLowerCase() + '. Можно, наоборот, присоединиться: «иду на митинг».']);
    const t = nrm([it.target, it.raw].join(' '));
    const m = POL.METHODS.find(x => x.re.test(t)) || POL.METHODS.find(x => x.id === (/разогна|подав/.test(t) ? 'police' : 'talks'));
    return POL.suppress(s, m.id);
  };
  // окно выбора в начале недели (протесты в вашей стране / ультиматум вам)
  POL.choice = (title, text, opts, icon) => new Promise(res => {
    UI.modal(`<div class="ev"><div class="evpic ev-revolt">${UI.ic(icon || 'flag')}</div><h3>${title}</h3><p>${text}</p><div class="eopts">${opts.map((o, i) => `<button class="eopt" data-i="${i}"><b>${o.n}</b><small>${o.d || ''}</small></button>`).join('')}</div></div>`);
    if (typeof NET !== 'undefined' && NET.autoPick) try { NET.autoPick(); } catch (e) { }
    document.querySelectorAll('#modal .eopt').forEach(b => b.onclick = () => { UI.closeModal(); res(+b.dataset.i); });
  });
  POL.weekly = (s, rep) => {
    const W = W_(s), H = W.cs[W.home]; if (!H || H.dead) return;
    const mv = s.mov; if (mv) { mv.heat = Math.max(0, mv.heat - 1.5); if (mv.sup > 0 && !E.isLeader(s)) mv.sup = Math.max(0, Math.round(mv.sup * 0.995)); }
    if (!E.isLeader(s)) return;
    // ультиматумы вам
    const q = (W.ultQ || []).filter(u => u.to === W.home && !(s.flags.ultDone || {})[u.id]);
    for (const u of q.slice(0, 1)) {
      (s.flags.ultDone = s.flags.ultDone || {})[u.id] = 1;
      const d = POL.DEMANDS.find(x => x.id === u.d), A = W.cs[u.from]; if (!A || A.dead) continue;
      rep.events.push({ fn: async () => {
        const i = await POL.choice('Ультиматум от ' + A.n, `${A.n} требует: ${d.n}. Иначе — война. Сила их армии примерно в ${(E.power(s, u.from) / Math.max(0.1, E.power(s, W.home))).toFixed(1)} раза больше вашей.`, [{ n: 'Принять', d: 'Мир сохранён, но вы теряете ' + (d.id === 'land' ? 'земли' : 'деньги') + ' и популярность.' }, { n: 'Отвергнуть', d: 'Народ сплотится вокруг вас (+популярность), но скорее всего начнётся война.' }], 'sword');
        let out;
        if (i === 0) { const lines = POL.applyDemand(s, u.from, W.home, d); const G = GOV.my(s); if (G) G.appr = cl(G.appr - 8, 0, 100); out = { ok: true, title: 'Ультиматум принят', lines: lines.concat(['Популярность −8']) }; }
        else { const G = GOV.my(s); if (G) G.appr = cl(G.appr + 6, 0, 100); let lines = ['Популярность +6']; if (Math.random() < 0.6) { op('war', { c: u.from, ci: W.home }); lines.push(A.n + ' объявила вам войну!'); } else lines.push(A.n + ' не решилась напасть. Пока.'); out = { ok: true, title: 'Ультиматум отвергнут', lines }; }
        UI.appendMsg({ k: 'out', title: out.title, ok: out.ok, lines: out.lines }); if (window.MAP && MAP.paint) MAP.paint(s); UI.renderAll();
      } });
    }
    // протесты в вашей стране
    const un = H.st.unrest || 0;
    s.flags.unrestCd = Math.max(0, (s.flags.unrestCd || 0) - 1);
    if (un >= 62 && !s.flags.unrestCd) {
      s.flags.unrestCd = un >= 80 ? 3 : 6;
      rep.events.push({ fn: async () => {
        const hot = (H.st.unrest || 0) >= 80;
        const ms = POL.METHODS.filter(m => !(m.pc && (!GOV.my(s) || (GOV.my(s).pc || 0) < m.pc)));
        const i = await POL.choice(hot ? 'Страна на грани революции' : 'Протесты по всей стране', `Недовольство: ${Math.round(H.st.unrest)}/100. ${hot ? 'Если ничего не сделать, власть может пасть — революцией или переворотом генералов.' : 'Люди требуют перемен: цены, работа, война. Как ответите?'}`, ms.map(m => ({ n: m.n, d: m.d })).concat([{ n: 'Ничего не делать', d: 'Протест может стихнуть сам — или разрастись.' }]), 'flag');
        const out = i < ms.length ? POL.suppress(s, ms[i].id) : { ok: false, title: 'Власть выжидает', lines: ['Недовольство: ' + Math.round(H.st.unrest) + '/100'] };
        if (i >= ms.length && (H.st.unrest || 0) >= 85 && Math.random() < 0.4) { const lines = POL.fall(s); out.title = 'Власть пала'; out.lines = lines; }
        const add = out.fx ? E.apply(s, out.fx) : [];
        UI.appendMsg({ k: 'out', title: out.title, ok: out.ok, lines: (out.lines || []).concat(add) }); UI.renderAll();
      } });
    }
  };
  // вас свергли
  POL.fall = s => {
    const W = W_(s), H = W.cs[W.home], p = s.pol ? s.pol.n : 'глава';
    const how = Math.random() < 0.5 ? 'революция' : 'переворот генералов';
    op('regime', { c: W.home, gov: how === 'революция' ? 'Республика (переходное правительство)' : 'Военная хунта', lead: '', stab: 10, unrest: 30, news: `${H.n}: ${how}! ${s.ch.name} ${s.ch.surname} лишён власти.`, imp: 2 });
    s.pol = null; E.apply(s, { rep: -20, happy: -20, stress: 25 });
    return ['Произошла ' + how + '. Вы больше не ' + p.toLowerCase() + '.', 'Можно попробовать вернуться: выборы, своя партия, переворот.'];
  };
  // ======================= репутация =======================
  POL.REP_WAYS = [
    { id: 'volunteer', re: /волонт|помога(ю|ть) (люд|бездомн|приют|пожил|старик)|субботник|добровол/, n: 'Волонтёрство', d: 'Бесплатно, +2…+4. Раз в 2 недели.', cd: 2, cost: 0, gain: [2, 4], ch: 80 },
    { id: 'neighbors', re: /сосед|двор|подъезд|район/, n: 'Помогать соседям и двору', d: 'Бесплатно, +1…+3.', cd: 1, cost: 0, gain: [1, 3], ch: 85 },
    { id: 'sponsor', re: /спонсор|праздник|турнир|команд|детск|школ|площадк/, n: 'Спонсировать праздник / детскую команду', d: 'Деньги, +4…+8.', cd: 3, cost: 150000, gain: [4, 8], ch: 90 },
    { id: 'media', re: /интервью|блог|соцсет|пост|видео|сми|газет|телевид|подкаст|выступ/, n: 'Интервью, блог, выступления', d: '+3…+6 при удаче, −2 при провале (харизма).', cd: 2, cost: 0, gain: [3, 6], ch: 0, sk: 'cha', fail: -2 },
    { id: 'mentor', re: /настав|лекци|учу|обуча|мастер-класс|курс/, n: 'Лекции и наставничество', d: '+3…+5 (интеллект 45+).', cd: 2, cost: 0, gain: [3, 5], ch: 0, sk: 'int', req: s => E.sk(s, 'int') >= 45 ? '' : 'Нужен интеллект 45+.' },
    { id: 'apology', re: /извин|покая|признать ошибк|публично/, n: 'Публичное извинение', d: 'Возвращает до половины недавней потери репутации.', cd: 8, cost: 0, gain: [0, 0], ch: 70 },
    { id: 'pr', re: /пиар|имидж|отмы|агентств|репутационн/, n: 'Нанять PR-агентство', d: 'Дорого, +5…+10.', cd: 4, cost: 600000, gain: [5, 10], ch: 85 },
  ];
  POL.repLvl = r => r >= 90 ? 'Легенда' : r >= 75 ? 'Знаменитость' : r >= 55 ? 'Известны в стране' : r >= 35 ? 'Уважаемы в городе' : r >= 15 ? 'Знают в округе' : 'Никто вас не знает';
  E.A.rep = (s, it) => {
    const t = nrm([it.target, it.raw].join(' '));
    if (/благотвор|пожертв|фонд/.test(t)) return E.A.charity(s, it);
    const w = POL.REP_WAYS.find(x => x.re.test(t)) || POL.REP_WAYS[0];
    return POL.repDo(s, w.id);
  };
  POL.repDo = (s, id) => {
    const w = POL.REP_WAYS.find(x => x.id === id); s.flags.repCd = s.flags.repCd || {};
    const cd = s.flags.repCd[id] || 0; if (cd > s.turn) return fail(w.n + ': рано повторять', ['Можно через ' + (cd - s.turn) + ' нед. Попробуйте другой способ.']);
    if (w.req) { const e = w.req(s); if (e) return fail(w.n + ': не подходит', [e]); }
    const cost = w.cost ? Math.round(E.m(s, w.cost)) : 0;
    if (cost && s.st.money < cost) return fail('Не хватает денег', [w.n + ': ' + E.money(cost)]);
    s.flags.repCd[id] = s.turn + w.cd;
    if (id === 'apology') { const lost = (s.repLog || []).filter(x => x.v < 0 && Date.parse(s.date) - Date.parse(x.d) < 180 * 864e5).reduce((a, x) => a - x.v, 0); if (lost < 3) return fail('Не за что извиняться', ['Недавно репутация не падала.']); const r = E.roll(s, 70); const g = r.ok ? Math.round(lost / 2) : 0; return { ok: r.ok, roll: r, title: r.ok ? 'Извинения приняли' : 'Извинениям не поверили', lines: [r.ok ? 'Люди оценили честность.' : 'Сочли пиаром.'], fx: { rep: g }, apCost: 1 }; }
    const ch = w.ch || E.chance(s, 55, w.sk, 0);
    const r = E.roll(s, ch);
    const k = Math.max(0.35, 1 - s.st.rep / 140); // чем выше репутация, тем медленнее растёт
    const g = Math.max(1, Math.round(E.ri(w.gain[0], w.gain[1]) * k * (r.crit ? 1.5 : 1)));
    if (!r.ok) return { ok: false, roll: r, title: w.n + ': не впечатлило', lines: ['Шанс был ' + ch + '%.'], fx: Object.assign({ stress: 3 }, w.fail ? { rep: w.fail } : {}, cost ? { money: -cost } : {}), apCost: 1 };
    return { ok: true, roll: r, title: w.n, lines: ['Репутация растёт: +' + g + (k < 1 ? ' (чем вы известнее, тем медленнее)' : '')].concat(cost ? ['Потрачено: ' + E.money(cost)] : []), fx: Object.assign({ rep: g, happy: 2 }, cost ? { money: -cost } : {}), apCost: 1 };
  };
  // журнал изменений репутации — видно, откуда она берётся
  const _act = E.act;
  E.act = (s, it) => { const r0 = s.st.rep; const out = _act(s, it); const d = Math.round(s.st.rep - r0); if (d) POL.repNote(s, d, out && out.title); return out; };
  POL.repNote = (s, v, t) => { s.repLog = s.repLog || []; s.repLog.push({ d: s.date, v, t: String(t || '').slice(0, 60) }); if (s.repLog.length > 40) s.repLog.shift(); };
  const _nw = E.nextWeek;
  E.nextWeek = (s, ext) => {
    const r0 = s.st.rep; const rep = _nw(s, ext);
    try { POL.weekly(s, rep); } catch (e) { console.warn('pol weekly', e); }
    // репутация сама понемногу тянется к «базе»: работа, бизнес, знакомства, должность
    try { if (rep.monthly) { const b = POL.repBase(s); if (s.st.rep < b) s.st.rep = Math.min(b, s.st.rep + 0.8); else if (s.st.rep > b + 30) s.st.rep -= 0.4; } } catch (e) { }
    const d = Math.round(s.st.rep - r0); if (d) POL.repNote(s, d, 'Неделя: события и жизнь');
    return rep;
  };
  POL.repBase = s => Math.round(8 + (s.job ? s.job.level * 4 + (s.job.salary > E.m(s, 150000) ? 5 : 0) : 0) + Math.min(20, s.biz.length * 5) + (s.pol ? 15 : 0) + Math.min(10, ((s.soc && s.soc.people) || []).filter(p => p.known).length / 3) + Math.min(10, E.sk(s, 'cha') / 10));
  POL.repUI = () => {
    const s = UI.s, r = Math.round(s.st.rep), b = POL.repBase(s), log = (s.repLog || []).slice().reverse().slice(0, 12);
    U.big(`${U.head('star', 'Репутация: ' + r + '/100', POL.repLvl(r))}
      <div class="repbox">
        <p><b>Что это.</b> Насколько вас знают и уважают. Нужна для: <b>работы</b> (выше шанс найма и повышения), <b>выборов</b> (у каждой должности свой порог), <b>кредитов</b>, <b>знакомств</b> и <b>революций</b>.</p>
        <p><b>Сама по себе</b> репутация тянется к «базе» — сейчас она <b>${b}</b> (работа и должность, бизнес, знакомые, харизма). Ниже базы — растёт сама, сильно выше — «забывают» и она медленно сползает.</p>
        <p><b>Падает</b> от криминала, тюрьмы, провалов, жёстких указов, скандалов.</p>
        <h4>Как поднять без должности</h4>
        <div class="repways">${POL.REP_WAYS.map(w => `<button class="btn small" data-rw="${w.id}" title="${UI.esc(w.d)}">${w.n}<small>${w.d}</small></button>`).join('')}<button class="btn small" data-rf="Жертвую на благотворительность">Благотворительность<small>Сумма на ваш выбор, до +15.</small></button><button class="btn small" data-rf="Устраиваю митинг">Митинг / общественная активность<small>+2…+8, но власти могут не одобрить.</small></button></div>
        <h4>Последние изменения</h4>
        <ul class="news">${log.map(x => `<li><b class="${x.v > 0 ? 'pos' : 'neg'}">${x.v > 0 ? '+' : ''}${x.v}</b> ${UI.esc(x.t || '')} <small>${E.dateStr(x.d)}</small></li>`).join('') || '<li><small>Пока пусто.</small></li>'}</ul>
      </div>`);
    document.querySelectorAll('#modal [data-rw]').forEach(btn => btn.onclick = () => { if (UI.busy) return; UI.closeModal(); const w = POL.REP_WAYS.find(x => x.id === btn.dataset.rw); UI.doIntent({ type: 'rep', target: w.n, raw: w.n }, w.n); });
    document.querySelectorAll('#modal [data-rf]').forEach(btn => btn.onclick = () => { UI.closeModal(); UI.fill(btn.dataset.rf); });
  };
  // окно «Улицы» — недовольство и ваше движение
  POL.streetUI = () => {
    const s = UI.s, W = W_(s), H = W.cs[W.home], un = Math.round(H.st.unrest || 0), mv = POL.mov(s), lead = E.isLeader(s);
    const top = W.cs.map((c, i) => ({ c, i })).filter(x => !x.c.dead && (x.c.st.unrest || 0) > 55).sort((a, b) => b.c.st.unrest - a.c.st.unrest).slice(0, 8);
    U.big(`${U.head('flag', 'Улицы и власть', H.n + ': недовольство ' + un + '/100')}
      <div class="repbox">
        <div class="kv"><span>Недовольство в стране</span><b class="${un > 60 ? 'neg' : ''}">${un}/100 ${un > 80 ? '— на грани революции' : un > 60 ? '— протесты' : un > 40 ? '— ворчат' : '— спокойно'}</b></div>${UI.bar(un, un > 60 ? 'bad' : '')}
        <div class="kv"><span>Страх (репрессии)</span><b>${Math.round(H.st.repr || 0)}</b></div>
        <p class="small">Недовольство растёт от низкой стабильности, безработицы, инфляции и войны; падает от реформ, роста экономики и силы. Страх временно глушит протесты, но потом уходит.</p>
        ${lead ? `<h4>Ответ власти</h4><div class="repways">${POL.METHODS.map(m => `<button class="btn small" data-sm="${m.id}">${m.n}<small>${m.d}</small></button>`).join('')}</div>`
        : `<h4>Ваше движение</h4><div class="kv"><span>Сторонников</span><b>${E.short(mv.sup)}</b></div><div class="kv"><span>Вооружено</span><b>${mv.armed}</b></div><div class="kv"><span>Внимание властей</span><b>${Math.round(mv.heat)}/100</b></div>
        <div class="repways">${[['Устраиваю митинг', 'Растит движение и репутацию'], ['Организую массовый митинг', 'Больше людей и риска'], ['Устраиваю забастовку', 'Бьёт по экономике'], ['Вооружаю сторонников', 'Для восстания, дорого'], ['Дворцовый переворот', 'Нужен пост министра/губернатора, звание майора или влияние 70+'], ['Начинаю революцию', 'Недовольство 60+, 5000+ сторонников, репутация 35+'], ['Поднимаю вооружённое восстание', '150+ бойцов, недовольство 45+: гражданская война']].map(x => `<button class="btn small" data-rf="${x[0]}">${x[0]}<small>${x[1]}</small></button>`).join('')}</div>`}
        <h4>Где неспокойно в мире</h4><ul class="news">${top.map(x => `<li>${UI.esc(x.c.n)}: <b>${Math.round(x.c.st.unrest)}</b>/100</li>`).join('') || '<li><small>Везде относительно тихо.</small></li>'}</ul>
      </div>`);
    document.querySelectorAll('#modal [data-sm]').forEach(b => b.onclick = () => { UI.closeModal(); const m = POL.METHODS.find(x => x.id === b.dataset.sm); UI.doIntent({ type: 'suppress', target: m.n, raw: m.n }, m.n); });
    document.querySelectorAll('#modal [data-rf]').forEach(b => b.onclick = () => { UI.closeModal(); UI.fill(b.dataset.rf); });
  };
  // «вооружаю сторонников» — в разбор
  const _un = E.A.unrest; E.A.unrest = (s, it) => { const t = nrm([it.target, it.raw].join(' ')); if (/вооруж\S* (сторонник|людей|движени|народ)/.test(t)) return POL.arm(s, t); return _un(s, it); };
  // повод для войны после отвергнутого ультиматума — война без штрафа
  // мультиплеер: война, объявленная клиентом, могла потеряться по дороге к хосту — тогда следующая синхронизация мира
  // «заключала мир» через пару недель. Клиент помнит свои свежие войны и переотправляет их хосту.
  const hookMpWars = () => {
    if (typeof NET === 'undefined' || !NET.applyWorld || typeof GOV === 'undefined') return;
    const _w = GOV.OPS.war; GOV.OPS.war = (s, a) => { const r = _w(s, a); try { if (NET.on && NET.on() && NET.role === 'client' && a.c === s.world.home) { s.flags.myWars = s.flags.myWars || {}; s.flags.myWars[a.ci] = { at: Date.parse(s.date), c: a.c }; } } catch (e) { } return r; };
    const _p = GOV.OPS.peace; GOV.OPS.peace = (s, a) => { try { if (s.flags.myWars) { delete s.flags.myWars[a.ci]; delete s.flags.myWars[a.c]; } } catch (e) { } return _p(s, a); };
    const _aw = NET.applyWorld;
    NET.applyWorld = (s, w) => {
      _aw(s, w);
      try {
        const my = s.flags && s.flags.myWars; if (!my) return; const W = s.world;
        for (const k of Object.keys(my)) {
          const ci = +k, o = my[k];
          if (Date.parse(s.date) - o.at > 21 * 864e5 || o.c !== W.home || !W.cs[ci] || W.cs[ci].dead || W.cs[W.home].dead) { delete my[k]; continue; }
          if (!WD.atWar(s, W.home, ci)) { WD.declare(s, W.home, ci, {}); if (NET.A.gov) NET.A.gov({ k: 'op', name: 'war', a: { c: W.home, ci } }); }
        }
      } catch (e) { console.warn('mp wars', e); }
    };
  };
  document.addEventListener('DOMContentLoaded', () => {
    addOps(); hookDeclare(); hookMpWars();
    const _m = WD.month; WD.month = s => { _m(s); try { POL.unrestMonth(s); } catch (e) { console.warn('unrest', e); } try { POL.botsMonth(s); } catch (e) { console.warn('bots', e); } };
    if (typeof AI !== 'undefined') {
      AI.SYS_INTERPRET = AI.SYS_INTERPRET.replace('other — всё остальное.', `ultimatum — предъявить ультиматум другой стране/региону (вступить в состав, отдать земли, выплатить, распустить армию, выйти из блока) — только глава государства; НЕ war
unrest — митинг, протест, забастовка, пикет, шествие, вооружить сторонников
revolt — революция, свергнуть власть, дворцовый переворот, вооружённое (кровавое) восстание
suppress — власть подавляет протест: переговоры с протестующими, разгон, аресты, комендантский час, ввести войска
rep — поднять/исправить репутацию: волонтёрство, помощь соседям, интервью/блог, спонсорство, лекции, PR, публичные извинения
other — всё остальное.`);
      AI.SCHEMA.properties.type.enum = E.ACTIONS.concat(['chat']);
    }
    // окно репутации по клику на «Репутация»
    const _top = UI.top; UI.top = (...a) => { const r = _top(...a); const b = [...document.querySelectorAll('#top .stat')].find(x => /Репутация/.test(x.textContent)); if (b) { b.onclick = () => POL.repUI(); b.title = 'Репутация: что это и как поднять. Нажмите.'; } return r; };
  });
})();
