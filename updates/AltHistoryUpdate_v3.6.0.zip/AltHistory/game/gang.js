// AltHistory — своя банда (ОПГ): окно управления, оружие, тренировки, верность, война с бандами;
// отделение региона в мультиплеере; понятное мошенничество (окно «Схемы»). Всё вымышлено — это игра.
'use strict';
const GANG = {};
(() => {
  const cl = (v, a, b) => Math.max(a, Math.min(b, v));
  const nrm = t => E.norm(t || '');
  const fail = (title, lines) => ({ ok: false, impossible: true, title, lines: lines || [], apCost: 0 });
  const O = s => (s.opg && !s.opg.gone ? s.opg : null);
  const fix = o => { if (o.arms === undefined) o.arms = 0; if (o.loyal === undefined) o.loyal = 60; if (o.train === undefined) o.train = 10; if (!o.log) o.log = []; return o; };
  GANG.ARMS = s => E.ww2(s)
    ? ['Кулаки и кастеты', 'Ножи и обрезы', 'Наганы', 'Трофейные винтовки', 'ППШ, пулемёт и грузовики']
    : ['Биты и кастеты', 'Ножи и травматы', 'Пистолеты', 'Автоматы', 'Передовое: броники, ночные прицелы, бронированные внедорожники'];
  GANG.ARMS_COST = [0, 4000, 18000, 60000, 180000]; // за бойца
  GANG.power = o => Math.round(o.members * (1 + o.arms * 0.45) * (0.6 + o.train / 125) * (0.6 + o.loyal / 150));
  GANG.income = (s, o) => Math.round(E.m(s, 2500) * o.members * (1 + o.terr * 0.25) * (1 + o.arms * 0.08));
  GANG.note = (s, o, t) => { o.log.push(E.monthStr(s.date) + ': ' + t); if (o.log.length > 30) o.log.shift(); };
  // ---------- новые приказы ----------
  const _opg = E.A.opg;
  E.A.opg = (s, it) => {
    const t = nrm([it.target, it.raw].join(' ')), o = O(s);
    if (it.secede || /отдел|независим|республик|автоном|суверен|сво[её] государ|отсоедин/.test(t)) return GANG.secede(s, it);
    if (o) {
      fix(o);
      if (/вооруж|оруж|ствол|автомат|экипир|снаряж|бронежил|броник|пулем|пистолет|прицел|техник|внедорож/.test(t)) return GANG.arm(s, o, t);
      if (/трениру|обуча|подготов|учени|стрельбищ|спортзал|качал/.test(t)) return GANG.drill(s, o);
      if (/зарплат|премир|подогре|общак|наград|верност|лояльн|доли/.test(t)) return GANG.pay(s, o);
      if (/распуст|разогна (свою|банду)|закрыть опг/.test(t)) { s.opg.gone = true; GANG.note(s, o, 'ОПГ распущена'); if (s.crime) { s.crime.boss = false; s.crime.gang = null; } return { ok: true, title: 'ОПГ распущена', lines: ['Люди разошлись. Розыск со временем утихнет.'], apCost: 0 }; }
      if (/войн|наезд|наезж|наех|разборк|стрелк|напасть на|напада|разгром|мочим|валим/.test(t) && /банд|группиров|конкурент|вокзальн|заводск|рыночн|портов|слобод|северн|центров|гаражн|речн|посадск|овражн|мостов/.test(t)) return GANG.war(s, o, t);
    }
    if (!o && /вооруж|оруж|ствол|трениру|набира|набрать|захват|район|премир/.test(t) && !/созда|основ|собра|сколот/.test(t)) {
      const C = s.crime || {};
      return fail('Своей ОПГ пока нет', (C.gang ? ['Вы в банде «' + C.gang + '» (' + D.CRIME_RANKS[C.rank || 0].toLowerCase() + ') — её вооружает главарь, не вы.'] : []).concat(['Своя банда: «создаю свою ОПГ» — нужно ' + E.money(E.m(s, 5000000)) + ' и влияние 20+ (или ранг «Бригадир» в чужой банде).', 'Потом всё управление — в окне «Моя ОПГ».']));
    }
    return _opg(s, it);
  };
  GANG.arm = (s, o, t) => {
    const names = GANG.ARMS(s);
    if (o.arms >= 4) return fail('Лучше оружия не достать', ['У «' + o.name + '» уже: ' + names[4] + '.']);
    const lvl = /передов|лучш|броник|бронежил|ночн|бронир|внедорож|пулем|ппш/.test(t) ? 4 : /автомат|калаш|винтов/.test(t) ? Math.max(3, o.arms + 1) : o.arms + 1;
    const to = Math.min(4, Math.max(o.arms + 1, lvl));
    const cost = Math.round(E.m(s, GANG.ARMS_COST[to] - GANG.ARMS_COST[o.arms]) * o.members);
    if (s.st.money < cost) return fail('Не хватает денег на оружие', [names[to] + ' для ' + o.members + ' чел.: ' + E.money(cost) + '.', 'Можно дешевле — на ступень: «' + names[o.arms + 1] + '» — ' + E.money(Math.round(E.m(s, GANG.ARMS_COST[o.arms + 1] - GANG.ARMS_COST[o.arms]) * o.members)) + '.']);
    const p0 = GANG.power(o); o.arms = to; L.crimeInit(s); s.crime.heat = cl((s.crime.heat || 0) + 4 + to * 3, 0, 100);
    GANG.note(s, o, 'вооружились: ' + names[to].toLowerCase());
    return { ok: true, title: '«' + o.name + '» вооружена', lines: ['Оружие: ' + names[to], 'Сила банды: ' + p0 + ' → ' + GANG.power(o), 'Потрачено: ' + E.money(cost), 'Розыск подрос: оружие не спрячешь.'], fx: { money: -cost, stress: 4 }, apCost: 1 };
  };
  GANG.drill = (s, o) => {
    const cost = Math.round(E.m(s, 3000) * o.members);
    if (s.st.money < cost) return fail('Не хватает денег', ['Сборы для ' + o.members + ' чел.: ' + E.money(cost) + '.']);
    const add = E.ri(8, 15), p0 = GANG.power(o); o.train = cl(o.train + add, 0, 100); o.loyal = cl(o.loyal + 3, 0, 100);
    return { ok: true, title: 'Тренировки', lines: ['Подготовка +' + add + ' (' + Math.round(o.train) + '/100)', 'Сила банды: ' + p0 + ' → ' + GANG.power(o)], fx: { money: -cost }, apCost: 1 };
  };
  GANG.pay = (s, o) => {
    const cost = Math.round(E.m(s, 8000) * o.members);
    if (s.st.money < cost) return fail('Не хватает денег', ['Премия всем: ' + E.money(cost) + '.']);
    const add = E.ri(12, 20); o.loyal = cl(o.loyal + add, 0, 100);
    return { ok: true, title: 'Премия бойцам', lines: ['Верность +' + add + ' (' + Math.round(o.loyal) + '/100). Предателей меньше.'], fx: { money: -cost }, apCost: 1 };
  };
  GANG.war = (s, o, t) => {
    const C = L.crimeInit(s); GANG.sync(s);
    const g = C.comp.find(x => x.n !== o.name && t.includes(nrm(x.n).slice(0, 5))) || C.comp.filter(x => x.n !== o.name).sort((a, b) => b.terr - a.terr)[0];
    if (!g) return fail('Воевать не с кем', ['Конкурентов в городе нет.']);
    const mine = GANG.power(o), theirs = Math.round(g.size * (1 + (g.aggr / 100)) * 1.4);
    const ch = cl(Math.round(50 + (mine - theirs) / Math.max(20, theirs) * 30), 8, 88);
    const r = E.roll(s, ch); C.heat = cl(C.heat + 14, 0, 100);
    if (!r.ok) { const lost = Math.max(2, Math.round(o.members * E.rnd(0.08, 0.2))); o.members = Math.max(5, o.members - lost); o.loyal = cl(o.loyal - 8, 0, 100); GANG.note(s, o, 'проиграли «' + g.n + '»'); return { ok: false, roll: r, title: 'Разборка с «' + g.n + '» проиграна', lines: ['Шанс был ' + ch + '% (ваша сила ' + mine + ' против ~' + theirs + ').', 'Потери: ' + lost + ' чел.'], fx: { stress: 12, health: -4 }, apCost: 1 }; }
    const d = Math.min(g.terr, E.ri(4, 10)); g.terr -= d; g.size = Math.max(3, Math.round(g.size * 0.75));
    const my = C.comp.find(x => x.n === o.name); if (my) my.terr += d;
    o.terr++; o.infl = cl(o.infl + 6, 0, 100); o.loyal = cl(o.loyal + 5, 0, 100);
    const loot = Math.round(E.m(s, 20000) * g.size); GANG.note(s, o, 'разгромили «' + g.n + '»');
    return { ok: true, roll: r, crit: r.crit, title: '«' + g.n + '» разгромлены', lines: ['Шанс был ' + ch + '%.', '+1 район (всего ' + o.terr + '), рынок города +' + d + '%.', 'Трофеи: ' + E.money(loot)], fx: { money: loot, stress: 8 }, apCost: 1 };
  };
  // своя ОПГ должна быть в списке банд города (иначе разборки «за территорию» терялись)
  GANG.sync = s => { const o = O(s), C = s.crime; if (!o || !C || !C.comp) return; if (C.gang === o.name || C.boss) { C.rank = Math.max(C.rank || 0, 5); C.boss = true; C.gang = o.name; } let g = C.comp.find(x => x.n === o.name); if (!g) { g = { n: o.name, size: o.members, inc: GANG.income(s, o), terr: Math.min(30, o.terr * 4), aggr: 50, cops: Math.round(o.infl), leader: s.ch.name + ' ' + s.ch.surname }; C.comp.push(g); } g.size = o.members; g.cops = Math.round(o.infl); };
  // ---------- отделение региона (и в мультиплеере — через хоста) ----------
  GANG.secede = (s, it) => {
    const o = O(s), W = s.world, home = W.home; if (o) fix(o);
    if (E.isLeader(s)) return fail('Вы и так глава страны', ['Отделять регион от своей же страны незачем.']);
    const need = E.m(s, 300000000), miss = [];
    if (!o) miss.push('своя ОПГ («создаю свою ОПГ»)');
    else { if (o.infl < 60) miss.push('влияние ОПГ 60+ (сейчас ' + Math.round(o.infl) + ')'); if (GANG.power(o) < 400) miss.push('сила банды 400+ (сейчас ' + GANG.power(o) + ') — люди, оружие, тренировки'); if (o.terr < 5) miss.push('5+ районов (сейчас ' + o.terr + ')'); }
    if (s.st.infl < 55) miss.push('ваше влияние 55+ (сейчас ' + Math.round(s.st.infl) + ')');
    if (s.st.money < need) miss.push('деньги: ' + E.money(need));
    if (miss.length) return fail('Для отделения региона не хватает', miss);
    const r = E.roll(s, cl(Math.round(35 + (o.infl - 60) + (GANG.power(o) - 400) / 30 + (s.st.infl - 55) / 2 + ((W.cs[home].st.unrest || 0) - 40) / 3), 10, 82));
    if (!r.ok) { o.members = Math.round(o.members * 0.6); o.infl -= 20; s.crime.heat = 100; return { ok: false, roll: r, title: 'Мятеж подавлен', lines: ['Силовики сработали на опережение. Половина людей арестована.'], fx: { money: -Math.round(need * 0.4), rep: -15, stress: 25, health: -8 }, apCost: 1 }; }
    const c0 = E.city(s), start = c0.prov !== undefined && W.own[c0.prov] === home ? c0.prov : E.countryProvs(s, home)[0];
    const want = Math.min(60, 4 + o.terr * 3), got = [start], seen = new Set(got);
    for (let i = 0; i < got.length && got.length < want; i++) for (const n of M().provinces[got[i]].nb) if (!seen.has(n) && W.own[n] === home && n !== W.cs[home].cap) { seen.add(n); got.push(n); if (got.length >= want) break; }
    const name = 'Республика ' + (E.cityName(s) || o.name);
    const col = '#' + Math.floor((0.25 + Math.random() * 0.6) * 0xffffff).toString(16).padStart(6, '0');
    const nc = GOV.op('rebels', { c: home, provs: got, n: name, col, pw: Math.max(3, Math.round(GANG.power(o) / 80)), gov: 'Самопровозглашённая республика', lead: s.ch.name + ' ' + s.ch.surname, id: 'S' + Date.now().toString(36), limited: true, news: `${name}: ${s.ch.name} ${s.ch.surname} объявил независимость! ${W.cs[home].n} не признаёт отделение.` });
    if (typeof nc !== 'number') return fail('Не получилось', ['Попробуйте ещё раз.']);
    W.home = nc; o.state = nc;
    E.takeOffice(s, { id: 'president', n: 'Глава ' + name.replace('Республика', 'Республики') });
    return { ok: true, roll: r, title: 'Независимость!', lines: [name + ' — ' + got.length + ' провинций.', 'Вы — глава новой страны. Бывшая родина объявила вам войну.', 'Теперь вам доступны армия, указы, ультиматумы, война и мир.'], fx: { money: -need, rep: 15, happy: 20, stress: 20 }, map: true, war: true, apCost: 1 };
  };
  if (typeof EXT !== 'undefined') EXT.secede = GANG.secede;
  // ---------- месяц: содержание, верность, предательства ----------
  if (typeof EXT !== 'undefined' && EXT.month) {
    const _m = EXT.month;
    EXT.month = (s, rep) => {
      _m(s, rep); const o = O(s); if (!o) return; fix(o); GANG.sync(s);
      const up = Math.round(E.m(s, 400) * o.members * (1 + o.arms * 0.6));
      s.st.money -= up; rep.monthly.exp.push(['ОПГ «' + o.name + '»: содержание бойцов и оружия', up]); rep.monthly.net -= up;
      // доход растёт от оружия — доплачиваем разницу к базовому
      const extra = GANG.income(s, o) - Math.round(E.m(s, 2500) * o.members * (1 + o.terr * 0.25)); if (extra > 0) { s.st.money += extra; rep.monthly.net += extra; }
      o.train = Math.max(0, o.train - 2); o.loyal = cl(o.loyal + (60 - o.loyal) * 0.1 - (s.st.money < 0 ? 8 : 0), 0, 100);
      if (o.loyal < 35 && Math.random() < (40 - o.loyal) / 60) { const n = Math.max(2, Math.round(o.members * E.rnd(0.05, 0.15))); o.members = Math.max(5, o.members - n); GANG.note(s, o, n + ' человек ушли к конкурентам'); rep.life.push(`ОПГ «${o.name}»: ${n} бойцов ушли к конкурентам — верность низкая (${Math.round(o.loyal)}). Поднимите: «выплачиваю премию бойцам».`); }
    };
  }
  // ---------- окно «Моя банда» ----------
  GANG.ui = () => {
    const s = UI.s, o = O(s); L.crimeInit(s);
    if (!o) { U.big(`${U.head('bolt', 'Своя ОПГ', 'пока нет')}<div class="repbox"><p>Своя банда — свои правила: доход каждый месяц, районы, война с конкурентами, а в конце — хоть отделение региона.</p><p>Нужно: ${E.money(E.m(s, 5000000))} и влияние 20+ (или ранг в чужой банде «Бригадир»+).</p><div class="repways"><button class="btn" data-gf="Создаю свою ОПГ">Создать ОПГ</button></div><p class="small">Это игра: всё вымышлено.</p></div>`); document.querySelectorAll('#modal [data-gf]').forEach(b => b.onclick = () => { UI.closeModal(); UI.fill(b.dataset.gf); }); return; }
    fix(o); GANG.sync(s);
    const names = GANG.ARMS(s), C = s.crime, w = L.wanted(s);
    const nextArm = o.arms < 4 ? Math.round(E.m(s, GANG.ARMS_COST[o.arms + 1] - GANG.ARMS_COST[o.arms]) * o.members) : 0;
    const act = (lbl, cmd, sub) => `<button class="btn small" data-go2="${UI.esc(cmd)}">${lbl}<small>${sub}</small></button>`;
    U.big(`${U.head('bolt', 'ОПГ «' + UI.esc(o.name) + '»', 'Сила ' + GANG.power(o) + ' · районов ' + o.terr + ' · розыск ' + '★'.repeat(w) + '☆'.repeat(5 - w))}
      <div class="gang">
        <div class="cgrid">
          <div class="cbox"><h5>Люди</h5><div class="kv"><span>Бойцов</span><b>${o.members}</b></div><div class="kv"><span>Верность</span><b class="${o.loyal < 40 ? 'neg' : ''}">${Math.round(o.loyal)}/100</b></div>${UI.bar(o.loyal, o.loyal < 40 ? 'bad' : 'good')}<div class="kv"><span>Подготовка</span><b>${Math.round(o.train)}/100</b></div>${UI.bar(o.train)}</div>
          <div class="cbox"><h5>Оружие</h5><div class="kv"><span>Сейчас</span><b>${names[o.arms]}</b></div><div class="arms">${names.map((n, i) => `<i class="${i <= o.arms ? 'on' : ''}" title="${UI.esc(n)}"></i>`).join('')}</div><div class="kv"><span>Следующая ступень</span><b>${o.arms < 4 ? E.short(nextArm) + ' ₽' : 'максимум'}</b></div></div>
          <div class="cbox"><h5>Деньги и власть</h5><div class="kv"><span>Доход в месяц</span><b class="pos">~${E.short(GANG.income(s, o))} ₽</b></div><div class="kv"><span>Содержание</span><b class="neg">~${E.short(Math.round(E.m(s, 400) * o.members * (1 + o.arms * 0.6)))} ₽</b></div><div class="kv"><span>Влияние ОПГ</span><b>${Math.round(o.infl)}/100</b></div><div class="kv"><span>Районов</span><b>${o.terr}</b></div></div>
        </div>
        <h4>Приказы</h4>
        <div class="repways">
          ${act('Набрать людей', 'Набираю людей в свою ОПГ', '+10…30 бойцов')}
          ${act('Вооружить', 'Вооружаю свою банду', o.arms < 4 ? names[o.arms + 1] : 'уже лучшее')}
          ${act('Передовое оружие', 'Вооружаем свою банду передовым оружием', 'сразу максимум')}
          ${act('Тренировки', 'Тренирую своих бойцов', '+подготовка, +верность')}
          ${act('Премия бойцам', 'Выплачиваю премию бойцам', '+верность')}
          ${act('Захватить район', 'Захватываю новый район', 'доход и влияние')}
          ${act('Прикормить полицию', 'Прикармливаю полицию', 'розыск −20')}
          ${act('Отделить регион', 'Объявляю независимость региона', 'конечная цель')}
        </div>
        <h4>Банды города — разборки</h4>
        <table class="tbl"><tr><th>Банда</th><th>Лидер</th><th>Людей</th><th>Рынок</th><th></th></tr>${C.comp.filter(g => g.n !== o.name).map(g => `<tr><td>${UI.esc(g.n)}</td><td>${UI.esc(g.leader)}</td><td>~${g.size}</td><td>${g.terr}%</td><td><button class="btn small" data-go2="Наезжаем на банду ${UI.esc(g.n)}">Наехать</button></td></tr>`).join('')}</table>
        <h4>Для отделения региона</h4><p class="small">Влияние ОПГ 60+, сила банды 400+, 5+ районов, ваше влияние 55+, ${E.short(E.m(s, 300000000))} ₽. Недовольство в стране повышает шанс.</p>
        <h4>Журнал</h4><ul class="news">${o.log.slice().reverse().slice(0, 10).map(x => `<li>${UI.esc(x)}</li>`).join('') || '<li><small>Пока пусто.</small></li>'}</ul>
        <p class="small">Это игра: всё вымышлено.</p>
      </div>`);
    document.querySelectorAll('#modal [data-go2]').forEach(b => b.onclick = () => { if (UI.busy) return; UI.closeModal(); const t = b.dataset.go2; UI.doIntent({ type: 'opg', target: t, raw: t, secede: /независим/.test(t) }, t); });
  };
  // ======================= мошенничество: понятные схемы =======================
  GANG.FRAUD = s => E.ww2(s) ? [
    { id: 'cards', n: 'Подделка продуктовых карточек', base: 66, sk: 'craft', gain: 0.8, heat: 7 },
    { id: 'spec', n: 'Спекуляция дефицитом', base: 70, sk: 'biz', gain: 0.7, heat: 5 },
    { id: 'docs', n: 'Липовые справки и пропуска', base: 60, sk: 'craft', gain: 1.2, heat: 8 },
    { id: 'store', n: 'Растрата на складе', base: 52, sk: 'int', gain: 2, heat: 12 },
  ] : [
    { id: 'ads', n: 'Фальшивые объявления о продаже', base: 72, sk: 'cha', gain: 0.6, heat: 4 },
    { id: 'docs', n: 'Поддельные справки и дипломы', base: 64, sk: 'craft', gain: 1, heat: 6 },
    { id: 'call', n: '«Звонок из банка» (колл-центр)', base: 58, sk: 'cha', gain: 1.6, heat: 9 },
    { id: 'ins', n: 'Страховая афера', base: 54, sk: 'int', gain: 2.2, heat: 10 },
    { id: 'pyr', n: 'Финансовая пирамида', base: 44, sk: 'biz', gain: 4.5, heat: 22 },
  ];
  GANG.fChance = (s, f) => { const C = L.crimeInit(s); return cl(Math.round(E.chance(s, f.base + Math.min(20, (C.fxp || 0) * 2) + (C.gang ? 4 : 0), f.sk, 0)), 5, 95); };
  GANG.fraud = (s, id) => {
    const C = L.crimeInit(s), list = GANG.FRAUD(s), f = list.find(x => x.id === id) || list[0];
    C.fcd = C.fcd || {}; if ((C.fcd[f.id] || 0) > s.turn) return fail(f.n + ': рано повторять', ['Схема «остынет» через ' + (C.fcd[f.id] - s.turn) + ' нед. Попробуйте другую.']);
    const ch = GANG.fChance(s, f), r = E.roll(s, ch); C.acts++; C.fcd[f.id] = s.turn + 2;
    if (r.ok) {
      const gain = Math.round(E.m(s, 30000) * f.gain * (1 + (C.rank || 0) * 0.3) * E.rnd(0.7, 1.4) * (r.crit ? 1.6 : 1));
      C.heat = cl(C.heat + f.heat, 0, 100); C.on = true; C.total += gain; C.income += gain; C.fxp = (C.fxp || 0) + 1; C.cred = cl(C.cred + 4, 0, 100);
      const lines = []; L.rankUp(s, lines); C.hist.push(E.monthStr(s.date) + ': ' + f.n.toLowerCase() + ' — ' + E.money(gain));
      return { ok: true, roll: r, crit: r.crit, title: f.n + ': сработало', lines: ['Шанс был ' + ch + '%. Добыча: ' + E.money(gain), 'Опыт схем: ' + C.fxp + ' (каждый успех +2% к шансу, до +20%)', 'Розыск: ' + '★'.repeat(L.wanted(s)) + '☆'.repeat(5 - L.wanted(s))].concat(lines), fx: { money: gain, stress: 5, rep: -1 }, apCost: 1 };
    }
    C.heat = cl(C.heat + Math.round(f.heat * 1.2), 0, 100);
    const caught = Math.random() < 0.08 + L.wanted(s) * 0.06 - C.bribe / 400;
    if (caught) { s._arrest = true; return { ok: false, roll: r, title: 'Схему раскрыли — задержаны', lines: ['Шанс был ' + ch + '%.'], fx: { stress: 25 }, caught: true, apCost: 1 }; }
    return { ok: false, roll: r, title: f.n + ': сорвалось', lines: ['Шанс был ' + ch + '%. Жертва не поверила, вы успели исчезнуть.', 'Розыск немного вырос.'], fx: { stress: 8 }, apCost: 1 };
  };
  GANG.fraudUI = () => {
    const s = UI.s, C = L.crimeInit(s);
    U.big(`${U.head('bolt', 'Схемы', 'мошенничество — без насилия, но с розыском')}
      <div class="repbox"><p>Выберите схему. Шанс зависит от навыка (в скобках) и опыта: каждая удачная схема даёт +2% (до +20%). Одну схему можно повторять раз в 2 недели. Поймают редко, но розыск растёт.</p>
      <table class="tbl"><tr><th>Схема</th><th>Шанс</th><th>Добыча</th><th>Розыск</th><th></th></tr>${GANG.FRAUD(s).map(f => { const cd = (C.fcd || {})[f.id] > s.turn; return `<tr><td>${f.n} <small>(${D.SKILLS[f.sk]})</small></td><td><b>${GANG.fChance(s, f)}%</b></td><td>~${E.short(E.m(s, 30000) * f.gain)} ₽</td><td>+${f.heat}</td><td><button class="btn small" data-fr="${f.id}" ${cd ? 'disabled' : ''}>${cd ? 'остывает' : 'Провернуть'}</button></td></tr>`; }).join('')}</table>
      <p class="small">Опыт схем: ${C.fxp || 0}. Это игра: всё вымышлено, в жизни мошенничество — преступление против реальных людей.</p></div>`);
    document.querySelectorAll('#modal [data-fr]').forEach(b => b.onclick = () => { if (UI.busy) return; UI.closeModal(); const f = GANG.FRAUD(s).find(x => x.id === b.dataset.fr); UI.doIntent({ type: 'crime', fraud: b.dataset.fr, target: f.n, raw: f.n }, f.n); });
  };
  // ключевые слова: «наезжаем на банду» раньше считалось «вступить в банду»
  { const A = id => D.CRIME_ACTS.find(x => x.id === id); const j = A('join'), w = A('war'), f = A('fraud');
    if (j) j.kw = ['вступ', 'в банду', 'в группировк', 'к браткам', 'в братву', 'примите в', 'принять в банд'];
    if (w) w.kw.push('наезж', 'наех', 'разгром', 'напасть на банд');
    if (f) f.kw.push('развож', 'развест', 'кидал', 'лохотрон', 'пирамид', 'поддел', 'фальшив', 'липов'); }
  const FRAUD_RE = /мошенн|развод|развес|развож|кидал|кинуть|афер|лохотрон|пирамид|фишинг|колл-центр|колл центр|кол-центр|липов|фальшив|поддел|страхов\S* (афер|мошен)|карточк|спекул|растрат/;
  const _crime = E.A.crime;
  E.A.crime = (s, it) => {
    const t = nrm([it.target, it.raw].join(' '));
    GANG.sync(s);
    if (it.fraud || FRAUD_RE.test(t)) {
      const list = GANG.FRAUD(s);
      const f = list.find(x => x.id === it.fraud) || list.find(x => t.includes(nrm(x.n).slice(0, 8))) || (/пирамид/.test(t) && list.find(x => x.id === 'pyr')) || (/звон|банк|колл|кол-/.test(t) && list.find(x => x.id === 'call')) || (/справк|диплом|документ|поддел|липов|пропуск|карточк/.test(t) && list.find(x => x.id === 'docs' || x.id === 'cards')) || (/страхов/.test(t) && list.find(x => x.id === 'ins')) || (/объявлен|авито|продаж/.test(t) && list.find(x => x.id === 'ads')) || list[0];
      return GANG.fraud(s, f.id);
    }
    // раньше любая непонятная криминальная фраза становилась «мошенничеством» — теперь только явная
    if (!D.CRIME_ACTS.some(x => x.kw.some(k => t.includes(k)))) return _crime(s, Object.assign({}, it, { raw: 'кража ' + (it.raw || ''), target: 'кража ' + (it.target || '') }));
    return _crime(s, it);
  };
  // ---------- кнопки: «Моя банда», «Схемы» ----------
  document.addEventListener('DOMContentLoaded', () => {
    if (typeof U === 'undefined') return;
    const _dock = U.dock; U.dock = () => { const s = UI.s; let h = _dock(); if (s && O(s)) h += `<button data-dock="gang" title="Моя банда">${UI.ic('bolt')}<span>Моя ОПГ</span></button>`; return h; };
    const _bd = U.bindDock; U.bindDock = () => { _bd(); document.querySelectorAll('[data-dock="gang"]').forEach(b => b.onclick = () => GANG.ui()); };
    const _cr = U.crime; U.crime = () => { _cr(); const box = document.querySelector('#modal .crime .chips'); if (box) { box.insertAdjacentHTML('afterbegin', `<button class="hot" id="gFraud">Схемы мошенничества →</button>${O(UI.s) ? '<button class="hot" id="gGang">Моя ОПГ →</button>' : '<button class="hot" id="gGang">Своя ОПГ →</button>'}`); document.getElementById('gFraud').onclick = () => GANG.fraudUI(); document.getElementById('gGang').onclick = () => GANG.ui(); } };
  });
})();
