// «Судьба» — защита от «зависшего чата». Редкий баг: поле ввода нейрочата блокировалось навсегда.
// Причины: (1) запрос к нейросети завис (движок перестал отвечать, а у пересказа недели не было таймаута);
// (2) ошибка внутри хода/недели — интерфейс оставался «занят»; (3) окно события перекрывалось другим окном,
// и неделя ждала выбора, которого уже не сделать. Здесь всё это лечится.
'use strict';
const GUARD = { live: new Set() };
(() => {
  // ---------- 1. Любой запрос к нейросети: прерывается, если долго нет ответа ----------
  const _chat = AI.chat;
  AI.chat = async (messages, opt = {}) => {
    if (GUARD.cut) throw new Error('прервано игроком'); // после «Прервать» до конца хода — без нейросети (шаблонный текст)
    const ac = new AbortController(), ext = opt.signal;
    if (ext) { if (ext.aborted) ac.abort(); else ext.addEventListener('abort', () => ac.abort(), { once: true }); }
    const stream = !!(opt.body && opt.body.stream);
    // до первого слова — до 150 с (на слабом ПК нейросеть долго читает память), потом — 45 с тишины = завис; обычный ответ — до 240 с
    let t = setTimeout(() => ac.abort(), stream ? 150000 : 240000);
    const bump = () => { clearTimeout(t); t = setTimeout(() => ac.abort(), 45000); };
    const rec = { ac, at: Date.now() }; GUARD.live.add(rec);
    const o = Object.assign({}, opt, { signal: ac.signal });
    if (opt.onToken) o.onToken = x => { bump(); opt.onToken(x); };
    else if (stream) o.onToken = () => bump();
    try { return await _chat(messages, o); } finally { clearTimeout(t); GUARD.live.delete(rec); }
  };
  const _sb = UI.setBusy; UI.setBusy = v => { if (!v) GUARD.cut = false; return _sb(v); };
  GUARD.abortAll = () => { GUARD.cut = !!UI.busy; for (const r of GUARD.live) { try { r.ac.abort(); } catch (e) { } } GUARD.live.clear(); try { AI.stopBg(); } catch (e) { } };

  // ---------- 2. Ход / неделя: ошибка не оставляет интерфейс заблокированным ----------
  const safe = (obj, name, label) => {
    const f = obj[name]; if (typeof f !== 'function') return;
    obj[name] = async function (...a) {
      const was = UI.busy;
      try { return await f.apply(this, a); }
      catch (e) {
        console.error(label, e);
        const where = GUARD.where(e);
        GUARD.errs.push({ at: new Date().toISOString(), m: e && e.message, st: e && e.stack && String(e.stack).slice(0, 600) }); if (GUARD.errs.length > 20) GUARD.errs.shift();
        try { UI.appendMsg({ k: 'sys', t: 'Что-то пошло не так (' + (e && e.message ? e.message.slice(0, 80) : 'ошибка') + (where ? ' · ' + where : '') + '). Игра продолжается — попробуйте ещё раз.' }); } catch (x) { }
      } finally {
        if (!was && UI.busy) { try { UI.setBusy(false); } catch (x) { } }
      }
    };
  };
  GUARD.errs = [];
  // где упало: «engine.js:455» — чтобы по скриншоту было видно место ошибки
  GUARD.where = e => { const m = String(e && e.stack || '').match(/\/(\w+\.js):(\d+)/); return m ? m[1] + ':' + m[2] : ''; };
  // перерисовка панелей не должна ломать ход: ошибка в одной панели — остальные рисуются дальше
  if (UI.renderAll) UI.renderAll = () => { for (const f of ['top', 'left', 'quick', 'legend', 'chatTabs', 'mapBtns']) { try { if (UI[f]) UI[f](); } catch (e) { console.error('render ' + f, e); GUARD.errs.push({ at: new Date().toISOString(), m: 'render ' + f + ': ' + (e && e.message), st: e && e.stack && String(e.stack).slice(0, 600) }); } } };
  safe(UI, 'send', 'send'); safe(UI, 'doIntent', 'doIntent'); safe(UI, 'nextWeek', 'nextWeek');
  if (typeof U !== 'undefined') {
    const _adv = U.advance;
    if (_adv) U.advance = async n => { const was = UI.busy; try { return await _adv(n); } catch (e) { console.error('advance', e); } finally { UI._multi = 0; if (!was && UI.busy) UI.setBusy(false); } };
  }

  // ---------- 3. Окно события не теряется ----------
  // Пока неделя ждёт выбора в событии, другое окно может его перекрыть. Тогда событие вернётся, как только то окно закроют.
  GUARD.ev = null;
  const isEv = el => el && el.firstElementChild && el.firstElementChild.classList.contains('ev') && el.querySelector('.eopt, #wnOk, #bnOk');
  const _modal = UI.modal;
  UI.modal = html => {
    const m = _modal(html);
    const box = m.firstElementChild;
    if (isEv(box)) GUARD.ev = box; // запоминаем само окно вместе с кнопками
    return m;
  };
  // выбор сделан — событие больше не ждёт
  document.addEventListener('click', e => { if (!GUARD.ev) return; const b = e.target.closest && e.target.closest('.eopt, #wnOk, #bnOk, #wnC'); if (b && GUARD.ev.contains(b)) GUARD.ev = null; }, true);
  const restore = () => {
    const m = document.getElementById('modal'); if (!GUARD.ev || !m) return false;
    if (m.firstElementChild === GUARD.ev && !m.classList.contains('hidden')) return false;
    m.innerHTML = ''; m.appendChild(GUARD.ev); m.classList.remove('hidden'); return true;
  };
  const _close = UI.closeModal;
  UI.closeModal = () => {
    const m = document.getElementById('modal');
    // закрывают чужое окно поверх ждущего события — вместо закрытия возвращаем событие
    if (GUARD.ev && m && m.firstElementChild === GUARD.ev && !m.classList.contains('hidden')) return; // само событие закрыть можно только выбором
    if (GUARD.ev && m && m.firstElementChild !== GUARD.ev) { _close(); setTimeout(restore, 0); return; }
    _close();
  };
  // событие не относится к текущей игре (новая игра / загрузка) — забываем
  if (UI.game) { const _g = UI.game; UI.game = (...a) => { GUARD.ev = null; return _g(...a); }; }

  // ---------- 4. Сторож: если всё равно «занято» слишком долго ----------
  setInterval(() => {
    if (!UI.s) return;
    const m = document.getElementById('modal'), modalOpen = m && !m.classList.contains('hidden');
    // ждущее событие пропало с экрана (окно скрыли в обход) — вернуть
    if (GUARD.ev && !modalOpen) restore();
    const inp = document.getElementById('inp'), send = document.getElementById('send');
    if (!UI.busy) { if (inp && inp.disabled) inp.disabled = false; if (send && send.disabled) send.disabled = false; const ch = document.querySelector('.chat.busy'); if (ch) ch.classList.remove('busy'); GUARD.hideStop(); return; }
    const age = Date.now() - (UI.busySince || Date.now());
    if (age > 20000) GUARD.showStop();
    // занято > 2 мин, никаких запросов к нейросети и ни одного окна выбора — освобождаем
    if (age > 120000 && !GUARD.live.size && !GUARD.ev && !(modalOpen && m.querySelector('.eopt'))) { console.warn('guard: busy reset'); UI._multi = 0; UI.setBusy(false); }
  }, 2000);

  // ---------- кнопка «Прервать», если нейросеть думает слишком долго ----------
  GUARD.showStop = () => {
    if (document.getElementById('gStop')) return;
    const box = document.getElementById('msgs'); if (!box) return;
    const b = document.createElement('button'); b.id = 'gStop'; b.className = 'gstop'; b.textContent = 'Нейросеть долго думает — прервать';
    b.onclick = () => { GUARD.abortAll(); UI.toast('Запрос прерван. Можно писать дальше.'); setTimeout(() => { if (UI.busy && !GUARD.ev && !GUARD.live.size) { UI._multi = 0; UI.setBusy(false); } GUARD.hideStop(); }, 1500); };
    box.parentNode.insertBefore(b, document.getElementById('quick'));
  };
  GUARD.hideStop = () => { const b = document.getElementById('gStop'); if (b) b.remove(); };
})();
