// «Судьба» v3 — повседневная жизнь: рынок жилья (ЦИАН), мебель, транспорт, семья, друзья, вакансии (HH),
// криминал, газеты. Подключается после engine.js и world.js и переопределяет часть их функций.
'use strict';
const L = {};
L.num = (v, d) => (+v).toFixed(d === undefined ? 1 : d).replace('.', ',');
L.gdp = v => v >= 1000 ? L.num(v / 1000, 1) + ' трлн $' : (v >= 10 ? Math.round(v) : L.num(v)) + ' млрд $';
E.EV = (s) => E.ww2(s) ? 'ww2' : 'modern';

// ---------- детерминированный генератор ----------
L.rng = seed => { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; };
L.hash = (...a) => { let h = 2166136261; for (const x of a.join('|')) { h ^= x.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; };
L.gen = name => /[аяь]$/.test(name) ? name.replace(/[ая]$/, m => /[гкхжшщч]а$/.test(name) || m === 'я' ? 'и' : 'ы').replace(/ь$/, 'и') : name + 'а';

// ============================================================================
//  ЖИЛЬЁ
// ============================================================================
L.cityStart = i => M().start[i] || M().start[0];
L.market = (s, ci) => {
  const c = L.cityStart(ci);
  if (E.ww2(s)) { const m = D.MARKET.ww2[c.n] || D.MARKET.ww2def.map((v, k) => k === 0 ? v * Math.sqrt(c.cost) : v * Math.sqrt(c.cost)); return { m2: m[0] * E.cpi(s), rm2: m[1] * E.cpi(s) }; }
  const m = D.MARKET.modern[c.n] || [100000 * c.cost, 22000 * c.cost];
  return { m2: m[0] * E.cpi(s), r1: m[1] * E.cpi(s), rm2: m[1] * E.cpi(s) / 38 };
};
L.HC = s => D.HCLASS[E.EV(s)];
// Объявления: ~20 штук на город, обновляются раз в 4 недели
L.listings = (s, ci) => {
  ci = ci === undefined ? s.ch.city : ci;
  const per = Math.floor(s.turn / 4);
  const r = L.rng(L.hash('cian', ci, per, s.era));
  const mk = L.market(s, ci), HC = L.HC(s), ww = E.ww2(s), city = L.cityStart(ci);
  const out = [];
  const pick = a => a[Math.floor(r() * a.length)];
  const kinds = ww ? ['room', 'room', 'room', 'room', 'flat', 'flat', 'house', 'house', 'house'] : ['room', 'flat', 'flat', 'flat', 'flat', 'flat', 'house', 'house'];
  for (let k = 0; k < 22; k++) {
    const kind = pick(kinds);
    const cls = kind === 'room' ? 'poor' : pick(['poor', 'poor', 'mid', 'mid', 'mid', 'rich']);
    const H = kind === 'room' ? HC.room : HC[kind][cls];
    const area = Math.round(H.area[0] + r() * (H.area[1] - H.area[0]));
    const rooms = kind === 'room' ? 1 : Math.max(H.rooms[0], Math.min(H.rooms[1], Math.round(area / (kind === 'house' ? 28 : 22))));
    const dist = kind === 'house' ? pick(['Пригород', 'Частный сектор', 'Посёлок у реки', 'Дачный посёлок', 'Окраина']) : pick(D.DISTRICTS);
    const dk = { 'Центр': 1.3, 'Набережная': 1.2, 'У парка': 1.1, 'Новостройки': 1.05, 'Старый город': 1.05, 'Спальный район': 0.95, 'У вокзала': 0.9, 'Окраина': 0.82, 'Промзона': 0.75, 'Пригород': 0.85 }[dist] || 1;
    const noise = 0.88 + r() * 0.24;
    let price = Math.round(mk.m2 * H.k * dk * noise * area / 1000) * 1000;
    let rent = Math.round(mk.rm2 * (kind === 'room' ? 1.35 : kind === 'house' ? 0.9 : 1) * (cls === 'rich' ? 1.45 : cls === 'poor' ? 0.85 : 1) * dk * noise * area / (ww ? 1 : 500)) * (ww ? 1 : 500);
    if (ww) { price = Math.round(price / 10) * 10; rent = Math.max(3, Math.round(rent)); }
    let deal = kind === 'room' ? 'rent' : (r() < 0.45 ? 'rent' : r() < 0.6 ? 'both' : 'sale');
    if (ww && kind === 'flat' && cls !== 'poor') deal = r() < 0.5 ? 'order' : 'sale';
    if (ww && kind === 'house') deal = 'sale';
    const floor = kind === 'flat' ? 1 + Math.floor(r() * (cls === 'poor' ? 5 : cls === 'rich' ? 24 : 12)) : 0;
    out.push({ id: `${ci}-${per}-${k}`, city: ci, kind, cls, n: H.n, d: H.d, area, rooms, dist, addr: (kind === 'house' ? 'ул. ' : 'ул. ') + pick(D.STREETS) + ', ' + (1 + Math.floor(r() * 120)), floor, deal, price, rent, happy: H.happy, cityN: E.startName(s, city), photo: Math.floor(r() * 4) });
  }
  return out.sort((a, b) => (a.deal === 'sale' ? a.price / 120 : a.rent) - (b.deal === 'sale' ? b.price / 120 : b.rent));
};
L.homeTitle = h => h.type === 'flat' || h.type === 'house' ? (D.HCLASS[E.EV(E.cur)][h.type] || {})[h.cls] && D.HCLASS[E.EV(E.cur)][h.type][h.cls].n : (D.HOMES[h.type] ? D.HOMES[h.type].n : (h.type === 'room' ? 'Комната' : 'Жильё'));
E.homeName = s => { const h = s.home; if (h.type === 'room' && h.area) return L.HC(s).room.n; return L.homeTitle(h) || 'Жильё'; };
E.homeHappy = s => {
  const h = s.home;
  let v = 0;
  if (h.type === 'flat' || h.type === 'house') v = ((L.HC(s)[h.type] || {})[h.cls] || {}).happy || 5;
  else if (h.type === 'room') v = L.HC(s).room.happy;
  else v = (D.HOMES[h.type] || { happy: 0 }).happy;
  return v + Math.min(12, E.comfort(s) * 0.5) + (h.owned ? 3 : 0);
};
// Аренда/квартплата и коммунальные
E.homeRent = s => {
  const h = s.home;
  if (h.type === 'parents') return E.price(s, 6000);
  if (h.type === 'dorm') return E.price(s, 4500);
  if (h.type === 'street') return 0;
  if (!h.owned && h.rent) return Math.round(h.rent);
  if (!h.owned && D.HOMES[h.type]) return E.price(s, D.HOMES[h.type].rent || 0);
  return 0;
};
E.utilities = s => {
  const h = s.home; if (!h.area || h.type === 'parents' || h.type === 'dorm') return 0;
  if (E.ww2(s)) return h.owned ? Math.round(h.area * 0.15 * E.cpi(s)) : 0;
  return Math.round(h.area * (h.type === 'house' ? 75 : 95) * Math.sqrt(E.city(s).cost) * E.cpi(s) / 100) * 100;
};
L.homeFromOld = s => {
  const h = s.home; if (!h || h.v3) return;
  const map = { own_flat: ['flat', 'mid', 48, true], own_house: ['house', 'mid', 110, true], flat_rent: ['flat', 'mid', 40, false], room: ['room', 'poor', 14, false] };
  const m = map[h.type];
  const furn = h.furn || [];
  if (m) s.home = { v3: 1, type: m[0], cls: m[1], area: m[2], rooms: m[0] === 'house' ? 3 : 1, owned: m[3], value: h.value || 0, rent: m[3] ? 0 : Math.round(L.market(s, s.ch.city).rm2 * m[2] * (m[0] === 'room' ? 1.35 : 1)), furn, city: s.ch.city };
  else s.home = Object.assign({ v3: 1, furn }, h, { furn });
  if (!s.home.furn) s.home.furn = [];
};
L.startHome = s => {
  // стартовое жильё по семье
  const bg = s.ch.bg, age = E.age(s);
  if (age < 18 || bg !== 'rich') { s.home = { v3: 1, type: age >= 25 ? 'room' : 'parents', furn: [] }; if (s.home.type === 'room') { const l = L.listings(s).find(x => x.kind === 'room') || L.listings(s)[0]; s.home = L.fromListing(s, l, false); } }
  else { const l = L.listings(s).find(x => x.kind === 'flat' && x.cls === 'mid' && x.deal !== 'sale') || L.listings(s).find(x => x.kind === 'flat'); s.home = L.fromListing(s, l, false); }
  // родители — базовая мебель
  if (s.home.type === 'parents' || s.home.type === 'room') s.home.furn = s.home.furn || [];
  if (s.home.type !== 'parents') s.home.furn = [{ id: 'bed', tier: 'eco' }, { id: 'table', tier: 'eco' }].concat(E.ww2(s) ? [{ id: 'stove', tier: 'eco' }] : [{ id: 'fridge', tier: 'eco' }, { id: 'stove', tier: 'eco' }]);
};
L.fromListing = (s, l, own) => ({ v3: 1, type: l.kind, cls: l.cls, area: l.area, rooms: l.rooms, owned: !!own, value: own ? l.price : 0, rent: own ? 0 : l.rent, addr: l.addr, dist: l.dist, city: l.city, furn: (s.home && s.home.furn) || [], since: s.date });

// снять / купить / ордер
L.take = (s, id, mode, mortgage) => {
  const ci = +id.split('-')[0];
  const l = L.listings(s, ci).find(x => x.id === id);
  if (!l) return { ok: false, title: 'Объявление устарело', lines: [] };
  const moving = ci !== s.ch.city;
  if (moving && s.job && !s.job.army) { /* переезд — работу придётся искать заново */ }
  const lines = [];
  if (mode === 'rent' || mode === 'order') {
    if (mode === 'order' && !(s.pol || (s.job && s.job.level >= 2) || s.st.rep >= 45)) return { ok: false, title: 'Ордер не дают', lines: ['Отдельные квартиры выделяют по ордеру — нужно быть ценным работником (повышение 2+), начальником или известным человеком.'] };
    const dep = mode === 'order' ? 0 : l.rent; const first = l.rent + dep + (E.ww2(s) ? 0 : Math.round(l.rent * 0.5 / 100) * 100);
    if (s.st.money < first) return { ok: false, title: 'Не хватает денег', lines: ['Нужно сразу ' + E.money(first) + (mode === 'order' ? '' : ' (первый месяц, залог и комиссия)') + '.'] };
    L.leave(s, lines);
    s.st.money -= first;
    s.home = L.fromListing(s, l, false); s.home.deposit = dep;
    lines.push((mode === 'order' ? 'Ордер получен: ' : 'Договор аренды: ') + l.n.toLowerCase() + ', ' + l.area + ' м²', (E.ww2(s) ? 'Квартплата: ' : 'Аренда: ') + E.money(l.rent) + '/мес');
  } else {
    let price = l.price;
    if (mortgage) {
      if (E.ww2(s)) return { ok: false, title: 'Ипотеки нет', lines: ['В 1930-е жильё покупают только за наличные.'] };
      const down = Math.round(price * 0.2), inc = E.monthlyIncome(s);
      const rate = 0.21, months = 240, mrate = rate / 12;
      const monthly = Math.round((price - down) * mrate / (1 - Math.pow(1 + mrate, -months)));
      if (s.st.money < down) return { ok: false, title: 'Нужен первый взнос', lines: ['20% — ' + E.money(down) + '. У вас ' + E.money(s.st.money) + '.'] };
      if (inc < monthly * 1.7) return { ok: false, title: 'Банк отказал', lines: ['Платёж ' + E.money(monthly) + '/мес при доходе ' + E.money(inc) + '/мес.', 'Банк хочет, чтобы платёж был не больше 60% дохода.'] };
      const r = E.roll(s, E.chance(s, 72, 'biz', s.st.rep * 0.1));
      if (!r.ok) return { ok: false, roll: r, title: 'Банк отказал', lines: ['Не прошли скоринг.'] };
      L.leave(s, lines);
      s.st.money -= down; s.loans.push({ n: 'Ипотека', left: monthly * months, monthly, rate });
      lines.push('Ипотека одобрена: взнос ' + E.money(down) + ', платёж ' + E.money(monthly) + '/мес на 20 лет (' + Math.round(rate * 100) + '% годовых)');
    } else {
      if (s.st.money < price) return { ok: false, title: 'Не хватает денег', lines: [l.n + ' стоит ' + E.money(price) + '.'] };
      L.leave(s, lines);
      s.st.money -= price; lines.push('Куплено за ' + E.money(price));
    }
    s.home = L.fromListing(s, l, true);
  }
  if (moving) { const old = E.cityName(s); s.ch.city = ci; s.ch.cityName = ''; if (s.job && !s.job.army) { lines.push('Работу в старом городе пришлось оставить.'); s.job = null; } E.fact(s, `${E.monthStr(s.date)}: переехал из города ${old} в город ${E.cityName(s)}.`); }
  s.flags.recentMove = s.turn;
  E.fact(s, `${E.monthStr(s.date)}: ${mode === 'sale' ? 'купил' : 'снял'} жильё — ${E.homeName(s).toLowerCase()}, ${l.area} м² (${E.cityName(s)}).`);
  E.apply(s, { happy: s.home.owned ? 12 : 5, stress: 6 });
  return { ok: true, title: mode === 'sale' ? 'Новый дом!' : 'Переезд', lines, map: moving };
};
// уходя со старого жилья: своё — сдаём в аренду
L.leave = (s, lines) => {
  const h = s.home;
  if (h.deposit) { s.st.money += h.deposit; lines.push('Залог за старое жильё вернули: ' + E.money(h.deposit)); }
  if (h.owned && h.value) {
    const rentIncome = Math.round(L.market(s, h.city || s.ch.city).rm2 * h.area * 0.9);
    s.props.push({ n: E.homeName(s) + (h.addr ? ', ' + h.addr : ''), value: h.value, rentOut: true, rentIncome, home: JSON.parse(JSON.stringify(h)) });
    lines.push('Своё старое жильё вы сдаёте: +' + E.money(rentIncome) + '/мес');
  }
};
L.sellProp = (s, idx) => {
  const p = s.props[idx]; if (!p) return null;
  const v = Math.round(p.value * (0.95 + Math.random() * 0.1));
  s.props.splice(idx, 1); s.st.money += v;
  E.fact(s, `${E.monthStr(s.date)}: продал недвижимость за ${E.money(v)}.`);
  return { ok: true, title: 'Продано: ' + p.n, lines: ['Выручка: ' + E.money(v)] };
};
L.toParents = s => { const lines = []; L.leave(s, lines); s.home = { v3: 1, type: 'parents', furn: s.home.furn || [] }; return { ok: true, title: 'Переехали к родителям', lines }; };

// ============================================================================
//  МЕБЕЛЬ И ТЕХНИКА
// ============================================================================
L.FURN = s => D.FURN[E.EV(s)];
E.comfort = s => (s.home.furn || []).reduce((a, f) => { const it = L.FURN(s).find(x => x.id === f.id); return a + (it ? it.c * (D.TIER[f.tier] || D.TIER.std).c * (f.broken ? 0.3 : 1) : 0); }, 0);
L.furnPrice = (s, it, tier) => Math.round(it.price * D.TIER[tier].k * E.cpi(s) * E.dif(s).cost * (E.ww2(s) ? 1 : Math.sqrt(E.city(s).cost)));
L.buyFurn = (s, id, tier) => {
  const it = L.FURN(s).find(x => x.id === id); if (!it) return null;
  if (['street'].includes(s.home.type)) return { ok: false, title: 'Некуда ставить', lines: ['Сначала найдите жильё.'] };
  const price = L.furnPrice(s, it, tier);
  if (s.st.money < price) return { ok: false, title: 'Не хватает денег', lines: [it.n + ' (' + D.TIER[tier].n.toLowerCase() + ') — ' + E.money(price)] };
  s.st.money -= price;
  s.home.furn = (s.home.furn || []).filter(f => f.id !== id);
  s.home.furn.push({ id, tier, d: s.date });
  E.apply(s, Object.assign({ happy: Math.max(1, Math.round(it.c * D.TIER[tier].c)) }, it.skill || {}));
  return { ok: true, title: 'Куплено: ' + it.n, lines: [D.TIER[tier].n + ' · ' + E.money(price)] };
};
E.missingWife = s => { const need = L.FURN(s).filter(x => x.wife); return need.find(x => !(s.home.furn || []).some(f => f.id === x.id)) || null; };

// ============================================================================
//  ТРАНСПОРТ
// ============================================================================
L.CARS = s => D.CARS[E.EV(s)];
L.carPrice = (s, c) => Math.round(c.price * E.cpi(s) * E.dif(s).cost);
E.transit = s => s.car && s.car.id !== 'bike' ? 0 : Math.round(D.TRANSIT[E.EV(s)] * Math.pow(E.city(s).cost, 0.7) * E.cpi(s) * (s.car ? 0.5 : 1));
E.carUp = s => s.car ? Math.round(s.car.up * E.cpi(s) * Math.sqrt(E.city(s).cost)) : 0;
L.buyCar = (s, id) => {
  const c = L.CARS(s).find(x => x.id === id); if (!c) return null;
  if (c.need && s.st.rep < c.need && !s.pol) return { ok: false, title: 'Не продадут', lines: ['Машины в 1930-е продают только по разнарядке — нужна репутация ' + c.need + '+ или должность.'] };
  const price = L.carPrice(s, c);
  const trade = s.car ? Math.round(s.car.value * 0.75) : 0;
  if (s.st.money + trade < price) return { ok: false, title: 'Не хватает денег', lines: [c.n + ' — ' + E.money(price) + (trade ? ' (старую машину возьмут за ' + E.money(trade) + ')' : '')] };
  s.st.money += trade - price;
  s.car = { id: c.id, n: c.n, value: price, up: c.up, happy: c.happy, d: s.date };
  E.apply(s, { happy: c.happy, stress: -3 });
  E.fact(s, `${E.monthStr(s.date)}: купил ${c.n}.`);
  return { ok: true, title: 'Ключи у вас: ' + c.n, lines: ['Цена: ' + E.money(price)].concat(trade ? ['Старую сдали в зачёт: ' + E.money(trade)] : []).concat(['Содержание: ~' + E.money(E.carUp(s)) + '/мес']) };
};
L.sellCar = s => { if (!s.car) return null; const v = Math.round(s.car.value * 0.7); const n = s.car.n; s.st.money += v; s.car = null; return { ok: true, title: 'Продали ' + n, lines: ['Выручка: ' + E.money(v)] }; };

// ============================================================================
//  СЕМЬЯ И ДРУЗЬЯ
// ============================================================================
L.initPeople = s => {
  s.kids = s.kids || [];
  if (s.npcs) return;
  const r = L.rng(L.hash(s.ch.name, s.ch.birth));
  const sx = r() < 0.8 ? s.ch.sex : (s.ch.sex === 'm' ? 'f' : 'm');
  const nm = D.NPC_NAMES[sx][Math.floor(r() * D.NPC_NAMES[sx].length)];
  const t = D.NPC_TYPES[0];
  s.npcs = [
    { id: 'friend', name: nm, sex: sx, role: t.role, d: t.d, trait: t.traits[Math.floor(r() * t.traits.length)], age: E.age(s) + Math.floor(r() * 3) - 1, att: 70, alive: true, flags: {}, hist: ['дружите с детства'], married: false, kids: 0, job: E.age(s) >= 18 ? (E.ww2(s) ? 'рабочий на заводе' : 'работает в автосервисе') : 'школьник' },
    { id: 'neighbor', name: E.ww2(s) ? 'Баба Нюра' : 'Тётя Валя', sex: 'f', role: 'соседка', d: D.NPC_TYPES[1].d, trait: D.NPC_TYPES[1].traits[Math.floor(r() * 3)], age: 68, att: 50, alive: true, flags: {}, hist: [], married: false, kids: 2, job: 'пенсионерка' },
  ];
  for (const n of s.npcs) if (!s.rel.some(x => x.name === n.name)) s.rel.push({ name: n.name, role: n.role, att: n.att, npc: n.id });
};
L.npc = (s, id) => (s.npcs || []).find(n => n.id === id);
L.npcSync = s => { for (const n of s.npcs || []) { const r = s.rel.find(x => x.npc === n.id || x.name === n.name); if (r) { if (r.att !== undefined && Math.abs(r.att - n.att) > 0.1) n.att = r.att; r.att = n.att; } } };
// Ежеквартальная встреча с другом
L.npcQuarter = s => {
  L.npcSync(s);
  const alive = (s.npcs || []).filter(n => n.alive && n.id === 'friend' || (n.alive && Math.random() < 0.25));
  if (!alive.length) return null;
  const n = alive[0].id === 'friend' ? alive[0] : E.pick(alive);
  const pool = D.NPC_STORY.concat(E.ww2(s) ? D.NPC_WW2 : []).filter(st => !st.when || st.when(s, n));
  const fresh = pool.filter(st => !(n.flags['st_' + st.id]) || ['borrow', 'fish', 'birthday', 'photos', 'quarrel', 'sport', 'letter'].includes(st.id));
  const st = (E.ww2(s) ? fresh.find(x => ['front', 'letter'].includes(x.id)) : null) || E.pick(fresh.length ? fresh : pool);
  n.flags['st_' + st.id] = 1;
  return { ev: 'npc', npc: n.id, story: st.id, sum: Math.round(E.m(s, 15000) * (1 + Math.random())) };
};
L.npcText = (s, t, e) => { const n = L.npc(s, e.npc); return t.replace(/\{n\}/g, n.name).replace(/\{g\}/g, L.gen(n.name)).replace(/\{sum\}/g, E.money(e.sum)); };
L.npcEvent = (s, e) => {
  const st = D.NPC_STORY.concat(D.NPC_WW2).find(x => x.id === e.story);
  return { id: 'npc', t: L.npcText(s, st.t, e), x: L.npcText(s, st.x, e), npc: e.npc, opts: st.opts.map(o => Object.assign({}, o, { n: L.npcText(s, o.n, e) })) };
};
L.npcResolve = (s, e, oi) => {
  const st = D.NPC_STORY.concat(D.NPC_WW2).find(x => x.id === e.story), o = st.opts[oi], n = L.npc(s, e.npc);
  const conv = fx => { if (!fx) return null; const f = Object.assign({}, fx); if (f.moneyK) { f.money = Math.round(e.sum * f.moneyK); delete f.moneyK; return f; } if (f.money) f.money = Math.round(E.m(s, f.money)); return f; };
  let lines = [], roll = null;
  const fx = conv(o.fx);
  if (fx && fx.do === 'jobtip') { delete fx.do; const j = E.pick(D.JOBS.filter(x => !x.req || !x.req.edu || x.req.edu <= s.ch.edu)); s.job = { id: j.id, title: j.ladder[0], org: '', salary: E.salary(s, j.sal), level: 0, perf: 55, months: 0, weeks: 0, sk: j.sk, ladder: j.ladder }; lines.push('Вы приняты: ' + j.ladder[0] + ', ' + E.money(s.job.salary) + '/мес'); }
  if (fx) { if (fx.money) s.st.money += fx.money, lines.push('Деньги ' + (fx.money > 0 ? '+' : '') + E.money(fx.money)); delete fx.money; lines = lines.concat(E.apply(s, fx)); }
  if (o.roll) { roll = E.roll(s, E.chance(s, 100 - o.roll.diff, o.roll.sk)); const f2 = conv(roll.ok ? o.ok : o.bad) || {}; if (f2.money) { s.st.money += f2.money; lines.push('Деньги ' + (f2.money > 0 ? '+' : '') + E.money(f2.money)); delete f2.money; } lines = lines.concat(E.apply(s, f2)); }
  if (o.att) { n.att = E.clamp(n.att + o.att, 0, 100); lines.push(n.name + ': отношение ' + (o.att > 0 ? '+' : '') + o.att); }
  if (o.tag) n.hist.push(o.tag + ' (' + E.monthStr(s.date) + ')');
  if (o.clear) delete n.flags[o.clear];
  if (o.life === 'debt') n.flags.debt = 1;
  if (o.life === 'marry') { n.married = true; n.hist.push('женился (' + E.monthStr(s.date) + ')'); }
  if (o.life === 'kid') n.kids++;
  if (o.life === 'job') n.job = E.pick(['механик', 'водитель', 'кладовщик', 'мастер']);
  if (o.life === 'front') { n.flags.front = 1; n.job = 'на фронте'; }
  if (n.hist.length > 20) n.hist.splice(1, 1);
  L.npcSync(s);
  E.logAdd(s, 'event', `${n.name}: ${o.n}`, { lines, ok: roll ? roll.ok : undefined });
  return { lines, roll, ok: roll ? roll.ok : true };
};
// Жизнь друзей сама по себе
L.npcYear = s => {
  for (const n of s.npcs || []) {
    if (!n.alive) continue;
    n.age++;
    if (n.id === 'neighbor' && n.age > 75 && Math.random() < 0.12) { n.alive = false; E.fact(s, `${E.monthStr(s.date)}: умерла соседка ${n.name}.`); s._npcNews = (s._npcNews || []).concat([`Умерла ${n.name}. Весь подъезд пришёл проводить.`]); }
    if (n.id === 'friend' && n.age > 72 && Math.random() < 0.06) { n.alive = false; s._npcNews = (s._npcNews || []).concat([`Не стало ${L.gen(n.name)}. Друга, с которым прошла вся жизнь.`]); E.fact(s, `${E.monthStr(s.date)}: умер друг детства ${n.name}.`); E.apply(s, { happy: -20, stress: 20 }); }
  }
};
L.npcFront = s => {
  for (const n of s.npcs || []) if (n.alive && n.flags.front) {
    const atWar = s.world.wars.some(w => w.a === s.world.home || w.b === s.world.home);
    if (!atWar) { n.flags.front = 0; n.job = 'вернулся с фронта'; n.hist.push('вернулся с войны (' + E.monthStr(s.date) + ')'); s._npcNews = (s._npcNews || []).concat([`${n.name} вернулся с фронта! Живой.`]); continue; }
    if (Math.random() < 0.012 * E.dif(s).death) { n.alive = false; s._npcNews = (s._npcNews || []).concat([`Похоронка: ${n.name} погиб на фронте.`]); E.fact(s, `${E.monthStr(s.date)}: на фронте погиб друг ${n.name}.`); E.apply(s, { happy: -25, stress: 25 }); }
  }
};
// семья: дети и супруг
L.kidAge = (s, k) => Math.floor((new Date(s.date) - new Date(k.birth)) / 3.156e10);
L.kidCost = s => (s.kids || []).reduce((a, k) => { const age = L.kidAge(s, k); return a + (age >= 18 ? 0 : E.price(s, age < 3 ? 14000 : age < 7 ? 16000 : 20000)); }, 0);
L.spouseIncome = s => s.flags.spouseJob && s.rel.some(r => r.role === 'супруг(а)') ? E.salary(s, 42000) : 0;
L.KIDNAMES = { m: ['Артём', 'Миша', 'Ваня', 'Саша', 'Лёва', 'Матвей', 'Дима', 'Егор'], f: ['Аня', 'Соня', 'Маша', 'Вика', 'Алиса', 'Ева', 'Полина', 'Варя'] };
L.KIDNAMES36 = { m: ['Володя', 'Коля', 'Юра', 'Боря', 'Толя', 'Гена', 'Витя', 'Слава'], f: ['Галя', 'Нина', 'Зоя', 'Валя', 'Люба', 'Тамара', 'Рая', 'Лида'] };
L.baby = s => {
  const sex = Math.random() < 0.5 ? 'm' : 'f';
  const name = E.pick((E.ww2(s) ? L.KIDNAMES36 : L.KIDNAMES)[sex]);
  (s.kids = s.kids || []).push({ name, sex, birth: s.date, att: 80 });
  E.fact(s, `${E.monthStr(s.date)}: родился ребёнок — ${name}.`);
  return ['В семье пополнение: ' + (sex === 'm' ? 'сын ' : 'дочь ') + name];
};
L.GADGETS = { modern: [['новый телефон', 35000], ['игровую приставку', 55000], ['ноутбук', 70000], ['электросамокат', 30000], ['наушники', 15000]], ww2: [['велосипед', 400], ['коньки', 40], ['фотоаппарат', 220], ['футбольный мяч', 25], ['часы', 150]] };

// ============================================================================
//  ВАКАНСИИ (HH)
// ============================================================================
L.vacancies = (s, ci, filter) => {
  ci = ci === undefined ? s.ch.city : ci;
  const r = L.rng(L.hash('hh', ci, s.turn, s.era));
  const EM = D.EMPLOYERS[E.EV(s)], city = L.cityStart(ci);
  const out = [];
  const pick = a => a[Math.floor(r() * a.length)];
  const sal = (base, j) => {
    const sm = 1 + (city.sal - 1) * (E.ww2(s) ? 0.3 : 0.65); // как в E.citySal — без «московских» 400 тысяч
    return base * sm * E.k(s) * Math.pow(E.cpi(s), 0.9) * E.dif(s).sal * (j && j.fixed ? 1 / sm : 1);
  };
  const n = 18 + Math.floor(r() * 10);
  for (let k = 0; k < n; k++) {
    const j = pick(D.JOBS);
    const lvl = r() < 0.75 ? 0 : Math.min(j.ladder.length - 1, 1 + Math.floor(r() * 2));
    const base = (j.lsal ? sal(j.lsal[Math.min(lvl, j.lsal.length - 1)], j) : sal(j.sal, j) * Math.pow(1.25, lvl)) * (0.88 + r() * 0.24);
    const round = v => E.ww2(s) ? Math.round(v / 5) * 5 : Math.round(v / 1000) * 1000;
    const exp = lvl === 0 ? (r() < 0.6 ? 0 : 1) : lvl + Math.floor(r() * 3);
    const req = Object.assign({}, j.req || {});
    const comp = E.ww2(s) ? pick(EM.pre) + ' ' + pick(EM.words) : pick(EM.pre) + ' «' + pick(EM.words) + '»';
    out.push({
      id: `${ci}-${s.turn}-${k}`, jid: j.id, lvl, title: j.ladder[lvl], comp, city: ci, cityN: E.startName(s, city),
      sal: round(base), salTo: round(base * (1.08 + r() * 0.17)), exp, req,
      sched: E.ww2(s) ? pick(['полный день', 'сменный график', 'две смены', 'полный день']) : pick(['полный день', 'полный день', 'сменный график', 'удалённо', 'гибкий график', 'вахта']),
      perks: [pick(EM.perks), pick(EM.perks)].filter((v, i, a) => a.indexOf(v) === i),
      hot: r() < 0.15,
    });
  }
  return out;
};
L.hhInit = s => { if (!s.hh) s.hh = { resume: { title: '', about: '', salary: 0 }, apps: [], career: [] }; };
L.expYears = s => { L.hhInit(s); const w = (s.hh.career || []).reduce((a, c) => a + (c.weeks || 0), 0) + (s.job ? s.job.weeks || 0 : 0); return Math.floor(w / 52); };
L.match = (s, v) => {
  const issues = [];
  if (v.req.edu && s.ch.edu < v.req.edu) issues.push('образование: нужно ' + D.EDU[v.req.edu]);
  if (v.req.age && E.age(s) < v.req.age) issues.push('возраст от ' + v.req.age);
  for (const k of Object.keys(D.SKILLS)) if (v.req[k] && E.sk(s, k) < v.req[k] - 10) issues.push(D.SKILLS[k].toLowerCase() + ' от ' + v.req[k]);
  const exp = L.expYears(s);
  if (v.exp > exp) issues.push('опыт от ' + E.years(v.exp));
  return issues;
};
L.apply = (s, vid) => {
  L.hhInit(s);
  if (s.hh.apps.some(a => a.v.id === vid)) return { ok: false, title: 'Вы уже откликнулись' };
  const week = s.hh.apps.filter(a => a.turn === s.turn).length;
  if (week >= 6) return { ok: false, title: 'Хватит на этой неделе', lines: ['За неделю — не больше 6 откликов.'] };
  const ci = +vid.split('-')[0];
  const v = L.vacancies(s, ci).find(x => x.id === vid); if (!v) return { ok: false, title: 'Вакансия закрыта' };
  s.hh.apps.push({ v, turn: s.turn, st: 'sent' });
  return { ok: true, title: 'Отклик отправлен', lines: [v.title + ' — ' + v.comp, 'Ответ придёт в течение недели.'] };
};
// раз в неделю работодатели отвечают
L.hhWeek = s => {
  L.hhInit(s);
  const out = [];
  for (const a of s.hh.apps) {
    if (a.st !== 'sent' || a.turn >= s.turn) continue;
    const issues = L.match(s, a.v);
    const want = s.hh.resume.salary || 0;
    let ch = 62 - issues.length * 22 + (E.sk(s, 'cha') - 40) * 0.3 + s.st.rep * 0.1 + (s.hh.resume.about && s.hh.resume.about.length > 40 ? 6 : 0) + (s.hh.resume.title ? 4 : 0) - (want > a.v.salTo ? 25 : want > a.v.sal ? 8 : 0) + E.dif(s).chance;
    if (a.v.hot) ch += 10;
    a.st = Math.random() * 100 < ch ? 'invite' : 'reject';
    out.push(a.st === 'invite' ? `Приглашение на собеседование: ${a.v.title} (${a.v.comp})` : `Отказ: ${a.v.title} (${a.v.comp})`);
  }
  // старые отклики уходят
  s.hh.apps = s.hh.apps.filter(a => s.turn - a.turn < 8 || a.st === 'invite');
  return out;
};
L.interview = (s, vid) => {
  const a = s.hh.apps.find(x => x.v.id === vid && x.st === 'invite'); if (!a) return null;
  if (s.ap <= 0) return { ok: false, blocked: true, title: 'На этой неделе сил больше нет', lines: ['Собеседование — одно действие.'] };
  s.ap--;
  const v = a.v, j = D.JOBS.find(x => x.id === v.jid);
  const r = E.roll(s, E.chance(s, 64 - v.lvl * 6, j ? j.sk : 'cha', (E.sk(s, 'cha') - 40) * 0.25));
  if (!r.ok) { a.st = 'reject'; return { ok: false, roll: r, title: 'Собеседование не прошли', lines: ['«Мы вам перезвоним». Не перезвонили.'], fx: { happy: -3 } }; }
  a.st = 'offer';
  const salary = Math.round((s.hh.resume.salary && s.hh.resume.salary <= v.salTo ? Math.max(v.sal, s.hh.resume.salary) : v.sal) * (r.crit ? 1.08 : 1));
  if (s.job) L.careerAdd(s);
  if (v.city !== s.ch.city) { s.ch.city = v.city; s.ch.cityName = ''; }
  s.job = { id: j ? j.id : 'custom', title: v.title, org: v.comp, salary, level: v.lvl, perf: 50, months: 0, weeks: 0, sk: j ? j.sk : 'cha', ladder: j ? j.ladder : [v.title], risky: j && j.risky, army: !!(j && j.army) };
  E.fact(s, `С ${E.monthGen(s.date)} работает: ${v.title} (${v.comp}), ${E.money(salary)}/мес.`);
  return { ok: true, roll: r, crit: r.crit, title: 'Вас взяли!', lines: [v.title + ' — ' + v.comp, 'Зарплата: ' + E.money(salary) + '/мес'], fx: { happy: 8, stress: 4 } };
};
L.careerAdd = s => { L.hhInit(s); if (s.job) s.hh.career.push({ title: s.job.title, org: s.job.org || '', weeks: s.job.weeks || 0, end: s.date }); if (s.hh.career.length > 12) s.hh.career.shift(); };

// ============================================================================
//  КРИМИНАЛ
// ============================================================================
L.crimeInit = s => {
  if (s.crime && s.crime.comp && s.crime.city === s.ch.city) return s.crime;
  const r = L.rng(L.hash('gangs', s.ch.city, s.era));
  const names = D.GANG_NAMES.slice().sort(() => r() - 0.5).slice(0, 4);
  const terr = names.map(() => 10 + r() * 30); const tot = terr.reduce((a, b) => a + b, 0) / 85;
  const comp = names.map((n, i) => ({ n, size: Math.round(8 + r() * 60), inc: Math.round(E.m(s, 300000 + r() * 2500000)), terr: Math.round(terr[i] / tot), aggr: Math.round(20 + r() * 70), cops: Math.round(10 + r() * 70), leader: E.pick(['Кабан', 'Седой', 'Лысый', 'Француз', 'Монгол', 'Профессор', 'Чёрный', 'Ржавый', 'Студент', 'Батя']) }));
  s.crime = Object.assign({ on: false, gang: null, rank: 0, cred: 0, heat: 0, income: 0, total: 0, hist: [], acts: 0, bribe: 0 }, s.crime || {}, { comp, city: s.ch.city, corr: Math.round((E.ww2(s) ? 12 : 35) + r() * (E.ww2(s) ? 15 : 35)) });
  return s.crime;
};
L.wanted = s => Math.min(5, Math.floor((s.crime ? s.crime.heat : 0) / 20));
E.A.crime = (s, it) => {
  const C = L.crimeInit(s);
  const t = E.norm([it.target, it.raw].join(' '));
  let a = D.CRIME_ACTS.find(x => x.kw.some(k => t.includes(k))) || D.CRIME_ACTS.find(x => x.id === (/взлом|угн/.test(t) ? 'rob' : 'fraud'));
  if (a.gang && !C.gang) return { ok: false, impossible: true, apCost: 0, title: 'Нужна банда', lines: ['Для этого нужно быть в банде. Напишите: «вступаю в банду».'] };
  const lines = [];
  if (a.id === 'join') {
    if (C.gang) return { ok: false, impossible: true, apCost: 0, title: 'Вы уже в банде', lines: ['«' + C.gang + '», ' + D.CRIME_RANKS[C.rank].toLowerCase()] };
    const g = C.comp.slice().sort((x, y) => y.terr - x.terr)[Math.floor(Math.random() * 2)];
    const r = E.roll(s, E.chance(s, 60, 'str', (E.sk(s, 'cha') - 40) * 0.2));
    if (!r.ok) return { ok: false, roll: r, title: 'Не взяли', lines: ['«Ты кто такой? Иди отсюда».'], fx: { happy: -3 } };
    C.on = true; C.gang = g.n; C.rank = 0; C.cred = 5; g.size++;
    C.hist.push(E.monthStr(s.date) + ': принят в «' + g.n + '»');
    return { ok: true, roll: r, title: 'Вы в банде «' + g.n + '»', lines: ['Главный — ' + g.leader + '.', 'Пока вы шестёрка. Доверие придётся заслужить.'], fx: { stress: 8 }, factAdd: `${E.monthStr(s.date)}: связался с криминалом — банда «${g.n}».` };
  }
  if (a.id === 'quit') {
    if (!C.on) return { ok: false, impossible: true, apCost: 0, title: 'Вы и так чисты', lines: [] };
    const r = E.roll(s, E.chance(s, 45 - C.rank * 6, 'cha'));
    const fx = r.ok ? { happy: 8, stress: -15 } : { health: -15, stress: 20 };
    C.on = false; C.gang = null; C.rank = 0; C.cred = 0;
    C.hist.push(E.monthStr(s.date) + ': завязал' + (r.ok ? '' : ' (с последствиями)'));
    return { ok: true, roll: r, title: r.ok ? 'Завязали' : 'Завязали, но проводили «по-своему»', lines: [r.ok ? 'Отпустили по-хорошему.' : 'Без больницы не обошлось.'], fx };
  }
  if (a.id === 'bribe') {
    const cost = Math.round(E.m(s, 40000) * (1 + L.wanted(s)) * (1.4 - C.corr / 100));
    if (s.st.money < cost) return { ok: false, impossible: true, apCost: 0, title: 'Нечем занести', lines: ['Нужно около ' + E.money(cost) + '.'] };
    const r = E.roll(s, E.chance(s, C.corr + 25, 'cha'));
    s.st.money -= cost;
    if (!r.ok) { C.heat = E.clamp(C.heat + 15, 0, 100); return { ok: false, roll: r, title: 'Взятку не взяли', lines: ['Деньги взяли, а дело — нет. ' + E.money(cost) + ' в никуда.'], fx: { stress: 12 } }; }
    C.heat = E.clamp(C.heat - 30, 0, 100); C.bribe = E.clamp(C.bribe + 20, 0, 100);
    return { ok: true, roll: r, title: 'Вопрос решён', lines: ['Отдали ' + E.money(cost) + '. Розыск ослаб.'], fx: { stress: -6 } };
  }
  if (a.id === 'lay') { C.heat = E.clamp(C.heat - 15, 0, 100); return { ok: true, title: 'Залегли на дно', lines: ['Розыск: ' + '★'.repeat(L.wanted(s)) + '☆'.repeat(5 - L.wanted(s))], fx: { stress: -5, happy: -2 } }; }
  // дело
  const DF = { 'легко': 75, 'средне': 55, 'сложно': 38 }[a.diff] || 55;
  const r = E.roll(s, E.chance(s, DF + C.rank * 4 + (C.gang ? 5 : 0), a.id === 'fraud' ? 'int' : a.id === 'rob' || a.id === 'war' ? 'str' : 'cha'));
  C.acts++;
  if (r.ok) {
    const gain = Math.round(E.m(s, 30000) * a.gain * (1 + C.rank * 0.5) * E.rnd(0.6, 1.5) * (r.crit ? 1.6 : 1));
    C.heat = E.clamp(C.heat + a.heat, 0, 100); C.cred = E.clamp(C.cred + 4 + (a.gain > 1.5 ? 4 : 0), 0, 100); C.on = true;
    C.total += gain; C.income += gain;
    if (a.id === 'war') { const g = E.pick(C.comp.filter(x => x.n !== C.gang)); const my = C.comp.find(x => x.n === C.gang); if (g && my) { const d = Math.min(g.terr, E.ri(2, 6)); g.terr -= d; my.terr += d; lines.push('«' + g.n + '» отдали ' + d + '% территории'); } }
    L.rankUp(s, lines);
    C.hist.push(E.monthStr(s.date) + ': ' + a.n.toLowerCase() + ' — успех, ' + E.money(gain));
    return { ok: true, roll: r, crit: r.crit, title: a.n + ': получилось', lines: ['Добыча: ' + E.money(gain), 'Розыск: ' + '★'.repeat(L.wanted(s)) + '☆'.repeat(5 - L.wanted(s))].concat(lines), fx: { money: gain, stress: 8, rep: -1 } };
  }
  C.heat = E.clamp(C.heat + a.heat * 1.4, 0, 100);
  C.hist.push(E.monthStr(s.date) + ': ' + a.n.toLowerCase() + ' — провал');
  const caught = Math.random() < 0.18 + L.wanted(s) * 0.08 - C.bribe / 400;
  if (caught) { s._arrest = true; return { ok: false, roll: r, title: 'Повязали!', lines: ['Вас задержали на месте.'], fx: { stress: 25 }, caught: true }; }
  return { ok: false, roll: r, title: a.n + ': сорвалось', lines: ['Еле ушли. Вас ищут активнее.'], fx: { stress: 12, health: a.id === 'rob' || a.id === 'war' ? -6 : 0 } };
};
L.rankUp = (s, lines) => { const C = s.crime; if (!C.gang) return; const need = [15, 32, 52, 72, 90]; while (C.rank < 5 && C.cred >= need[C.rank]) { C.rank++; lines.push('Вас повысили: ' + D.CRIME_RANKS[C.rank]); } };
L.crimeMonth = (s, rep) => {
  const C = s.crime; if (!C) return;
  if (C.gang) {
    const g = C.comp.find(x => x.n === C.gang);
    const share = Math.round((g ? g.inc : E.m(s, 500000)) * (0.02 + C.rank * 0.035));
    s.st.money += share; C.income = share; C.total += share;
    if (rep && rep.monthly) rep.monthly.inc.push(['Доля в общаке «' + C.gang + '»', share]);
    C.heat = E.clamp(C.heat + 2 - C.bribe / 40, 0, 100);
  } else C.income = 0;
  C.heat = E.clamp(C.heat - 4, 0, 100); C.bribe = E.clamp(C.bribe - 5, 0, 100);
  // конкуренты живут своей жизнью
  for (const g of C.comp) { g.size = Math.max(3, Math.round(g.size * E.rnd(0.95, 1.07))); g.inc = Math.round(g.inc * E.rnd(0.9, 1.12)); }
  if (Math.random() < 0.15) { const a = E.pick(C.comp), b = E.pick(C.comp.filter(x => x !== a)); const d = Math.min(b.terr, E.ri(1, 5)); b.terr -= d; a.terr += d; (s._cityNews = s._cityNews || []).push(`Разборка: «${a.n}» потеснили «${b.n}» на рынке у вокзала.`); }
  // облава
  if (C.on && Math.random() < L.wanted(s) * 0.05 * E.dif(s).bad * (1 - C.bribe / 150)) s._arrest = true;
};
// задержание — особое событие
E.SPECIAL.arrest = { id: 'arrest', t: 'Задержание', x: 'Наручники, автозак, допрос до утра. Следователь листает толстую папку: «Ну что, будем сотрудничать?»', opts: [
  { n: 'Дать взятку следователю', roll: { sk: 'cha', diff: 50 }, ok: { do: s => { const c = Math.round(E.m(s, 150000) * (1 + L.wanted(s))); s.st.money -= c; s.crime.heat = 30; return ['Отпустили за ' + E.money(c)]; } }, bad: { do: s => L.jail(s, 1.3) } },
  { n: 'Нанять адвоката', roll: { sk: 'int', diff: 45 }, ok: { do: s => { const c = Math.round(E.m(s, 120000)); s.st.money -= c; s.crime.heat = 40; return ['Адвокат развалил дело. Гонорар ' + E.money(c)]; } }, bad: { do: s => L.jail(s, 1) } },
  { n: 'Молчать и сидеть', fx: { do: s => L.jail(s, 0.8) } }] };
L.jail = (s, k) => {
  const months = Math.max(2, Math.round((3 + L.wanted(s) * 5 + (s.crime.rank || 0) * 2) * k * (E.dif(s).bad > 1 ? 1.3 : 1)));
  const d = new Date(s.date); d.setMonth(d.getMonth() + months); s.date = d.toISOString();
  s.job = null; s.crime.heat = 10; s.crime.hist.push(E.monthStr(s.date) + ': отсидел ' + months + ' мес.');
  if (!s.home.owned && s.home.type !== 'parents') { s.home = { v3: 1, type: 'parents', furn: [] }; }
  E.apply(s, { health: -months, happy: -20, rep: -15, stress: 20, str: 2 });
  E.fact(s, `${E.monthStr(s.date)}: вышел на свободу после ${months} мес. заключения.`);
  return ['Срок: ' + months + ' мес. Вы вышли ' + E.dateStr(s.date) + '.', 'Работа и съёмное жильё потеряны.'];
};

// ============================================================================
//  ГАЗЕТЫ
// ============================================================================
L.paperName = (s, kind) => kind === 'world' ? (E.ww2(s) ? 'Международное обозрение' : 'Мир за месяц') : (E.ww2(s) ? 'Рабочий вестник · ' + E.cityName(s) : 'Городские вести · ' + E.cityName(s));
L.cityPaper = (s, rep) => {
  const r = L.rng(L.hash('paper', s.turn, s.ch.city));
  const pick = a => a[Math.floor(r() * a.length)];
  const C = s.world.cs[s.world.home], city = E.cityName(s), ww = E.ww2(s);
  const arts = [];
  const war = s.world.wars.some(w => w.a === s.world.home || w.b === s.world.home);
  // главное
  if (war) arts.push({ h: ww ? 'Всё для фронта, всё для победы!' : 'Город живёт в условиях войны', t: `${city} перестраивается на военный лад: ${ww ? 'заводы переходят на выпуск продукции для фронта, на проходных — плакаты «Родина-мать зовёт!»' : 'усилены меры безопасности, растут цены на импортные товары'}.`, big: 1 });
  const local = ww ? [
    ['Пятилетку — досрочно!', `Завод имени Кирова отрапортовал о перевыполнении плана на ${E.ri(108, 160)}%. Лучшим ударникам вручены премии.`],
    ['Новый трамвайный маршрут', `От вокзала до заводского посёлка пустили трамвай №${E.ri(3, 19)}. Рабочие довольны: дорога сократилась на полчаса.`],
    ['Ударники культурного фронта', 'В рабочем клубе открылся кружок самодеятельности. Записаться можно у культорга.'],
    ['Колхоз «Заря» собрал рекордный урожай', `Средний сбор — ${E.ri(12, 22)} центнеров с гектара. Председатель благодарит трактористов МТС.`],
    ['Бдительность — наше оружие', 'Граждан призывают сообщать о подозрительных лицах в отделение милиции.'],
    ['Открылась новая баня', 'На Заводской улице открылась баня на 200 мест. Цена билета — 20 копеек.'],
    ['Лыжный кросс', `${E.ri(300, 2000)} физкультурников вышли на старт городского лыжного кросса.`],
  ] : [
    ['Ремонт дорог', `Мэрия обещает отремонтировать ${E.ri(12, 80)} километров дорог до конца сезона. Пробки на объездах — уже сейчас.`],
    ['Открылся новый парк', 'В спальном районе открыли парк с велодорожками и площадкой для собак.'],
    ['Тарифы ЖКХ', `С июля коммунальные платежи вырастут на ${E.ri(8, 12)}%. Чиновники говорят — «в пределах инфляции».`],
    ['Пробки', 'Город снова встал: в часы пик скорость упала до 18 км/ч.'],
    ['Фестиваль на набережной', 'В выходные — фестиваль уличной еды и музыки. Вход свободный.'],
    ['Новая станция', 'Открыт новый остановочный пункт — до центра теперь 20 минут.'],
    ['Вакансии', `Центр занятости: в городе ${E.ri(3, 18)} тысяч открытых вакансий, больше всего ищут водителей, курьеров и медсестёр.`],
    ['Цены на квартиры', `Квадратный метр на вторичке за месяц ${pick(['подорожал', 'подешевел', 'не изменился'])}: средняя цена — ${E.money(L.market(s, s.ch.city).m2)}.`],
  ];
  for (let k = 0; k < 3; k++) { const a = local.splice(Math.floor(r() * local.length), 1)[0]; if (a) arts.push({ h: a[0], t: a[1] }); }
  // экономика страны
  const g = C.h.gdp, ch = g.length > 12 ? (g[g.length - 1] / g[g.length - 13] - 1) * 100 : 0;
  arts.push({ h: ww ? 'Хозяйство страны' : 'Экономика', t: `${C.n}: ${ch >= 0 ? 'рост' : 'спад'} экономики за год — ${L.num(Math.abs(ch))}%, инфляция ${L.num(C.st.infl)}%, безработица ${L.num(C.st.unemp)}%.` });
  // криминальная хроника
  for (const t of (s._cityNews || []).splice(0)) arts.push({ h: 'Происшествия', t });
  if (s.crime && s.crime.on && L.wanted(s) >= 2) arts.push({ h: 'Криминальная хроника', t: `Полиция разыскивает участников серии дерзких преступлений. Приметы подозреваемого публикуются на стендах «Их разыскивает ${ww ? 'милиция' : 'полиция'}».` });
  // о вас
  if (s.st.rep >= 45 || s.pol) arts.push({ h: 'Люди нашего города', t: `${s.ch.name} ${s.ch.surname} — ${E.position(s).toLowerCase()}. ${s.st.rep >= 70 ? 'Горожане называют его одним из самых влиятельных людей города.' : 'Имя всё чаще звучит в разговорах.'}` });
  for (const b of s.biz || []) if (b.lastProfit !== undefined && Math.random() < 0.3) arts.push({ h: 'Бизнес', t: `«${b.n}» ${b.lastProfit > 0 ? 'расширяется и набирает сотрудников' : 'переживает непростые времена'}.` });
  for (const t of (s._npcNews || []).splice(0)) arts.push({ h: 'Из жизни соседей', t });
  // погода и объявления
  const m = new Date(s.date).getMonth(), lat = E.city(s).y;
  const temp = Math.round(6 - 13 * Math.cos(m / 12 * 2 * Math.PI) + (r() * 6 - 3) - (lat > 400 ? 5 : 0));
  arts.push({ h: 'Погода', t: `${city}: на неделе ${temp > 0 ? '+' : ''}${temp}°, ${pick(['ясно', 'облачно', 'дожди', temp < 0 ? 'снег' : 'ветрено', 'переменная облачность'])}.`, small: 1 });
  arts.push({ h: 'Объявления', t: ww ? pick(['Продаётся патефон с пластинками. Спросить Зою, кв. 5.', 'Меняю комнату 14 м² на две поменьше.', 'Требуются грузчики на товарную станцию.', 'Утерян профсоюзный билет. Нашедшего просят вернуть.']) : pick(['Сдам однушку у метро, без животных.', 'Отдам котят в добрые руки.', 'Ремонт квартир под ключ, недорого.', 'Куплю старые монеты и значки.', 'Ищу попутчиков до моря на машине.']), small: 1 });
  return { kind: 'city', d: s.date, name: L.paperName(s, 'city'), no: s.turn, arts };
};
L.worldPaper = (s) => {
  const W = s.world, al = E.alive(s);
  const since = new Date(s.date); since.setMonth(since.getMonth() - 1);
  const news = W.news.filter(n => new Date(n.d) >= since);
  const arts = [];
  const top = news.filter(n => n.imp >= 2);
  if (top.length) arts.push({ h: top[0].t.split(':')[0].slice(0, 60), t: top[0].t, big: 1 });
  const ch = i => { const g = W.cs[i].h.gdp; return g.length > 2 ? g[g.length - 1] / g[g.length - 2] - 1 : 0; };
  const big = al.filter(i => W.cs[i].st.gdp > (E.ww2(s) ? 20 : 200));
  if (big.length > 3) {
    const sorted = big.slice().sort((a, b) => ch(b) - ch(a));
    arts.push({ h: 'Экономика мира', t: `Лидер роста за месяц — ${W.cs[sorted[0]].n} (+${L.num(ch(sorted[0]) * 100, 2)}%), хуже всех — ${W.cs[sorted[sorted.length - 1]].n} (${L.num(ch(sorted[sorted.length - 1]) * 100, 2)}%).` });
  }
  if (W.wars.length) arts.push({ h: 'Войны', t: 'Идут бои: ' + W.wars.slice(0, 6).map(w => `${W.cs[w.a].n} — ${W.cs[w.b].n}`).join('; ') + (W.wars.length > 6 ? ` и ещё ${W.wars.length - 6}` : '') + '.' });
  for (const n of news.filter(n => n.imp >= 1).slice(-7)) arts.push({ h: n.kind === 'elect' ? 'Выборы' : n.kind === 'crisis' ? 'Кризис' : n.kind === 'war' ? 'Война' : n.kind === 'res' ? 'Ресурсы' : 'В мире', t: n.t });
  const short = news.filter(n => n.kind === 'res');
  if (!short.length && Math.random() < 0.5) arts.push({ h: 'Рынки', t: E.ww2(s) ? 'Цены на зерно и хлопок на мировых биржах стабильны.' : 'Нефть, золото и зерно торгуются без резких движений.', small: 1 });
  const H = W.cs[W.home];
  arts.push({ h: H.n + ': итоги месяца', t: `ВВП ${L.gdp(H.st.gdp)}, стабильность ${Math.round(H.st.stab)}%, армия ${Math.round(H.st.army).toLocaleString('ru-RU')} тыс. человек.` });
  return { kind: 'world', d: s.date, name: L.paperName(s, 'world'), no: W.month, arts };
};
L.addPaper = (s, p) => { (s.papers = s.papers || []).push(p); if (s.papers.length > 24) s.papers.shift(); s.unread = (s.unread || 0) + 1; };

// ============================================================================
//  ИНИЦИАЛИЗАЦИЯ И МИГРАЦИЯ
// ============================================================================
L.init = s => {
  s.open = s.open || []; s.chron = s.chron || [];
  L.homeFromOld(s);
  if (!s.home.furn) s.home.furn = [];
  L.initPeople(s);
  L.hhInit(s);
  if (!s.papers) s.papers = [];
  if (s.car === undefined) { s.car = null; const old = s.items.find(i => /машин|мотоцикл/i.test(i.n)); if (old) { s.car = { id: 'old', n: old.n, value: old.value, up: old.upkeep || 6000, happy: 8 }; s.items.splice(s.items.indexOf(old), 1); } }
  if (!s.v3) { s.v3 = 1; }
};
