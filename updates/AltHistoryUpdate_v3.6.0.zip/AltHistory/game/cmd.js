// AltHistory — служба в армии: чем выше звание, тем больше подразделение под вашим командованием.
// Сержант — отделение, лейтенант — взвод, капитан — рота, майор — батальон, полковник — полк,
// генералы — дивизии на карте (можно водить их сами, как глава государства, но только свои).
'use strict';
const CMD = {};
(() => {
  const cl = (v, a, b) => Math.max(a, Math.min(b, v));
  const nrm = t => E.norm(t || '');
  const fail = (title, lines) => ({ ok: false, impossible: true, title, lines: lines || [], apCost: 0 });
  CMD.UNITS = [
    { n: 'нет (служите в отделении)', men: 0 }, { n: 'Отделение', men: 10 }, { n: 'Взвод', men: 30 }, { n: 'Рота', men: 100 },
    { n: 'Батальон', men: 450 }, { n: 'Полк', men: 1800 }, { n: 'Дивизия', men: 10000, divs: 1 }, { n: 'Корпус', men: 30000, divs: 3 }, { n: 'Армия', men: 90000, divs: 6 },
  ];
  CMD.GEN = ['Генерал-майор', 'Генерал-лейтенант', 'Генерал армии'];
  CMD.on = s => !!(s.job && (s.job.army || s.job.id === 'army' || s.job.id === 'pilot'));
  CMD.lvl = s => { if (!CMD.on(s)) return 0; const L0 = s.job.level || 0; const lad = s.job.ladder || []; const t = lad[L0] || ''; const gi = CMD.GEN.indexOf(t); return gi >= 0 ? 6 + gi : Math.min(5, L0 + (/комбриг/i.test(t) ? 1 : 0)); };
  CMD.get = s => {
    if (!CMD.on(s)) return null;
    // генеральские звания — продолжение лестницы
    const lad = s.job.ladder; if (lad && !lad.some(x => /генерал/i.test(x))) lad.push(...CMD.GEN);
    const lv = CMD.lvl(s), U0 = CMD.UNITS[lv];
    const c = s.cmd || (s.cmd = { men: 0, mor: 60, train: 30, eq: 30, xp: 0, medals: 0, divs: [], name: '' });
    if (c.lv !== lv) { c.lv = lv; c.men = U0.men; c.name = U0.men ? (E.ri(1, 99) + '-' + (lv >= 6 ? 'я ' : 'й ') + U0.n.toLowerCase()) : ''; c.divs = []; }
    return c;
  };
  CMD.power = c => Math.round(c.men * (0.5 + c.train / 200) * (0.5 + c.mor / 200) * (0.6 + c.eq / 160));
  E.ACTIONS.push('command');
  E.A.command = (s, it) => {
    const c = CMD.get(s); if (!c) return fail('Вы не военный', ['Командовать можно, служа в армии: «иду служить по контракту» (или в военкомат).']);
    const t = nrm([it.target, it.raw].join(' ')), lv = CMD.lvl(s), H = s.world.cs[s.world.home];
    if (!lv) return fail('Пока вы рядовой', ['Подразделение дают с сержанта. Служите хорошо и просите повышения: «прошу повышения».']);
    const war = WD.enemies(s, s.world.home).length > 0, j = s.job;
    if (/в бой|в атаку|наступ|штурм|атаков|воева|на фронт|в рейд/.test(t)) {
      if (!war) return fail('Войны нет', ['В мирное время — учения, смотры и забота о бойцах. Боевой опыт будет, когда страна воюет.']);
      if (lv >= 6) return CMD.ui();
      const ch = cl(Math.round(35 + c.train / 3 + c.mor / 5 + c.eq / 6 + E.sk(s, 'str') / 8 + E.sk(s, 'int') / 10), 10, 90);
      const r = E.roll(s, ch); const loss = Math.round(c.men * (r.ok ? E.rnd(0.02, 0.08) : E.rnd(0.08, 0.2)));
      c.men = Math.max(1, c.men - loss); c.xp += r.ok ? 3 : 1; c.mor = cl(c.mor + (r.ok ? 6 : -10), 0, 100);
      j.perf = cl(j.perf + (r.ok ? 20 : -5), 0, 100);
      let med = ''; if (r.crit || (r.ok && Math.random() < 0.15)) { c.medals++; med = 'Награда: ' + E.pick(E.ww2(s) ? ['медаль «За отвагу»', 'орден Красной Звезды', 'орден Красного Знамени'] : ['медаль «За отвагу»', 'орден Мужества', 'медаль Суворова']); }
      const hurt = !r.ok && Math.random() < 0.3;
      return { ok: r.ok, roll: r, crit: r.crit, title: r.ok ? CMD.UNITS[lv].n + ' выполнил(а) задачу' : 'Бой тяжёлый, задача не выполнена', lines: ['Шанс был ' + ch + '%. Потери: ' + loss + ' чел. (осталось ' + c.men + ')', 'Боевой опыт подразделения: ' + c.xp].concat(med ? [med] : []).concat(hurt ? ['Вы ранены.'] : []), fx: Object.assign({ stress: 15, rep: r.ok ? 3 + (med ? 3 : 0) : 0 }, hurt ? { health: -E.ri(8, 20) } : {}), apCost: 1 };
    }
    if (/снаряж|оружи|техник|бронетехн|танк|боеприп|экипир|выбить|запрос/.test(t)) {
      const r = E.roll(s, cl(Math.round(40 + s.st.infl / 3 + E.sk(s, 'cha') / 4 + j.perf / 6), 10, 88));
      if (r.ok) c.eq = cl(c.eq + E.ri(10, 20), 0, 100);
      return { ok: r.ok, roll: r, title: r.ok ? 'Снабжение выбито' : 'Снабжение не дали', lines: ['Оснащение: ' + Math.round(c.eq) + '/100'], fx: { stress: 3 }, apCost: 1 };
    }
    if (/забот|отпуск|паек|паёк|баня|морал|дух|письм|увольнител|кормеж|кормёж|быт/.test(t)) {
      c.mor = cl(c.mor + E.ri(8, 14), 0, 100); j.perf = cl(j.perf + 4, 0, 100);
      return { ok: true, title: 'Забота о бойцах', lines: ['Боевой дух: ' + Math.round(c.mor) + '/100'], fx: { happy: 2, rep: 1 }, apCost: 1 };
    }
    if (/пополн|набрать|призыв|людей/.test(t)) {
      const max = CMD.UNITS[lv].men; if (c.men >= max) return fail('Подразделение укомплектовано', [c.men + '/' + max + ' чел.']);
      const add = Math.min(max - c.men, Math.round(max * E.rnd(0.1, 0.3))); c.men += add; c.train = cl(c.train - 5, 0, 100);
      return { ok: true, title: 'Пополнение', lines: ['+' + add + ' человек (' + c.men + '/' + max + '). Новичков нужно учить.'], apCost: 1 };
    }
    // учения / строевая / смотр — по умолчанию
    const r = E.roll(s, cl(Math.round(55 + E.sk(s, 'str') / 6 + E.sk(s, 'int') / 8 + c.eq / 10), 15, 92));
    const add = r.ok ? E.ri(6, 12) * (r.crit ? 2 : 1) : E.ri(1, 3);
    c.train = cl(c.train + add, 0, 100); j.perf = cl(j.perf + (r.ok ? 10 : 2), 0, 100);
    return { ok: r.ok, roll: r, crit: r.crit, title: r.ok ? 'Учения прошли отлично' : 'Учения так себе', lines: ['Выучка: ' + Math.round(c.train) + '/100', 'Оценка службы: ' + Math.round(j.perf) + '/100 — от неё зависит повышение.'], fx: { stress: 5, str: r.ok ? 1 : 0 }, apCost: 1 };
  };
  // ---------- генералы: свои дивизии на карте ----------
  CMD.take = s => {
    const c = CMD.get(s), lv = CMD.lvl(s), need = CMD.UNITS[lv].divs || 0; if (!need) return;
    if (typeof ARMY === 'undefined') return;
    if (!ARMY.of(s, s.world.home).length) ARMY.op('seed', { c: s.world.home });
    const mine = ARMY.of(s, s.world.home);
    c.divs = c.divs.filter(id => mine.some(d => d.id === id));
    const taken = new Set(); // другие игроки-генералы (в мультиплеере) не учитываем — дивизий обычно хватает
    for (const d of mine) { if (c.divs.length >= need) break; if (!c.divs.includes(d.id) && !taken.has(d.id) && d.train <= 0) c.divs.push(d.id); }
  };
  CMD.ui = () => {
    const s = UI.s, c = CMD.get(s);
    if (!c) { U.big(`${U.head('shield', 'Армия', 'вы не служите')}<div class="repbox"><p>Пойти служить: «иду служить по контракту». С сержанта у вас будет своё подразделение, с генерала — дивизии на карте.</p><div class="repways"><button class="btn" data-cf="Иду служить в армию по контракту">Пойти служить</button></div></div>`); document.querySelectorAll('#modal [data-cf]').forEach(b => b.onclick = () => { UI.closeModal(); UI.fill(b.dataset.cf); }); return; }
    const lv = CMD.lvl(s), U0 = CMD.UNITS[lv], j = s.job, war = WD.enemies(s, s.world.home).length > 0;
    if (U0.divs) CMD.take(s);
    const divs = U0.divs && typeof ARMY !== 'undefined' ? ARMY.of(s, s.world.home).filter(d => c.divs.includes(d.id)) : [];
    const nextT = j.ladder[j.level + 1];
    const btn = (l, cmd, sub, dis) => `<button class="btn small" data-cm="${UI.esc(cmd)}" ${dis ? 'disabled' : ''}>${l}<small>${sub}</small></button>`;
    U.big(`${U.head('shield', j.title + (c.name ? ' · ' + c.name : ''), lv ? 'Под командованием: ' + U0.n.toLowerCase() + (U0.divs ? '' : ', ' + c.men + ' чел.') : 'подразделения пока нет')}
      <div class="repbox">
        ${lv ? `<div class="cgrid"><div class="cbox"><h5>Подразделение</h5><div class="kv"><span>Людей</span><b>${U0.divs ? divs.length + ' дивиз.' : c.men + '/' + U0.men}</b></div><div class="kv"><span>Сила</span><b>${U0.divs ? '—' : CMD.power(c)}</b></div><div class="kv"><span>Награды</span><b>${c.medals}</b></div><div class="kv"><span>Боевой опыт</span><b>${c.xp}</b></div></div>
        <div class="cbox"><h5>Состояние</h5><div class="kv"><span>Выучка</span><b>${Math.round(c.train)}</b></div>${UI.bar(c.train)}<div class="kv"><span>Боевой дух</span><b>${Math.round(c.mor)}</b></div>${UI.bar(c.mor, c.mor < 35 ? 'bad' : 'good')}<div class="kv"><span>Оснащение</span><b>${Math.round(c.eq)}</b></div>${UI.bar(c.eq)}</div>
        <div class="cbox"><h5>Карьера</h5><div class="kv"><span>Оценка службы</span><b>${Math.round(j.perf)}/100</b></div>${UI.bar(j.perf, 'good')}<div class="kv"><span>Месяцев в звании</span><b>${j.months}</b></div><div class="kv"><span>Следующее звание</span><b>${nextT || 'высшее'}</b></div></div></div>` : '<p>Вы рядовой. Отделение дадут с сержанта: служите, а через 3 месяца просите повышения.</p>'}
        ${U0.divs ? `<h4>Ваши дивизии на карте</h4><ul class="news">${divs.map(d => `<li><b>${UI.esc(d.n)}</b> — ${UI.esc(M().provinces[d.p].n)}, численность ${Math.round(d.str)}%, организация ${Math.round(d.org)}% <button class="btn small" data-dv="${d.p}">Показать</button></li>`).join('') || '<li><small>Свободных дивизий нет — они ещё обучаются.</small></li>'}</ul><p class="small">Кликните по значку дивизии на карте, затем по провинции — туда пойдёт. Вражеская — штурм. Управлять можно только своими дивизиями.</p>` : ''}
        ${lv ? `<h4>Приказы</h4><div class="repways">
          ${btn('Учения', 'Провожу учения со своими бойцами', '+выучка, +оценка службы')}
          ${btn('Забота о бойцах', 'Забочусь о быте и боевом духе солдат', '+боевой дух')}
          ${btn('Выбить снабжение', 'Запрашиваю новое снаряжение для своих', '+оснащение (харизма, влияние)')}
          ${btn('Пополнение', 'Набираю пополнение в своё подразделение', 'до штата')}
          ${btn('В бой', 'Веду своё подразделение в бой', war ? 'опыт, награды, риск' : 'только во время войны', !war || U0.divs)}
          ${btn('Просить повышения', 'Прошу повышения в звании', 'нужна оценка службы и 3+ мес.')}
        </div>` : `<div class="repways">${btn('Просить повышения', 'Прошу повышения в звании', 'нужно 3+ мес. службы')}</div>`}
      </div>`);
    document.querySelectorAll('#modal [data-cm]').forEach(b => b.onclick = () => { if (UI.busy) return; UI.closeModal(); const t = b.dataset.cm; UI.doIntent({ type: /повышени/.test(t) ? 'promote' : 'command', target: t, raw: t }, t); });
    document.querySelectorAll('#modal [data-dv]').forEach(b => b.onclick = () => { UI.closeModal(); const p = +b.dataset.dv, P = M().provinces[p]; if (MAP.focusOn) MAP.focusOn(P.x, P.y, 500); ARMY.click(p); });
  };
  // карта: генерал видит свои дивизии и может их водить
  document.addEventListener('DOMContentLoaded', () => {
    if (typeof ARMY !== 'undefined') {
      const _my = ARMY.my; ARMY.my = () => { const r = _my(); if (r >= 0) return r; const s = UI.s; return s && s.cmd && s.cmd.divs && s.cmd.divs.length && CMD.on(s) ? s.world.home : -1; };
      const _click = ARMY.click; ARMY.click = p => {
        const s = UI.s; const r = _click(p);
        if (r && ARMY.sel && s && !E.isLeader(s)) { ARMY.sel.ids = ARMY.sel.ids.filter(id => (s.cmd.divs || []).includes(id)); if (!ARMY.sel.ids.length) { ARMY.sel = null; ARMY.draw(); UI.toast('Здесь нет ваших дивизий — командуете только своими', 'bad'); } }
        return r;
      };
    }
    if (typeof U !== 'undefined') {
      const _dock = U.dock; U.dock = () => { const s = UI.s; let h = _dock(); if (s && CMD.on(s)) h += `<button data-dock="unit" title="Моя часть">${UI.ic('shield')}<span>Моя часть</span></button>`; return h; };
      const _bd = U.bindDock; U.bindDock = () => { _bd(); document.querySelectorAll('[data-dock="unit"]').forEach(b => b.onclick = () => CMD.ui()); };
    }
    if (typeof AI !== 'undefined') { AI.SYS_INTERPRET = AI.SYS_INTERPRET.replace('other — всё остальное.', 'command — игрок-военный командует своим подразделением: учения, забота о бойцах, снаряжение, пополнение, вести в бой\nother — всё остальное.'); AI.SCHEMA.properties.type.enum = E.ACTIONS.concat(['chat']); }
  });
  // повышение военного: оценка службы и опыт командования помогают; после полковника — генералы
  const _pro = E.A.promote;
  E.A.promote = (s, it) => {
    if (CMD.on(s)) { CMD.get(s); const c = s.cmd; if (c && c.xp) s.job.perf = cl(s.job.perf + Math.min(15, c.xp), 0, 100); }
    const r = _pro(s, it);
    if (CMD.on(s) && r && r.ok) { const c = CMD.get(s), U0 = CMD.UNITS[CMD.lvl(s)]; r.lines = (r.lines || []).concat([U0.men ? 'Теперь под вашим командованием: ' + U0.n.toLowerCase() + (U0.divs ? ' (' + U0.divs + ' дивиз. на карте)' : ', ' + U0.men + ' чел.') : '', 'Окно «Моя часть» — внизу.']).filter(Boolean); if (U0.divs) CMD.take(s); }
    return r;
  };
})();
